#ifndef PSOTNIC_TOPICS_H
#define PSOTNIC_TOPICS_H 1

const char *topics[] = {
	"Abuse never dies.",
	"Born to abuse.",
	"All your base are belong to us.",
	"Roses are red, violets are blue, and we have just abused you.",
	"Sex is like a card game, if you don't have a good partner, then you better have a good hand.",
	"On the 8th day God created Linux",
	"Gues what? Your channel now belongs to us",
	"Kamikazes do it once",
	"Everyone is a genius.  It's just that some people are too stupid to realize it.",
	"Nothing makes a person more productive than the last minute",
	"What is mind?  No matter. | What is matter?  Never mind.",
	"It doesn't matter whether you win or lose -- until you lose",
	"I think, therefore I am... I think.",
	"Girls are like rocks; you skip the flat ones.",
	"Greetz to all ppl from #pw, #op and #psotnic ;-)",
	NULL
};
#endif
