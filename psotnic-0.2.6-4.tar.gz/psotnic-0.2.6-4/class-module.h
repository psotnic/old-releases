#ifndef PSOTNIC_CLASS_MODULE_H
#define PSOTNIC_CLASS_MODULE_H 1

#include "prots.h"

#endif
