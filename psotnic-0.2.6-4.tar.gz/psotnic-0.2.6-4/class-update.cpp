/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

update::update()
{
	child.fd = parent = 0;
}

/* return values:
	 0 - all ok
	-1 - already updating
	-2 - pipe faild
	-3 - fork faild
*/

int update::forkAndGo(char *site)
{
	//already updating
	if(child.fd)
	{
		net.send(HAS_N, "[*] Already updating", NULL);
		return -1;
	}

	//creating child -> parent pipe
	int tmp[2];

	//pipe faild
	if(pipe(tmp))
	{
		net.send(HAS_N, "[-] pipe() failed: ", strerror(errno), NULL);
		end();
		return -2;
	}
	child.fd = tmp[0];
	parent = tmp[1];

	pid_t dady = getpid();
	pid = fork();

	//error
	if(pid == -1)
	{
		net.send(HAS_N, "[-] fork() failed: ", strerror(errno), NULL);
		end();
		return -3;
	}
	//child
	else if(!pid)
	{
		//pipe
		if(fcntl(parent, F_SETFL, O_NONBLOCK) == -1)
		{
			end();
			exit(2);
		}

		//redirect
		dup2(parent, fileno(stdout));
		dup2(parent, fileno(stderr));

		char psot[MAX_LEN];
		snprintf(psot, MAX_LEN, "./%s -u %s", thisfile, site);
		system(psot);

		kill(dady, SIGUSR1);
		kill(getpid(), 9);
	}
	//parent
	return 0;
}

void update::end()
{
	child.close();
	close(parent);
	if(pid) kill(pid, 9);
	memset(this, 0, sizeof(update));
}

#define SITE	"http://polibuda.info/~grusin/update/0.2.3/"

int update::doUpdate(char *site)
{
	int n;
	char buf[MAX_LEN];
	unsigned char filedigest[16];
	unsigned char wwwdigest[16];
	char targz[256];
	char file[256];
	char arg[2][MAX_LEN];

	http ursynow, mirror;


	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);


	if(!site || !*site)
		site = SITE;

	http::url link(site);
	printf("[*] Connecting to http://%s\n", link.host);

	snprintf(buf, MAX_LEN, "%s?product=%s", site, getFullVersionString());

	if((n = ursynow.get(buf)) > 0)
	{
		str2words(arg[0], ursynow.data, 2, MAX_LEN, 0);
		http::url url(arg[0]);

		if(!url.ok() || !url.file || !match("psotnic*.tar.gz", url.file) || strlen(arg[1]) != 32)
		{
			printf("[-] Invalid response\n");
			return 1;
		}

		quoteHex(arg[1], wwwdigest);

		sprintf(buf, "%s.tar.gz\n", getFullVersionString());

		if(!strcmp(url.file, buf))
		{
			printf("[+] Your psotnic is up2date ;-)\n");
			return 0;
		}


		printf("[+] Fetching %s\n", arg[0]);
		srand();

		MD5CreateAuthString(buf, 16);
		snprintf(targz, 256, "%s.update.tar.gz", buf);

		if((n = mirror.get(arg[0], targz)) > 0)
		{
			printf("[+] Unpacking\n");

			strncpy(file, url.file, strlen(url.file) - 7);
			snprintf(buf, MAX_LEN, "tar -zxf %s %s", targz, file);
			unlink(file);
			system(buf);

			if(MD5HashFile(filedigest, file) != 1)
			{
				printf("[-] Cannot stat %s (%s)\n", file, strerror(errno));
				unlink(targz);
				return 0;
			}
			if(memcmp(wwwdigest, filedigest, 16))
			{
				printf("[-] Md5 sum does not match, file is hacked\n");
				quoteHexStr(filedigest, arg[1], 16);
       			unlink(targz);
				unlink(file);
				return 0;
			}

			printf("[+] Cleaning up\n");
			unlink(targz);
			unlink("psotnic");
			symlink(file, "psotnic");
			printf("[+] Ready to rock'n'roll\n");
			return 1;
		}
		else
		{
			printf("[-] %s (%s)\n", http::error(n), strerror(errno));
		}

	}
	else
	{
		printf("%s\n", ursynow.data);
		printf("[-] %s (%s)\n", http::error(n), strerror(errno));
	}
	return 0;
}

