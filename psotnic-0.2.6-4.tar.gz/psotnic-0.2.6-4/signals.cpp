/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

void sigChild()
{
	int status;
	while(waitpid(-1, &status, WNOHANG) > 0) ;
}

void sigTerm()
{
	signal(SIGTERM, SIG_IGN);
	if(net.irc.fd > 0) net.irc.send("QUIT :", (const char *) config.quitreason, NULL);
	net.send(HAS_N, "[!] Got termination signal", NULL);
	stopPsotnic = 1;
}

void sigInt()
{
	signal(SIGINT, SIG_IGN);
	if(net.irc.fd > 0) net.irc.send("QUIT :", (const char *) config.quitreason, NULL);
	net.send(HAS_N, "[!] Terminated by user", NULL);
	stopPsotnic = 1;
}

void sigHup()
{
	userlist.save(config.userlist_file);
}

void sigSegv()
{
	signal(SIGSEGV, SIG_IGN);
	net.irc.send("QUIT :Segmentation fault, please send core backtrace to pks@irc.pl", NULL);
	net.send(HAS_N, "[!] Segmentation fault", NULL);
}

void safeExit()
{
	net.send(HAS_N, "[*] Abnormal program termination", NULL);
	stopPsotnic = 1;
}

void sigCpuTime()
{
	net.send(HAS_N, "[*] Soft cpu time limit reached, terminating", NULL);
	stopPsotnic = 1;
}

void sigUpdated()
{
	psotget.end();
}

#define register_signal(x, y) \
{	\
	memset(&sv, 0, sizeof(sv)); \
	sv.sa_handler = y;	\
	sigaction(x, &sv, NULL);	\
}

void signalHandling()
{
	struct sigaction sv;

	register_signal(SIGPIPE, SIG_IGN);
	register_signal(SIGCHLD, (sighandler_t) sigChild);
 	register_signal(SIGTERM, (sighandler_t) sigTerm);
	register_signal(SIGINT, (sighandler_t) sigInt);
	register_signal(SIGHUP, (sighandler_t) sigHup);
	register_signal(SIGUSR1, (sighandler_t) sigUpdated);
	register_signal(SIGSEGV, (sighandler_t) sigSegv);
}
