/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

/*
 * Copyright (C) 2002 Josh A. Beam
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "prots.h"
#include "global-var.h"

/* connect to hostname:port via a socks5 proxy; returns file descriptor */
int socks5_connect_to(char *hostname, unsigned short port, char *username, char *password)
{
    int i;
    int fd;
    char buf[515];
    unsigned char len;
    unsigned char atyp;

    if(!socks5.host)
        return -1;

    fd = doConnect(socks5.host, socks5.port, "", 0);
    if(fd < 1)
    {
        net.send(OWNERS, "[-] Unable to connect to SOCKS5 server ", socks5.host, ":", itoa(socks5.port), NULL);
        return -1;
    }

    buf[0] = 0x05;
    buf[1] = 0x01;
    if(username && password)
        buf[2] = 0x02;
    else
        buf[2] = 0x00;
    send(fd, buf, 3, 0);
    if(read_byte(fd) != 0x05 || read_byte(fd) != buf[2])
    {
		net.send(OWNERS, "[-] Bad SOCKS5 server response (invalid welcome string?)", NULL);
        killSocket(fd);
        return -1;
    }

    if(username && password)
    {
        unsigned char tmplen;

        buf[0] = 0x01;
        len = (strlen(username) > 255) ? 255 : strlen(username);
        buf[1] = len;
        memcpy(buf + 2, username, len);

        tmplen = (strlen(password) > 255) ? 255 : strlen(password);
        buf[2 + len] = tmplen;
        memcpy(buf + 3 + len, password, tmplen);

        send(fd, buf, (3 + len + tmplen), 0);

        if(read_byte(fd) != 0x01 || read_byte(fd) != 0x00)
        {
            net.send(OWNERS, "[-] SOCKS5 authentication failed", NULL);
            killSocket(fd);
            return -1;
        }
    }
	net.send(OWNERS, "[+] Connected to SOCKS5 server ", socks5.host, ":", itoa(socks5.port), NULL);

    buf[0] = 0x05;
    buf[1] = 0x01;
    buf[2] = 0x00;
    buf[3] = 0x03;
    len = (strlen(hostname) > 255) ? 255 : strlen(hostname);
    buf[4] = (len & 0xff);
    memcpy(buf + 5, hostname, len);
    buf[5 + len] = (port >> 8);
    buf[6 + len] = (port & 0xff);
    send(fd, buf, (7 + len), 0);
    if(read_byte(fd) != 0x05 || read_byte(fd) != 0x00)
    {
		net.send(OWNERS, "[-] Bad SOCKS5 server response (invalid remote addr?)", NULL);
        killSocket(fd);
        return -1;
    }

    read_byte(fd);
    atyp = read_byte(fd);
    if(atyp == 0x01)
    {
        for(i = 0; i < 4; i++)
            read_byte(fd);
    }
    else if(atyp == 0x03)
    {
        len = read_byte(fd);
        for(i = 0; i < len; i++)
            read_byte(fd);
    }
    else
    {
		net.send(OWNERS, "[-] Bad SOCKS5 server response (remote connect failed?)", NULL);
        killSocket(fd);
        return -1;
    }
    for(i = 0; i < 2; i++)
        read_byte(fd);

	net.send(OWNERS, "[+] Connected to remote addr via SOCKS5 proxy", NULL);
    return fd;
}
