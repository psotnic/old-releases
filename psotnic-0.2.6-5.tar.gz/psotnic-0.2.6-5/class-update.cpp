/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"
#include "seed.h"

update::update()
{
	child.fd = parent = 0;
}

bool update::forkAndGo(char *site)
{
	//already updating
	if(child.fd)
	{
		net.send(HAS_N, "[*] Already updating", NULL);
		return false;
	}

	//creating child -> parent pipe
	int tmp[2];

	//pipe faild
	if(pipe(tmp))
	{
		net.send(HAS_N, "[-] pipe() failed: ", strerror(errno), NULL);
		end();
		return false;
	}
	child.fd = tmp[0];
	parent = tmp[1];

	pid = fork();
	
	switch(pid)
	{
		case -1:
			net.send(HAS_N, "[-] fork() failed: ", strerror(errno), NULL);
			end();
			return false;
		
		case 0:
			if(!fcntl(parent, F_SETFL, O_NONBLOCK))
			{
				//redirect
				dup2(parent, fileno(stdout));
				dup2(parent, fileno(stderr));
				if(doUpdate(site))
					kill(SIGUSR1, pid); //that should restart parent;
			}
			_exit(0);
			
		default:
			return true;
	}
}

void update::end()
{
	child.close();
	close(parent);
	memset(this, 0, sizeof(update));
}

bool update::doUpdate(char *site)
{
	int n;
	char buf[MAX_LEN];
	char updir[MAX_LEN], dir[MAX_LEN];

	http php, file;

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

	http::url updateSite(site ? site : "http://polibuda.info/~grusin/update.php");
	printf("[*] Connecting to http://%s\n", updateSite.host);

	//get link to the newest version
	if((n = php.get(updateSite)) > 0)
	{
		http::url link(php.data);
		
		if(link.ok() && match("*.tar.gz", link.file) && strlen(link.file) < MAX_LEN)
		{
			printf("[+] The newest version is: %s, downloading (this may take a while)\n", link.file);
			snprintf(updir, 256, ".update-%d", getpid());
			
			if(mkdir(updir, 0700))
			{
				printf("[-] Cannot create update directory: %s\n", strerror(errno));
				return false;
			}
			 
			if(chdir(updir))
			{
				printf("[-] Cannot change directory to %s: %s\n", updir, strerror(errno));
				return false;
			}	
			
			if((n = file.get(link, link.file)) > 0)
			{
				printf("[+] Unpacking\n");
				
				int len = strlen(link.file) - 7;
				
				strncpy(dir, link.file, len);
				buf[len] = '\0';
				
				snprintf(buf, MAX_LEN, "tar -zxf %s && mv %s/* .", link.file, dir);
				if(system(buf))
					goto dupa;
#ifdef HAVE_ANTIPTRACE				
				if(system("./configure --with-antiptrace"))
#else
				if(system("./configure"))
#endif
					goto dupa;
				
				printf("[+] Restoring seeds (creating seed.h)\n");
				FILE *f = fopen("seed.h", "w+");
				if(!f)
					goto dupa;
				
				fprintf(f, "#ifndef PSOTNIC_SEED_H\n");
				fprintf(f, "#define PSOTNIC_SEED_H 1\n");
				fprintf(f, "static unsigned char cfg_seed[] = \"");
				for(int i=0; i<16; ++i)
					fprintf(f, "\x02%x", cfg_seed[i]);
				fprintf(f, "\";\n");
				fprintf(f, "static unsigned char ul_seed[] = \"");
				for(int i=0; i<16; ++i)
					fprintf(f, "\x02%x", ul_seed[i]);
				fprintf(f, "\";\n");
				fprintf(f, "#endif\n");
				
				if(fclose(f))
					goto dupa;
				
				printf("[*] Compiling (this may take a longer while)\n");
#ifdef HAVE_STATIC
				if(system("make static"))
#elseif HAVE_DEBUG
				if(system("make debug"))
#else
				if(system("make dynamic"))
#endif
					goto dupa;
				
				printf("[*] Copying files\n");
#ifdef HAVE_CYGWIN
				if(rename("bin/psotnic.exe", "../psotnic.exe"))
#else
				if(rename("bin/psotnic", "../psotnic"))
#endif
					goto dupa;
				
				printf("[*] Cleaning up\n");
				if(chdir("..") || rmdirext(updir))
				{
					printf("[-] Failed to remove %s: %s\n", updir, strerror(errno));
					return false;
				}
				
				printf("[+] We are ready to rock'n'roll ;-)\n");
				return true;
			}
			else
			{
				printf("[-] Unable to download file: %s\n", file.error(n));
				dupa:
				printf("[-] Error occured during last operation: %s\n", strerror(errno));
				printf("[*] Cleaning up after a failure\n");
				if(chdir("..") || rmdirext(updir))
					printf("[-] Failed to remove %s: %s\n", updir, strerror(errno));
				return false;
			}
		}
		else
		{
			printf("[-] Invalid response (%s)\n", php.data);
			return false;
		}
	}
	else
	{
		printf("[-] Error occured: %s\n", php.error(n));
		return false;
	}
}
