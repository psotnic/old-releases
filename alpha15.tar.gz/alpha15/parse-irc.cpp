/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_irc(char *data)
{
	char arg[11][MAX_LEN], *a, *b, *c;
	chan *ch;
	CHANUSER *p;
	int i, flags, n;

	if(!strlen(data)) return;

	for (i=0; i < 11; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4], &arg[5], &arg[6], &arg[7], &arg[8], &arg[9], &arg[10]);
	/* debug */
	if(!strcmp(arg[1], "PRIVMSG"))
	{
		ch = ME.FindChannel(arg[2]);
		if(!strcasecmp(arg[3], "!debug"))
		{
			printf("### DEBUG ###\n");
			if(ch) ch->Display();
			printf("CHANNELS: %d\n", ME.channels);
		}
		/*
		else if(!strcasecmp(arg[3], "!cycle"))
		{
			quote(ME.servfd, "PART ", arg[2], " :Cycle time", NULL);
			ME.chanlist[ME.FindChannelInList(arg[2])].joinsent = 0;
			ME.nextjoin = NOW + CYCLE_DELAY;
		}
		*/
		else if(!strcasecmp(arg[3], "!re"))
		{
			ME.RecheckChannels();
		}
	}

	/* reaction */
	if(!strcmp(arg[1], "JOIN"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ch = ME.CreateNewChannel(arg[2]);
			quote(ME.servfd, "WHO ", arg[2], NULL);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch->ptr) return;
			ch->GotJoin(arg[0], 0);
		}
		return;
	}
	if(!strcmp(arg[1], "MODE"))
	{
		ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(!ch->ptr) return;
			a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
			ch->GotMode(arg[3], a, arg[0]);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[1], "KICK"))
	{
		if(!strcasecmp(ME.nick, arg[3]))
		{
			ME.RemoveChannel(arg[2]);
			ME.chanlist[ME.FindChannelInList(arg[2])].joinsent = 0;
			ME.nextjoin = NOW + REJOIN_DELAY;
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch->ptr) return;
			ch->GotKick(arg[3], arg[0]);
		}
		return;
	}
	if(!strcmp(arg[1], "PART"))
	{
		if(!strcasecmp(ME.mask, arg[0])) ME.RemoveChannel(arg[2]);
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch->ptr) return;
			mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
			ch->GotPart(a);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[1], "NICK"))
	{
		ME.GotNickChange(arg[0], arg[2]);
		return;
	}
	if(!strcasecmp(arg[1], "352"))
	{
		ch = ME.FindChannel(arg[3]);
		a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
		p = ch->GotJoin(a, match(arg[8], "*@*"));
		if(!strcasecmp(arg[7], ME.nick))
		{
			ch->ptr = p;
			//if(!(p->flags & HAS_B)) p->flags += HAS_B;
		}
		free(a);
		return;
	}
	if(!strcmp(arg[1], "315"))
	{
		ch = ME.FindChannel(arg[3]);
		//ch->DebugDisplay();
		return;
	}
	if(!strcmp(arg[1], "QUIT"))
	{
		ME.GotUserQuit(arg[0]);
		return;
	}
	if(!strcmp(arg[0], "PING"))
	{
		quote(ME.servfd, "PONG :", arg[1], NULL);
		return;
	}
	if(!strcmp(arg[1], "433") || !strcmp(arg[1], "473") && !(ME.status & STATUS_REGISTERED))
	{
		if(MagicNickCreator(arg[3])) quote(ME.servfd, "NICK ", arg[3], NULL);
		else
		{
			printf("[*] Cannot generate alternative nick for %s\n", arg[3]);
			SafeExit();
		}
		return;
	}
	if(!strcmp(arg[1], "471") || !strcmp(arg[1], "473") || !strcmp(arg[1], "474"))
	{
		ME.chanlist[ME.FindChannelInList(arg[3])].joinsent = 2;
		if(!I_AM_HUB) quote(hub.fd, S_INVITE, " ", arg[3], NULL);
		else quote(FD_BOTS, S_INVITE, " ", arg[3], " ", ME.nick, NULL);
		return;
	}
	if(!strcmp(arg[1], "475"))
	{
		ME.chanlist[ME.FindChannelInList(arg[3])].joinsent = 2;
		if(!I_AM_HUB) quote(hub.fd, S_KEY, " ", arg[3], NULL);
		else quote(FD_BOTS, S_KEY, " ", arg[3], " ", ME.nick, NULL);
		return;
	}
	if(!strcmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
	{
		ME.status += STATUS_REGISTERED;
		maskstrip(arg[9], ME.nick, ME.ident, ME.host);
		mem_strcpy(ME.mask, arg[9]);
		mem_strcpy(ME.servname, arg[0]);
		srand(hash32(ME.nick)*getpid());
		if(hub.fd) quote(hub.fd, S_NEWNICK, " ", ME.nick, NULL);
		return;
	}
	if(!strcmp(arg[1], "INVITE"))
	{
		if((userlist.IsOwner(arg[0]) || userlist.IsBot(arg[0])) && ME.FindChannelInList(arg[3]) != -1)
			quote(ME.servfd, "JOIN ", arg[3], NULL);

		return;
	}
	if(!strcmp(arg[1], "NOTICE") && !strcasecmp(arg[0], ME.servname))
	{
		if(!strcasecmp(arg[6], "invitation"))
		{
			ch = ME.FindChannel(arg[2]);
			if(ch) mem_strncpy(ch->BanOverride, arg[10], strlen(arg[10]) - 1);
		}
		return;
	}
	if(!strcmp(arg[1], "PRIVMSG"))
	{
 		if(arg[3][0] == '\001')
		{
			if(data[strlen(data)-2] != '\001') return;
			data[strlen(data)-2] = '\0';
			for(i=0; i<3; ) if(*data++ == ' ') ++i;
			parse_ctcp(arg[0], ++data);
			return;
		}
		if(!strcmp(arg[3], "!hub"))
		{
			quote(ME.servfd, "NOTICE ", arg[0], " :Hub version ", S_VERSION, " reporting for duty, sir", NULL);
		}
		return;
	}
}
