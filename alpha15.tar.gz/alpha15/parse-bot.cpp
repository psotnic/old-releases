/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_bot(SOCK *s, char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;
	int i;

	if(!strlen(data)) return;

	for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  									  &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

	if(!strcmp(arg[0], S_NEWNICK) && strlen(arg[1]))
	{
		quote(FD_OWNERS, "*** ", s->name, " is now known as ", arg[1], NULL);
		free(s->name);
		mem_strcpy(s->name, arg[1]);
		return;
	}
	if(!strcmp(arg[0], S_INVITE))
	{
		ch = ME.FindChannel(arg[1]);
		if(strlen(arg[2]))
		{
			mem_strcpy(a, arg[2]);
		}
		else mem_strcpy(a, s->name);

		if(ch)
		{
			if(ch->ptr->flags & IS_OP) quote(ME.servfd, "INVITE ", a, " ", arg[1], NULL);
			else
			{
				s->status -= STATUS_REGISTERED;
				quote(FD_BOTS, S_INVITE, " ", arg[1], " ", a, NULL);
				s->status += STATUS_REGISTERED;
			}
		}
		else
		{
			s->status -= STATUS_REGISTERED;
			quote(FD_BOTS, S_INVITE, " ", arg[1], " ", a, NULL);
			s->status += STATUS_REGISTERED;
		}
		free(a);

		return;
	}
}
