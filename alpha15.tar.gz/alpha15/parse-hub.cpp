/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_hub(char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;
	int i;
	HANDLE *h;

	if(!strlen(data)) return;

	for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  									  &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

	if(!strcmp(arg[0], S_UL_UPLOAD_START) && !(ME.status &= STATUS_DOWNLOADINGUL))
	{
		printf("[*] Fetching Userlist\n");
		ME.status += STATUS_DOWNLOADINGUL;
		mem_strcpy(userlist.ulbuf, "");
		userlist.ulbuflines = 0;
		return;
	}
	if(!strcmp(arg[0], S_UL_UPLOAD_END) && (ME.status & STATUS_DOWNLOADINGUL))
	{
		ME.status -= STATUS_DOWNLOADINGUL;
		userlist.Update();
		return;
	}
	if(ME.status & STATUS_DOWNLOADINGUL)
	{
		strcat(data, "\n\0");
		mem_strcat(userlist.ulbuf, data);
		++userlist.ulbuflines;
		return;
	}

	/* add */
	if(!strcmp(arg[0], S_ADDUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
	{
		userlist.AddHandle(arg[1]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ADDHOST) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.AddHost(h, arg[2]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ADDCHAN) && strlen(arg[1]))
	{
		if(strlen(arg[2])) ME.AddChannelToList(arg[1], arg[2]);
   		else ME.AddChannelToList(arg[1], "");
		if(strlen(arg[2])) quote(ME.servfd, "JOIN ", arg[1], " ", arg[2], NULL);
		else quote(ME.servfd, "JOIN ", arg[1], NULL);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ADDBOT) && strlen(arg[2]))
	{
		userlist.AddBot(arg[1], arg[2], arg[3]);
		++userlist.SN;
   		return;;
	}

	/* remove */
	if(!strcmp(arg[0], S_RMUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
	{
		userlist.RemoveHandle(arg[1]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_RMHOST) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.RemoveHost(h, arg[2]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_RMCHAN) && strlen(arg[1]))
	{
		ME.RemoveChannelFromList(arg[1]);
		quote(ME.servfd, "PART ", arg[1], " :", config.partreason, NULL);
		++userlist.SN;
		return;
   	}
	if(!strcmp(arg[0], S_RMBOT) && strlen(arg[1]))
	{
		userlist.RemoveBot(arg[1]);
		++userlist.SN;
   		return;
	}
	/* other */
	if(!strcmp(arg[0], S_CHATTR) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.ChangeFlags(h, arg[2]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ULSAVE))
	{
		userlist.Save(config.userlist_file);
		return;
	}
	if(!strcmp(arg[0], S_INVITE))
	{
		ch = ME.FindChannel(arg[1]);
		if(ch) if(ch->ptr->flags & IS_OP) quote(ME.servfd, "INVITE ", arg[2], " ", arg[1], NULL);
	}
	if(!strcmp(arg[0], S_NEWNICK))
	{
		if(hub.nick) free(hub.nick);
		mem_strcpy(hub.nick, arg[1]);
	}
}
