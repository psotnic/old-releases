#include "prots.h"
#include "global-var.h"

int SafeExit()
{
	printf("[W] Abnormal program termination\n");
	userlist.Save(config.userlist_file);
	printf("[*] calling exit(1) \n");
	exit(1);
	printf("[-] ups... you should _NOT_ see this message\n");
	printf("[-] hell broke loose, its time to pray\n");
}

int SignalHandling()
{
	sigset_t sigmask;
	struct sigaction action;

	sigemptyset(&sigmask);
	sigaddset(&sigmask, SIGPIPE);
	sigprocmask(SIG_SETMASK, &sigmask, 0);

    sigemptyset(&action.sa_mask);
    action.sa_handler = (sighandler_t) SafeExit;
    action.sa_flags = 0;
 	sigaction(SIGTERM, &action, NULL);
	sigaction(SIGSEGV, &action, NULL);
	sigaction(SIGINT, &action, NULL);
	sigaction(SIGHUP, &action, NULL);

	return 0;
}



