#define _GNU_SOURCE				1

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fnmatch.h>
#include <arpa/inet.h>
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <errno.h>
#include <arpa/inet.h>

#define mem_strncpy(dest, src, n) \
        dest = (char *) malloc(n+1); \
        strncpy(dest, src, n); \
	    dest[n-1] = '\0'

#define mem_strcpy(dest, src) \
        dest = (char *) malloc(strlen(src)+1); \
        strcpy(dest, src);

#define mem_strcat(dest, src) \
		dest = realloc(dest, sizeof(char)*(strlen(src)+strlen(dest)+1)); \
		strcat(dest, src)

#define maskstrip(mask, nick, ident, host) \
		a = strchr(mask, '!'); \
    	b = strchr(mask, '@'); \
    	mem_strncpy(nick, mask, (int) abs(mask - a) +1); \
    	mem_strncpy(ident, a+1, (int) abs(a - b)); \
    	mem_strcpy(host, b+1)

#define debug()					printf("[D] [%s:%d] %s(): %s\n", __FILE__, __LINE__, __FUNCTION__, strerror(errno));
#define sclose(n)				shutdown(n, SHUT_RDWR)
#define	bk()					printf("### %s(): %s:%d\n", __FUNCTION__, __FILE__, __LINE__);

#define HAS_A                   1
#define HAS_D                   2
#define HAS_O                   4
#define HAS_F                   8
#define HAS_M                   16
#define HAS_N                   32
#define HAS_S                   64
#define HAS_B                   128
#define IS_OP                   256
#define HAS_ALL					63

#define ARG_MODES				"oblkeIv"

#define STATUS_CONNECTED		1
#define STATUS_REGISTERED		2
#define STATUS_OWNER			4

#define LIST_TOOP				1
#define LIST_BOTSTOOP			2
#define LIST_BOTS				4
#define LIST_TOKICK				8

#define MAX_LEN					1024
#define MAX_CONN        		64
#define MAX_SERVERS				16
#define MAX_CHANNELS			16
#define MAX_HOSTS				64

#define HUB_CONN_DELAY			10
#define IRC_CONN_DELAY			30
#define CHAN_CHECK_DELAY		10
#define CYCLE_DELAY 			3
#define REJOIN_DELAY			2

#define BOTNET_HUB				1
#define BOTNET_BOT				2
#define BOTNET_SLAVE			3

#define FD_OWNERS				-1000
#define FD_BOTS					-1001

#define TCP_NODELAY				1

#define S_UL_UPLOAD_START		"UL:UPLOAD:START"
#define S_UL_UPLOAD_END			"UL:UPLOAD:END"
#define S_NEWNICK				"NEWNICK"
#define S_REGISTER				"REGISTER"
#define S_VERSION				"0.0.13"
#define S_UNKNOWN				"<unknown>"
#define S_BOTNAME				"psotnic"



struct _sock
{
    int fd;
	char *name;
	int status;
};

struct _server
{
	char *host;
	int port;
	char *pass;
};

struct _chanuser
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	struct _chanuser *next;
    struct _chanuser *prev;
};

struct _handle
{
	char *name;
	char *host[MAX_HOSTS];
	int flags;
	struct _handle *next;
	struct _handle *prev;
};

struct _ptrlist
{
	struct _chanuser *ptr;
	struct _ptrlist *next;
	struct _ptrlist *prev;
};

struct _hub
{
	int fd;
	char *nick;
	char *ident;
	char *host;
	char *pass;
	int port;
};

struct _bot
{
	char *ip;
	char *mask;
	char *pass;
	struct _bot *next;
	struct _bot *prev;
};

struct _config
{
	char *nick;
	char *ident;
	char *nickappend;
	char *userlist_file;
	char *realname;
	char *myipv4;
	char *vhost;
	char *default_channel;
	char *default_channel_pass;
	struct _server server[MAX_SERVERS];
};

struct _chanlist
{
	char *name;
	char *pass;
	int joinsent;
};

typedef struct _chanuser CHANUSER;
typedef struct _ptrlist PTRLIST;
typedef struct _sock SOCK;
typedef struct _server SERVER;
typedef struct _handle HANDLE;
typedef struct _hub HUB;
typedef struct _config CONFIG;
typedef struct _chanlist CHANLIST;
typedef struct _bot BOT;

class ptrlist
{
	public:

	PTRLIST *first;
	int ent;

	PTRLIST *GetItem(int num);
	int SortAdd(CHANUSER *ptr);
	int Remove(char *nick);
	int Find(CHANUSER *ptr);
	void DebugDisplay();
	void reset();
	ptrlist();
	~ptrlist();
};


class chan
{
   	public:
	ptrlist ToOp, BotsToOp, OpedBots, ToKick;
	CHANUSER *first, *last, *ptr;
	char *name;
	int modes, users;
	int NextCheck;

	void DeOp(CHANUSER **MultHandle, int num);
	void Op(CHANUSER **MultHandle, int num);
	void Kick(CHANUSER **MultHandle, int num);
	void RemoveAll(CHANUSER *handle);
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *mask);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick);
    void DebugDisplay();
	CHANUSER *GotJoin(char *mask, int op);
	CHANUSER *GetUser(char *nick);
	chan();
	~chan();
};

struct _channel
{
	class chan channel;
	struct _channel *next;
	struct _channel *prev;
};



typedef struct _channel CHANNEL;

class client
{
	public:
	CHANNEL *first, *last, *current;
	client();
	~client();
	int channels, servfd, servid, nextconn_hub, nextconn_serv, nextjoin, status;
	char *nick, *ident, *host, *mask;
	CHANLIST chanlist[MAX_CHANNELS];
	SOCK serv;

	chan *CreateNewChannel(char *name);
	chan *FindChannel(char *name);
	void RemoveChannel(char *name);
	void GotUserQuit(char *mask);
	void CheckQueue();
	int ConnectToIRC();
	int ConnectToHUB();
	void reset();
	int AddChannelToList(char *name, char *pass);
	int RemoveChannelFromList(char *name);
	int FindChannelInList(char *name);
	void JoinChannels();
	void RecheckChannels();
	void Display();
	void GotNickChange(char *from, char *to);
};

class ul
{
	public:
	HANDLE *first, *last;
	BOT *Bfirst, *Blast;
	int ent, bots;
	unsigned long long int SN; // ;-)

	HANDLE *AddHandle(char *name);
	int RemoveHandle(char *name);
	void RemoveAllData(HANDLE *p);
	int FindHost(HANDLE *p, char *host);
	int AddHost(HANDLE *p, char *host);
	int RemoveHost(HANDLE *p, char *host);
	int ChangeFlags(HANDLE *p, char *flags);
	HANDLE *FindHandle(char *name);
	int ChangeFlags(char *name, char *flags);
	void GetFlags(HANDLE *p, char *buf);
	int Save(char *file);
	int Load(char *file);
	int GetFlags(char *mask);
	BOT *AddBot(char *mask, char *ip, char *pass);
	int RemoveBot(char *mask);
	void RemoveAllBotData(BOT *p);
	BOT *FindBot(char *mask);
	int IsOwner(char *mask);
	int IsBot(char *ip);
	int CheckBotPass(char *ip, char *pass);
	void reset();
	ul();
	~ul();
};

int DoConnect(char *server, int port, char *vhost, int options);
int match(char *str, char *pattern);
int precache();
unsigned int hash32(char *word);
void quote(int file, char *lst, ...);
char *push(char *ptr, char *lst, ...);
void Divide(int *ret, int value, int parts, int part_size);
int GetRandomNumbers(int *n, int start, int end, int num);
int MyTurn(ptrlist *p, int hash, int num);
int GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num);
void ircparser(char *data);
int StartListening(char *ip, int port);
int AddSock(int fd);
int ReadOneLine(int fd, char *buf, int len);
int getpeerport(int fd);
char *getpeerip(int fd);
int AcceptConnection(int fd);
char *inet2char(int inetip);
void ownerparser(SOCK *s, char *data);
void CloseSock(SOCK *s);
void LoadConfig(char *file);
int SignalHandling();
int SafeExit();
int MagicNickCreator(char *nick);
int extendhost(char *host, char *buf, int len);
void RegisterBot(SOCK *s, char *data);
void botparser(SOCK *s, char *data);
