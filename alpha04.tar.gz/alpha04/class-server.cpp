#include "prots.h"
#include "global-var.h"

void client::RemoveChannel(char *name)
{
	CHANNEL *p;

	if(!strcmp(first->channel.name, name))
	{
		p = first;
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		channels--;

	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->channel.name, name))
			{
				channels--;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
			}
		}
	}
	current = first;
}


chan *client::FindChannel(char *name)
{
 	if(!current) return NULL;
		if(!strcmp(current->channel.name, name)) return &current->channel;
	current = first;
	while(1)
	{
		if(!current) break;
		if(!strcmp(current->channel.name, name)) return &current->channel;
		current = current->next;
	}
	return NULL;
}

chan *client::CreateNewChannel(char *name)
{
	if(!channels)
	{
		first = current = last = new(CHANNEL);
		current->prev = current->next = NULL;
		mem_strcpy(current->channel.name, name);
		current->channel.modes = 0;
		channels++;
		return &current->channel;
	}
	else
	{
		current = last->next = new(CHANNEL);
  		current->prev = last;
		current->next = NULL;
		current->channel.modes = 0;
		mem_strcpy(current->channel.name, name);
		last = current;
		channels++;
		return &current->channel;
	}

}

client::client()
{
	first = last = current = NULL;
	channels = 0;
}
