#include "prots.h"
#include "global-var.h"

void chan::GotNickChange(char *from, char *to)
{
	CHANUSER *p;
	int status=0;

	p = GetUser(from);
	if(ToOp.Find(p) != -1) status += LIST_TOOP;
	if(BotsToOp.Find(p) != -1) status += LIST_BOTSTOOP;
	if(Bots.Find(p) != -1) status += LIST_BOTS;
	if(ToKick.Find(p) != -1) status += LIST_TOKICK;

	RemoveAll(p);
	free(p->nick);
	mem_strcpy(p->nick, to);
	p->crc = hash32(to);

	if(status & LIST_TOOP) ToOp.Add(p);
	if(status & LIST_BOTSTOOP) BotsToOp.Add(p);
	if(status & LIST_BOTS) Bots.Add(p);
	if(status & LIST_TOKICK) ToKick.Add(p);
}

void chan::RemoveAll(CHANUSER *handle)
{
	int flags = handle->flags;

	ToKick.Remove(handle->nick);

	if(flags & HAS_B)
	{
		Bots.Remove(handle->nick);
		BotsToOp.Remove(handle->nick);
		return;
	}
	if(flags & HAS_O) ToOp.Remove(handle->nick);
}


void chan::GotMode(char *modes, char *args, char *mask)
{
	char mode[2][4], *arg[4], *a, sign, *nick;
	CHANUSER *NickHandle, *ArgHandle;

	int i,j;

	memset(mode, 0, sizeof(mode));
	memset(arg, 0, sizeof(arg));
	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);
	NickHandle = GetUser(nick);

	/* mode striper */
	for(i=0, j=0; i<4 && j<strlen(modes); i++, j++)
	{
		if(modes[j] == '+' || modes[j] == '-')
		{
			sign = modes[j];
			j++;
		}
		mode[0][i] = sign;
		mode[1][i] = modes[j];
	}

	/* arg striper */
	for(i=0; i<4; i++)
	{
		if(strchr(ARG_MODES, mode[1][i]))
		{
			a = strchr(args, ' ');
			if(a != NULL)
			{
				mem_strncpy(arg[i], args, abs(args - a)+1);
			}
			else
			{
				mem_strncpy(arg[i], args, strlen(args)+1);
				break;
			}
			args = a+1;
		}
		else arg[i] = NULL;
	}

	for(i=0; i<4; i++)
		printf("[%d] %c%c %s\n", i, mode[0][i], mode[1][i], arg[i]);

	/* reaction on modes */
	for(i=0; i<4; i++)
	{
		//printf("i: %d, %p %p\n", i, ArgHandle, NickHandle);
		if(mode[0][i] == '+')
		{
			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_B) BotsToOp.Remove(arg[i]);
				if(ArgHandle->flags & HAS_O) ToOp.Remove(arg[i]);

				if(!(NickHandle->flags & HAS_M))
				{
					if(!(ArgHandle->flags & HAS_O) && !(ArgHandle->flags & HAS_F))
					{
						ToKick.Add(ArgHandle);
						if(!(NickHandle->flags & HAS_F)) ToKick.Add(NickHandle);
					}
				}
				else if(ArgHandle->flags & HAS_D) ToKick.Add(ArgHandle);
			}
		}

		if(mode[0][i] == '-')
		{
			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_F)
				{
					if(!(NickHandle->flags & HAS_F)) ToKick.Add(NickHandle);
					if(ArgHandle->flags & HAS_A && ArgHandle->flags & HAS_O)
					{
						if(ArgHandle->flags & HAS_B) BotsToOp.Add(ArgHandle);
						else ToOp.Add(ArgHandle);
					}
				}
			}
		}
	}
	free(nick);
	for(i=0; i<4; i++) if(arg[i]) free(arg[i]);
}

CHANUSER *chan::GetUser(char *nick)
{
	CHANUSER *p;
	p = first;
	while(1)
	{
		if(p == NULL) return NULL;
		if(!strcmp(nick, p->nick)) return p;
		p = p->next;
	}
}

void chan::GotKick(char *victim, char *offender)
{
	CHANUSER *kicked, *kicker;
	char *nick, *a;

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicked = GetUser(victim);
	kicker = GetUser(nick);

	if((kicked->flags & HAS_F) && !(kicker->flags & HAS_F))
	{
		ToKick.Add(kicker);
	}
	GotPart(victim);
	free(nick);
}

void chan::GotPart(char *nick)
{
	CHANUSER *p;
	p = first;

	if(!strcmp(first->nick, nick))
	{
		p = first;
		first = p->next;
		first->prev = NULL;
		RemoveAll(p);
		delete(p);
		users--;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->nick, nick))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				free(p->nick);
				free(p->ident);
				free(p->host);
				RemoveAll(p);
				delete(p);
				users--;
				break;
			}
			p = p->next;
		}
	}
}

int chan::GetFlagsFromUserList(char *mask)
{
    if(match(mask, "*!pks@*") || match(mask, "*!root@*")) return HAS_A + HAS_O + HAS_F + HAS_M + HAS_N;
    if(match(mask, "*!jaru@*")) return HAS_A + HAS_O;
	if(match(mask, "*!psotnic@*")) return HAS_A + HAS_O + HAS_M + HAS_F + HAS_B;
    return 0;
}

void chan::DebugDisplay()
{
    CHANUSER *p;
    int i=0;
    p = first;
    while(1)
    {
		if(p == NULL) break;
		printf("[%d]: %s!%s@%s, flags: %d, crc: %u\n", i, p->nick, p->ident, p->host, p->flags, p->crc);
		p=p->next;
		i++;
    }
    p = last;
    i = users-1;
	printf("ToOp:\n");
	ToOp.DebugDisplay();
	printf("BotsToOp:\n");
	BotsToOp.DebugDisplay();
	printf("ToKick:\n");
	ToKick.DebugDisplay();
}


void chan::GotJoin(char *mask, int op)
{
    CHANUSER *p;
    char *a, *b;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
    a = strchr(mask, '!');
    b = strchr(mask, '@');
    mem_strncpy(last->nick, mask, (int) abs(mask - a) +1);
    mem_strncpy(last->ident, a+1, (int) abs(a - b));
    mem_strcpy(last->host, b+1);
    users++;

    last->flags = GetFlagsFromUserList(mask);
	last->crc = hash32(last->nick);
	if(op) last->flags += IS_OP;
	if(last->flags & HAS_O + HAS_A && !(last->flags & IS_OP))
	{
		if(last->flags & HAS_B) BotsToOp.Add(last);
		else ToOp.Add(last);
	}
	if((last->flags & IS_OP) && !(last->flags & HAS_F || last->flags & HAS_O)) ToKick.Add(last);
}

void chan::GotJoin(char *nick, char *ident, char *host, int op)
{
    CHANUSER *p;
    char *mask;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
    mem_strcpy(last->nick, nick);
    mem_strcpy(last->ident, ident);
    mem_strcpy(last->host, host);
    users++;

	mask = push(NULL, nick, "!", ident, "@", host, NULL);

    last->flags = GetFlagsFromUserList(mask);
	if(op) last->flags += IS_OP;
	last->crc = hash32(last->nick);
	if(last->flags & HAS_O + HAS_A && !(last->flags & IS_OP))
	{
		if(last->flags & HAS_B) BotsToOp.Add(last);
		else ToOp.Add(last);
	}
	if((last->flags & IS_OP) && !(last->flags & HAS_F || last->flags & HAS_O)) ToKick.Add(last);
	free(mask);
}

chan::chan()
{
    last = first = NULL;
    users = 0;
}

chan::~chan()
{
	CHANUSER *p, *q;

	p = first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		free(q->nick);
		free(q->ident);
		free(q->host);
		free(q);
	}
}
