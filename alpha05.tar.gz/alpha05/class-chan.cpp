#include "prots.h"
#include "global-var.h"

void chan::GotNickChange(char *from, char *to)
{
	CHANUSER *p;
	int status=0;

	p = GetUser(from);
	if(ToOp.Find(p) != -1) status += LIST_TOOP;
	if(BotsToOp.Find(p) != -1) status += LIST_BOTSTOOP;
	if(OpedBots.Find(p) != -1) status += LIST_BOTS;
	if(ToKick.Find(p) != -1) status += LIST_TOKICK;

	RemoveAll(p);
	free(p->nick);
	mem_strcpy(p->nick, to);
	p->crc = hash32(to);

	if(status & LIST_TOOP) ToOp.SortAdd(p);
	if(status & LIST_BOTSTOOP) BotsToOp.SortAdd(p);
	if(status & LIST_BOTS) OpedBots.SortAdd(p);
	if(status & LIST_TOKICK) ToKick.SortAdd(p);
}

void chan::RemoveAll(CHANUSER *handle)
{
	int flags = handle->flags;

	ToKick.Remove(handle->nick);

	if(flags & HAS_B)
	{
		OpedBots.Remove(handle->nick);
		BotsToOp.Remove(handle->nick);
		return;
	}
	if(flags & HAS_O) ToOp.Remove(handle->nick);
}

CHANUSER *chan::GetUser(char *nick)
{
	CHANUSER *p;
	p = first;
	while(1)
	{
		if(!p) return NULL;
		//printf("matching: %s vs. %s\n", nick, p->nick);
		if(!strcasecmp(nick, p->nick)) return p;
		p = p->next;
	}
}

void chan::GotKick(char *victim, char *offender)
{
	CHANUSER *kicked, *kicker;
	char *nick, *a;

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicked = GetUser(victim);
	kicker = GetUser(nick);

	if((kicked->flags & HAS_F) && !(kicker->flags & HAS_F))
	{
		ToKick.SortAdd(kicker);
	}
	GotPart(victim);
	free(nick);
}

void chan::GotPart(char *nick)
{
	CHANUSER *p;
	p = first;

	if(!strcasecmp(first->nick, nick))
	{
		first = first->next;
		first->prev = NULL;
		RemoveAll(p);
		delete(p);
		users--;
	}
	else if(!strcasecmp(last->nick, nick))
	{
		p = last->prev;
		p->next = NULL;
		RemoveAll(last);
		delete(last);
		users--;
		last = p;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcasecmp(p->nick, nick))
			{
				//printf("@@@@@@ del: %s\n", nick);
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				free(p->nick);
				free(p->ident);
				free(p->host);
				RemoveAll(p);
				delete(p);
				users--;
				break;
			}
			p = p->next;
		}
	}
}

int chan::GetFlagsFromUserList(char *mask)
{
    if(match(mask, "*!pks@*") || match(mask, "*!root@*")) return HAS_A + HAS_O + HAS_F + HAS_M + HAS_N;
    if(match(mask, "*!jaru@*")) return HAS_A + HAS_O;
	if(match(mask, "*!psotnic@*")) return HAS_A + HAS_O + HAS_M + HAS_F + HAS_B;
    return 0;
}

void chan::DebugDisplay()
{
    CHANUSER *p;
    int i=0;
    p = first;
    while(1)
    {
		if(p == NULL) break;
		printf("[%d]: %s!%s@%s, flags: %d, crc: %u\n", i, p->nick, p->ident, p->host, p->flags, p->crc);
		p=p->next;
		i++;
    }
    p = last;
    i = users-1;
	printf("ToOp:\n");
	ToOp.DebugDisplay();
	printf("BotsToOp:\n");
	BotsToOp.DebugDisplay();
	printf("ToKick:\n");
	ToKick.DebugDisplay();
	printf("OpedBots:\n");
	OpedBots.DebugDisplay();

}


CHANUSER *chan::GotJoin(char *mask, int op)
{
    CHANUSER *p;
    char *a, *b;
	int i;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
    a = strchr(mask, '!');
    b = strchr(mask, '@');
    mem_strncpy(last->nick, mask, (int) abs(mask - a) +1);
    mem_strncpy(last->ident, a+1, (int) abs(a - b));
    mem_strcpy(last->host, b+1);
    users++;

    last->flags = GetFlagsFromUserList(mask);
	last->crc = hash32(last->nick);

	if(last->flags & HAS_O + HAS_A && !op)
	{
		if(last->flags & HAS_B) BotsToOp.SortAdd(last);
		else ToOp.SortAdd(last);
	}
	if(op)
	{
		last->flags += IS_OP;
		if(!(last->flags & HAS_F || last->flags & HAS_O)) ToKick.SortAdd(last);
		if(last->flags & HAS_B) OpedBots.SortAdd(last);
	}
	return last;
}

chan::chan()
{
    last = first = NULL;
    users = 0;
	NextCheck = BotsBeforeMe = -1;
	ptr = NULL;
}

chan::~chan()
{
	CHANUSER *p, *q;

	p = first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		free(q->nick);
		free(q->ident);
		free(q->host);
		free(q);
	}
}
