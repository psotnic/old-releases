extern unsigned int magic[8];
extern struct client ME;
