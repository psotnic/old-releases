#include "prots.h"
unsigned int magic[8];
client ME;

int main()
{
	chan *ch;
	char buf[MAX_LEN], arg[10][MAX_LEN], *a, *b, *c;
	int i, serv, ret;
	struct timeval tv;
	time_t last, cur;
	fd_set rfd;
	CHANUSER *p;

	precache();

	ME.status = 0;
	ME.serv = serv = DoConnect("127.0.0.1", 6667);
 	fcntl(serv, F_SETFL, O_NONBLOCK);
	if(serv)
	{
		ME.status += STATUS_CONNECTED;
		tv.tv_sec = 1;
        tv.tv_usec = 0;
		FD_ZERO(&rfd);
    	FD_SET(serv, &rfd);
	}
	srand(time(NULL)*getpid());
	sprintf(buf, "p[%d]", rand()%1000);
	quote(serv, "NICK ", buf, NULL);
	quote(serv, "USER bot 8 * :tra la la", NULL);

	last=cur = time(NULL);
	while(serv)
	{
			if(!tv.tv_sec) tv.tv_sec = 1;
			tv.tv_usec = 0;
			FD_ZERO(&rfd);
    		FD_SET(serv, &rfd);
			ret = select(serv+1, &rfd, NULL, NULL, &tv);

			cur = time(NULL);
			if(cur != last)
			{
				last = cur;
				//printf("######-lol-#######\n");
			}
			if(!ret) continue;
			/* xmas clean ups */
			memset(&buf, 0, sizeof(buf));
			for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

			/* read one line */
			for (i=0; i<MAX_LEN; i++)
			{
				//if(feof(serv)) exit(1);
				read(serv, &buf[i], 1);
				if (buf[i] == '\0') break;
				if (buf[i] == '\n')
				{
					buf[i] = '\0';
					break;
				}
				if (buf[i] == ':' && (buf[i-1] == ' ' || i == 0)) i--;
			}
			sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
														 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
			/* debug */
			if(!strcasecmp(arg[1], "PRIVMSG"))
			{
				ch = ME.FindChannel(arg[2]);
				if(!strcasecmp(arg[3], "!debug"))
				{
					printf("### DEBUG ###\n");
					if(ch) ch->DebugDisplay();
				}
				if(!strcasecmp(arg[3], "!cycle"))
				{

					quote(serv, "PART ", arg[2], " :Cycle time", NULL);
					quote(serv, "JOIN ", arg[2], NULL);
				}
			}

			if(strlen(buf))
			{
				printf("<%s> recv[%2d]: ", ME.nick, strlen(buf));
				for (i=0; i<10; i++) printf("%s ", arg[i]);
				printf("\n");
			}

			/* reaction */
			if(!strcasecmp(arg[1], "JOIN"))
			{
				if(!strcmp(ME.mask, arg[0]))
				{
					ch = ME.CreateNewChannel(arg[2]);
					quote(serv, "WHO ", arg[2]);
				}
				else
				{
					ch = ME.FindChannel(arg[2]);
					if(!ch->ptr) continue;
					ch->GotJoin(arg[0], 0);
				}
			}
			else if(!strcasecmp(arg[1], "MODE"))
			{
				ch = ME.FindChannel(arg[2]);
				if(ch)
				{
					if(!ch->ptr) continue;
					a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
					ch->GotMode(arg[3], a, arg[0]);
					free(a);
				}

			}
			else if(!strcasecmp(arg[1], "KICK"))
			{
				if(!strcasecmp(ME.nick, arg[3]))
				{
					ME.RemoveChannel(arg[2]);
					printf("i was kicked form %s\n", arg[2]);
					quote(serv, "JOIN ", arg[2], NULL);
				}
				else
				{
					ch = ME.FindChannel(arg[2]);
					if(!ch->ptr) continue;
					ch->GotKick(arg[3], arg[0]);
				}
			}
			else if(!strcasecmp(arg[1], "PART"))
			{
				if(!strcasecmp(ME.mask, arg[0])) ME.RemoveChannel(arg[2]);
				else
				{
					ch = ME.FindChannel(arg[2]);
					if(!ch->ptr) continue;
					mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
					ch->GotPart(a);
					free(a);
				}
			}
			else if(!strcasecmp(arg[1], "352"))
			{
				ch = ME.FindChannel(arg[3]);
				a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
				p = ch->GotJoin(a, match(arg[8], "*@*"));
				if(!strcasecmp(arg[7], ME.nick))
				{
					ch->ptr = p;
					if(!(p->flags & HAS_B)) p->flags += HAS_B;
				}
				free(a);
			}
			else if(!strcasecmp(arg[1], "315"))
			{
				ch = ME.FindChannel(arg[3]);
				//ch->DebugDisplay();
			}
			else if(!strcasecmp(arg[1], "QUIT")) ME.GotUserQuit(arg[0]);
			else if(!strcasecmp(arg[0], "PING")) quote(serv, "PONG :", arg[1]);
			else if(!strcasecmp(arg[1], "433")) quote(serv, "NICK ", arg[3], "_", NULL);
			else if(!strcasecmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
			{
				ME.status += STATUS_REGISTERED;
				maskstrip(arg[9], ME.nick, ME.ident, ME.host);
				mem_strcpy(ME.mask, arg[9]);
				quote(serv, "join #piwo", NULL);
			}


	}
	ME.status = 0;
	return 0;
}

