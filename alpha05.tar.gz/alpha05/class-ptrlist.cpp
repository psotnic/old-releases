#include "prots.h"
#include "global-var.h"

int ptrlist::GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num)
{
	int i=0, j=0, k;
	int n[num];
	PTRLIST *p;

	printf("GetRandomItems(%p, %p, %d)\n", ret, start, interval);
	if(!start)
	{
		printf("NO START\n");
		return 0;
	}
	p = start;


	if(interval < num+1)
	{
		while(1)
		{
			if(!p || i == num) break;
			ret[i] = p->ptr;
			p = p->next;
			i++;
		}
		printf("!!! INTERNAL DEBUG !!!\n");
		for(j=0; j<i; j++)
		{
			printf(">> nick: %s\n", ret[j]->nick);
		}
		return i;
	}
	else
	{
		GetRandomNumbers((int *) n, 0, interval, num);
		//printf("'lucky' numbers: %d %d %d\n", n[0], n[1], n[2]);
		while(1)
		{
			if(!p) break;
			for(k=0; k<num; k++)
			{
				if(i == n[k])
				{
					printf("ret[%d] = %p (%s)\n", j, p->ptr, p->ptr->nick);
					ret[j] = p->ptr;
					j++;
				}
			}
			i++;
			p = p->next;
		}
	}
	printf("### INTERNAL DEBUG ###\n");
	for(i=0; i<num; i++)
	{
		printf(">> nick: %s\n", ret[i]->nick);
	}
	return num;
}

PTRLIST *ptrlist::GetItem(int num)
{
	PTRLIST *p;
	int i;

	if(num+1 > ent) return NULL;
	p = first;
	i = 0;

	while(1)
	{
		if(i == num) return p;
		p = p->next;
		i++;
	}
}

int ptrlist::Find(CHANUSER *ptr)
{
	PTRLIST *p;
	int i=0;
	p=first;
	while(1)
	{
		if(!p) return -1;
		if(ptr == p->ptr) return i;
		i++;
		p = p->next;
	}
}

void ptrlist::Remove(char *nick)
{
	PTRLIST *p;
	p = first;

	if(!ent) return;
	if(!strcmp(first->ptr->nick, nick))
	{
		p = first;
		first->prev = NULL;
		first = first->next;
		delete(p);
		ent--;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->ptr->nick, nick))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
				ent--;
				break;
			}
			p = p->next;
		}
	}
}

int ptrlist::SortAdd(CHANUSER *ptr)
{
	PTRLIST *p, *q;
	int i=0;

	if(!ent)
	{
		first = new(PTRLIST);
		first->next = first->prev = NULL;
		first->ptr = ptr;
	}
	else
	{
		if(ptr->crc < first->ptr->crc)
		{
			q = new(PTRLIST);
			q->ptr = ptr;
			first->prev = q;
			q->prev = NULL;
			q->next = first;
			first = q;
		}
		else
		{
			p = first;
			while(1)
			{
				if(ptr->crc == p->ptr->crc) return -1;
				if(ptr->crc < p->ptr->crc)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = p;
					q->prev = p->prev;
					p->prev->next = q;
					p->prev = q;
					break;
				}
				else if(p->next == NULL)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = NULL;
					q->prev = p;
					p->next = q;
					break;
				}
				p = p->next;
				i++;
			}
		}
	}
	ent++;
	return i;
}

void ptrlist::DebugDisplay()
{
	PTRLIST *p;
	p = first;
	while(1)
	{
		if(p == NULL) break;
		printf("[%8d][%d]: %s!%s@%s \n", p->ptr->crc, p->ptr->flags, p->ptr->nick, p->ptr->ident, p->ptr->host);
		p = p->next;
	}
}

ptrlist::ptrlist()
{
	first = NULL;
	ent = 0;
}

ptrlist::~ptrlist()
{
	PTRLIST *p, *q;

	p=first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		delete(q);
	}
}
