#include "prots.h"
#include "global-var.h"

int extendhost(char *host, char *buf, int len)
{
    char *ex, *at;

    if(strlen(host) + 10 > len) return 0;

    ex = strchr(host, '!');
    at = strchr(host, '@');

    if(ex != strrchr(host, '!') || at != strrchr(host, '@')) return 0;

    if(at)
    {
        if(!ex)
        {
            if(at == host) strcpy(buf, "*!*");
            else strcpy(buf, "*!");
            strcat(buf, host);
        }
        else if(ex == host)
        {
            strcpy(buf, "*");
            strcat(buf, host);
        }
        else strcpy(buf, host);
        if(*(at + 1) == '\0') strcat(buf, "*");
        return 1;
    }
    else
    {
        if(ex) return 0;
        if(strchr(host, '.') || strchr(host, ':'))
        {
            strcpy(buf, "*!*@");
            strcat(buf, host);
            return 1;
        }
        strcpy(buf, "*!");
        strcat(buf, host);
        strcat(buf, "@*");
        return 1;
    }
}

int MagicNickCreator(char *nick)
{
	int nicklen, applen;
	char *n;

	nicklen = strlen(nick);
	if(nicklen == 9) return 0;
	applen = strlen(config.nickappend);

	n = strchr(config.nickappend, nick[nicklen-1]);

	if(n)
	{
		if(nick[nicklen-1] == config.nickappend[applen-1]) nick[nicklen] = config.nickappend[0];
		else nick[nicklen-1] = config.nickappend[abs(n - config.nickappend) + 1];
	}
	else nick[nicklen] = config.nickappend[0];
	return 1;
}

void CloseSock(SOCK *s)
{
	sclose(s->fd);
	s->fd = 0;
	if(s->flags & STATUS_REGISTERED) free(s->nick);
	s->flags = 0;
}

char *inet2char(int inetip)
{
	struct sockaddr_in sin;
	sin.sin_addr.s_addr = inetip;
	return inet_ntoa(sin.sin_addr);
}

int IsOwner(char *mask)
{
	if(match(mask, "*!pks@*") || match(mask, "*!root@*")) return 1;
	else return 0;
}

int AcceptConnection(int fd)
{
	int n, i;
	struct sockaddr_in from;
	socklen_t fromsize = sizeof(struct sockaddr_in);
	const int one = 1;

	if((n = accept(fd, (sockaddr *) &from, &fromsize)) > 0)
	{
		printf("[*] Connection attempt from %s\n", inet_ntoa(from.sin_addr));
		fcntl(n, F_SETOWN);
		fcntl(n, F_SETFL, O_NONBLOCK);
		setsockopt(n, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));
		if(AddSock(n) == -1)
		{
			sclose(n);
			return -1;
		}
		printf("[+] Connection established\n");
		return n;
	}
	else
	{
		debug();
		printf("[-] Connection lost\n");
		return -1;
	}
}

int getpeerport(int fd)
{
	struct sockaddr_in peer;
	socklen_t peersize;
	peersize = sizeof(struct sockaddr_in);
	if(getpeername(fd, (sockaddr *) &peer, &peersize) == -1)
	{
		//debug();
		return -1;
	}
	return ntohs(peer.sin_port);
}

int ReadOneLine(int fd, char *buf, int len)
{
	int i;
	memset(buf, 0, len);
	for (i=0; i<len-1; i++)
	{
		if(read(fd, &buf[i], 1) < 1)
		{
			if(errno != EAGAIN)	return -1;
		}
		if(buf[i] == '\0') break;
		if(buf[i] == '\n')
		{
			buf[i] = '\0';
			break;
		}
		if(buf[i] == ':' && (buf[i-1] == ' ' || i == 0)) i--;
	}
	printf("[*] read[%2d:%5d]: %s\n", strlen(buf), getpeerport(fd), buf);
	return i;
}

int StartListening(char *ip, int port)
{
    struct sockaddr_in sin;
    struct in_addr addr;
    int s, ret;
    const int one = 1;

	printf("[*] Opening listening socket at %s:%d\n", ip, port);
    if((s = socket(AF_INET, SOCK_STREAM, 0)) == 0) return -1;

    if(setsockopt(s , SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0) return -1;

    memset (&sin, 0, sizeof (struct sockaddr_in));
    if(strlen(ip)) sin.sin_addr.s_addr = inet_addr(ip);
    else sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    if(bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1) return -1;

    if(listen(s, SOMAXCONN) == -1) return -1;

	printf("[+] Socket awaits incomming connections\n");
    return s;
}

int AddSock(int fd)
{
    int i;

    for(i=0; i<MAX_CONN; i++)
    {
        if(sock[i].fd < 1)
        {
            sock[i].fd = fd;
			sock[i].flags = STATUS_CONNECTED;
            return i;
        }
    }
	return -1;
}


int precache()
{
    int i;
    for(i=1, magic[0]=6; i<9; i++) magic[i] = magic[i-1]*6;
	for(i=0; i<MAX_CONN; i++) memset(&sock[i], 0, sizeof(sock[i]));
	for(i=0; i<MAX_SERVERS; i++) memset(&config.server[i], 0, sizeof(config.server[i]));
	for(i=0; i<MAX_CHANNELS; i++) memset(&ME.chanlist[i], 0, sizeof(ME.chanlist[i]));

	memset(&hub, 0, sizeof(hub));
	memset(&config, 0, sizeof(config));

	AUTOOP_BOTS = 3;
	PUNISH_BOTS = 3;
	PUNISH_METHOD = 1;
}

void Divide(int *ret, int value, int parts, int part_size)
{
	if(parts == 1)
	{
		ret[0] = value;
		ret[1] = ret[2] = 0;
		return;
	}

	if(value > part_size*2)
    {
        ret[0] = value / parts;
        ret[1] = (value - ret[0]) / (parts-1);
        if(parts == 3) ret[2] = value - ret[0] - ret[1];
        else ret[2] = 0;
    }
    else if(value > part_size)
    {
        ret[0] = part_size;
        ret[1] = value - ret[0];
        ret[2] = 0;
    }
    else
    {
        ret[0] = value;
        ret[1] = ret[2] = 0;
    }
}

int DoConnect(char *server, int port, char *vhost, int options)
{
    struct sockaddr_in sin;
    struct in_addr addr;
    int s;
 
    /* create a socket */
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (!s)
	{
		debug();
		return -1;

	}

	memset (&sin, 0, sizeof (struct sockaddr_in));
    if(strlen(vhost)) sin.sin_addr.s_addr = inet_addr(vhost);
	else sin.sin_addr.s_addr = INADDR_ANY;
    if (bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1)
	{
		debug();
		return -1;
	}
    /* where do we want to connect */
    memset (&sin, 0, sizeof (struct sockaddr_in));
    sin.sin_family = PF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);
    if (sin.sin_addr.s_addr == -1)
	{
		debug();
		return -1;
	}
    /* connect to server */
    if (connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1)
	{
		debug();
		return -1;
	}
	/* set socket in nonbloking state */
	if(options > 0) if(fcntl(s, F_SETFL, options) == -1)
	{
		debug();
		return -1;
	}
	return s;
}

int match(char *str, char *pattern)
{
    if (!fnmatch(pattern, str, FNM_CASEFOLD)) return 1;
    else return 0;
}



unsigned int hash32(char *word)
{
    unsigned int i, crc;
    for(i = 0, crc = 0; i < strlen(word); i++) crc+=word[i]*magic[i];
    if(crc < 0) crc = 0;
    return crc;
}

void quote(int file, char *lst, ...)
{
    va_list ap;
	char *ptr, *p;
    int size=2, i;


    /* get size */
    va_start(ap, lst);
    size+=strlen(lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }
    /* alocate memory and copy | cat first element*/
    va_start(ap, lst);
    ptr = (char *) malloc(size*sizeof(char));
    strcpy(ptr, lst);
    /* strcat rest */
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
	}

	ptr[size-1] = '\n';
	strcat(ptr, "\0");
	if(file > 0)
	{
		write(file, ptr, size);
		printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(file), ptr);
	}
	else if(file == FD_OWNERS)
	{
		for(i=0; i<MAX_CONN; i++)
		{
			if(sock[i].fd > 0 && sock[i].flags & STATUS_OWNER)
			{
				write(sock[i].fd, ptr, size);
				printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(sock[i].fd), ptr);
			}
		}
	}
	else if(file == FD_BOTS)
	{
		for(i=0; i<MAX_CONN; i++)
		{
			if(sock[i].fd > 0 && sock[i].flags & STATUS_REGISTERED)
			{
				write(sock[i].fd, ptr, size);
				printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(sock[i].fd), ptr);
			}
		}
	}
	free(ptr);
}

char *push(char *ptr, char *lst, ...)
{
    va_list ap;
    int size=1;
    char *p;

    /* get size */
    va_start(ap, lst);
    size+=strlen(lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }

    /* alocate memory and copy | cat first element*/
    va_start(ap, lst);
    if(ptr)
    {
        size+=strlen(ptr);
        ptr = (char *) realloc(ptr, size*sizeof(char));
        strcat(ptr, lst);
    }
    else
    {
        ptr = (char *) malloc(size*sizeof(char));
        strcpy(ptr, lst);
    }

    /* strcat rest */
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
    }
    return ptr;
}
