/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

void var::reset()
{
	for(int i=0; i<ent; ++i) *varent[i].i = varent[i].def;
}

void var::sendVar(int i, char *name, char *from)
{
	if(!from) return;
	if(i < 0 || i >=ent) return;
	if(!name) return;

	char buf[MAX_LEN], spaces[MAX_LEN];
	int j;

	for(j=0; j<align-(signed int) strlen(varent[i].name); ++j) spaces[j] = ' ';
	spaces[j] = '\0';

	int2units(buf, MAX_LEN, *varent[i].i, varent[i].ut);
	net.sendOwner(from, name, ": ", varent[i].name, spaces, " = ", buf, NULL);

}

int var::parseuser(char *from, char *name, char *a, char *b)
{
	char buf[MAX_LEN];
	int n, i;

	memset(buf, 0, MAX_LEN);

	if(!*a)
	{
		for(i=0; i<ent ;++i)
		{
			if(varent[i].i)
				sendVar(i, name, from);
		}
		return -2;
	}
	else if(!*b)
	{
		i = getvar(a);
		if(i == -1)
		{
			if(from) net.sendOwner(from, "No such variable '", a, "'", NULL);
		}
		else
		{
			sendVar(i, name, from);
			return -2;
		}
	}
	else
	{
		switch((i = setvar(a, b, &n)))
		{
			case -1:
			{
				if(from)
					net.sendOwner(from, "No such variable '", a, "'", NULL);
				return -1;
			}
			case -2:
			{
				if(from)
					net.sendOwner(from, "Invalid data format", NULL);
				return -1;
			}
			case -3:
			{
				if(from)
				{
					char from[MAX_LEN];
					char to[MAX_LEN];
					int2units(from, MAX_LEN, varent[n].from, varent[n].ut);
					int2units(to, MAX_LEN, varent[n].to, varent[n].ut);
					sprintf(buf, "Value does not bellong to range <%s, %s>", from, to);
					net.sendOwner(from, buf);
				}
				return -1;
			}
			default: break;
		}

		//no errors:
		if(i >= 0)
		{
			int2units(buf, MAX_LEN, *varent[i].i, varent[i].ut);
			if(from) net.send(HAS_N, name, ": variable '", a, "' has been set to ", buf, NULL);
			userlist.nextSave = NOW + SAVEDELAY;
			return i;
		}
	}
	return -1;
}

int var::setvar(char *name, char *val, int *n)
{
	int i, v;

	if((i = getvar(name)) == -1)
		return -1;

	if(n) *n = i;

	if(units2int(val, varent[i].ut, v) != 1)
		return -2;

	if(v >= varent[i].from && v <= varent[i].to)
	{
		*varent[i].i = v;
		return i;
	}

	//out of range
	return -3;
}

int var::getvar(char *name)
{
	int i;
	for(i=0; i<ent; ++i)
		if(!strcmp(varent[i].name, name)) return i;
	return -1;
}

void var::addvar(char *name, int def, int *iptr, int a, int b, unit_table *ut)
{
 	varent = (VAR *) realloc(varent, (ent + 1) * sizeof(VAR));
	//mem_strcpy(varent[ent].name, name);
	varent[ent].name = name;
	varent[ent].i = iptr;
	*varent[ent].i = def;
	varent[ent].def = def;
	varent[ent].from = a;
	varent[ent].to = b;
	varent[ent].ut = ut;
	++ent;

	int len = strlen(name);
	if(len > align) align = len;
}

/* Constructors */
var::var()
{
	//printf(">> Var constructor\n");
}

settings::settings()
{
	align = ent = 0;
	varent = NULL;

	addvar("cycle-delay",			10, &CYCLE_DELAY, 			 0, 60,		 	ut_time);
	addvar("rejoin-delay",			 0, &REJOIN_DELAY, 			 0, 60, 		ut_time);
	addvar("rejoin-fail-delay",		25, &REJOIN_FAIL_DELAY,		 7, 60,		 	ut_time);
	addvar("hub-conn-delay",		20, &HUB_CONN_DELAY,		10, 3600,	 	ut_time);
	addvar("irc-conn-delay",		15, &IRC_CONN_DELAY,		10, 3600, 		ut_time);
	addvar("auth-time",				45, &AUTH_TIME,				15, 360, 		ut_time);
	addvar("private-ctcp",		 	 1, &PRIVATE_CTCP,			 0, 1);
	addvar("ops-per-mode",			 2, &OPS_PER_MODE,			 1, 3);
	addvar("ask-for-op-delay",		 4, &ASK_FOR_OP_DELAY,		 1, 60,		 	ut_time);
	addvar("getop-op-check",		 1, &GETOP_OP_CHECK,		 0, 1);
	addvar("conn-timeout",		   180, &CONN_TIMEOUT, 			15, 600,	 	ut_time);
    addvar("keep-nick-check-delay", 10, &KEEP_NICK_CHECK_DELAY,  5, 24*3600, 	ut_time);
	addvar("remember-old-keys",		 0, &REMEMBER_OLD_KEYS,		 0, 1);
	addvar("telnet-owners",			 1, &TELNET_OWNERS,			 0, 2);
	addvar("max-matches",			20, &MAX_MATCHES,			 0, MAX_INT);
	addvar("perip-max-shown-cons",	 6, &PERIP_MAX_SHOWN_CONNS,  0, MAX_INT);
	addvar("perip-burst-size",		30, &PERIP_BURST_SIZE,	 	 6, MAX_INT);
	addvar("perip-burst-time",		60,	&PERIP_BURST_TIME,		30, MAX_INT, 	ut_time);
	addvar("perip-ignore-time",		300,&PERIP_IGNORE_TIME,		 0, MAX_INT, 	ut_time);
	addvar("synflood-max-conns",	100,&SYNFLOOD_MAX_CONNS,	30, MAX_INT);
	addvar("synflood-ignore-time",	300,&SYNFLOOD_IGNORE_TIME,	 0, MAX_INT, 	ut_time);
	addvar("bIe-mode-bounce-time", 3600,&BIE_MODE_BOUNCE_TIME,	 0, MAX_INT, 	ut_time);
	addvar("wasop-cache-time",	   3000,&WASOP_CACHE_TIME,		 0, MAX_INT, 	ut_time);
	addvar("away-time",			 8*3600,&AWAY_TIME,		      3600, 24*3600, 	ut_time);
	addvar("chat-time",			 6*3600,&CHAT_TIME,			  3600, 24*3600, 	ut_time);
	addvar("between-msg-delay",	   5*60,&BETWEEN_MSG_DELAY,	    10, 2*3600, 	ut_time);
	addvar("randomness",		    -50,&RANDOMNESS,		  -100, 0,			ut_perc);
	addvar("public-away",		      0,&PUBLIC_AWAY,		  	 0, 1);
	addvar("ident-clones",			  3,&IDENT_CLONES,		     0, MAX_INT);
	addvar("host-clones",			  3,&HOST_CLONES,		     0, MAX_INT);
	addvar("proxy-clones",			  3,&PROXY_CLONES,		     0, MAX_INT);
	addvar("clone-life-time",	   	  0,&CLONE_LIFE_TIME,		 0, 24*7*3600,	ut_time);
	addvar("critical-bots",	   	      0,&CRITICAL_BOTS,		 	 0, MAX_INT);
	addvar("quarantine-time",	     15,&QUARANTINE_TIME,	 	 0, 120,		ut_time);
	addvar("backup-mode-delay",		  7,&BACKUP_MODE_DELAY,		 1, 60,			ut_time);
	addvar("dont-trust-ops",		  0,&DONT_TRUST_OPS,		 0, 2);
}

chanset::chanset()
{
	align = ent = 0;

	addvar("aop-bots", 			1,	 &AOP_BOTS,	 		-100, MAX_INT,	ut_perc);
	addvar("bot-aop-bots",		1,	 &BOT_AOP_BOTS, 	-100, MAX_INT,	ut_perc);
	addvar("punish-bots",		-30, &PUNISH_BOTS,		-100, MAX_INT,	ut_perc);
	addvar("getop-bots",		1,	 &GETOP_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("invite-bots",		2, 	 &INVITE_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("guardian-bots",		2, 	 &GUARDIAN_BOTS,	-100, MAX_INT,	ut_perc);
	addvar("channel-ctcp",		1, 	 &CHANNEL_CTCP, 	   0, 1);
	addvar("enforce-bans",		1, 	 &ENFORCE_BANS, 	   0, 2);
	addvar("enforce-limits",	1, 	 &ENFORCE_LIMITS,	   0, 1);
	addvar("stop-nethack",		1, 	 &STOP_NETHACK, 	   0, 1);
	addvar("limit",				1, 	 &LIMIT,			   0, 1);
	addvar("limit-time",		120, &LIMIT_TIME,		   1, MAX_INT, 	ut_time);
	addvar("limit-offset",		5, 	 &LIMIT_OFFSET,		   1, MAX_INT);
	addvar("limit-bots",		1, 	 &LIMIT_BOTS,		   1, 2);
    addvar("limit-tolerance",	-50, &LIMIT_TOLERANCE,	-100, MAX_INT,	ut_perc);
    addvar("owner-limit-time",	15,  &OWNER_LIMIT_TIME,	   0, 60, 		ut_time);
	addvar("takeover",			0,	 &TAKEOVER,			   0, 1);
	addvar("bitch",				1,	 &BITCH,			   0, 1);
	addvar("wasoptest",			1,	 &WASOPTEST,		   0, 1);
	addvar("clonecheck",		1,	 &CLONECHECK,		   0, 2);
	addvar("dynamic-bans",		1,	 &DYNAMIC_BANS,		   0, 1);
	addvar("dynamic-invites",	1,	 &DYNAMIC_INVITES,	   0, 1);
	addvar("dynamic-exempts",	1,	 &DYNAMIC_EXEMPTS,	   0, 1);
	addvar("lockdown",			1,	 &LOCKDOWN,			   0, 1);
	addvar("lockdown-time",	    3*60,&LOCKDOWN_TIME,	   0, MAX_INT,	ut_time);
	addvar("protect-chmodes",   1,   &PROTECT_CHMODES,     0, 2);
}

chanset::chanset(const chanset &chset)
{
	*this = chset;
}

prvset::prvset()
{
	align = ent = 0;
	varent = NULL;

	addvar("debug-show-irc-write", 			0,	 &debug_show_irc_write,	 		0, 3);
	addvar("debug-show-irc-read", 			0,	 &debug_show_irc_read,	 		0, 3);
}

/* Destruction derby */
void var::DestroyThisShit()
{
	/*
	while(--ent)
	{
		//printf(">> destructor: del %s\n", varent[ent-1].name);
		//free(varent[ent-1].name);
	}
	*/
	free(varent);
}

settings::~settings()
{
	DestroyThisShit();
}

chanset::~chanset()
{
	DestroyThisShit();
};

prvset::~prvset()
{
	DestroyThisShit();
};
