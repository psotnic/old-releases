settings set
time_t NOW
penal penalty
client ME
ul userlist
inet net