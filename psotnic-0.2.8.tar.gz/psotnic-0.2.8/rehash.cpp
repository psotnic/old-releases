/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

bool PrepareToRehash(const char *owner)
{
	//there are certain conditions that stop us from rehashing
	if(!ME.nick)
	{
		net.sendOwner(owner, "[-] Not connected to irc, no point of rehasing, use restart instead", NULL);
		return false;
	}

	if(net.irc.write.len || net.irc.read.len)
	{
		net.sendOwner(owner, "[-] Irc socket is busy at the moment, please try again later", NULL);
		return false;
	}

	chan *ch = ME.first;

	while(ch)
	{
		if(!ch->synced())
		{
			net.sendOwner(owner, "[-] Some of the channels are not synced, please wait a while and try again later", NULL);
			return false;
		}
		ch = ch->next;
	}

/*
#client save
:lublin.irc.pl 001 insmod :Welcome to the Internet Relay Network insmod!~modprobe@nat.riviera.pw.edu.pl
:lublin.irc.pl 002 insmod :Your host is lublin.irc.pl, running version 2.11.1a2
:lublin.irc.pl 042 insmod 616LAAQVS :your unique ID
:lublin.irc.pl 211 insmod insmod[@194.29.137.67] 0 29 2400 3 66 :0
:lublin.irc.pl 219 insmod L :End of STATS report

#channel save
:insmod!~modprobe@nat.riviera.pw.edu.pl JOIN :#psotnic

:lublin.irc.pl 332 insmod #psotnic :http://polibuda.info/~grusin (howto-en updated) | psotnic 0.2.3rc10 (fbsd4.11+ and
:lublin.irc.pl 333 insmod #psotnic pks!pks@nemezis.net 1113486671

:lublin.irc.pl 353 insmod = #psotnic :insmod mrcn- +Ven0m `Q @N3m0 +bajt rainy^ k__ +_Tomi007 bassta- +Flak` @linuksik
:lublin.irc.pl 366 insmod #psotnic :End of NAMES list.

:lublin.irc.pl 352 insmod #psotnic ~modprobe nat.riviera.pw.edu.pl lublin.irc.pl insmod H :0 Psotnic C++ Edition
:lublin.irc.pl 352 insmod #psotnic mrcn bc28.internetdsl.tpnet.pl warszawa.irc.pl mrcn- H :2 chaos theory in action.
:lublin.irc.pl 315 insmod #psotnic :End of WHO list.

:lublin.irc.pl 324 insmod #psotnic +tnl 55

:lublin.irc.pl 367 insmod #psotnic *!*Tiscali@*
:lublin.irc.pl 368 insmod #psotnic :End of Channel Ban List

:lublin.irc.pl 346 insmod #psotnic help!site@http://polibuda.info/~grusin
:lublin.irc.pl 347 insmod #psotnic :End of Channel Invite List

:lublin.irc.pl 348 insmod #psotnic *!gunman@z10n.tech.us.edu.pl
:lublin.irc.pl 349 insmod #psotnic :End of Channel Exception List

:lublin.irc.pl 344 insmod #psotnic *!gunman@z10n.tech.us.edu.pl
:lublin.irc.pl 345 insmod #psotnic :End of Channel Reop List
*/

	pstring<65536> irc;

	#define IRC(x) irc = irc + ":" + (const char *) net.irc.origin + " " + x + " " + ME.nick + " "

	IRC("001") + ":Welcome to the Internet Relay Network " + ME.mask + "\n";
	if(net.irc.status & STATUS_211)
		IRC("002") + ":Your host is lublin.irc.pl, running version 2.11.1\n";

	IRC("042") + ME.uid + " :your unique ID\n";
	IRC("211") + ME.nick + "[@" + ME.ircip + "]\n";
	IRC("210") + "L :End of STATS report\n";

	ch = ME.first;

	while(ch)
	{
		irc = irc + ":" + ME.mask + " JOIN " + ch->name + "\n";
		if(ch->topic)
			IRC("332") + ch->name + " " + ch->topic + "\n";

		ptrlist<chanuser>::iterator i = ch->users.begin();
		while(i)
		{
			IRC("352") + ch->name + " " + (const char *) i->ident + " " + (const char *) i->host + "foo.bar.com " + (const char *) i->nick +
				(i->flags & IS_OP ? "H@" : (i->flags & IS_VOICE ? "H+" : "H")) + " :0\n";
			i++;
		}
		IRC("315") + ch->name + " :End of NAMES list.\n";

	}


	#undef IRC
	return 1;
}
