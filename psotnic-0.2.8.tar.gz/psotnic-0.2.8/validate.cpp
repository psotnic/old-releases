/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"
#include "validate.h"

void validate()
{
	int fd;
	int ok = 0;

	if((fd = open(thisfile, O_RDONLY)) > 0)
	{
		struct stat file;

		if(stat(thisfile, &file) == 0)
		{
			int n, i;

			char *data;
			unsigned char digest[32];
			ok = 1;

			data = (char *) malloc(file.st_size);
			if(read(fd, data, file.st_size) == file.st_size);
			{
				memcpy(&n, &FileMD5[32], 4);

				MD5Hash(&digest[0], data, n, Key, sizeof(Key)-1);
				MD5Hash(&digest[16], data+n+36, file.st_size-n-36, Key, sizeof(Key)-1);

				for(i=0; i<32; ++i)
				{
					if(FileMD5[i] != digest[i])
					{
					    ok = 0;
					    break;
					}
				}
			}
			free(data);
		}
		close(fd);
	}

	if(!ok)
	{
		printf("[*] MD5 digest based file protector 0.0.3\n");
		printf("[*] Copyright (C) 2003-2005 Grzegorz Rusin <grusin@gmail.pl>\n");
		printf("[-] Screw you guys, this file is hacked\n");
		exit(1);
	}
	else return;

	exit(1);
}
