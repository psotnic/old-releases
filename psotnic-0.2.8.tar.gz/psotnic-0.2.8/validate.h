#ifndef PKS_VALIDATE_H
#define PKS_VALIDATE_H 1

static unsigned char FileMD5[] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXYYYY";
static unsigned char Key[] = "��j�1�]:A��o��UT.Kl/�";

#endif

