extern int errno;

long int nanotime()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_usec;
}
