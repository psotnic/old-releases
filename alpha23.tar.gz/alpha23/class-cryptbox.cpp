/**********r****************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int cryptBox::init(unsigned char *str, int len)
{
	key = (unsigned char *) malloc(len);
	if(!key) return 0;

	MD5Init(&md5);
	memcpy(key, str, len);
	keyLen = len;
	offset = 0;
	return 1;
}

void cryptBox::encode(unsigned char *in, unsigned char *out, int len)
{
	int i, j;
	unsigned char buf[64], p;
	
	for(i=0; ;i+=64)
	{
		memset(buf, 0, 64);
		j = len - i;
		if(j > 64) j = 64;
		memcpy(buf, in, j);
		MD5Update(&md5, in, j);
		if(j != 64) break;
	}

	for(i=0; i<len; ++i)
	{
		offset %= keyLen;
		p = key[offset++];

		for(i=0; i<8; ++i, ++p)
		{
			p %= keyLen;
			h += key[p];
		}
		out[i] = in[i] + h;
	}
}

void cryptBox::final(unsigned char *hash)
{
	MD5Final(hash, &md5);
}
