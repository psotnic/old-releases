/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/* Network Connection Handling */

inet::inet()
{
	conn = (inetconn *) malloc(sizeof(inetconn));
	memset(&conn[0], 0, sizeof(inetconn));
	max_conns = 1;
	owners = bots = unreg = conns = 0;
}


void inet::resize()
{
	if(max_conns == conns)
	{
		int size = max_conns * 2;
		int i;

		conn = (inetconn *) realloc(conn, size*sizeof(inetconn));
		for(i=max_conns; i<size; ++i) memset(&conn[i], 0, sizeof(inetconn));
		max_conns = size;
		if(set.debug) printf("max_conns: %d\n", max_conns);
	}
	else if(conns == max_conns / 4 && conns > 4)
	{
		max_conns /= 2;
		conn = (inetconn *) realloc(conn, max_conns*sizeof(inetconn));
		if(set.debug) printf("max_conns: %d\n", max_conns);
	}
}


inetconn *inet::addConn(int fd)
{
	int i;

	resize();
	for(i=0; i<max_conns; ++i)
	{
        if(conn[i].fd < 1)
		{
			memset(&conn[i], 0, sizeof(inetconn));
            conn[i].fd = fd;
			conn[i].status = STATUS_CONNECTED;
	        ++conns;
            return &conn[i];
        }
    }
	return NULL;
}

inetconn *inet::findConn(char *name)
{
	int i;

	for(i=0; i<max_conns; ++i)
		if(conn[i].fd> 0 && !strcmp(conn[i].name, name)) return &conn[i];
	return NULL;
}	

void inet::closeConn(int fd)
{
	int i;
	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].fd == fd)
		{
			conn[i].close();
			if(i != conns)
			{
				conn[i] = conn[conns];
				memset(&conn[conns], 0, sizeof(inetconn));
			}
			resize();
		}
	}
}

void inet::send(int who, char *lst, ...)
{
	va_list ap;
	int i;
	
	va_start(ap, lst);

	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].status & STATUS_REGISTERED && conn[i].status & who)
			conn[i].va_send(ap, lst);
	}

}
/* Specific Internet Connection Handling */

inetconn::inetconn()
{
	//memset(this, 0, sizeof(inetconn));
}

void inetconn::close()
{
	if(this == &net.irc)
	{
		putlog("[-] Disconnected from IRC (%s)\n", strerror(errno));
		ME.reset();
	}
	else if (this == &net.hub)
	{
		if(net.hub.status & STATUS_CONNECTED) putlog("[-] Disconnected from HUB (%s)\n", strerror(errno))
		else putlog("[-] Cannot establish connection to HUB (%s)\n", strerror(errno))
	}
	else 
	{
		int n = status;
		char *error;
		status = 0;
		
		if(errno) error = strerror(errno);
		else mem_strcpy(error, "EOF from client");
		
		putlog("[*] Closing net.conn[%d] (%s, %s, %s)\n", this - &net.conn[0], name, origin, error);

		if(n & STATUS_REGISTERED)
		{
			if(n & STATUS_OWNER)
			{
				net.send(FD_OWNERS, "*** ", name, " has left the partyline (", error, ")", NULL);
				--net.owners;
			}
			else if(n & STATUS_BOT)
			{
				net.send(FD_OWNERS, "*** ", name, " has left the botnet (", error, ")", NULL);
				--net.bots;
			}
			if(!errno) free(error);
		}
	}
		
	if(read.buf) free(read.buf);
	if(write.buf) free(write.buf);
	if(name) free(name);
	if(tmpstr) free(tmpstr);
	if(origin) free(origin);
	killSocket(fd);
	memset(this, 0, sizeof(inetconn));
}

int inetconn::va_send(va_list ap, char *lst)
{
	//if(fd < 1) return -1;

	int size = va_getlen(ap, lst) + 3;
	char *p = va_push(NULL, ap, lst, size);

	p[size-3] = '\r';
	p[size-2] = '\n';
	p[size-1] = '\0';
	size--;

	if(set.debug) printf("[*] send[%s]: %s", name ? name : origin, p);
	if(write.buf)
	{
		write.buf = (char *) realloc(write.buf, write.len + size);
		memcpy(write.buf + write.len, p, size);
		write.len += size;
	}
	else
	{
		int n = ::write(fd, p, size);
		if(n == -1) n = 0;
		if(n != size)
		{
			write.len = size-n;
			write.pos = 0;
			write.buf = (char *) malloc(size-n);
			memcpy(write.buf, p+n, size-n);
		}
	}
	free(p);
	return size;
}

int inetconn::send(char *lst, ...)
{
    va_list ap;
	int n;

	va_start(ap, lst);
	n = va_send(ap, lst);
	va_end(ap);
	return n;
}

int inetconn::readln(char *buf, int len)
{
	int n;

	//if(fd < 1) return -1;
	if(::read(fd, buf, 1) > 0)
	{
		if(buf[0] == ':' && this == &net.irc) return 0;
		if(buf[0] == '\n' || buf[0] == '\0')
		{
			if(read.buf)
			{
				n = read.len;
				strncpy(buf, read.buf, n);
				if(n && buf[n-1] == '\r') buf[n-1] = '\0';
				else buf[n] = '\0';
				free(read.buf);
				memset(&read, 0, sizeof(read));
			}
			else n = 1;
			if(set.debug) printf("[*] read[%s]: %s\n", name ? name : origin, buf);
				
			return n;

		}
		else
		{
			if(!read.buf)
			{
				read.buf = (char *) malloc(len);
				read.buf[0] = buf[0];
				read.len = 1;
			}
			else
			{
				read.buf[read.len++] = buf[0];

				if(read.len == MAX_LEN - 1)
				{
					//buffer overflow attempt
					//free(read.buf);
					//memset(&read, 0, sizeof(read));
					putlog("[!] Buffer overflow attempt from %s (%s:%d)\n", name, getpeerip(fd), getpeerport(fd));
					return -1;
				}
			}
			return 0;
		}
	}
	return -1;
}

int inetconn::IsRegBot()
{
	return status & STATUS_BOT && status & STATUS_REGISTERED;
}

int inetconn::IsRegOwner()
{
	return status & STATUS_OWNER && status & STATUS_REGISTERED;
}

int inetconn::sendPing()
{
	if(lastPing && NOW - lastPing > set.PING_TIMEOUT / 3)
	{
		send(S_FOO, NULL);
		lastPing = NOW;
		return 1;
	}
	return 0;
}

int inetconn::timedOut()
{
	if(killTime && killTime <= NOW)
	{
		errno = ETIMEDOUT;
		close();
		return 1;
	}
	sendPing();
	return 0;
}
