class inetconn
{
	public:
    int fd;
    int status;
	char *name;
	char *pass;
	char *origin;
	char *tmpstr;
	int tmpint;
	int killTime;
	int lastPing;

	IOBUF read;
	IOBUF write;

	USER_HANDLE *handle;
	
	int send(char *lst, ...);
	int va_send(va_list ap, char *lst);
	int readln(char *buf, int len);
	void close();

	int IsRegBot();
	int IsRegOwner();

	int sendPing();
	int timedOut();
	inetconn();
};

class inet
{
	private:
	void resize();
	
	public:
	int conns, max_conns, listenfd, owners, bots, unreg;
	inetconn *conn, hub, irc;

	inetconn *addConn(int fd);
	inetconn *findConn(char *name);
	void closeConn(int fd);
	void send(int who, char *lst, ...);

	inet();
	//~inet();
};

class var
{
	public:
	int ent;
 	VAR *varent;

	void addvar(char *name, int def, int *iptr, int a, int b);
	void reset();
	int getvar(char *name);
	int setvar(char *name, char *val);
	int parseuser(inetconn *c, char *name, char *a, char *b);

	var();
	inline void DestroyThisShit();
};

class settings : public var
{
	public:
	int NO_PRIVATE_CTCP;
	int ACTION_PENALITY;
	int FRIEND_ACTION_PENALITY;
	int CYCLE_DELAY;
	int REJOIN_DELAY;
	int REJOIN_FAIL_DELAY;
	int HUB_CONN_DELAY;
	int IRC_CONN_DELAY;
	int AUTH_TIME;
	int OPS_PER_MODE;
	int ASK_FOR_OP_DELAY;
	int PING_TIMEOUT;
	int KEEP_NICK_CHECK_DELAY;
	int SAVE_NICK;
	int REMEMBER_OLD_KEYS;
	int TELNET_OWNERS;
	
	int debug;
	int creation;

	settings();
	~settings();
};

class chanset : public var
{
	public:
	int AUTOOP_BOTS;
	int BOT_AUTOOP_BOTS;
	int PUNISH_BOTS;
	int UNBAN_BOTS;
	int INVITE_BOTS;
	int SHIT_BOTS;
	int LIMIT_CHAN_USERS;
	int LIMIT_UPDATE_TIME;
	int LIMIT_UPDATE_BY;
	int LIMIT_UPDATE_BOTS;
	int NO_GLOBAL_CTCP;
	int ENFORCE_BANS;
	int ENFORCE_LIMITS;
	int STOP_NETHACK;
	int GETOP_BOTS;
	int PROTECT_MODE_BOTS;
	int OWNER_LIMIT_KEEP;
	
	chanset();
	~chanset();
};

struct CHANLIST
{
	char *name;
	char *pass;
	chanset *chset;
	int joinsent;
	int nextjoin;
};

class ptrlist
{
	public:
	PTRLIST *first;
	int ent;

	PTRLIST *GetItem(int num);
	void SortAdd(CHANUSER *ptr);
	//void Add(CHANUSER *u);
	//int Remove(char *nick);
	int Find(CHANUSER *ptr);
	int Remove(CHANUSER *ptr);
	//CHANUSER *Find(char *name);
	void Display();


	/* Constructor */
	ptrlist();

	/* Destruction derby */
	~ptrlist();
	void reset();
};

class stringlist
{
	public:
	STRINGLIST *first, *last;
	int ent;

	int Remove(char *str, int num);
	STRINGLIST *Add(char *a, char *b, char *c, int status);
	STRINGLIST *Find(char *str, int num);
	STRINGLIST *Find(char *a, char *b, char *c);
	STRINGLIST *WildFind(char *str, int num);

	void Display();

	/* Constructor */
	stringlist();

	/* Destruction derby */
	~stringlist();
	void Destroy(STRINGLIST *p);
};

class chan
{
   	public:
	ptrlist ToOp, BotsToOp, OpedBots, ToKick;
	stringlist ToBan;
	CHANUSER *first, *last, *ptr;
	chan *next, *prev;
	char *name, *BanOverride, *modes, *key;
	int users, status, limit, channum, nextlimit;
	chanset *chset;
	time_t InitialOp;
	
	/* Actions */
	void Op(CHANUSER **MultHandle, int num);
	void Op(CHANUSER *p, unsigned int hash);
	void Op(CHANUSER *p);
	void DeOp(CHANUSER *p, unsigned int hash);
	void DeOp(CHANUSER *p);
	void Kick4(CHANUSER **MultHandle, int num);
	void Kick6(CHANUSER **MultHandle, int num);
	void Kick(CHANUSER *p, unsigned int hash, char *reason);
	void Kick(CHANUSER *p, char *reason);
	void KickBan(CHANUSER *p, char *mask, char *reason);
	void Unban(char *str, unsigned int hash);
	int Invite(char *nick, int f);
	void EnforceLimits();
	void AskForOp();
	void UpdateLimit();
	void UpdateKey(char *newkey);
	int massKick(int who);
	
	/* Got something */
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *mask);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick, int quit);
	int GotBan(char *ban, CHANUSER *caster);
	CHANUSER *GotJoin(char *mask, int op);
	CHANUSER *GetUser(char *nick);

	/* other */
	void RecheckFlags();
	void QuoteBots(char *str);
	int QuoteOpedBots(char *str, int num);
	void ReOp();
	void Rejoin(int t);
	int NumberOfBots(int num);
	int chops();
	int synced();
	

	/* Debug */
	void Display();

	/* Constructor */
	chan();

	/* Destruction derby */
	~chan();
	void Destroy(CHANUSER *p);
	void RemoveFromAllPtrLists(CHANUSER *handle);
};

class client
{
	public:
	chan *first, *last, *current;
	int channels, nextconn_hub, nextconn_serv, nextjoin, status;
	char *nick, *ident, *host, *mask;
	time_t NextAction, NextMsg, KillTime, NextNickCheck, startedAt;

	/* Irc chanels */
	chan *CreateNewChannel(char *name);
	chan *FindChannel(char *name);
	chan *FindNotSyncedChannel(char *name);
	void RemoveChannel(char *name);
	void GotUserQuit(char *mask);
	void RecheckFlags();
	void RecheckFlags(char *channel);
	void Rejoin(char *name, int t);
	void RejoinCheck();
	void ScheludeJoinToAllChannels();
	void GotNickChange(char *from, char *to);
	void CheckQueue();

	/* Nick stuff */
 	void RegisterWithNewNick(char *nick);

	/* Net */
	int ConnectToIRC();
	int ConnectToHUB();
	void BotNetInvite(char *channel, char *nick);

	/* Debug */
	void Display();

	/* Constructor */
	client();

	/* Destruction derby */
	~client();
	void reset();
};

class ul
{
	public:
	USER_HANDLE *first, *last;
	BOT_HANDLE *Bfirst, *Blast;
	CHANLIST chanlist[MAX_CHANNELS];
	int ent, bots, ulbuflines;
	unsigned long long int SN; // ;-)
	char *ulbuf, bighash[8192];
	time_t nextSave;
	
	/* User Handle */
	USER_HANDLE *AddHandle(char *name);
	USER_HANDLE *FindHandle(char *name);
	int RemoveHandle(char *name);
	int userLevel(USER_HANDLE *h, int n);
	int emptyFlags(USER_HANDLE *h);

	/* Bot Handle */
	BOT_HANDLE *AddBot(char *mask, char *ip, char *pass);
	BOT_HANDLE *FindBot(char *mask);
	int RemoveBot(char *mask);

	/* Host */
	int AddHost(USER_HANDLE *p, char *host);
	int FindHost(USER_HANDLE *p, char *host);
	int RemoveHost(USER_HANDLE *p, char *host);
	int matchHost(USER_HANDLE *p, char *host);
	USER_HANDLE *matchMaskToHandle(char *mask);

	/* Flags */
	int ChangeFlags(USER_HANDLE *p, char *flags, int channum);
	int ChangeFlags(char *name, char *flags, char *channel);
	int ChangeFlags(inetconn *c, char *name, char *flags, char *channel);
	int GetFlags(char *mask, chan *ch);
	void flags2str(int flags, char *str);
	int IsOwner(char *mask);
	int IsBot(char *ip);
	int IsIdiot(char *mask, int channum);

	/* Channels */
	int AddChannelToList(char *name, char *pass);
	int RemoveChannelFromList(char *name);
	int FindChannelInList(char *name);
	int GlobalChset(inetconn *c, char *var, char *value);

	/* other */
	int Save(char *file);
	int Load(char *file);
	void Update();
	void Send(inetconn *c);
	char *CheckBotMD5Digest(char *ip, char *digest, char *authstr);
	USER_HANDLE *checkOwnerPass(char *username, char *pass);
	USER_HANDLE *changePass(char *user, char *pass);
	void setHashedPassword(char *user, char *md5hash);
	int hasWriteAccess(inetconn *c, char *handle);
	USER_HANDLE *matchPassToHandle(char *pass, char *host, int flags);
	void autoSave();
	void sendUsers(inetconn *c);


	/* Constructor */
	ul();

	/* Destruction derby */
	~ul();
	void reset();
	void Destroy(USER_HANDLE *p);
	void Destroy(BOT_HANDLE *p);
	void Destroy(CHANLIST *p);
};

class cryptBox
{
	private:
	unsigned char h;
	int offset;
		
	public:
	unsigned char *key;

	int keyLen;
	MD5_CTX md5;

	int init(unsigned char *str, int len);
	//void hexInit(char *str);
	void encode(unsigned char *in, unsigned char *out, int len);
	void decode(unsigned char *in, unsigned char *out, int len);
	void final(unsigned char *hash);
};

/*
class dns
{
	public:
	int resfd;

	void SendQuery(char *domain, int type);
	void ParsePacket(char *packet, int len); //fsck .. :P
	void RecvPacket();
	int VerifyPacket(char *packet, int len, sockaddr_in *from, socklen_t *fromlen);

	// Constructor
	dns();
};


class partyline
{
	private:
	void BotPart(array <SOCK> *ary, int fd);
	void BotPart(array <SOCK> *ary, char *name);
	
	public:
	array <SOCK> UpLinkBots, DownLinkBots, MyBots, MyOwners;
	int bots, owners;

	void BotConnected(int fd);
	void BotJoin(SOCK *s, char *name, char *server, int fromfd);
	SOCK *BotFind(char *name, int where);
	SOCK *BotFind(int fd, int where);
	void BotPart(int fd);
	void BotPart(char *name);
	void OwnerJoin(int fd, char *nick, int status);
	void OwnerPart(int fd);
	
	//Constructor
	partyline();

};

*/
