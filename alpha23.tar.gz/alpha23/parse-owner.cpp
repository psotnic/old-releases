/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_owner(inetconn *c, char *data)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	USER_HANDLE *h;
	STRINGLIST *sl;
	BOT_HANDLE *b;
	int i, n;

	if(!strlen(data)) return;
	memset(buf, 0, MAX_LEN);
	str2words(arg[0], data, 10, MAX_LEN);

	/* NOT REGISTERED OWNER */
	if(!(c->status & STATUS_REGISTERED))
	{
		if(!(c->status & STATUS_TELNET))
		{
			switch(c->tmpint)
			{
				case 1:
				{
					if(MD5HexValidate(config.ownerpass, arg[0], strlen(arg[0]), 0, 0))
					{
						c->killTime = NOW + set.AUTH_TIME;
						++c->tmpint;
						c->send("Enter user password: ", NULL);
					}
					else
					{
						net.send(FD_OWNERS, "!!! Invalid owner password supplied by ", c->origin, NULL);
						putlog("[!] %s supplied bad owner password\n", c->origin);
						c->close();
					}
					return;
				}
				case 2:
				{
					if(strlen(arg[0]) && (h = userlist.matchPassToHandle(arg[0], c->origin, HAS_N)))
					{
						c->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_OWNER;
						if(h->flags[MAX_CHANNELS] & HAS_S) c->status += STATUS_SUPERMAN;
						c->tmpint = 0;
						c->killTime = 0;
						++net.owners;
						c->handle = h;
						mem_strcpy(c->name, h->name);
						SendLogo(c);
					}
					else
					{
						net.send(FD_OWNERS, "!!! Invalid user password supplied by ", c->origin, NULL);
						putlog("[!] %s supplied bad owner password\n", c->origin);
						c->close();
					}
					return;
				}
				default: break;
			}
		}
		else
		{
			switch(c->tmpint)
			{
				case 1:
				{
					mem_strcpy(c->name, arg[0]);
					++c->tmpint;
					write(c->fd, "password: ", strlen("password: "));
					return;
				}

				case 2:
				{
					if((h = userlist.checkOwnerPass(c->name, arg[0])))
					{
						c->status = STATUS_CONNECTED + STATUS_OWNER + STATUS_REGISTERED;
						if(h->flags[MAX_CHANNELS] & HAS_S) c->status += STATUS_SUPERMAN;
						c->tmpint = 0;
						c->killTime = 0;
						mem_strcpy(c->origin, getpeerip(c->fd));
						++net.owners;
						SendLogo(c);
						return;
					}
					break;
					
				}
				default: break;
			}
			putlog("[-] Telnet user %s (%s:%d) failed to authorize\n", c->name, getpeerip(c->fd), getpeerport(c->fd));
			c->close();
			return;
		}
		bk();
		putlog("parse-owner::Code is screwed up\n");
		exit(1);
		return;
	}

	/* REGISTERED OWNER */

	/* small hack */
	//c->status -= STATUS_OWNER;
	if(arg[0][0] != '.')
	{
		net.send(FD_OWNERS, "\002<\002", c->name, "\002>\002 ", data, NULL);
	}
	else
	{
		struct tm *ltime= localtime(&NOW);
		strftime(buf, MAX_LEN, "[\002%H\002:\002%M\002] ", ltime);
		
		if((!strcmp(arg[0], ".passwd") || !strcmp(arg[0], ".chpass")) && strlen(arg[2]))
		{
			net.send(FD_OWNERS, buf, "\002#\002", c->name, "\002#\002 ", arg[0]+1, " ", arg[1], " [something]", NULL);
		}
		else if(!strcmp(arg[0], ".+bot") && strlen(arg[2]))
		{
			net.send(FD_OWNERS, buf, "\002#\002", c->name, "\002#\002 ", "+bot ", arg[1], "[something] [something]", NULL);
		}
		else
		{
			net.send(FD_OWNERS, buf, "\002#\002", c->name, "\002#\002 ", data+1, NULL);
		}
	}
	//c->status += STATUS_OWNER;

	/* big hack ;-) */
	if(!strcmp(arg[0], ".bye"))
	{
		a = srewind(data, 1);
		if(!a) a = arg[0] + 1;
		net.send(FD_OWNERS, "*** ", c->name, " has left the partyline (", a, ")", NULL);
		c->status = 0;
		c->close();
		--net.owners;
		return;
	}
	if(!strcmp(arg[0], ".+user") && strlen(arg[1]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			c->send("Please add bots via .+bot command", NULL);
			return;
		}
		if(userlist.AddHandle(arg[1]))
		{
			c->send("Adding user '", arg[1], "'", NULL);
			net.send(FD_BOTS, S_ADDUSER, " ", arg[1], NULL);
			++userlist.SN;
		}
		else c->send("User '", arg[1], "' allready exists", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-user") && strlen(arg[1]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			c->send("Please remove bots via .-bot command", NULL);
			return;
		}
		if(!strcasecmp(arg[1], "idiots") || !strcasecmp(arg[1], userlist.first->next->name))
		{
			c->send("This user is immortal", NULL);
			return;
		}
		switch(userlist.hasWriteAccess(c, arg[1]))
		{
			case -1:
			{
				c->send("User '", arg[1], "' does not exist", NULL);
				break;
			}
			case 0:
			{
				c->send(S_NOPERM, NULL);
				break;
			}
			case 1:
			{
				userlist.RemoveHandle(arg[1]);
				c->send("Removing user '", arg[1], "'", NULL);
				net.send(FD_BOTS, S_RMUSER, " ", arg[1], NULL);
				ME.RecheckFlags();
				++userlist.SN;
				break;
			}
		}
		return;
	}
	if(!strcmp(arg[0], ".users"))
	{
		if(userlist.ent == 1) c->send("No users in userlist", NULL);
		else userlist.sendUsers(c);
		return;
	}
	if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			c->send("Please add bots via .+bot command", NULL);
			return;
		}
		if(!extendhost(arg[2], buf, MAX_LEN))
		{
			c->send("Invalid hostname", NULL);
			return;
		}
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.hasWriteAccess(c, arg[1]) == 1)
			{
				if(userlist.AddHost(h, buf) != -1)
				{
					c->send("Adding host '", buf, "' to user '", arg[1], "'", NULL);
					net.send(FD_BOTS, S_ADDHOST, " ", arg[1], " ", buf, NULL);
					ME.RecheckFlags();
					++userlist.SN;
				}
				else c->send("Host '", buf, "' exists", NULL);
			}
			else c->send(S_NOPERM, NULL);
		}
		else c->send("User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-host") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			c->send("Please remove bots via .-bot command", NULL);
			return;
		}
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.hasWriteAccess(c, arg[1]) == 1)
			{
				if(userlist.RemoveHost(h, arg[2]) != -1)
				{
					c->send("Removing host '", arg[2], "' from user '", arg[1], "'", NULL);
					net.send(FD_BOTS, S_RMHOST, " ", arg[1], " ", buf, NULL);
					ME.RecheckFlags();
					++userlist.SN;
				}
				else c->send("Host '", arg[2], "' does not exists", NULL);
			}
			else c->send(S_NOPERM, NULL);
		}
		else c->send("User '", arg[1], "' does not exist", NULL);
		return;
	}
	if((!strcmp(arg[0], ".match") || !strcmp(arg[0], ".whois") || !strcmp(arg[0], ".wi")) && strlen(arg[1]))
	{
		if(strcasecmp(arg[1], "bot"))
		{
			h = userlist.FindHandle(arg[1]);
			if(h)
			{
				userlist.flags2str(h->flags[MAX_CHANNELS], buf);
				c->send("Global flags: ", buf, NULL);
				if(!isNullString(h->pass, AUTHSTR_LEN)) c->send("Password is set", NULL);
				else c->send("No password set", NULL);
				a = push(NULL, "Channel flags: ", NULL);
				for(n=i=0; i<MAX_CHANNELS; ++i)
				{
					if(h->flags[i] && userlist.chanlist[i].name)
					{
						userlist.flags2str(h->flags[i], buf);
						if(!n) a = push(a, userlist.chanlist[i].name, ": ", buf, NULL);
						else a = push(a, ", ", userlist.chanlist[i].name, ": ", buf, NULL);
						++n;
					}
				}
				if(n) c->send(a, NULL);
				free(a);
				for(i=0, n=0; i<MAX_HOSTS; i++)
				{
					if(h->host[i] != NULL)
					{
						sprintf(buf, "[#%d]: ", ++n);
						c->send(buf, h->host[i], NULL);
					}
				}
				if(!n) c->send("No hosts has been found", NULL);
			}
			else c->send("User '", arg[1], "' does not exist", NULL);
		}
		else
		{
			if(!(c->status & STATUS_SUPERMAN))
			{
				c->send(S_NOPERM, NULL);
				return;
			}
			if(userlist.bots)
			{
				c->send("Found following bots (mask/ip/pass):", NULL);
				b = userlist.Bfirst;
				n = 0;
				while(b)
				{
					sprintf(buf, "[#%d]: ", ++n);
					c->send(buf, b->mask, " ", b->ip, " ", b->pass, NULL);
					b = b->next;
				}
			}
			else c->send("No bot entries has been found", NULL);
		}
		return;
	}
	if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			c->send("Changing bot flags is forbiden", NULL);
			return;
		}
		n = userlist.ChangeFlags(c, arg[1], arg[2], arg[3]);
		switch(n)
		{
			case -1: c->send("Invalid handle", NULL);
			return;

			case -2: c->send("Invalid channel", NULL);
			return;

			case -3: c->send("Main owner *must* be +ns", NULL);
			return;

			case -4: c->send("`aofm' are *only* valid channel flags", NULL);
			return;

			case -5: c->send(S_NOPERM, NULL);
			return;

			default: break;
		}
		userlist.flags2str(n, buf);
		if(strlen(arg[3]))
		{
			c->send("Changing ", arg[3], " flags for '", arg[1], "' to '", buf, "'", NULL);
			net.send(FD_BOTS, S_CHATTR, " ", arg[1], " ", arg[2], " ", arg[3], NULL);
			ME.RecheckFlags(arg[3]);
		}
		else
		{
			c->send("Changing global flags for '", arg[1], "' to '", buf, "'", NULL);
			net.send(FD_BOTS, S_CHATTR, " ", arg[1], " ", arg[2], NULL);
			ME.RecheckFlags();
		}
		++userlist.SN;
		return;
	}
	if((!strcmp(arg[0], ".+chan") || !strcmp(arg[0], ".mjoin")) && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(arg[1][0] != '#' && arg[1][0] != '+' && arg[1][0] != '&' && arg[1][0] != '!')
		{
			c->send("Invalid channel name", NULL);
			return;
		}
		n = userlist.AddChannelToList(arg[1], arg[2]);
		if(n == -2)
		{
			c->send("Changing password for channel '", arg[1], "' to '", arg[2], "'", NULL);
			net.send(FD_BOTS, S_ADDCHAN, " ", arg[1], " ", arg[2], NULL);
		}
		else if(n > -1)
		{
			c->send("Channel '", arg[1], "' has been added to channel list", NULL);
			n = atoi(arg[3]);
			if(n < 0)
			{
				n *= -1;
				sprintf(arg[3], "%d", n);
				net.send(FD_BOTS, S_ADDCHAN, " ", arg[1], " ", arg[2], " ", arg[3], NULL);
				ME.Rejoin(arg[1], n);
				c->send("Delaying mass join by ", arg[3], " seconds", NULL);
			}
			else if(n > 0)
			{
				int j = n;
				for(i=0; i<net.max_conns; ++i)
				{
					if(net.conn[i].IsRegBot())
					{
						sprintf(buf, "%d", j);
						net.conn[i].send(S_ADDCHAN, " ", arg[1], " ", arg[2], " ", buf, NULL);
						j += n;
					}
				}
				c->send("Setting delay between bots joins to ", arg[3], " seconds", NULL);
				ME.Rejoin(arg[1], 0);
			}
			else
			{
				net.send(FD_BOTS, S_ADDCHAN, " ", arg[1], " ", arg[2], NULL);
				ME.Rejoin(arg[1], 0);
			}
			++userlist.SN;
		}
		else if(n == -1) c->send("Channel exists in channel list", NULL);
		else c->send("Maximum number of channels joined", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-chan") || !strcmp(arg[0], ".mpart") && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.RemoveChannelFromList(arg[1]))
		{
			c->send("Channel '", arg[1], "' removed from channel list", NULL);
			net.send(FD_BOTS, S_RMCHAN, " ", arg[1], NULL);
			net.irc.send("PART ", arg[1], " :", config.partreason, NULL);
			++userlist.SN;
		}
		else c->send("Channel does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".+bot") && strlen(arg[3]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(!extendhost(arg[1], buf, MAX_LEN))
		{
			c->send("Invalid hostname", NULL);
			return;
		}
		if((inet_addr(arg[2]) == INADDR_NONE || !match(arg[2], "*.*.*.*")) && strcmp(arg[2], "-"))
		{
			c->send("Invalid IPv4 address", NULL);
			return;
		}
		if(userlist.AddBot(buf, arg[2], arg[3]))
		{
			c->send("Adding new bot ", buf, NULL);
			net.send(FD_BOTS, S_ADDBOT, " ", buf, " ", S_UNKNOWN, " ", S_UNKNOWN, NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else c->send("Mask '", buf, "' allready appears in userlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-bot") && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.RemoveBot(arg[1]))
		{
			c->send("Removing bot '", arg[1], "'", NULL);
			net.send(FD_BOTS, S_RMBOT, " ", arg[1], NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else c->send("Host '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".channels"))
	{
		for(n=i=0; i<MAX_CHANNELS; i++)
		{
			if(userlist.chanlist[i].name)
			{
				if(!n) a = push(NULL, userlist.chanlist[i].name, NULL);
				else a = push(a, ", ", userlist.chanlist[i].name, NULL);
				if(strlen(userlist.chanlist[i].pass)) a = push(a , " (key: ", userlist.chanlist[i].pass, ")", NULL);
				++n;
			}
		}
		if(n) c->send("Channels: ", a, NULL);
		else c->send("No channels found", NULL);
		return;
	}
	if(!strcmp(arg[0], ".save"))
	{
		userlist.Save(config.userlist_file);
		c->send("Saving userlist", NULL);
		net.send(FD_BOTS, S_ULSAVE, NULL);
		return;
	}
	if(!strcmp(arg[0], ".bots"))
	{
		if(net.bots)
		{
			a = NULL;
			for(i=0; i<net.max_conns; ++i)
				if(net.conn[i].IsRegBot())
					a = push(a, net.conn[i].name, " ", NULL);

		sprintf(buf, "%d", net.bots);
		c->send("Bots on-line(", buf, "): ", a, NULL);
		free(a);
		}
		else c->send("All bots are down", NULL);
		return;
	}
	if(!strcmp(arg[0], ".owners"))
	{
		a = NULL;
		for(i=0; i<net.max_conns; ++i)
		{
			if(net.conn[i].IsRegOwner())
				a = push(a, net.conn[i].name, " ", NULL);
		}
		sprintf(buf, "%d", net.owners);
		c->send("Owners on-line(", buf, "): ", a, NULL);
		if(a) free(a);
		return;
	}
	if(!strcmp(arg[0], ".set"))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		i = set.parseuser(c, "set", arg[1], arg[2]);
		if(i > -1)
		{
			net.send(FD_BOTS, S_SET, " ", arg[1], " ", arg[2], NULL);
			++userlist.SN;
		}
		return;
	}
	if((!strcmp(arg[0], ".chset") || !strcmp(arg[0], ".chanset")) && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		i = userlist.FindChannelInList(arg[1]);
		if(i != -1)
		{
			n = userlist.chanlist[i].chset->parseuser(c, arg[1], arg[2], arg[3]);
			if(n > -1)
			{
				net.send(FD_BOTS, S_CHSET, " ", arg[1], " ", arg[2], " ", arg[3], buf, NULL);
				++userlist.SN;
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".gset") && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(strlen(arg[2]))
		{
			if(userlist.GlobalChset(c, arg[1], arg[2]) != -1)
			{
				net.send(FD_BOTS, S_GCHSET, " ", arg[1], " ", arg[2], NULL);
				++userlist.SN;
			}
			return;
		}
		else
		{
			if(!userlist.chanlist[0].name)
			{
				c->send("I dont have any channels in my list", NULL);
				return;
			}
			if(userlist.chanlist[0].chset->parseuser(c, userlist.chanlist[0].name, arg[1], arg[2]) == -1)
				return;

			for(i=1; i<MAX_CHANNELS; ++i)
			{
				if(userlist.chanlist[i].name)
				{
					userlist.chanlist[i].chset->parseuser(c, userlist.chanlist[i].name, arg[1], arg[2]);
				}
			}
			return;
		}
	}

	if(!strcmp(arg[0], ".cycle") && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.FindChannelInList(arg[1]) != -1)
		{
			if(ME.FindChannel(arg[1]))
			{
				net.irc.send("PART ", arg[1], " :", config.cyclereason, NULL);
				ME.Rejoin(arg[1], set.CYCLE_DELAY);
			}
			if(strlen(arg[2]))
			{
				inetconn *bot = net.findConn(arg[2]);
				if(bot && bot->IsRegBot()) bot->send(S_CYCLE, " ", arg[1], NULL);
				else c->send("Invalid bot", NULL);
			}
			else
			{
				net.send(FD_BOTS, S_CYCLE, " ", arg[1], NULL);
				c->send("Doing cycle on ", arg[1], NULL);
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".+shit") && strlen(arg[1]))
	{
		if(!extendhost(arg[1], buf, MAX_LEN))
		{
			c->send("Invalid mask", NULL);
			return;
		}
		a = srewind(data, 2);
		if(shitlist.Add(buf, a ? a : NULL, NULL, 0))
  		{
			if(a) c->send("Adding new shit '", buf, " (", a , ")'", NULL);
			else c->send("Adding new shit '", buf, "'", NULL);
  		}
		else c->send("Mask exists in shitlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-shit") && strlen(arg[1]))
	{
		if(shitlist.Remove(arg[1], 0))
		{
			c->send("Removing host '", arg[1], "' from shitlist", NULL);
		}
		else c->send("Mask does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".shits"))
	{
		if(shitlist.ent)
		{
			sprintf(buf, "%d", shitlist.ent);
			c->send("Found ", buf, " shit(s)", NULL);
			sl = shitlist.first;
			i = 0;
			while(sl)
			{
				sprintf(buf, "[#%d]: ", ++i);
				if(sl->str[1]) c->send(buf, sl->str[0], " (", sl->str[1], ")", NULL);
				else c->send(buf, sl->str[0], NULL);
				sl = sl->next;
			}
		}
		else c->send("No masks in shitlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".invite") && strlen(arg[2]))
	{
		if(userlist.FindChannelInList(arg[2]) == -1)
		{
			c->send(arg[2], " is not in my chanlist", NULL);
			return;
		}
		chan *ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(ME.NextAction <= NOW && ME.NextMsg && ch->ptr->flags & IS_OP)
			{
				if(!ch->GetUser(arg[1]))
				{
					net.irc.send("INVITE ", arg[1], " ", arg[2], NULL);
					ME.NextMsg = NOW + set.FRIEND_ACTION_PENALITY;
					c->send("Inviting ", arg[1], " to ", arg[2], NULL);
				}
				else c->send("From my point of view you are on ", arg[2], NULL);
			}
			else if(!(ch->ptr->flags & IS_OP)) c->send("Strange, I don't have op", NULL);
			else c->send("I am too busy, try again in few secs", NULL);
		}
		else
		{
			c->send("I am not on ", arg[2], ", retry this request in few secs ;-)", NULL);
			net.send(FD_BOTS, S_INVITE, " ", arg[2], NULL);
		}
		return;
	}

	if(!strcmp(arg[0], ".nick") && strlen(arg[1]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(!strlen(arg[2]))
		{
			free(config.nick);
			mem_strcpy(config.nick, arg[1]);
			net.irc.send("NICK ", arg[1], NULL);
		}
		else
		{
			inetconn *bot = net.findConn(arg[2]);
			if(bot && bot->IsRegBot())
			{
				bot->send(S_CHANGENICK, " ", arg[1], NULL);
			}
			else c->send("'", arg[2], "' is not connected to me", NULL);
		}
		return;
	}
	if((!strcmp(arg[0], ".passwd") || !strcmp(arg[0], ".chpass")) && strlen(arg[2]))
	{
		if(!(h = userlist.changePass(arg[1], arg[2]))) c->send("Invalid handle", NULL);
		else
		{
			if(userlist.hasWriteAccess(c, arg[1]) == 1)
			{
				c->send("Changing password for '", arg[1], "'", NULL);
				net.send(FD_BOTS, S_PASSWD, " ", arg[1], " ", h->pass, NULL);
				++userlist.SN;
			}
			else c->send(S_NOPERM, NULL);
		}
		return;
	}
	if(!strcmp(arg[0], ".status"))
	{
		c->send("- about me:", NULL);
		c->send("Hi. I'm ", ME.nick, " and I'm running psotnic ", S_VERSION, NULL);
		sprintf(buf, "%d", (int) NOW - (int) ME.startedAt);
		c->send("Up for: ", buf, " seconds", NULL);
		sprintf(buf, "%d bots and %d owners", net.bots, net.owners);
		c->send("I have ", buf, " on-line", NULL);
		if(net.irc.fd) c->send("Connected to ", net.irc.origin, " as ", ME.nick, "!", ME.ident, "@", ME.host, NULL);
		else c->send("Not connected to irc", NULL);
		if(ME.channels)
		{
			c->send("- my channels: ", NULL);
			chan *ch = ME.first;
			while(ch)
			{
				sprintf(buf, "%d ops, %d total", ch->chops(), ch->users);
				c->send(ch->name, " (", buf, ")", NULL);
				ch = ch->next;
			}
		}
		return;
	}
	if(!strcmp(arg[0], ".mk") && strlen(arg[2]))
	{
		if(!(c->status & STATUS_SUPERMAN))
		{
			c->send(S_NOPERM, NULL);
			return;
		}

		chan *ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(!strcmp(arg[1], "all"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_ALL);
				net.send(FD_BOTS, S_MKA, " ", arg[2], NULL);
				c->send("Doing mass kick all on ", arg[2], NULL);
			}
			else if(!strcmp(arg[1], "ops"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_OPS);
				net.send(FD_BOTS, S_MKO, " ", arg[2], NULL);
				c->send("Doing mass kick ops on ", arg[2], NULL);
			}
			else if(!strcmp(arg[1], "nonops"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_NONOPS);
				net.send(FD_BOTS, S_MKN, " ", arg[2], NULL);
				c->send("Doing mass kick nonops on ", arg[2], NULL);
			}
			else
			{
				c->send("No such user class", NULL);
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".list") && strlen(arg[1]))
	{
		if(arg[1][0] == 'p') net.send(FD_BOTS, S_LIST, "P", NULL);
		c->send("Botnet CTCP PING request sent", NULL);
		sprintf(buf, "%d %d\n", (int) NOW, (int) nanotime());
		net.irc.send("NOTICE ", ME.nick, " :P ", buf);
		return;
	}
	if(!strcmp(arg[0], ".help"))
	{
		c->send("Available commands:", NULL);
		c->send(".+user  <handle>                    .-user <handle>", NULL);
		c->send(".+host  <handle> <host>             .-host <handle> <host>", NULL);
		c->send(".+bot   <mask>   <dccip> <pass>     .-bot  <mask>", NULL);
		c->send(".+chan  <chan>   [key]   [delay]    .-chan <chan>", NULL);
		c->send(".+shit  <mask>   [reason]           .-shit <mask>", NULL);
		c->send(".chattr <handle> <flags> [chan]     .match <handle>", NULL);
		c->send(".set    [var]    [value]            .gset  [var]    [value]", NULL);
		c->send(".chset  <chan>   [var]   [value]    .cycle <chan>   [bot]", NULL);
		c->send(".invite <nick>   <chan>             .nick  [bot]    <nick>", NULL);
		c->send(".passwd <handle> <pass>             .bye   [reason]", NULL);
		c->send(".mk <ops|nonops|all> <#chan> [lock]", NULL);
		c->send(".bots   .owners  .shits  .channels", NULL);
		c->send(".users  .save", NULL);
		c->send("Supported flags: -aofmndst (flag 'd' overrides all flags)", NULL);
		c->send("Built-in handles: bot, idiots", NULL);
		c->send("Read CHANGELOG for more details", NULL);
		return;
	}
	if(arg[0][0] == '.')
	{
		c->send("What? You need .help?", NULL);
		return;
	}
}
