/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_irc(char *data)
{
	char arg[11][MAX_LEN], *a, *b, buf[MAX_LEN];
	chan *ch;
	CHANUSER *p;
	int i;

	if(!strlen(data)) return;
	str2words(arg[0], data, 11, MAX_LEN);

	ME.KillTime = NOW + set.PING_TIMEOUT;
	
	/* debug */
	if(set.debug && !strcmp(arg[1], "PRIVMSG"))
	{
		ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(!strcasecmp(arg[3], "!debug"))
			{
				printf("### DEBUG ###\n");
				printf("CHANNELS: %d\n", ME.channels);
				ME.Display();
			}
		}
		else if(!strcasecmp(arg[3], "!re"))	ME.RecheckFlags();
	}

	/* reaction */
	if(!strcmp(arg[1], "JOIN"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ME.CreateNewChannel(arg[2]);
			net.irc.send("WHO ", arg[2], NULL);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(ch) ch->GotJoin(arg[0], 0);
		}
		return;
	}
	if(!strcmp(arg[1], "MODE"))
	{
		ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
			ch->GotMode(arg[3], a, arg[0]);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[1], "KICK"))
	{
		if(!strcasecmp(ME.nick, arg[3]))
		{
			ME.RemoveChannel(arg[2]);
			userlist.chanlist[userlist.FindChannelInList(arg[2])].joinsent = 0;
			ME.Rejoin(arg[2], set.REJOIN_DELAY);
			ME.nextjoin = NOW + set.REJOIN_DELAY;
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(ch) ch->GotKick(arg[3], arg[0]);
		}
		return;
	}
	if(!strcmp(arg[1], "PART"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ME.RemoveChannel(arg[2]);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(ch)
			{
				mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
				ch->GotPart(a, 0);
				free(a);
			}

		}
		return;
	}
	if(!strcmp(arg[1], "NICK"))
	{
		ME.GotNickChange(arg[0], arg[2]);
		return;
	}
	if(!strcasecmp(arg[1], "352"))
	{
		ch = ME.FindNotSyncedChannel(arg[3]);
		if(ch)
		{
			a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
			p = ch->GotJoin(a, match(arg[8], "*@*"));
			if(!strcasecmp(arg[7], ME.nick))
			{
				ch->ptr = p;
				set(p->flags, HAS_B);
			}
			free(a);
		}
		return;
	}
	if(!strcmp(arg[1], "315"))
	{
		ch = ME.FindNotSyncedChannel(arg[3]);
		if(ch)
		{
			if(!ch->ToKick.ent)	net.irc.send("MODE ", arg[3], NULL);
			ch->status |= STATUS_SYNCED;
		}
		else putlog("WHO RPL from not exising channel: %s\n", data);
		return;
	}
	if(!strcmp(arg[1], "324"))
	{
		ch = ME.FindChannel(arg[3]);
		if(ch)
		{
			if(ch->modes) free(ch->modes);
			ch->limit = 0;
			mem_strcpy(ch->modes, arg[4] + 1);

			a = strchr(arg[4], 'l');
			b = strchr(arg[4], 'k');
			if(a > b)
			{
				ch->UpdateKey(arg[6]);
				if(*arg[5]) ch->limit = atol(arg[5]);
			}
			else if(b > a)
			{
				ch->UpdateKey(arg[5]);
				if(*arg[6]) ch->limit = atol(arg[6]);
			}
			else ch->UpdateKey("");
		}
		/*
		if(strlen(arg[4]) == 1 && !strcmp(ch->ptr->nick, ME.nick) && ch->ptr->flags & IS_OP)
			quote(ME.servfd, "MODE ", arg[3], " +snt", NULL);
		*/
		return;
	}
	if(!strcmp(arg[1], "QUIT"))
	{
		ME.GotUserQuit(arg[0]);
		return;
	}
	if(!strcmp(arg[0], "PING"))
	{
		net.irc.send("PONG ", arg[1], NULL);
		return;
	}
	if(!strcmp(arg[1], "433"))
	{
		if(ME.status & STATUS_REGISTERED) ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		else
		{
			ME.RegisterWithNewNick(arg[3]);
			sleep(1);
		}
		return;
	}
	if(!strcmp(arg[1], "437"))
	{
		if(ME.status & STATUS_REGISTERED)
		{
			i = userlist.FindChannelInList(arg[3]);
			if(i == -1)
			{
				/* Nick is temp...*/
				ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
			}
			else
			{
				/* Channel is temp... */
				ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);
			}
		}
		else ME.RegisterWithNewNick(arg[3]);
	}
	if(!strcmp(arg[1], "471") || !strcmp(arg[1], "473") || !strcmp(arg[1], "474"))
	{
		i = userlist.FindChannelInList(arg[3]);
		if(i != -1)
		{
			ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);

			if(!config.listenport) net.hub.send(S_INVITE, " ", arg[3], NULL);
			else net.send(FD_BOTS, S_INVITE, " ", arg[3], NULL);
		}
		return;
	}
	if(!strcmp(arg[1], "475"))
	{
		i = userlist.FindChannelInList(arg[3]);
		if(i != -1)
		{
			ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);
			if(!config.listenport) net.hub.send(S_KEY, " ", arg[3], NULL);
			else net.send(FD_BOTS, S_KEY, " ", arg[3], NULL);
		}
		return;
	}
	if(!strcmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
	{
		ME.status += STATUS_REGISTERED;
		maskstrip(arg[9], ME.nick, ME.ident, ME.host);
		mem_strcpy(ME.mask, arg[9]);
		mem_strcpy(net.irc.origin, arg[0]);
		srand(hash32(ME.nick)*getpid());
		if(net.hub.fd && net.hub.status & STATUS_REGISTERED) net.hub.send(S_NEWNICK, " ", ME.nick, NULL);
		if(strcmp(ME.nick, config.nick)) ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		else ME.NextNickCheck = 0;
		ME.ScheludeJoinToAllChannels();
		if(set.creation)
		{
			userlist.reset();
			printf("[*] Please do `/msg %s mainowner <handle> <password>'\n", ME.nick);
			printf("[*] eg. `/msg %s mainowner %s foobar'\n", ME.nick, getenv("USER"));
		}
		return;
	}
	if(!strcmp(arg[1], "INVITE"))
	{
		if((i = userlist.FindChannelInList(arg[3])) != -1 && !ME.FindChannel(arg[3]))
		{
			if(!userlist.chanlist[i].joinsent)
			{
				net.irc.send("JOIN ", arg[3], " ", userlist.chanlist[i].pass, NULL);
				userlist.chanlist[i].joinsent = 1;
			}
		}
		return;
	}
	if(!strcmp(arg[1], "NOTICE") && !strcasecmp(arg[0], net.irc.origin))
	{
		if(!strcasecmp(arg[6], "invitation"))
		{
			ch = ME.FindChannel(arg[2]);
			if(ch) mem_strncpy(ch->BanOverride, arg[10], strlen(arg[10]) - 1);
		}
		return;
	}
	if(!strcmp(arg[1], "PRIVMSG"))
	{
		/* CTCP */
 		if(arg[3][0] == '\001')
		{
			if(data[strlen(data)-1] != '\001') return;
			data[strlen(data)-1] = '\0';
			for(i=0; i<3; ) if(*data++ == ' ') ++i;
			parse_ctcp(arg[0], ++data, arg[2]);
			return;
		}
		/* op pass #chan */
		if(!strcmp(arg[3], "op") && strlen(arg[5]))
		{
			ch = ME.FindChannel(arg[5]);
			if(ch)
			{
				p = ch->GetUser(arg[0]);
				if(p && p->flags & HAS_O && !(p->flags & IS_OP))
				{
					USER_HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
					if(h) ch->Op(p);
				}
			}
			return;
		}
		/* invite pass #chan */
		if(!strcmp(arg[3], "invite") && strlen(arg[5]))
		{
			ch = ME.FindChannel(arg[5]);
			if(ch)
			{
				USER_HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
				if(h && (h->flags[MAX_CHANNELS] & HAS_F || h->flags[ch->channum] & HAS_F))
				{
					ch->Invite(arg[0], 0);
				}
			}
			return;
		}
		/* key pass chan */
		if(!strcmp(arg[3], "key") && strlen(arg[5]))
		{
			ch = ME.FindChannel(arg[5]);
			if(ch && ch->key && *ch->key && ME.NextAction <= NOW && ME.NextMsg <= NOW)
			{
				USER_HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
				if(h && (h->flags[MAX_CHANNELS] & HAS_F || h->flags[ch->channum] & HAS_F))
				net.irc.send("NOTICE ", arg[0], " :", arg[5], "'s key: ", ch->key, NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
			}
		}
		
		/*
		if(!strcmp(arg[3], "pass") && strlen(arg[4]) && (ch = ME.FindChannel(arg[2])))
		{
			a = strchr(arg[0], '!');
			strncpy(buf, arg[0], abs(a - arg[0]));
			buf[abs(a - arg[0])] = '\0';
			p = ch->GetUser(buf);
			if(p && p->flags & HAS_O)
			{
				USER_HANDLE *h = userlist.matchMaskToHandle(arg[0]);
				if(h)
				{
					if(isNullString(h->pass, AUTHSTR_LEN))
					{
						MD5HexHash(h->pass, arg[4], strlen(arg[4]), NULL, 0);
						net.irc.send("PRIVMSG ", buf, " :Password changed to ", arg[4], NULL);
					}
					else
					{
						net.irc.send("PRIVMSG ", buf, " :You allready have password set", NULL);
					}
					ME.NextMsg = NOW + set.ACTION_PENALITY;
				}
			}
		}
		*/
		/* +n hub */
		/*
		if(!strcmp(arg[3], "!hub") && config.listenport)
		{
			ch = ME.FindChannel(arg[2]);
			if(ch)
			{
				a = strchr(arg[0], '!');
				strncpy(buf, arg[0], abs(a - arg[0]));
				buf[abs(a - arg[0])] = '\0';
				p = ch->GetUser(buf);
				if(p && p->flags & HAS_N)
					net.irc.send("NOTICE ", arg[0], " :Hub version ", S_VERSION, " reporting for duty, sir", NULL);
			}
			return;
		}
		*/
		/* mainowner */
		if(set.creation && !strcmp(arg[3], "mainowner") && strlen(arg[5]))
		{
			if(!strcmp(arg[4], "bot") || !strcmp(arg[4], "idiots"))
			{
				net.irc.send("PRIVMSG ", arg[0], " :Invalid handle", NULL);
				return;
			}

			USER_HANDLE *h = userlist.AddHandle(arg[4]);
			if(h)
			{
				sprintf(buf, "*%s", strchr(arg[0], '!'));
				userlist.AddHost(h, buf);
				userlist.changePass(arg[4], arg[5]);
				userlist.ChangeFlags(arg[4], "aofmns", "");			

				net.irc.send("PRIVMSG ", arg[0], " :Account created", NULL);
				printf("[*] Added user `%s' with host `%s' and password `%s'\n", arg[4], buf, arg[5]);
				printf("[*] Now do `/chat %s' and supply owner pass from the config file and %s's password\n", ME.nick, arg[4]);
				if(!userlist.Bfirst)
				{	
					sprintf(buf, "%s*!%s@%s", ME.nick, ME.ident, ME.host);
					userlist.AddBot(buf, "-", "-");
					printf("[*] Adding myself as '%s'\n", buf);
				}
				userlist.Save(config.userlist_file);
				if(!set.debug) lurk();
				set.creation = 0;
				++userlist.SN;
			}
		}
		return;
	}
	if(!strcmp(arg[0], "NOTICE"))
	{
		
		/* P time nano */
		/*
		if(strlen(arg[5]) && !strcmp(arg[2], "P") && strncmp(arg[0], ME.nick, strlen(ME.nick)))
		{
			if(config.listenport) c
			
			*/
	}
}
