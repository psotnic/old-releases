/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int ul::emptyFlags(USER_HANDLE *h)
{
	int i;

	for(i=0; i<MAX_CHANNELS+1; ++i)
		if(h->flags[i]) return 0;

	return 1;
}
			

int ul::userLevel(USER_HANDLE *h, int n)
{
	if(!h) return 0;
	if(h->flags[n] & HAS_S) return 7;
	if(h->flags[n] & HAS_N) return 6;
	if(h->flags[n] & HAS_M) return 5;
	if(h->flags[n] & HAS_F) return 4;
	if(h->flags[n] & HAS_O) return 3;
	//if(h->flags[n] & HAS_V) return 2;
	if(h->flags[n] & HAS_D) return 1;
	return 0;
}

void ul::sendUsers(inetconn *c)
{
	USER_HANDLE *h;
	int j, i, lvl, display;
	char *group[8], buf[MAX_LEN];
	int count[8];


	for(i=MAX_CHANNELS; i != -1; --i)
	{
		if(i == MAX_CHANNELS) c->send("--- global users ---", NULL);
		else if(!chanlist[i].name) continue;

		display = 0;
		
		h = first->next;
		memset(group, 0, sizeof(group));
		memset(count, 0, sizeof(count));
		while(h)
		{
			lvl = userLevel(h, i);
			if(lvl)
			{
				group[lvl] = push(group[lvl], h->name, " ", NULL);
				++count[lvl];
				if(i != MAX_CHANNELS) display = 1;
			}
			h = h->next;
		}
		if(display) c->send("--- ", chanlist[i].name, " users ---", NULL);
		for(j=7; j; --j)
		{
			if(!count[j]) continue;
			switch(j)
			{
				case 7: sprintf(buf, "super owners(%d): ", count[j]); break;
				case 6: sprintf(buf, "owners(%d): ", count[j]); break;
				case 5: sprintf(buf, "masters(%d): ", count[j]); break;
				case 4: sprintf(buf, "friends(%d): ", count[j]); break;
				case 3: sprintf(buf, "chops(%d): ", count[j]); break;
				case 2: sprintf(buf, "voices(%d): ", count[j]); break;
				case 1: sprintf(buf, "chdeops(%d): ", count[j]); break;
			}
			c->send(buf, group[j], NULL);
			free(group[j]);
		}
	}

	h = first->next;
	group[0] = NULL;
	count[0] = 0;
	while(h)
	{
		if(emptyFlags(h))
		{
			group[0] = push(group[0], h->name, " ", NULL);
			++count[0];
		}
		h = h->next;
	}
	if(count[0])
	{
		bk();
		sprintf(buf, "no flags(%d): ", count[0]);
		c->send("--- no flags ---", NULL);
		c->send(buf, group[0], NULL);
		free(group[0]);
	}
}
	
	
			

USER_HANDLE *ul::matchMaskToHandle(char *mask)
{
	USER_HANDLE *h = first;
	USER_HANDLE	*found = NULL;
	int i;
	
	while(h)
	{
		for(i=0; i<MAX_HOSTS; ++i)
		{
			if(match(mask, h->host[i]))
			{
				if(found)
				{
					net.send(FD_OWNERS, "*** Mask conflict between ", h->name, " and ", found->name, ", cannot automaticly set password", NULL);
					return NULL;
				}
				else found = h;
			}
		}
		h = h->next;
	}
	return h;
}
				

void ul::autoSave()
{
	if(nextSave && config.userlist_file && nextSave <= NOW)
	{
		Save(config.userlist_file);
		nextSave = 0;
		net.send(FD_OWNERS, "*** Autosaving userlist", NULL);
	}
}

int ul::matchHost(USER_HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; ++i)
		if(match(host, p->host[i])) return i;
	return -1;
}
	

USER_HANDLE *ul::matchPassToHandle(char *pass, char *host, int flags)
{
	USER_HANDLE *h = first;

	while(h)
	{
		if(((h->flags[MAX_CHANNELS] & flags) == flags) && !isNullString(h->pass, AUTHSTR_LEN) &&
			MD5HexValidate(h->pass, pass, strlen(pass), 0 ,0) && matchHost(h, host) != -1)
				return h;
		h = h->next;
	}
	return NULL;
}

int ul::hasWriteAccess(inetconn *c, char *handle)
{
	USER_HANDLE *h = FindHandle(handle);

	if(!h) return -1;
	
	if((c->status & STATUS_SUPERMAN && first->next != h) || !strcmp(c->name, handle)) return 1;
	if(!(h->flags[MAX_CHANNELS] & HAS_N) && (c->status & STATUS_OWNER)) return 1;
	
	return 0;
}

void ul::setHashedPassword(char *user, char *md5hash)
{
	USER_HANDLE *h = FindHandle(user);
	if(h)
	{
		memset(h->pass, 0, AUTHSTR_LEN+1);
		strncpy(h->pass, md5hash, AUTHSTR_LEN);
	}
	nextSave = NOW + 60;
}

USER_HANDLE *ul::changePass(char *user, char *pass)
{
	USER_HANDLE *h = FindHandle(user);

	if(!h) return NULL;
	MD5HexHash(h->pass, pass, strlen(pass), 0, 0);
	nextSave = NOW + 60;
	return h;
}
	
USER_HANDLE *ul::checkOwnerPass(char *username, char *pass)
{
	USER_HANDLE *h = FindHandle(username);

	if(h && (h->flags[MAX_CHANNELS] & HAS_N) && (h->flags[MAX_CHANNELS] & HAS_T) &&
		!isNullString(h->pass, AUTHSTR_LEN) && MD5HexValidate(h->pass, pass, strlen(pass), 0, 0))
			return h;
	else return NULL;
}

int ul::IsIdiot(char *mask, int channum)
{
	if(HAS_D & (first->flags[MAX_CHANNELS] | first->flags[channum]))
	{
		for(int i=0; i<MAX_HOSTS; ++i)
			if(first->host[i])
				if(match(mask, first->host[i]))
					return 1;
	}
	return 0;
}

int ul::GlobalChset(inetconn *c, char *var, char *value)
{
	int i;

	if(!chanlist[0].name)
	{
		c->send("I dont have any channels in my list", NULL);
		return -1;
	}
	if(chanlist[0].chset->parseuser(c, "all channels", var, value) == -1)
		return -1;
	
	for(i=1; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			chanlist[i].chset->parseuser(NULL, "all channels", var, value);

	nextSave = NOW + 60;
	return 0;
}

int ul::AddChannelToList(char *name, char *pass)
{
	int i;
	USER_HANDLE *u = first;

	/* change pass */
	if((i = FindChannelInList(name)) != -1)
	{
		if(!strcmp(chanlist[i].pass, pass)) return -1;
		free(chanlist[i].pass);
		mem_strcpy(chanlist[i].pass, pass);
		nextSave = NOW + 60;
		return -2;
	}
	/* add new channel */
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(!chanlist[i].name)
		{
			mem_strcpy(chanlist[i].name, name);
			mem_strcpy(chanlist[i].pass, pass);
			chanlist[i].chset = new(chanset);
			chanlist[i].joinsent = 0;
			while(u)
			{
				u->flags[i] = 0;
				u = u->next;
			}
			nextSave = NOW + 60;
			return i;
		}
	}
	return -3;
}

int ul::FindChannelInList(char *name)
{
	int i;

	for(i=0; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			if(!strcasecmp(chanlist[i].name, name)) return i;
	return -1;
}

int ul::RemoveChannelFromList(char *name)
{
	int i;
	USER_HANDLE *u = first;

	i = FindChannelInList(name);
	if(i == -1) return 0;
	while(u)
	{
		u->flags[i] = 0;
		u = u->next;
	}
	Destroy(&chanlist[i]);
	nextSave = NOW + 60;
	return 1;
}

void ul::Update()
{
	int n;
	char arg[10][MAX_LEN], buf[MAX_LEN];
	char *b = ulbuf;
	char *a = NULL;
	USER_HANDLE *h;

	reset();
	set.reset();

	for(n=0; n<ulbuflines; ++n)
	{
		memset(buf, 0, MAX_LEN);
		a = strchr(b, '\n');
		strncpy(buf, b, abs(b-a));
		b = a + 1;
		
		str2words(arg[0], buf, 10, MAX_LEN);

		if(!strcmp(arg[0], S_ADDUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], S_ADDHOST) && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], S_CHATTR) && strlen(arg[2]))
		{
			ChangeFlags(arg[1], arg[2], arg[3]);
			continue;
		}
		if(!strcmp(arg[0], S_ADDCHAN) && strlen(arg[1]))
		{
			if(strlen(arg[2]))AddChannelToList(arg[1], arg[2]);
   			else AddChannelToList(arg[1], "");
			continue;
		}
		if(!strcmp(arg[0], S_ADDBOT) && strlen(arg[2]))
		{
			AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], S_SN) && strlen(arg[1]))
		{
			SN = strtoull(arg[1], NULL, 10);
			continue;
		}
		if(!strcmp(arg[0], S_SET) && strlen(arg[2]))
		{
			set.setvar(arg[1], arg[2]);
			continue;
		}
		if(!strcmp(arg[0], S_CHSET) && strlen(arg[3]))
		{
			int i = FindChannelInList(arg[1]);
			if(i != -1)	chanlist[i].chset->setvar(arg[2], arg[3]);
			continue;
		}
		if(!strcmp(arg[0], S_PASSWD) && strlen(arg[2]))
		{
			setHashedPassword(arg[1], arg[2]);
			continue;
		}
	}

	free(ulbuf);
	putlog("[+] Rehashed\n");
	nextSave = 0;
	Save(config.userlist_file);
}


void ul::Send(inetconn *c)
{
	char buf[MAX_LEN];
	USER_HANDLE *h = first;
	BOT_HANDLE *b = Bfirst;
	int i, n;

	if(!c) return;

	c->send(S_UL_UPLOAD_START, NULL);
	sprintf(buf, "%llu", SN);
	c->send(S_SN, " ", buf, NULL);
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(chanlist[i].name)
		{
			if(strlen(chanlist[i].pass)) c->send(S_ADDCHAN, " ", chanlist[i].name, " ", chanlist[i].pass, NULL);
			else c->send(S_ADDCHAN, " ", chanlist[i].name, NULL);
			chanset *chset = chanlist[i].chset;
			for(n=0; n < chset->ent; ++n)
			{
				if(chset->varent[n].def != *chset->varent[n].i)
				{
					sprintf(buf, "%d", *chset->varent[n].i);
					c->send(S_CHSET, " ", chanlist[i].name, " ", chset->varent[n].name, " ", buf, NULL);
				}
			}
		}
	}
	while(h)
	{
		if(h != first) c->send(S_ADDUSER, " ", h->name, NULL);
		for(i=0; i<MAX_HOSTS; ++i)
			if(h->host[i]) c->send(S_ADDHOST, " ", h->name, " ", h->host[i], NULL);

		if(h->flags[MAX_CHANNELS])
		{
			flags2str(h->flags[MAX_CHANNELS], buf);
			c->send(S_CHATTR, " ", h->name, " ", buf, NULL);
		}
		for(i=0; i<MAX_CHANNELS; ++i)
		{
			if(chanlist[i].name && h->flags[i])
			{
				flags2str(h->flags[i], buf);	
				c->send(S_CHATTR, " ", h->name, " ", buf, " ", chanlist[i].name, NULL);
			}
		}
		if(!isNullString(h->pass, AUTHSTR_LEN)) c->send(S_PASSWD, " ", h->name, " ", h->pass, NULL);
		h = h->next;
	}
	while(b)
	{
		c->send(S_ADDBOT, " ", b->mask, " ", S_SECRET, " ", S_SECRET, NULL);
		b = b->next;
	}
 	for(i=0; i<set.ent; ++i)
	{
		if(set.varent[i].def != *set.varent[i].i)
		{
			sprintf(buf, "%d", *set.varent[i].i);
			c->send(S_SET, " ", set.varent[i].name, " ", buf, NULL);
		}
	}
	c->send(S_UL_UPLOAD_END, NULL);
}

char *ul::CheckBotMD5Digest(char *ip, char *digest, char *authstr)
{
	BOT_HANDLE *b = Bfirst;

	while(b)
	{
		if(match(ip, b->ip))
			if(MD5HexValidate(digest, authstr, strlen(authstr), b->pass, strlen(b->pass))) return b->pass;
		b = b->next;
	}
	return NULL;

}

int ul::IsOwner(char *mask)
{
	USER_HANDLE *h = first;
	int i;

	while(h)
	{
		if(h->flags[MAX_CHANNELS] & HAS_N)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(h->host[i])
				{
					if(match(mask, h->host[i]))
					{
						if(h->flags[MAX_CHANNELS] & HAS_S) return 2;
						else return 1;
					}
				}
			}
		}
		h = h->next;
	}
	return 0;
}

int ul::IsBot(char *ip)
{
	BOT_HANDLE *b = Bfirst;

	while(b)
	{
		if(match(ip, b->ip)) return 1;
		b = b->next;
	}
	return 0;
}

BOT_HANDLE *ul::FindBot(char *mask)
{
	BOT_HANDLE *p = Bfirst;

	while(p)
	{
		if(!strcasecmp(p->mask, mask)) return p;
		p = p->next;
	}
	return NULL;
}

BOT_HANDLE *ul::AddBot(char *mask, char *ip, char *pass)
{
    BOT_HANDLE *p;

	if(FindBot(mask)) return NULL;
    if(!bots)
    {
		Blast = Bfirst = new(BOT_HANDLE);
		Bfirst->next = Bfirst->prev = NULL;
	}
    else
    {
		p = Blast->next = new(BOT_HANDLE);
		p->prev = Blast;
		p->next = NULL;
		Blast = p;
    }
	++bots;
	mem_strcpy(Blast->mask, mask);
	mem_strcpy(Blast->ip, ip);
	mem_strcpy(Blast->pass, pass);
	nextSave = NOW + 60;
	return Blast;
}

int ul::RemoveBot(char *mask)
{
	BOT_HANDLE *p = Bfirst;

	if(!Bfirst) return 0;
	if(!strcasecmp(Bfirst->mask, mask))
	{
		Bfirst = Bfirst->next;
		if(Bfirst) Bfirst->prev = NULL;
		Destroy(p);
		--bots;
		if (!bots) Blast = NULL;
		nextSave = NOW + 60;
		return 1;
	}
	else if(!strcasecmp(Blast->mask, mask))
	{
		p = Blast->prev;
		p->next = NULL;
		Destroy(Blast);
		--bots;
		Blast = p;
		nextSave = NOW + 60;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->mask, mask))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--bots;
				nextSave = NOW + 60;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

int ul::GetFlags(char *mask, chan *ch)
{
	USER_HANDLE *p = first;
	BOT_HANDLE *b = Bfirst;
	int need = HAS_ALL, got, i;

	if(IsIdiot(mask, ch->channum)) return HAS_D;
	
	while(b)
	{
		if(match(mask, b->mask))
		{
			need -= HAS_A + HAS_O + HAS_F + HAS_M + HAS_B;
			break;
		}
		b = b->next;
	}
	while(p)
	{
		got = need & (p->flags[MAX_CHANNELS] | p->flags[ch->channum]);
		if(got)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(p->host[i])
				{
					if(match(mask, p->host[i]))
					{
						need -= got;
						break;
					}
				}
			}
		}
		p = p->next;
	}
	got = HAS_ALL - need;
	return (got & HAS_D) ? HAS_D : got;
}

int ul::Save(char *file)
{
	char buf[MAX_LEN];
	FILE *f;
	USER_HANDLE *h = first;
	BOT_HANDLE *b = Bfirst;
	STRINGLIST *s = shitlist.first;
	int i, n;

	putlog("[*] Saving userlist\n");
	f = fopen(file, "w");
	if(!f)
	{
		putlog("[-] Error: %s\n", strerror(errno));
		exit(1);
	}
	fprintf(f, "#userlist generated by %s version %s\n", S_BOTNAME, S_VERSION);
	fprintf(f, "#if you want to hand edit please change value of SERIAL_NUMBER\n");
	fprintf(f, "#WARNING: .+chan entries must be placed before any .chattr entires\n");
	fprintf(f, "#WARNING2: first user is main owner\n\n");
	fprintf(f, "SERIAL_NUMBER %llu\n\n", SN);

	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(chanlist[i].name)
		{
			if(strlen(chanlist[i].pass)) fprintf(f, ".+chan %s %s\n", chanlist[i].name, chanlist[i].pass);
			else fprintf(f, ".+chan %s\n", chanlist[i].name);
			for(n=0; n < chanlist[i].chset->ent; ++n)
			{
				if(chanlist[i].chset->varent[n].def != *chanlist[i].chset->varent[n].i)
				{
					fprintf(f, ".chset %s %s %d\n", chanlist[i].name,
												 	 chanlist[i].chset->varent[n].name,
												 	 *chanlist[i].chset->varent[n].i);
				}
			}
		}
	}
	fprintf(f, "\n");
	while(h)
	{
		if(h != first) fprintf(f, ".+user %s\n", h->name);
		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i] != NULL) fprintf(f, ".+host %s %s\n", h->name, h->host[i]);

		if(h->flags[MAX_CHANNELS])
		{
			flags2str(h->flags[MAX_CHANNELS], buf);
			fprintf(f, ".chattr %s %s\n", h->name, buf);
		}
		for(i=0; i<MAX_CHANNELS; ++i)
		{
			if(chanlist[i].name && h->flags[i])
			{
				flags2str(h->flags[i], buf);
				fprintf(f, ".chattr %s %s %s\n", h->name, buf, chanlist[i].name);
			}
		}
		if(!isNullString(h->pass, AUTHSTR_LEN)) fprintf(f, ".passwd %s %s\n", h->name, h->pass);
		h = h->next;
		fprintf(f, "\n");
	}
	while(b)
	{
		fprintf(f, ".+bot %s %s %s\n", b->mask, b->ip, b->pass);
		b = b->next;
	}
	fprintf(f, "\n");
	for(i=0; i<set.ent; ++i)
	{
		if(set.varent[i].def != *set.varent[i].i)
		{
			fprintf(f, ".set %s %d\n", set.varent[i].name, *set.varent[i].i);
		}
	}
	fprintf(f, "\n");
	if(config.listenport)
	{
		while(s)
		{
			if(s->str[1])	fprintf(f, ".+shit %s %s\n", s->str[0], s->str[1]);
			else fprintf(f, ".+shit %s\n", s->str[0]);
			s = s->next;
		}
	}
	
	if(set.SAVE_NICK)
	{
		fprintf(f, "\n");
		fprintf(f, ".nick %s\n", config.nick);
	}
	fclose(f);
	chmod(file, S_IRUSR | S_IWUSR);
	putlog("[+] Done\n");
	nextSave = 0;
	return 1;
}

int ul::Load(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN];
	char *a;
	USER_HANDLE *h;
	FILE *f;
	int handles = 0;

	printf("[*] Loading userlist from '%s'\n", config.userlist_file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[W] Userlist file not present (new bot?)\n");
		return 0;
	}
	while(!feof(f))
	{
		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);
		str2words(arg[0], buf, 10, MAX_LEN);
		buf[strlen(buf) - 1] = '\0';

		if(*buf == '\0' || *buf == '#' || *buf == ';') continue;

		if(!strcmp(arg[0], ".+user") && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			++handles;
			continue;
		}
		if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
		{
			ChangeFlags(arg[1], arg[2], arg[3]);
			continue;
		}
		if(!strcmp(arg[0], ".+chan") && strlen(arg[1]))
		{
			AddChannelToList(arg[1], arg[2]);
			continue;
		}

		if(!strcmp(arg[0], ".+bot") && strlen(arg[3]))
		{
			AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], "SERIAL_NUMBER") && strlen(arg[1]))
		{
			SN = strtoull(arg[1], NULL, 10);
			continue;
		}
		if(!strcmp(arg[0], ".set") && strlen(arg[2]))
		{
			set.setvar(arg[1], arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chset") && strlen(arg[3]))
		{
			int i = FindChannelInList(arg[1]);
			if(i != -1)	chanlist[i].chset->setvar(arg[2], arg[3]);
			continue;
		}
		if(config.listenport)
		{
			if(!strcmp(arg[0], ".+shit") && strlen(arg[1]))
			{
				a = srewind(buf, 2);
				if(a) shitlist.Add(arg[1], a, NULL, 0);
				else shitlist.Add(arg[1], NULL, NULL, 0);
				continue;
			}
		}
		if(!strcmp(arg[0], ".nick") && strlen(arg[1]))
		{
			free(config.nick);
			mem_strcpy(config.nick, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], ".passwd") && strlen(arg[2]))
		{
			userlist.setHashedPassword(arg[1], arg[2]);
			continue;
		}
	}
	fclose(f);
	printf("[+] Userlist loaded\n");
	nextSave = 0;
	return handles;
}

void ul::flags2str(int flags, char *str)
{
	int i = 0;
	
	if(flags & HAS_A) str[i++] = 'a';
	if(flags & HAS_O) str[i++] = 'o';
	if(flags & HAS_F) str[i++] = 'f';
	if(flags & HAS_M) str[i++] = 'm';
	if(flags & HAS_N) str[i++] = 'n';
	if(flags & HAS_D) str[i++] = 'd';
	if(flags & HAS_T) str[i++] = 't';
	if(flags & HAS_S) str[i++] = 's';
	if(i == 0) str[i++] = '-';
	str[i] = '\0';
}

int ul::ChangeFlags(USER_HANDLE *p, char *flags, int channum)
{
	/* main owner must have +sn */
	if(p == first->next && (!strchr(flags, 's') || !strchr(flags, 'n')))
		return -3;
	/* forbiden channel flags: st */
	if(channum != MAX_CHANNELS && (strchr(flags, 's') || strchr(flags, 't')/* || strchr(flags, 'n')*/))
		return -4;
							
	p->flags[channum] = 0;
	
	if(p != first)
	{
		if(strchr(flags, 'a')) p->flags[channum] |= HAS_A;
		if(strchr(flags, 'o')) p->flags[channum] |= HAS_O;
		if(strchr(flags, 'f')) p->flags[channum] |= HAS_F | HAS_O;
		if(strchr(flags, 'm')) p->flags[channum] |= HAS_M | HAS_F | HAS_O;
		if(strchr(flags, 'n')) p->flags[channum] |= HAS_N | HAS_F | HAS_O | HAS_M;
		if(strchr(flags, 't')) p->flags[channum] |= HAS_T | HAS_N | HAS_F | HAS_O | HAS_M;
		if(strchr(flags, 's')) p->flags[channum] |= HAS_S | HAS_N | HAS_F | HAS_O | HAS_M;
	}
	if(strchr(flags, 'd')) p->flags[channum] += HAS_D;
	nextSave = NOW + 60;
	return p->flags[channum];	
}

int ul::ChangeFlags(inetconn *c, char *name, char *flags, char *channel)
{
	if(!(c->status & STATUS_SUPERMAN) && (strchr(flags, 's') || strchr(flags, 't')) ||
		!hasWriteAccess(c, name)) return -5;
	return ChangeFlags(name, flags, channel);
}

int ul::ChangeFlags(char *name, char *flags, char *channel)
{
	USER_HANDLE *p = FindHandle(name);
	int num = MAX_CHANNELS;

	if(!p) return -1;
	if(strlen(channel))
	{
		num = FindChannelInList(channel);
		if(num == -1) return -2;
	}
	return ChangeFlags(p, flags, num);
}

int ul::FindHost(USER_HANDLE *p, char *host)
{
	int i;

	if(!p) return -1;

	for(i=0; i<MAX_HOSTS; i++)
		if(p->host[i])
			if(!strcasecmp(p->host[i], host)) return i;

	return -1;
}

USER_HANDLE *ul::FindHandle(char *name)
{
	USER_HANDLE *p = first;

	while(p)
	{
		if(!strcasecmp(p->name, name)) return p;
		p = p->next;
	}
	return NULL;
}

int ul::RemoveHost(USER_HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			if(!strcasecmp(p->host[i], host))
			{
				free(p->host[i]);
				p->host[i] = NULL;
				nextSave = NOW + 60;
				return i;
			}
		}
	}
	return -1;
}

int ul::AddHost(USER_HANDLE *p, char *host)
{
	int i;

	if(FindHost(p, host) != -1) return -1;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] == NULL)
		{
			mem_strcpy(p->host[i], host);
			nextSave = NOW + 60;
			return i;
		}
	}
	return -1;
}

int ul::RemoveHandle(char *name)
{
	USER_HANDLE *p = first;

	if(!first) return 0;

	if(!strcasecmp(first->name, name))
	{
		putlog("[!!!] Please don't hack me, thank you [!!!]\n");
		return 0;
		/*
		first = first->next;
		if(first) first->prev = NULL;
		Destroy(p);
		--ent;
		if(!ent) last = NULL;
		return 1;
		*/
	}
	else if(!strcasecmp(last->name, name))
	{
		p = last->prev;
		p->next = NULL;
		Destroy(last);
		--ent;
		last = p;
		nextSave = NOW + 60;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->name, name))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--ent;
				nextSave = NOW + 60;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

USER_HANDLE *ul::AddHandle(char *name)
{
    USER_HANDLE *p;
	int i;

	if(FindHandle(name)) return NULL;
    if(!ent)
    {
		last = first = new(USER_HANDLE);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(USER_HANDLE);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
	++ent;
	mem_strcpy(last->name, name);
	memset(last->pass, 0, AUTHSTR_LEN);
	for(i=0; i<MAX_HOSTS; ++i) last->host[i] = NULL;
	for(i=0; i<MAX_CHANNELS + 1; ++i) last->flags[i] = 0;
	nextSave = NOW + 60;
	return last;
}

/* Constructor */
ul::ul()
{
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
	nextSave = 0;
	int i;

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
	AddHandle("idiots");
	first->flags[MAX_CHANNELS] = HAS_D;
}

/* Destruction derby */
ul::~ul()
{
	USER_HANDLE *hp = first;
	USER_HANDLE *hq;
	int i;
	
	while(hp)
	{
		hq = hp;
		hp = hp->next;
		Destroy(hq);
	}

	BOT_HANDLE *bp = Bfirst;
	BOT_HANDLE *bq;
	while(bp)
	{
		bq = bp;
		bp = bp->next;
		Destroy(bq);
	}

	for(i=0; i<MAX_CHANNELS; ++i) Destroy(&chanlist[i]);
}

void ul::Destroy(CHANLIST *p)
{
	if(p->name) free(p->name);
	if(p->pass) free(p->pass);
	delete(p->chset);
	memset(p, 0, sizeof(CHANLIST));
}

void ul::Destroy(BOT_HANDLE *p)
{
	if(p->mask) free(p->mask);
	if(p->ip) free(p->ip);
	if(p->pass) free(p->pass);
	free(p);
}

void ul::Destroy(USER_HANDLE *p)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i])
		{
			free(p->host[i]);
			p->host[i] = NULL;
		}
	}
	free(p->name);
	free(p);
}

void ul::reset()
{
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
	nextSave = 0;
	int i;

	this->~ul();

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
	AddHandle("idiots");
	first->flags[MAX_CHANNELS] = HAS_D;
}


