extern time_t NOW;
extern client ME;
extern settings set;
extern ul userlist;
extern CONFIG config;
extern stringlist shitlist;
extern char *thisfile;
extern int logfile;
extern inet net;

