/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_bot(inetconn *c, char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;

	if(!strlen(data)) return;
	str2words(arg[0], data, 10, MAX_LEN);
	
	/* REGISTER CONNECTION */
	if(!(c->status & STATUS_REGISTERED))
	{
		switch(c->tmpint)
		{
			case 1:
			{
				if(!strcmp(arg[0], config.botnetword))
				{
					c->tmpstr = (char *) malloc(AUTHSTR_LEN + 1);
					++c->tmpint;
					MD5CreateAuthString(c->tmpstr, AUTHSTR_LEN);
					c->send(S_AUTH, " ", c->tmpstr, NULL);
					return;
				}
				/* maybe that's owner */
				if(config.ownerpass && set.TELNET_OWNERS && MD5HexValidate(config.ownerpass, arg[0], strlen(arg[0]), 0, 0))
				{
					c->status = STATUS_CONNECTED | STATUS_OWNER | STATUS_TELNET;
					c->tmpint = 1;
					c->killTime = NOW + set.AUTH_TIME;
					c->send("Welcome ", getpeerip(c->fd), NULL);
					//lame
					write(c->fd, "login: ", strlen("login: "));
					return;
				}
				break;
			}
			case 2:
			{
				if(!strcmp(arg[0], S_AUTHRPL) && strlen(arg[1]) == 32)
				{
					a = userlist.CheckBotMD5Digest(getpeerip(c->fd), arg[1], c->tmpstr);
					if(a)
					{
						c->pass = a;
						++c->tmpint;
						c->send(S_AUTHOK, NULL);
						return;
					}
				}
				break;
			}
			case 3:
			{
				if(!strcmp(arg[0], S_AUTH) && strlen(arg[1]) == AUTHSTR_LEN)
				{
					char hash[33];

					++c->tmpint;
					MD5HexHash(hash, arg[1], AUTHSTR_LEN, c->pass, strlen(c->pass));
					c->send(S_AUTHRPL, " ", hash, NULL);
					return;
				}
				break;
			}
			case 4:
			{
				/* S_REGISTER <ME.nick> <S_VERSION> <userlist.SN> [irc server] */
				if(!strcmp(arg[0], S_REGISTER) && strlen(arg[3]))
				{
					c->send(S_NEWNICK, " ", ME.nick, NULL);
					mem_strcpy(c->name, arg[1]);
					mem_strcpy(c->origin, arg[4]);
					c->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_BOT;
					c->tmpint = 0;
					c->killTime = NOW + set.PING_TIMEOUT;
					c->lastPing = NOW;
					net.send(FD_OWNERS, "*** ", arg[1], " has joined the botnet", NULL);
					if(userlist.SN != strtoull(arg[3], NULL, 10))
					{
						net.send(FD_OWNERS, "*** Sending userlist to ", arg[1], NULL);
						userlist.Send(c);
					}
					++net.bots;
					return;
				}
				break;
			}
			default: break;
		}
		/* HUH */
		putlog("[-] Failed to register bot (%s:%d)\n", getpeerip(c->fd), getpeerport(c->fd));
		c->close();
	}

	/* PARSE DATA FROM REGISTERED BOT */

	c->killTime = NOW + set.PING_TIMEOUT;
	
	if(!strcmp(arg[0], S_NEWNICK) && strlen(arg[1]))
	{
		net.send(FD_OWNERS, "*** ", c->name, " is now known as ", arg[1], NULL);
		free(c->name);
		mem_strcpy(c->name, arg[1]);
		return;
	}
	/* S_INVITE <chan> [nick] */
	if(!strcmp(arg[0], S_INVITE) && strlen(arg[1]))
	{
		if(strlen(arg[2])) ME.BotNetInvite(arg[1], arg[2]);
		else ME.BotNetInvite(arg[1], c->name);
		return;
	}
	if(!strcmp(arg[0], S_KEY) && strlen(arg[1]))
	{
		ch = ME.FindChannel(arg[1]);
		if(ch && ch->key) c->send(S_KEYRPL, " ", arg[1], " ", ch->key, NULL);
		return;
	}
	if(!strcmp(arg[0], S_OP) && strlen(arg[1]))
	{
		ch = ME.FindChannel(arg[1]);
		if(ch)
		{
			CHANUSER *u = ch->GetUser(c->name);
			if(u) ch->Op(u);
		}
	}
	if(!strcmp(arg[0], S_GETOP) && strlen(arg[2]))
	{
		if(userlist.FindChannelInList(arg[1]) != -1)
		{
			inetconn *ask = net.findConn(arg[2]);
			if(ask) ask->send(S_OP, " ", arg[1], " ", c->name, NULL);
		}
	}
}
