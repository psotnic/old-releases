/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/*
	0 = none
	1 = psotnic
	2 = irssi
	3 = epic
	4 = lice
	5 = bitchx
*/

/* irssi like */
void parse_ctcp(char *mask, char *data, char *to)
{
	char arg[10][MAX_LEN], *a, buf[MAX_LEN], who[MAX_LEN];
	char *global = strchr("!#&+", to[0]);
	int n, p;

	if(!strlen(data)) return;
	a = strchr(mask, '!');
	strncpy(who, mask, abs(a-mask));
	str2words(arg[0], data, 10, MAX_LEN);

	putlog("[*] Got ctcp: %s\n", data);

	if(ME.NextMsg <= NOW && ME.NextAction <= NOW && !(set.NO_PRIVATE_CTCP && !global))
	{
		if(config.ctcptype > 0)
		{
			if(!strcmp(arg[0], "PING") && strlen(arg[2]))
			{
				if(strlen(data) > 40) return;
				net.irc.send("NOTICE ", who, " :\001PING ", arg[1], " ", arg[2], "\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "TIME"))
			{
				a = ctime(&NOW);
				a[strlen(a) - 1] = '\0';
				net.irc.send("NOTICE ", who, " :\001TIME ", a, "\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
		}
		switch(config.ctcptype)
		{
			case 2:
			/* irssi */
			if(!strcmp(arg[0], "VERSION"))
			{
				struct utsname name;
				uname(&name);
				net.irc.send("NOTICE ", who, " :\001VERSION irssi v0.8.6 - running on ", name.sysname, " ", name.machine, "\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				//FIXME: should we free `name'?
				return;
			}
			if(!strcmp(arg[0], "USERINFO"))
			{
				net.irc.send("NOTICE ", who, " :\001USERINFO ", config.realname, "\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "CLIENTINFO"))
			{
				net.irc.send("NOTICE ", who, " :\001CLIENTINFO PING VERSION TIME USERINFO CLIENTINFO\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			break;

			case 1: case 3: case 4:
			/* psotnic epic lice */
			if(!strcmp(arg[0], "VERSION"))
			{
				struct utsname name;
				uname(&name);

				ME.NextMsg = NOW + set.ACTION_PENALITY;
				switch(config.ctcptype)
				{
					case 1:
					net.irc.send("NOTICE ", who, " :\001VERSION psotnic ", S_VERSION, " by pks <pks@irc.pl>\001", NULL);
					break;
					case 3:
					net.irc.send("NOTICE ", who, " :\001VERSION ircII EPIC-4.1.1.6 ", name.sysname, " ", name.machine, " - Accept no limitations.\001", NULL);
					break;
					case 4:
					net.irc.send("NOTICE ", who, " :\001VERSION ircII EPIC-4.1.1.6 ", name.sysname, " ", name.machine, " - \002LiCe\002 v4.2.0pre7\001", NULL);
					break;
				}
				//FIXME: should we free `name'?
				return;
			}
			if(!strcmp(arg[0], "USERINFO"))
			{
				net.irc.send("NOTICE ", who, " :\001USERINFO ", config.realname, "\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "ERRMSG"))
			{
				net.irc.send("NOTICE ", who, " :\001ERRMSG n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "ECHO"))
			{
				net.irc.send("NOTICE ", who, " :\001ECHO n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "FINGER"))
			{
				net.irc.send("NOTICE ", who, " :\001FINGER n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "CLIENTINFO"))
			{
				if(!*arg[1])
				{
					net.irc.send("NOTICE ", who, " :\001CLIENTINFO SED UTC ACTION DCC VERSION CLIENTINFO USERINFO ERRMSG FINGER TIME PING ECHO :Use CLIENTINFO <COMMAND> to get more specific information\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "SED"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO SED contains simple_crypted_data\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "UTC"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO UTC substitutes the local timezone\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
 			    }
				if(!strcmp(arg[1], "ACTION"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO ACTION contains action descriptions for atmosphere\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "DCC"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO DCC requests a direct_client_connection\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "VERSION"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO VERSION shows client type, version and environment\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "CLIENTINFO"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO CLIENTINFO gives information about available CTCP commands\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "USERINFO"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO USERINFO returns user settable information\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "ERRMSG"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO ERRMSG returns error messages\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "FINGER"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO FINGER shows real name, login name and idle time of user\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "TIME"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO TIME tells you the time on the user's host\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "PING"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO PING returns the arguments it receives\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "ECHO"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO ECHO returns the arguments it receives\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
			}
			break;

			case 5:
			/* Bitch-X */
			if(!strcmp(arg[0], "VERSION"))
			{
				struct utsname name;
				uname(&name);
				net.irc.send("NOTICE ", who, " :\001VERSION \002BitchX-1.0c19+\002 by panasync - ", name.sysname, " ", name.machine, " \002: Keep it to yourself!\002 \001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "USERINFO"))
			{
				net.irc.send("NOTICE ", who, " :\001USERINFO n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "ERRMSG"))
			{
				net.irc.send("NOTICE ", who, " :\001ERRMSG n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
            if(!strcmp(arg[0], "FINGER"))
            {
            	net.irc.send("NOTICE ", who, " :\001FINGER  n/a\001", NULL);
                ME.NextMsg = NOW + set.ACTION_PENALITY;
                return;
            }
			if(!strcmp(arg[0], "ECHO"))
			{
				net.irc.send("NOTICE ", who, " :\001ECHO n/a\001", NULL);
				ME.NextMsg = NOW + set.ACTION_PENALITY;
				return;
			}
			if(!strcmp(arg[0], "CLIENTINFO"))
			{
				if(!*arg[1])
				{
					net.irc.send("NOTICE ", who, " :\001CLIENTINFO SED UTC ACTION DCC CDCC BDCC XDCC VERSION CLIENTINFO USERINFO ERRMSG FINGER TIME PING ECHO INVITE WHOAMI OP OPS UNBAN IDENT XLINK UPTIME :Use CLIENTINFO <COMMAND> to get more specific information\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "SED"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO SED contains simple_crypted_data\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "UTC"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO UTC substitutes the local timezone\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "ACTION"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO ACTION contains action descriptions for atmosphere\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "DCC"))
				{
					net.irc.send("NOTICE ",who, " :\001CLIENTINFO DCC requests a direct_client_connection\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "VERSION"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO VERSION shows client type, version and environment\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
					return;
				}
				if(!strcmp(arg[1], "CLIENTINFO"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO CLIENTINFO gives information about available CTCP commands\001", NULL);
					ME.NextMsg = NOW + set.ACTION_PENALITY;
                	return;
				}
				if(!strcmp(arg[1], "USERINFO"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO USERINFO returns user settable information\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "ERRMSG"))
				{
    		        net.irc.send("NOTICE ",who ," :\001CLIENTINFO ERRMSG returns error messages\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
		            return;
                }
                if(!strcmp(arg[1], "FINGER"))
				{
    	            net.irc.send("NOTICE ",who ," :\001CLIENTINFO FINGER shows real name, login name and idle time of user\001", NULL);
        	        ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "TIME"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO TIME tells you the time on the user's host\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "PING"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO PING returns the arguments it receives\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "ECHO"))
				{
            	    net.irc.send("NOTICE ",who ," :\001CLIENTINFO ECHO returns the arguments it receives\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "CDCC"))
                {
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO CDCC checks cdcc info for you\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "BDCC"))
				{
    		        net.irc.send("NOTICE ",who ," :\001CLIENTINFO BDCC checks cdcc info for you\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
            	}
                if(!strcmp(arg[1], "XDCC"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO XDCC checks cdcc info for you\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "INVITE"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO INVITE invite to channel specified\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "WHOAMI"))
				{
    	            net.irc.send("NOTICE ",who ," :\001CLIENTINFO WHOAMI user list information\001", NULL);
        	        ME.NextMsg = NOW + set.ACTION_PENALITY;
            	    return;
               	}
                if(!strcmp(arg[1], "OP"))
				{
					net.irc.send("NOTICE ",who ," :\001CLIENTINFO OP ops the person if on userlist\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
            	if(!strcmp(arg[1], "OPS"))
				{
    	            net.irc.send("NOTICE ",who ," :\001CLIENTINFO OPS ops the person if on userlist\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
        			return;
                }
                if(!strcmp(arg[1], "UNBAN"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO UNBAN unbans the person from channel\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "IDENT"))
				{
                	net.irc.send("NOTICE ",who ," :\001CLIENTINFO IDENT change userhost of userlist\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "XLINK"))
				{
    	            net.irc.send("NOTICE ",who ," :\001CLIENTINFO XLINK x-filez rule\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
                if(!strcmp(arg[1], "UPTIME"))
				{
                    net.irc.send("NOTICE ",who ," :\001CLIENTINFO UPTIME my uptime\001", NULL);
                    ME.NextMsg = NOW + set.ACTION_PENALITY;
                    return;
                }
            }
            break;
            default: break;
		}
	}
	/* dcc chat */
	if(!strcmp(arg[0], "DCC") && !strcmp(arg[1], "CHAT") && strlen(arg[4]))
	{
		sprintf(buf, "%s", inet2char(htonl(strtoul(arg[3], NULL, 10))));
		putlog("[*] Dcc chat request from %s (%s:%s)\n", mask, buf, arg[4]);
		if((p = userlist.IsOwner(mask) && config.listenport))
  		{
			n = DoConnect(buf, atoi(arg[4]), config.myipv4, 1);
			if(n > 0)
			{
				inetconn *c = net.addConn(n);
				c->status = STATUS_CONNECTED + STATUS_OWNER;
				if(p == 2) c->status += STATUS_SUPERMAN;

				mem_strcpy(c->origin, mask);
				c->killTime = NOW + set.AUTH_TIME;
				c->tmpint = 1;
				c->send("Enter owner password:", NULL);
			
				putlog("[+] Connection established\n");
			}
			else
			{
				net.irc.send("PRIVMSG ", who, " :Cannot establish connection (", strerror(errno), ")", NULL);
				putlog("[-] Cannot establish connection with %s (%s)\n", who, strerror(errno));
			}
		}
		else putlog("[-] %s is not an owner\n", mask);
 		return;
	}
}
