/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int SigTerm()
{
	net.irc.send("QUIT :", config.quitreason, NULL);
	net.send(FD_OWNERS, ">> Got termination signal <<", NULL);
	putlog("[*] Got termination signal\n");
	userlist.Save(config.userlist_file);
	putlog("[*] Calling exit(1) \n");
	exit(1);
}

int SigInt()
{
	net.irc.send("QUIT :", config.quitreason, NULL);
	net.send(FD_OWNERS, ">> Terminated by user <<", NULL);
	putlog("[*] Terminated by user\n");
	userlist.Save(config.userlist_file);
	putlog("[*] Calling exit(1) \n");
	exit(1);
}

int SigHup()
{
	userlist.Save(config.userlist_file);
	return 0;
}

int SigSegv()
{
	net.irc.send("QUIT :Yet another bug found, please send log to pks@irc.pl", NULL);
	net.send(FD_OWNERS, ">> Segmentation fault <<", NULL);
	putlog("[E] Segmentation fault\n");
	putlog("[E] Plase send log (10 to 30 lines) to pks@irc.pl\n");
	putlog("[E] Thank you\n");
	putlog("[*] Calling exit(2)\n");
	exit(2);
}

int SafeExit()
{
	putlog("[*] Abnormal program termination\n");
	userlist.Save(config.userlist_file);
	putlog("[*] Calling exit(3)\n");
	exit(3);
}

void SignalHandling()
{
	signal(SIGPIPE, SIG_IGN);

 	signal(SIGTERM, (sighandler_t) SigTerm);
	signal(SIGINT, (sighandler_t) SigInt);
	signal(SIGHUP, (sighandler_t) SigHup);
	signal(SIGSEGV, (sighandler_t) SigSegv);
}



