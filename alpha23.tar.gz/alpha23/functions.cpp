/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int isNullString(char *str, int len)
{
	int i;

	for(i=0; i<len; ++i)
		if(*str++) return 0;
	return 1;
}
	

void lurk()
{
	pid_t pid = fork();
	if(pid == -1)
	{
		printf("[-] Fork faild: %s\n", strerror(errno));
	}
	else if(!pid) return;
	else
	{
		printf("[+] Going into background\n");
		exit(0);
	}
}

void parse_cmdline(int argc, char *argv[])
{
	int i;
		
	if(argc == 1)
	{
		printf("Syntax: %s [-v] [-d] [-p] <config file>\n", argv[0]);
		exit(1);
	}

	if(!strcmp(argv[1], "-v")) exit(0);
	
	for(i=1; i<argc; ++i)
	{
		if(!strcmp(argv[i], "-p"))
		{
			char buf[MAX_LEN], hash[33];
			printf("Bot is now running in MD5 hash generator mode\n");
			
			while(1)
			{
				printf("string to hash: ");
				scanf("%s", buf);
				MD5HexHash(hash, buf, strlen(buf), NULL, 0);
				printf("MD5 hash      : %s\n", hash);
			}
		}
		else if(!strcmp(argv[i], "-d")) set.debug = 1;
		else if(!strcmp(argv[i], "-v")) exit(0);
		else if(i == argc - 1) LoadConfig(argv[i]);
		else
		{
			printf("Unknown option `%s`\n", argv[i]);
			exit(1);
		}
	}
}		

char *my_strstr(char *haystack, size_t haystacklen, char *needle, size_t needlelen)
{
	size_t h, n;
	char *ph = haystack;
	char *pn = needle;

	for(h=0; h<haystacklen; ++h, ++ph)
	{
		if(*ph == *pn)
		{
			for(n=0, pn=needle; n<needlelen && h<haystacklen; ++n, ++h, ++ph, ++pn)
				if(*ph != *pn) break;
			if(n == needlelen) return ph - needlelen;
		}
	}
	return NULL;
}


long int nanotime()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_usec;
}

char *srewind(char *str, int word)
{
	int i;

	if(!str) return NULL;

	while(isspace(*str))
	{
		if(*str == '\0') return NULL;
		++str;
	}
	for(i=0; i<word; ++i)
	{
		while(!isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
		while(isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
	}
	return str;
}

int UserLevel(CHANUSER *u)
{
	if(u->flags & HAS_N || u->flags & HAS_B) return 3;
	if(u->flags & HAS_M) return 2;
	if(u->flags & HAS_O) return 1;
	return 0;
}

void str2words(char *word, char *str, int x, int y)
{
	int i, j;

	for(i=0; i<x; ++i)
	{
		while(isspace(*str))
		{
			if(*str == '\0') break;
			++str;
		}
		if(*str == '\0') break;

		for(j=0; j<y-1 && !isspace(*str); ++j, ++str)
		{
			if(*str == '\0') break;
			*word = *str;
			++word;
		}
		memset(word, 0, y - j - 1);
		word += y - j;
		if(*str == '\0') break;
	}

	for(++i; i<x; ++i)
	{
		memset(word, 0, y - 1);
		word += y;
	}

}

void SendLogo(inetconn *c)
{
	char owners[16], bots[16], *timestr;
	struct utsname name;

	timestr = ctime(&NOW);
	timestr[strlen(timestr) - 1] = '\0';
	
	uname(&name);
	sprintf(owners, "%d", net.owners);
	sprintf(bots, "%d", net.bots);

	c->send("", NULL);
	c->send("\002    _/_/_/   _/_/_/   _/_/_/  _/_/_/_/ _/      _/  _/   _/_/_/\002", NULL);
	c->send("\002   _/   _/ _/       _/    _/    _/    _/_/    _/  _/  _/\002", NULL);
	c->send("\002  _/_/_/   _/_/_/  _/    _/    _/    _/  _/  _/  _/  _/\002", NULL);
	c->send("\002 _/            _/ _/    _/    _/    _/    _/_/  _/  _/\002", NULL);
	c->send("\002_/       _/_/_/   _/_/_/     _/    _/      _/  _/   _/_/_/\002", NULL);
	c->send("", NULL);
	c->send("      Copyright (c) 2003 Grzegorz Rusin <pks@irc.pl>", NULL);
	c->send("", NULL);
	c->send("Psotnic version: \002", S_VERSION , "\002", NULL);
	c->send("Local time: \002", timestr, "\002", NULL);
	c->send("Machine info: \002", name.sysname, " ", name.release, " ", name.machine, "\002", NULL);
	c->send("Owners on-line: \002", owners, "\002 (type .owners to see list)", NULL);
	c->send("Bots on-line: \002", bots, "\002 (type .bots to see list)", NULL);
	c->send("", NULL);

	net.send(FD_OWNERS, "*** ", c->name, " has joined the partyline", NULL);
}

int DoConnect6(char *server, int port, char *vhost, int options)
{
    struct sockaddr_in6 sin6;
	int s;

	s = socket(AF_INET6, SOCK_STREAM, 0);
	if(!s) return -1;

	memset(&sin6, 0, sizeof(sin6));

	if(strlen(vhost)) inet_pton(AF_INET6, vhost, (void *) &sin6.sin6_addr);
	else sin6.sin6_addr = in6addr_any;

	if(bind (s, (struct sockaddr *) &sin6, sizeof (sin6)) == -1)
	{
		killSocket(s);
		return -1;
	}

	memset(&sin6, 0, sizeof (struct sockaddr_in6));
	sin6.sin6_family = AF_INET6;
	sin6.sin6_port = htons(port);
	inet_pton(AF_INET6, server, (void *) &sin6.sin6_addr);

	if(connect(s, (struct sockaddr *) &sin6, sizeof(sin6)) == -1)
	{
		killSocket(s);
		return -1;
	}

	if(options > 0) if(fcntl(s, F_SETFL, options) == -1)
	{
		killSocket(s);
		return -1;
	}
	return s;
}

void propaganda()
{
	printf("\n");
	printf("Psotnic C++ edition, version %s (%s %s)", S_VERSION,__DATE__, __TIME__);
	printf("\n");
	printf(S_COPYRIGHT);
	printf("\n\n");
}

int extendhost(char *host, char *buf, unsigned int len)
{
    char *ex, *at;

    if(strlen(host) + 10 > len) return 0;

    ex = strchr(host, '!');
    at = strchr(host, '@');

    if(ex != strrchr(host, '!') || at != strrchr(host, '@')) return 0;

    if(at)
    {
        if(!ex)
        {
            if(at == host) strcpy(buf, "*!*");
            else strcpy(buf, "*!");
            strcat(buf, host);
        }
        else if(ex == host)
        {
            strcpy(buf, "*");
            strcat(buf, host);
        }
        else strcpy(buf, host);
        if(*(at + 1) == '\0') strcat(buf, "*");
        return 1;
    }
    else
    {
        if(ex) return 0;
        if(strchr(host, '.') || strchr(host, ':'))
        {
            strcpy(buf, "*!*@");
            strcat(buf, host);
            return 1;
        }
        strcpy(buf, "*!");
        strcat(buf, host);
        strcat(buf, "@*");
        return 1;
    }
}

int MagicNickCreator(char *nick)
{
	int nicklen, applen;
	char *n;

	srand(nanotime());
	nicklen = strlen(nick);
	applen = strlen(config.nickappend);

	if(nicklen >= 9 && (!strchr(config.nickappend, nick[8]) || nick[8] == config.nickappend[applen-1]))
		return 0;

	n = strchr(config.nickappend, nick[nicklen-1]);

	if(n)
	{
		if(nick[nicklen-1] == config.nickappend[rand() % applen]) nick[nicklen] = config.nickappend[0];
		else nick[nicklen-1] = config.nickappend[abs(n - config.nickappend) + 1];
	}
	else nick[nicklen] = config.nickappend[0];

	return 1;
}

char *inet2char(unsigned int inetip)
{
	struct sockaddr_in sin;
	sin.sin_addr.s_addr = inetip;
	return inet_ntoa(sin.sin_addr);
}

int AcceptConnection(int fd)
{
	int n;
	struct sockaddr_in from;
	socklen_t fromsize = sizeof(struct sockaddr_in);
	const int one = 1;
	inetconn *c;

	if((n = accept(fd, (sockaddr *) &from, &fromsize)) > 0)
	{
		putlog("[*] Connection attempt from %s\n", inet_ntoa(from.sin_addr));
		if(userlist.IsBot(inet_ntoa(from.sin_addr)) || set.TELNET_OWNERS)
		{
			fcntl(n, F_SETOWN);
			fcntl(n, F_SETFL, O_NONBLOCK);
			setsockopt(n, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));
			c = net.addConn(n);
			c->tmpint = 1;
			c->killTime = NOW + set.AUTH_TIME;
			c->status = STATUS_CONNECTED + STATUS_BOT + STATUS_TELNET;
			putlog("[+] Accepting connection\n");
			return n;
		}
		else
		{
			putlog("[-] Unknown ip, disconnecting\n");
			killSocket(n);
			return -1;
		}
	}
	else
	{
		killSocket(n);
		putlog("[-] Connection lost (%s)\n", strerror(errno));
		return -1;
	}
}

char *getpeerip(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int ret, e = errno;
	#endif
	socklen_t peersize = sizeof(struct sockaddr_in);
	ret = getpeername(fd, (sockaddr *) &peer, &peersize);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	if(ret == -1) return NULL;
	else return inet_ntoa(peer.sin_addr);
}

int getpeerport(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int ret, e = errno;
	#endif
	socklen_t peersize = sizeof(struct sockaddr_in);
	ret = getpeername(fd, (sockaddr *) &peer, &peersize);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	if(ret == -1) return 1;
	else return ntohs(peer.sin_port);
}

int StartListening(char *ip, int port)
{
    struct sockaddr_in sin;
    int s;
    const int one = 1;

	printf("[*] Opening listening socket at %s:%d\n", ip, port);
    if((s = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		killSocket(s);
		return -1;
	}

    if(setsockopt(s , SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0)
	{
		killSocket(s);
		return -1;
	}

    memset (&sin, 0, sizeof (struct sockaddr_in));
    if(strlen(ip)) sin.sin_addr.s_addr = inet_addr(ip);
    else sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    if(bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1)
	{
		killSocket(s);
		return -1;
	}

    if(listen(s, SOMAXCONN) == -1)
	{
		killSocket(s);
		return -1;
	}

	/*
	// source of errors on freebsd 
	if(strcmp(ip, inet2char(sin.sin_addr.s_addr)) || ntohs(sin.sin_port) != port)
	{
		sclose(s);
		printf("[-] Invalid ip address or port\n");
		return -1;
	}
	*/
	printf("[+] Socket awaits incomming connections\n");

    return s;
}

void precache()
{
    int i;

	for(i=0; i<MAX_SERVERS; ++i) memset(&config.server[i], 0, sizeof(config.server[i]));
	memset(&config, 0, sizeof(config));
	config.ctcptype = 2; /* irssi */
	validate();
}

void Divide(int *ret, int value, int parts, int part_size)
{
	if(parts == 1)
	{
		ret[0] = value;
		ret[1] = ret[2] = 0;
		return;
	}

	if(value > part_size*2)
    {
        ret[0] = value / parts;
        ret[1] = (value - ret[0]) / (parts-1);
        if(parts == 3) ret[2] = value - ret[0] - ret[1];
        else ret[2] = 0;
    }
    else if(value > part_size)
    {
        ret[0] = part_size;
        ret[1] = value - ret[0];
        ret[2] = 0;
    }
    else
    {
        ret[0] = value;
        ret[1] = ret[2] = 0;
    }
}

void killSocket(int fd)
{
	#ifdef _NO_LAME_ERRNO
	int e = errno;
	#endif
	shutdown(fd, SHUT_RDWR);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
}

int DoConnect(char *server, int port, char *vhost, int noblock)
{
    struct sockaddr_in sin;
    int s;

	s = socket(AF_INET, SOCK_STREAM, 0);
    if(!s) return -1;

	memset (&sin, 0, sizeof (sin));
    if(strlen(vhost)) sin.sin_addr.s_addr = inet_addr(vhost);
	else sin.sin_addr.s_addr = INADDR_ANY;
    if(bind (s, (struct sockaddr *) &sin, sizeof (sin)) == -1)
	{
		killSocket(s);
		return -1;
	}

    memset (&sin, 0, sizeof (sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);

	if(noblock == -1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		killSocket(s);
		return -1;
	}
    if(connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1)
	{
		if(noblock == -1 && errno == EINPROGRESS) return s;
		killSocket(s);
		return -1;
	}
	if(noblock == 1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		killSocket(s);
		return -1;
	}
	return s;
}

int match(char *str, char *pattern)
{
    if (!fnmatch(pattern, str, FNM_CASEFOLD | FNM_NOESCAPE)) return 1;
    else return 0;
}

unsigned int hash32(char *word)
{
    char c;
    unsigned bit_hi = 0;
    int bit_low = 0;
    int len = strlen(word);

    if(len > 64) len = 63;

	/* i barrowed this code from epic ;-) */
    for(; *word && len; ++word, --len)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
    return ((bit_hi & 8191) << 3) + (bit_low & 0x7);
}

unsigned int hash32(char *word, char *where)
{
    char c;
    unsigned bit_hi = 0;
    int bit_low = 0;
    int wordlen = strlen(word);
	int wherelen = strlen(where);

    if(wordlen > 32) wordlen = 32;
	if(wherelen > 32) wherelen = 31;

    for(; *word && wordlen; ++word, --wordlen)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
	for(; *where && wherelen; ++where, --wherelen)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
    return ((bit_hi & 8191) << 3) + (bit_low & 0x7);
}

int va_getlen(va_list ap, char *lst)
{
	int size = strlen(lst);
	char *p;

	while((p = va_arg(ap, char *)))
		size += strlen(p);
	
	return size;
}

char *push(char *ptr, char *lst, ...)
{
	va_list ap;

	va_start(ap, lst);
    ptr = va_push(ptr, ap, lst, va_getlen(ap, lst) + 1);
	va_end(ap);

    return ptr;
}

char *va_push(char *ptr, va_list ap, char *lst, int size)
{
	char *p;
		
	if(ptr)
	{
        size += strlen(ptr);
        ptr = (char *) realloc(ptr, size*sizeof(char));
        strcat(ptr, lst);
    }
    else
    {
        ptr = (char *) malloc(size*sizeof(char));
        strcpy(ptr, lst);
    }

    /* strcat rest */
	while((p = va_arg(ap, char *)))
	{
		strcat(ptr, p);
	}
	return ptr;
}	
