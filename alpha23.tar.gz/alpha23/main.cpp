/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"

time_t NOW;
client ME;
settings set;
ul userlist;
inet net;
CONFIG config;
stringlist shitlist;
char *thisfile;
int logfile;

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd, wfd;
	inetconn *c;
	set.creation = 0;

	mem_strcpy(thisfile, argv[0]);
		
	propaganda();
	precache();
	parse_cmdline(argc, argv);
	if(userlist.Load(config.userlist_file))
	{
		if(!set.debug) lurk();
	}
	else if(config.listenport)
	{
		printf("[!] No owners in userlist, running in owner creation mode\n");
		set.creation = 1;
	}
	//SignalHandling();

	last = NOW = time(NULL);
	tv.tv_sec = 1;

	/* MAIN LOOP */
	while(1)
	{
		if(tv.tv_sec > 1 || tv.tv_sec <= 0) tv.tv_sec = 1;
		tv.tv_usec = 0;

		/* Add sockets to SETs */
		FD_ZERO(&rfd);
		FD_ZERO(&wfd);
		
	   	if(net.irc.fd && !net.irc.timedOut()) FD_SET(net.irc.fd, &rfd);
	    if(net.hub.fd && !net.hub.timedOut())
	    {
			if(net.hub.status & STATUS_SYNSENT) FD_SET(net.hub.fd, &wfd);
			FD_SET(net.hub.fd, &rfd);
		}

		if(config.listenport)
		{
			FD_SET(net.listenfd, &rfd);
			for(i=0; i<net.max_conns; ++i)
			{
				if(net.conn[i].fd && !net.conn[i].timedOut())
				{
					FD_SET(net.conn[i].fd, &rfd);
				}
			}
		}

		for(i=0; i<net.max_conns; ++i)
			if(net.conn[i].write.buf)
				FD_SET(net.conn[i].fd, &wfd);

		/* SELECT */
		ret = select(65535, &rfd, &wfd, NULL, &tv);
		//getchar();

		NOW = time(NULL);
		if(NOW > last + 2)
		{
			last = NOW;
			if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
			userlist.autoSave();
		}
		if(!net.hub.fd && config.havehub && ME.nextconn_hub <= NOW)
		{
			ME.ConnectToHUB();
			ME.nextconn_hub = NOW + set.HUB_CONN_DELAY;
		}
		if(!net.irc.fd && ME.nextconn_serv <= NOW)
		{
			ME.ConnectToIRC();
			ME.nextconn_serv = NOW + set.IRC_CONN_DELAY;
		}
		if(ME.status & STATUS_REGISTERED && ME.NextNickCheck <= NOW && ME.NextNickCheck)
		{
			net.irc.send("NICK ", config.nick, NULL);
			ME.NextNickCheck = 0;
		}
		ME.RejoinCheck();

		if(ret < 1) continue;

		/* WRITE BUFFER */
		for(i=0; i<net.max_conns; ++i)
		{
			c = &net.conn[i];
			if(c->write.buf && FD_ISSET(c->fd, &wfd))
			{
				write(c->fd, c->write.buf + c->write.pos++, 1);
				if(c->write.pos == c->write.len)
				{
					free(c->write.buf);
					memset(&c->write, 0, sizeof(c->write));
				}
			}
		}

		/* READ from DNS */
		/*
		if(FD_ISSET(DNS.resfd, &rfd))
		{
			DNS.RecvPacket();
		}
		*/
		/* READ from IRC */
		if(FD_ISSET(net.irc.fd, &rfd))
		{
			n = net.irc.readln(buf, MAX_LEN);
			if(n > 0) parse_irc(buf);
			else if(n == -1) net.irc.close();
		}

		/* READ from HUB */
		if(FD_ISSET(net.hub.fd, &rfd))
		{
			n = net.hub.readln(buf, MAX_LEN);
			if(n > 0 && net.hub.status & STATUS_CONNECTED) parse_hub(buf);
			else if(n == -1) net.hub.close();
		}

		/* ACCEPT connections */
		if(FD_ISSET(net.listenfd, &rfd)) AcceptConnection(net.listenfd);

		/* READ from BOTS and OWNERS */
		if(config.listenport)
		{
			for(i=0; i<net.max_conns; i++)
			{
				c = &net.conn[i];
				if(c->fd > 0)
				{
					if(FD_ISSET(c->fd, &rfd))
					{
						n = c->readln(buf, MAX_LEN);
						if(n > 0)
						{
							if(c->status & STATUS_OWNER) parse_owner(c, buf);
							else if(c->status & STATUS_BOT) parse_bot(c, buf);
						}
						else if(n == -1) c->close();
                	}
            	}
			}
		}
		if(net.hub.fd && net.hub.status & STATUS_SYNSENT)
		{
			if(FD_ISSET(net.hub.fd, &wfd))
			{
				putlog("[+] Connection to HUB established\n");
				net.hub.status = STATUS_CONNECTED;
				net.hub.tmpint = 1;
				net.hub.killTime = NOW + set.AUTH_TIME;
				net.hub.send(config.botnetword, NULL);
			}
		}
	}
	//return 0;
}

