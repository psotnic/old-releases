static unsigned char FileMD5[] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXYYYY";
static char Key[] = "\x00\x5b\x31\xc9\x89\xca\xcd\x80";

