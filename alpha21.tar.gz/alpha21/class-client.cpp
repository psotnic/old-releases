/**************************************************
*  This file is a part of psotnic 0.x.x code.
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void client::BotNetInvite(char *channel, char *nick)
{
	chan *ch = FindChannel(channel);
	char *a;

	if(userlist.FindChannelInList(channel) == -1) return;

	if(ch)
	{
		if(ch->Invite(nick, 1)) return;
		else if(config.listenport)
		{
			a = push(NULL, S_INVITE, " ", channel, " ", nick, NULL);
			ch->QuoteOpedBots(a, ch->NumberOfBots(ch->chset->INVITE_BOTS));
			free(a);
		}
	}
	else if(config.listenport)
	{
		quote(FD_BOTS, S_INVITE, " ", channel, NULL);
	}
}

void client::Rejoin(char *name, int t)
{
	int i;

	i = userlist.FindChannelInList(name);
	if(i != -1)
	{
		userlist.chanlist[i].nextjoin = NOW + t;
		userlist.chanlist[i].joinsent = 0;
	}
}

void client::RejoinCheck()
{
	int i;
	if(!(ME.status & STATUS_REGISTERED)) return;
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(userlist.chanlist[i].name && userlist.chanlist[i].nextjoin <= NOW && !userlist.chanlist[i].joinsent)
		{
			if(!ME.FindChannel(userlist.chanlist[i].name))
			{
				if(strlen(userlist.chanlist[i].pass)) quote(servfd, "JOIN ", userlist.chanlist[i].name, " ", userlist.chanlist[i].pass, NULL);
				else quote(servfd, "JOIN ", userlist.chanlist[i].name, NULL);
				userlist.chanlist[i].joinsent = 1;
			}
		}
	}
}

void client::ScheludeJoinToAllChannels()
{
	int i, j;

	for(i=j=0; i<MAX_CHANNELS; i++)
	{
		if(userlist.chanlist[i].name)
		{
			userlist.chanlist[i].nextjoin = j*10 + NOW + 2;
			userlist.chanlist[i].joinsent = 0;
			j++;
		}
	}
}

void client::GotNickChange(char *from, char *to)
{
	char *a = strchr(from, '!');
	char *fromnick;
	chan *p = first;

	mem_strncpy(fromnick, from, abs(a - from) + 1);
	while(p)
	{
		p->GotNickChange(fromnick, to);
		p = p->next;
	}
	free(fromnick);
}

void client::Display()
{
	chan *p;

	p = first;

	printf("### Channels:\n");
	while(1)
	{
		if(!p) break;
		printf("### '%s'\n", p->name);
		p = p->next;
	}
}

void client::RecheckFlags()
{
	chan *ch = ME.first;

	while(ch)
	{
		ch->RecheckFlags();	
		ch = ch->next;
	}
}

void client::RecheckFlags(char *channel)
{
	chan *ch = FindChannel(channel);
	if(ch) ch->RecheckFlags();
}

int client::ConnectToHUB()
{
	int fd;

	sclose(hub.fd);
	hub.fd = 0;

	printf("[*] Connecting to HUB: %s port %d\n", config.hubhost, config.hubport);
	fd = DoConnect(config.hubhost, config.hubport, config.myipv4, -1);

	if(fd > 0)
	{
		hub.fd = fd;
		hub.status = STATUS_SYNSENT;
		return fd;
	}

	printf("[-] Error occured: %s, next try in %d secconds\n", strerror(errno), set.HUB_CONN_DELAY);
	return -1;
}

int client::ConnectToIRC()
{
	int i, n;

	ME.status = 0;
	ME.servid = -1;
	ME.servfd = 0;

	for(i=0; i<MAX_SERVERS; i++)
	{
		if(config.server[i].port)
		{
			printf("[*] Connecting to IRC: %s port %d\n", config.server[i].host, config.server[i].port);
			if(strchr(config.server[i].host, ':'))
				n = DoConnect6(config.server[i].host, config.server[i].port, config.vhost, 1);
			else
				n = DoConnect(config.server[i].host, config.server[i].port, config.vhost, 1);
			if(n > 0)
			{
				printf("[+] Connection to IRC established\n");
				/*
				if(setsockopt(n, IPPROTO_TCP, TCP_NODELAY, (char *) &tmp,sizeof(int)) == 0)
					printf("[+] Socket is running in TCP_NODELAY mode\n");
				else printf("[-] Couldn't set socket in TCP_NODELAY mode\n");
				*/
				ME.servid = i;
				ME.servfd = n;
				ME.status = STATUS_CONNECTED;
				quote(n, "NICK ", config.nick, NULL);
				quote(n, "USER ", config.ident, " 8 * :", config.realname, NULL);
				return n;
			}
			else
			{
				printf("[-] Couldn't connect to IRC (%s)\n", strerror(errno));
				printf("[*] Next try in %d seconds\n", set.IRC_CONN_DELAY);
			}
		}
	}
	return 0;
}

/* FIXME: is this queue lame? */
void client::CheckQueue()
{
	if(ME.NextAction > NOW) return;
	chan *ch = first;
	int j;
	CHANUSER **MultHandle, *u;

	while(ch)
	{
		if(ch->ptr)
		{
			if(!(ch->ptr->flags & IS_OP))
			{
				if(ch->InitialOp <= NOW - set.ASK_FOR_OP_DELAY)
				{
					ch->AskForOp();
					ch->InitialOp = NOW;
				}
			}
			else
			{
				/*
				if(ch->BotsToOp.ent)
				{
					MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * set.OPS_PER_MODE);
					j = GetRandomItems(MultHandle, ch->BotsToOp.first, ch->BotsToOp.ent, set.OPS_PER_MODE);
					ch->Op(MultHandle, j);
					free(MultHandle);
					return;
				}
				*/
				if(ch->ToKick.ent)
				{
					MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
					j = GetRandomItems(MultHandle, ch->ToKick.first, ch->ToKick.ent, 4);
					ch->Kick4(MultHandle, j);
					free(MultHandle);
					return;
				}
				else if(ch->ToBan.ent)
				{
					STRINGLIST *s;
					s = ch->ToBan.first;
					if((u = ch->GetUser(s->str[1])))
					{
						ch->KickBan(u, s->str[0], s->str[2]);
						if(config.listenport)
						{
							/* Send this shit to some bots ;-) */
							char *a = push(NULL, S_KICKBAN, " ", ch->name, " ", s->str[1], " ", s->str[0], " ", s->str[2], NULL);
							srand(hash32(ch->name,  s->str[0]));
							ch->QuoteOpedBots(a, ch->NumberOfBots(ch->chset->SHIT_BOTS));
							srand(hash32(ME.nick)*getpid());
						}
						return;
					}
					else ch->ToBan.Remove(s->str[0], 0);
				}
				//else ch->EnforceLimits();
			}
		}
		ch = ch->next;
	}
}

void client::GotUserQuit(char *mask)
{
	char *a, *nick;
	chan *ch = first;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);

	while(ch)
	{
		ch->GotPart(nick, 1);
		ch = ch->next;
	}
	free(nick);
}

void client::RemoveChannel(char *name)
{
	chan *ch = first;
	int n;

	if(!channels) return;

	if(!strcasecmp(first->name, name))
	{
		first = first->next;
		if(first) first->prev = NULL;
		delete(ch);
		--channels;
		if(!channels) last = NULL;
	}
	else if(!strcasecmp(last->name, name))
	{
		ch = last->prev;
		ch->next = NULL;
		delete(last);
		--channels;
		last = ch;
	}
	else
	{
		ch = first->next;
		while(ch)
		{
			if(!strcasecmp(ch->name, name))
			{
				ch->prev->next = ch->next;
				if(ch->next) ch->next->prev = ch->prev;
				delete(ch);
				--channels;
			}
			ch = ch->next;
		}
	}
	current = first;

	n = userlist.FindChannelInList(name);
	if(n != -1) userlist.chanlist[n].joinsent = 0;
}


chan *client::FindChannel(char *name)
{

	if(current)
		if(!strcasecmp(current->name, name)) return current;

	current = first;
	while(current)
	{
		if(!strcasecmp(current->name, name)) return current;
		current = current->next;
	}
	return NULL;
}

chan *client::CreateNewChannel(char *name)
{
	int n;
	if(!channels)
	{
		first = current = last = new(chan);
		current->prev = current->next = NULL;
		mem_strcpy(current->name, name);
	}
	else
	{
		current = last->next = new(chan);
  		current->prev = last;
		current->next = NULL;
		mem_strcpy(current->name, name);
		last = current;
	}

	n = userlist.FindChannelInList(name);
	if(n != -1)
	{
		userlist.chanlist[n].joinsent = 0;
		current->chset = userlist.chanlist[n].chset;
		current->channum = n;
	}

	++channels;
	return current;
}

/* Constructor */
client::client()
{
	first = last = current = NULL;
	channels = servfd = servid = nextconn_hub = nextconn_serv = nextjoin = status = 0;
	nick = ident = host = mask = servname = NULL;
	NextAction = NextMsg = NOW;
	KillTime = 0;
}

/* Destruction derby */
client::~client()
{
	chan *ch = first;
	chan *p;

	while(ch)
	{
		p = ch;
		ch = ch->next;
		delete(p);
	}

	if(nick) free(nick);
	if(ident) free(ident);
	if(host) free(host);
	if(mask) free(mask);
	if(servname) free(servname);
}

void client::reset()
{
	this->~client();

	first = last = current = NULL;
	channels = servfd = servid = nextjoin = status = 0;
	nick = ident = host = mask = servname = NULL;
	NextAction = NextMsg = NOW;
	KillTime = 0;
}
