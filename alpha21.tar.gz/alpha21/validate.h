/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

static unsigned char FileMD5[] = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXYYYY";
static char Key[] = "\x00\x5b\x31\xc9\x89\xca\xcd\x80";
/*
static char *Files[] =
{
	"BUGS",
	"CHANGELOG",
	"LICENSE",
	"TODO",
	"hub.conf",
	"bot.conf",
	"\0"
};
*/
