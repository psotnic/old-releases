/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/*
void partyline::BotPart(array <SOCK> *ary, int fd)
{
	int i;

	for(i=0; i < ary->entries; ++i)
	{
		while(ary->entry[i]->fd == fd && i < ary->entries)
		{
			ary->Remove(i);
		}
	}
}	

void partyline::BotPart(char *name)


void partyline::BotPart(int fd)
{
	BotPart(&MyBots, fd);
	BotPart(&UpLinkBots, fd);
	BotPart(&DownLinkBots, fd);
}

SOCK *partyline::BotFind(char *name, int where)
{
	array <SOCK> *s;
	int i;
	
	if(!where) s = &MyBots;
	else if(where < 0) s = &DownLinkBots;
	else s = &UpLinkBots;

	for(i=0; i < s->entries; ++i)
		if(!strcmp(s->entry[i]->name, name)) return s->entry[i];

	return NULL;
}

SOCK *partyline::BotFind(int fd, int where)
{
	array <SOCK> *s;
	int i;

	if(!where) s = &MyBots;
	else if(where < 0) s = &DownLinkBots;
	else s = &UpLinkBots;

	for(i=0; i < s->entries; ++i)
		if(s->entry[i]->fd == fd) return s->entry[i];

	return NULL;
}

void partyline::BotConnected(int fd)
{
	SOCK *s = new(SOCK);
	memset(s, 0, sizeof(SOCK));
	s->fd = fd;
	MyBots.Add(s);
}

void partyline::BotJoin(SOCK *s, char *name, char *server, int fromfd)
{
	if(s)
	{
		mem_strcpy(s->name, name);
		mem_strcpy(s->origin, server);
		s->status = STATUS_REGISTERED + STATUS_CONNECTED + STATUS_BOT; //status
		s->pass = NULL;
		s->killtime = 0;
		s->authstep = 0;
		//SEND_JOIN_TO_HUB_AND_DOWNLINK_BOTS();
	}
	else 
	{
		SOCK *s = new(SOCK);
		memset(s, 0, sizeof(SOCK));

		mem_strcpy(s->name, name);
		mem_strcpy(s->origin, server);
		s->status = STATUS_REGISTERED + STATUS_CONNECTED + STATUS_BOT;
		s->fd = fromfd;
		if(fromfd == hub.fd)
		{
			UpLinkBots.Add(s);
			//SEND_JOIN_TO_DOWNLINK_BOTS();
		}
		else
		{
			DownLinkBots.Add(s);
			//SEND_JOIN_TO_HUB();
		}
		
	}
}

partyline::partyline()
{
	owners = bots = 0;
}

*/
