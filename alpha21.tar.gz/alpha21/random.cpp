/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void randstr(char *str, int n)
{
	int i;
	srand(nanotime());
	for(i=0; i<n; ++i) str[i] = rand() % 100 + 32;
}

int GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num)
{
	int i=0, j=0, k;
	int n[num];
	PTRLIST *p;

	if(!start)	return 0;
	p = start;

	if(interval < num+1)
	{
		while(1)
		{
			if(!p || i == num) break;
			ret[i] = p->ptr;
			p = p->next;
			i++;
		}
		return i;
	}
	else
	{
		GetRandomNumbers((int *) n, 0, interval, num);
		while(1)
		{
			if(!p) break;
			for(k=0; k<num; k++)
			{
				if(i == n[k])
				{
					ret[j] = p->ptr;
					j++;
				}
			}
			i++;
			p = p->next;
		}
	}
	return num;
}


int MyTurn(ptrlist *p, int hash, int num)
{
	CHANUSER **MultHandle;
	int i, j;

	MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*num);
	srand(hash);
	j = GetRandomItems(MultHandle, p->first, p->ent, num);
	for(i=0; i<j; i++)
	{
		if(!strcmp(MultHandle[i]->nick, ME.nick))
		{
			free(MultHandle);
			srand(hash32(ME.nick)*getpid());
			return 1;
		}
	}
	free(MultHandle);
	srand(hash32(ME.nick)*getpid());
	return 0;
}

int GetRandomNumbers(int *n, int start, int end, int num)
{
    int interval = end - start;
    int i, j;

    if(num > interval) num = interval;
    for(i=0; i<num; )
    {
        n[i] = (rand() % interval);
        for(j=0; j<i; j++) if(n[i] == n[j]) break;
        if(i == j) i++;
    }
    return num;
}
