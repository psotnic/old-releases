/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/*
void partyline::BotJoin(char *nick, char char *server, int fromuplink)
{



Constructor
partyline::partyline()
{
	owner = bots = 0;
}
*/