/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/* STRANGE ACTION */
void chan::EnforceLimits()
{
	if(chset->ENFORCE_LIMITS && limit)
	{
		int n = users - limit;
		CHANUSER *u = last;

		if(n > 0)
		{
			while(n && u)
			{
				if(!(u->flags & HAS_F))
				{
					ToKick.SortAdd(u);
					--n;
				}
				u = u->prev;
			}
		}
	}
}

/* MULTIUSER ACTIONS */
void chan::Op(CHANUSER **MultHandle, int num)
{
	char *a = NULL;
	int i, j;

	if(!num) return;

	if(ME.NextAction <= NOW && NOW - ME.LastMode > set.AFTER_OP_DELAY)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & OP_SENT))
			{
				a = push(a, " ", MultHandle[i]->nick, NULL);
   				MultHandle[i]->flags += OP_SENT;
				++j;
			}
		}
		if(j)
		{
			quote(ME.servfd, "MODE ", name, j == 3 ? " +ooo" : j == 2 ? " +oo" : " +o", a, NULL);
			/* FIXME: good asumptions? */
			if(j == 3) ME.NextAction = NOW + 1 + AdditionalPenality();
			else ME.NextAction = NOW + AdditionalPenality();
			free(a);
			ME.LastMode = NOW;
		}
	}
}

void chan::Kick4(CHANUSER **MultHandle, int num)
{
	if(!num) return;
	if(num > 4) num = 4;

	char *a = NULL;
	int i, j;

	if(ME.NextAction <= NOW)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j)
		{
			quote(ME.servfd, "KICK ", name, " ", a, " :", config.kickreason, NULL);
			ME.NextAction = NOW + j + AdditionalPenality();
			free(a);
		}
	}
}

void chan::Kick6(CHANUSER **MultHandle, int num)
{
	if(!num) return;
	if(num < 5) Kick4(MultHandle, num);
	else
	{
		if(num > 6) num = 6;

		Kick4(MultHandle, 2);
		ME.NextAction = NOW;
		Kick4(MultHandle+2, num-2);
		ME.NextAction = NOW + num  + AdditionalPenality();
	}
}

/* SINGLEUSER */
void chan::Op(CHANUSER *p, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(chset->PUNISH_BOTS)))
		Op(p);
}

void chan::Op(CHANUSER *p)
{
	if(!(p->flags & OP_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			quote(ME.servfd, "MODE ", name, " +o ", p->nick, NULL);
			ME.NextAction = NOW + 1;
			p->flags += OP_SENT;
		}
	}
}

void chan::DeOp(CHANUSER *p, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(chset->PUNISH_BOTS)))
		DeOp(p);
}

void chan::DeOp(CHANUSER *p)
{
	if(!(p->flags & DEOP_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			quote(ME.servfd, "MODE ", name, " -o ", p->nick, NULL);
			ME.NextAction = NOW + 1;
			p->flags += DEOP_SENT;
		}
	}
}


void chan::Kick(CHANUSER *p, unsigned int hash, char *reason)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(chset->PUNISH_BOTS)))
		Kick(p, reason);
}

void chan::Kick(CHANUSER *p, char *reason)
{
	if(!(p->flags & KICK_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			if(reason) quote(ME.servfd, "KICK ", name, " ", p->nick, " :", reason, NULL);
			else quote(ME.servfd, "KICK ", name, " ", p->nick, " :", config.kickreason, NULL);
			ME.NextAction = NOW + 1 + AdditionalPenality();
			p->flags += KICK_SENT;
		}
	}
}

void chan::KickBan(CHANUSER *p, char *mask, char *reason)
{
	if(ME.NextAction <= NOW)
	{
		ME.NextAction = NOW;
		if(!(p->flags & BAN_SENT))
		{
			quote(ME.servfd, "MODE ", name, " +b ", mask, NULL);
			p->flags += BAN_SENT;
			++ME.NextAction;
		}
		if(!(p->flags & KICK_SENT))
		{
			if(reason) quote(ME.servfd, "KICK ", name, " ", p->nick, " :", reason, NULL);
			else quote(ME.servfd, "KICK ", name, " ", p->nick, " :", config.banreason, NULL);
			p->flags += KICK_SENT;
			ME.NextAction += AdditionalPenality();
		}
	}
}

void chan::Unban(char *str, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(chset->UNBAN_BOTS)) && ME.NextAction <= NOW)
	{
		char ban[5] = "-";
		char *a;
		int i;

		for(i=1, a=str; i<4; ++a)
		{
			if(*a == '\0') break;
			if(*a == ' ') ban[i++] = 'b';
		}
		ban[i] = '\0';
		quote(ME.servfd, "MODE ", name, " ", ban, " ", str, NULL);
	}
}

int chan::Invite(char *nick, int f)
{
	if(ME.NextAction <= NOW)
	{
		if(ME.NextMsg <= NOW)
		{
			if(ptr->flags & IS_OP)
			{
				quote(ME.servfd, "INVITE ", nick, " ", name, NULL);
				ME.NextMsg = NOW + f ? set.FRIEND_ACTION_PENALITY : set.ACTION_PENALITY;
				return 1;
			}
		}
	}
	return 0;
}
