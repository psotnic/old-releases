/**********r****************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int chan::QuoteOpedBots(char *str, int num)
{
	int *n = (int *) malloc(num * sizeof(int));
	int i, j, k, l;
	int r = 0;
	PTRLIST *p = OpedBots.first;

	j = GetRandomNumbers((int *) n, 0, OpedBots.ent, num);

	for(k=0; ;++k)
	{
		if(!p) break;
		for(i=0; i<j; ++i)
		{
			/* now get fd */
			if(n[i] == k)
			{
				/* it's me */
				if(p->ptr == ptr && ptr) r = 1;
				/* other bots */
				else for(l=0; l<MAX_CONN; ++l)
				{
					if(sock[l].fd)
					{
						if(!strcasecmp(sock[l].name, p->ptr->nick))
						{
							quote(sock[l].fd, str, NULL);
						}
					}
				}
			}
		}
		p = p->next;
	}
	return r;
}

int chan::GotBan(char *ban, CHANUSER *caster)
{
	if(!ban) return 0;

	CHANUSER *u;
	char mask[MAX_LEN];

	for(u = first; u; u = u->next)
	{
		if(u->flags & HAS_F && UserLevel(caster) <= UserLevel(u))
		{
			UserMask(mask, u);
   			if(match(mask, ban))
			{
				if(!(caster->flags & HAS_F)) ToKick.SortAdd(caster);
				return 1;
			}
		}
	}

	if(chset->ENFORCE_BANS)
	{
		for(u = first; u; u = u->next)
		{
			if(!(u->flags & HAS_F) && UserLevel(caster) > UserLevel(u))
			{
				UserMask(mask, u);
				if(match(mask, ban)) ToKick.SortAdd(u);
			}
		}
	}
	return 0;
}

void chan::Rejoin(int t)
{
	int i;

	i = userlist.FindChannelInList(name);
	if(i != -1)	userlist.chanlist[i].nextjoin = NOW + t;
}

int chan::NumberOfBots(int num)
{
	if(num >= 0) return num;
	if(num == -100) return OpedBots.ent;
	return (num * OpedBots.ent * (-1)) / 100  + 1;
}

void chan::ReOp()
{
	char *buf;
	buf = push(NULL, "REOP ", name, NULL);
	QuoteBots(buf);
	quote(FD_OWNERS, "*** Reoping ", name, NULL);
	free(buf);
}

void chan::QuoteBots(char *str)
{
	CHANUSER *p;
	int i;

	p = first;
	while(1)
	{
		if(!p) return;
		if(p->flags & HAS_B)
			for(i=0; i<MAX_CONN; ++i)
				if(sock[i].fd)
					if(!strcasecmp(sock[i].name, p->nick) || sock[i].name[0] == '<')
						quote(sock[i].fd, str, NULL);
		p = p->next;
	}
}

void chan::GotNickChange(char *from, char *to)
{
	CHANUSER *p = GetUser(from);
	STRINGLIST *s;
	int status = 0;

	if(!p) return;

	if(ToOp.Remove(p)) status += 1;
	if(BotsToOp.Remove(p)) status += 2;
	if(OpedBots.Remove(p)) status += 4;
	if(ToKick.Remove(p)) status += 8;

	free(p->nick);
	mem_strcpy(p->nick, to);

	if(status & 1) ToOp.SortAdd(p);
	if(status & 2) BotsToOp.SortAdd(p);
	if(status & 4) OpedBots.SortAdd(p);
	if(status & 8) ToKick.SortAdd(p);

	s = ToBan.Find(NULL, from, NULL);
	if(s)
	{
		free(s->str[1]);
		mem_strcpy(s->str[1], to);
	}
}

CHANUSER *chan::GetUser(char *nick)
{
	CHANUSER *p = first;
	if(!nick) return NULL;
	while(p)
	{
		if(!strcasecmp(nick, p->nick)) return p;
		p = p->next;
	}
	return NULL;
}

void chan::GotKick(char *victim, char *offender)
{
	CHANUSER *kicked, *kicker;
	char *nick, *a;

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicked = GetUser(victim);
	kicker = GetUser(nick);

	if((kicked->flags & HAS_F) && !(kicker->flags & HAS_F))
	{
		ToKick.SortAdd(kicker);
		DeOp(kicker, hash32(kicker->nick, name));
	}
	GotPart(victim, 0);
	free(nick);
}

void chan::GotPart(char *nick, int quit)
{
	CHANUSER *p = first;

	int bot = 0;

	if(!first) return;
	if(!strcasecmp(first->nick, nick))
	{
		bot = first->flags & HAS_B;
		first = first->next;
		if(first) first->prev = NULL;
		RemoveFromAllPtrLists(p);
		Destroy(p);
		--users;
		if(!users) last = NULL;
	}
	else if(!strcasecmp(last->nick, nick))
	{
		bot = last->flags & HAS_B;
		p = last->prev;
		p->next = NULL;
		RemoveFromAllPtrLists(last);
		Destroy(last);
		--users;
		last = p;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->nick, nick))
			{
				bot = p->flags & HAS_B;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				RemoveFromAllPtrLists(p);
				Destroy(p);
				--users;
				break;
			}
			p = p->next;
		}
	}
	if(users == 1 && !(ptr->flags & IS_OP))
	{
		if(status & STATUS_SYNCED)
		{
			quote(ME.servfd, "PART ", name, NULL);
			quote(ME.servfd, "JOIN ", name, NULL);
		}
	}
	else if(BotsToOp.ent == users)
	{
		if(config.listenport && status & STATUS_SYNCED && (!bot || quit)) ReOp();
	}
	else if(!modes && !ToKick.ent) quote(ME.servfd, "MODE ", name, NULL);

}

void chan::Display()
{
    CHANUSER *p = first;
    int i;
	char buf[32];

    while(1)
    {
		if(p == NULL) break;
		i=0;
		if(p->flags & HAS_A) buf[i++] = 'a';
		if(p->flags & HAS_B) buf[i++] = 'b';
		if(p->flags & HAS_O) buf[i++] = 'o';
		if(p->flags & HAS_F) buf[i++] = 'f';
		if(p->flags & HAS_M) buf[i++] = 'm';
		if(p->flags & HAS_N) buf[i++] = 'n';
		if(p->flags & HAS_D) buf[i++] = 'd';
		if(i == 0) buf[i++] = '-';
		buf[i] = '\0';
		printf("[%d]: %s!%s@%s, flags: %s[%d]\n", i, p->nick, p->ident, p->host, buf, p->flags);
		p=p->next;
		i++;
    }
    p = last;
    i = users-1;
	printf("ToOp:\n");
	ToOp.Display();
	printf("BotsToOp:\n");
	BotsToOp.Display();
	printf("ToKick:\n");
	ToKick.Display();
	printf("OpedBots:\n");
	OpedBots.Display();
	printf("ToBan:\n");
	ToBan.Display();
	printf("Modes: %s\n", modes);
	printf("Limit: %d\n", limit);
	printf("Key: %s\n", key);
}


CHANUSER *chan::GotJoin(char *mask, int op)
{
    CHANUSER *p;
	STRINGLIST *s = NULL;
    char *a, *b;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }

    a = strchr(mask, '!');
    b = strchr(mask, '@');
    mem_strncpy(last->nick, mask, (int) abs(mask - a) +1);
    mem_strncpy(last->ident, a+1, (int) abs(a - b));
    mem_strcpy(last->host, b+1);
    ++users;
    last->flags = userlist.GetFlags(mask);

	if(config.listenport)
	{
		if((s = shitlist.WildFind(mask, 0)))
		{
			if(!ToBan.Find(s->str[0], 0))
			{
				a = push(NULL, S_KICKBAN, " ", name, " ", last->nick, " ", s->str[0], " ", s->str[1], NULL);
				srand(hash32(name,  s->str[0]));
				if(QuoteOpedBots(a, NumberOfBots(chset->SHIT_BOTS))) KickBan(last, s->str[0], s->str[1]);
				srand(hash32(ME.nick)*getpid());
				ToBan.Add(s->str[0], last->nick, s->str[1], 0);
				free(a);
			}
		}
	}
	if(chset->LIMIT_CHAN_USERS && limit && users > limit && !(last->flags & HAS_F))
	{
		ToKick.SortAdd(last);
		Kick(last, hash32(last->nick, name), config.limitreason);
	}
	else if(last->flags & (HAS_O + HAS_A) && !op && !(last->flags & HAS_D) && !s)
	{
		if(last->flags & HAS_B) BotsToOp.SortAdd(last);
		else ToOp.SortAdd(last);

		/* Add this actions to queue
		   We dont have unban list so we have to send data */
		if(ptr && OpedBots.ent && ME.NextAction <= NOW)
		{
			if(MyTurn(&OpedBots, hash32(last->nick, name), NumberOfBots(chset->AUTOOP_BOTS)))
			{
				if(BanOverride)
				{
					if(last->flags & HAS_F)
					{
						quote(ME.servfd, "MODE ", name, " +o-b ", last->nick, " ", BanOverride, NULL);
						set(last->flags, OP_SENT);
					}
				}
				else Op(last);
			}
		}
	}

	if(op)
	{
		last->flags += IS_OP;
		if(!(last->flags & HAS_F || last->flags & HAS_O)) ToKick.SortAdd(last);
		if(last->flags & HAS_B) OpedBots.SortAdd(last);
	}
	else if(BanOverride && !(last->flags & HAS_F))
	{
		ToKick.SortAdd(last);
		Kick(last, hash32(last->nick, name), config.banreason);
	}

	if(BanOverride)
	{
		free(BanOverride);
		BanOverride = NULL;
	}
	if(BotsToOp.ent == users && config.listenport && status & STATUS_SYNCED) ReOp();

	return last;
}

/* Constructor */
chan::chan()
{
    last = first = NULL;
    limit = status = users = 0;
	ptr = NULL;
	name = BanOverride = modes = key = NULL;
}

/* Destruction derby */
chan::~chan()
{
	CHANUSER *p = first;
	CHANUSER *q;

	while(p)
	{
		q = p;
		p = p->next;
		Destroy(q);
	}
	if(BanOverride) free(BanOverride);
	if(name) free(name);
	if(modes) free(modes);
	if(key) free(key);
}

void chan::Destroy(CHANUSER *p)
{
	free(p->nick);
	free(p->ident);
	free(p->host);
	free(p);
}

void chan::RemoveFromAllPtrLists(CHANUSER *handle)
{
	ToKick.Remove(handle);
	OpedBots.Remove(handle);
	BotsToOp.Remove(handle);
	ToOp.Remove(handle);
}
