/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

/*************
* LIST
*/

template <class _type>
class list
{
	public:
	struct node
	{
		_type *obj;
		node *next;
		node *prev;
	} *first, *last;
	int ent;

	void Add(_type *ptr)
	{
		if(!ent)
		{
			first = last = new(node);
			first->prev = first->next = NULL;
			first->obj = ptr;
		}
		else
		{
			last->next = new(node);
			last->next->prev = last;
			last = last->next;
			last->obj = ptr;
			last->next = NULL;
		}
		++ent;
		printf(">> Add\n");
	}

	node *Find(_type *ptr)
	{
		node *p = first;
		while(p)
		{
			if(p->obj = ptr) return p;
			p = p->next;
		}
		return NULL;
	}

	int Remove(_type *ptr, node *p)
	{
		if(ent == 1) delete(first);
		else
		{
			if(ptr == first->obj)
			{
				first = first->next;
				if(first) first->prev = NULL;
				delete(first);

			}
			else if(ptr == last->obj)
			{
				last = last->prev;
				last->next = NULL;
				delete(last);
			}
			else
			{
				if(!p) p = Find(ptr);
				if(p)
				{
					p->prev->next = p->next;
					p->next->prev = p->prev;
					delete(p);
				}
				else return 0;
			}
		}
		--ent;
		return 1;
	}

	list()
	{
		printf(">> List Constructor\n");
		first = last = NULL;
		ent = 0;
	}

	~list()
	{
		node *p = first;
		node *q;
		printf(">> List Destructor\n");
		while(p)
		{
			q = p;
			p = p->next;
			delete(q);
		}
	}

};

