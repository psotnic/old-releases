/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_hub(char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;
	int i;
	USER_HANDLE *h;

	if(!strlen(data)) return;
	str2words(arg[0], data, 10, MAX_LEN);

	if(!(hub.status & STATUS_REGISTERED))
	{
		switch(hub.authstep)
		{
			case 1:
			{
				if(!strcmp(arg[0], S_AUTH) && strlen(arg[1]) == AUTHSTR_LEN)
				{
					char hash[33];
					++hub.authstep;
					//printf("### hashing '%s' '%s'\n", arg[1], config.hubpass);
					MD5HexHash(hash, arg[1], AUTHSTR_LEN, config.hubpass, strlen(config.hubpass));
					quote(hub.fd, S_AUTHRPL, " ", hash, NULL);
					return;
				}
				break;
			}
			case 2:
			{
				if(!strcmp(arg[0], S_AUTHOK))
				{
					++hub.authstep;
					hub.authstr = (char *) malloc(AUTHSTR_LEN + 1);
					MD5CreateAuthString(hub.authstr, AUTHSTR_LEN);
					quote(hub.fd, S_AUTH, " ", hub.authstr, NULL);
					return;
				}
				break;
			}
			case 3:
			{
				if(!strcmp(arg[0], S_AUTHRPL) && strlen(arg[1]) == 32)
				{

					if(MD5HexValidate(arg[1], hub.authstr, 32, config.hubpass, strlen(config.hubpass)))
					{
						char buf[32];

						free(hub.authstr);
						hub.authstr = NULL;
						sprintf(buf, "%llu", userlist.SN);
						mem_strcpy(hub.name, "<hub>");
						if(ME.status & STATUS_REGISTERED) quote(hub.fd, S_REGISTER , " ", ME.nick, " ", S_VERSION, " ", buf, NULL);
						else quote(hub.fd, S_REGISTER, " <", config.nick, "> ", S_VERSION, " ", buf, NULL);
						hub.status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_HUB;
						hub.killtime = 0;
						return;
					}
				}
				break;
			}
			default: break;
		}
		/* HUH */
		printf("[-] Failed to register HUB\n");
		CloseSock(&hub);
	}


	if(!strcmp(arg[0], S_UL_UPLOAD_START) && !(ME.status & STATUS_DOWNLOADINGUL))
	{
		printf("[*] Fetching Userlist\n");
		ME.status += STATUS_DOWNLOADINGUL;
		mem_strcpy(userlist.ulbuf, "");
		userlist.ulbuflines = 0;
		return;
	}
	if(!strcmp(arg[0], S_UL_UPLOAD_END) && ME.status & STATUS_DOWNLOADINGUL)
	{
		ME.status -= STATUS_DOWNLOADINGUL;
		userlist.Update();
		return;
	}
	if(ME.status & STATUS_DOWNLOADINGUL)
	{
		strcat(data, "\n\0");
		mem_strcat(userlist.ulbuf, data);
		++userlist.ulbuflines;
		return;
	}

	/* add */
	if(!strcmp(arg[0], S_ADDUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
	{
		userlist.AddHandle(arg[1]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ADDHOST) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.AddHost(h, arg[2]);
		++userlist.SN;
		ME.RecheckFlags();
		return;
	}
	if(!strcmp(arg[0], S_ADDCHAN) && strlen(arg[1]))
	{
		if(strlen(arg[2])) userlist.AddChannelToList(arg[1], arg[2]);
   		else userlist.AddChannelToList(arg[1], "");
		if(strlen(arg[2])) quote(ME.servfd, "JOIN ", arg[1], " ", arg[2], NULL);
		else quote(ME.servfd, "JOIN ", arg[1], NULL);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_ADDBOT) && strlen(arg[2]))
	{
		userlist.AddBot(arg[1], arg[2], arg[3]);
		++userlist.SN;
		ME.RecheckFlags();
   		return;;
	}

	/* remove */
	if(!strcmp(arg[0], S_RMUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
	{
		userlist.RemoveHandle(arg[1]);
		++userlist.SN;
		ME.RecheckFlags();
		return;
	}
	if(!strcmp(arg[0], S_RMHOST) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.RemoveHost(h, arg[2]);
		++userlist.SN;
		ME.RecheckFlags();
		return;
	}
	if(!strcmp(arg[0], S_RMCHAN) && strlen(arg[1]))
	{
		userlist.RemoveChannelFromList(arg[1]);
		quote(ME.servfd, "PART ", arg[1], " :", config.partreason, NULL);
		++userlist.SN;
		return;
   	}
	if(!strcmp(arg[0], S_RMBOT) && strlen(arg[1]))
	{
		userlist.RemoveBot(arg[1]);
		++userlist.SN;
		ME.RecheckFlags();
   		return;
	}

	/* other */
	if(!strcmp(arg[0], S_CHATTR) && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h) userlist.ChangeFlags(h, arg[2]);
		++userlist.SN;
		ME.RecheckFlags();
		return;
	}
	if(!strcmp(arg[0], S_ULSAVE))
	{
		userlist.Save(config.userlist_file);
		return;
	}

 	/* S_KICKBAN <chan> <nick> <mask> [reason] */
	if(!strcmp(arg[0], S_KICKBAN) && strlen(arg[3]))
	{
		ch = ME.FindChannel(arg[1]);
		if(ch)
		{
			CHANUSER *u;
			if((u = ch->GetUser(arg[2])))
			{
				a = srewind(data, 4);
				if(!a) a = config.banreason;

				if(ME.NextAction <= NOW)
				{
					if(u->flags & IS_OP) quote(ME.servfd, "MODE ", arg[1], " -o+b ", arg[2], arg[3], NULL);
					else quote(ME.servfd, "MODE ", arg[1], " +b ", arg[3], NULL);
					quote(ME.servfd, "KICK ", arg[1], " ", arg[2], " :", a, NULL);
					ME.NextAction = NOW + 3;
				}
				ch->ToBan.Add(arg[3], arg[2], a, 0);
			}
		}
		return;
	}
	if(!strcmp(arg[0], S_SET) && strlen(arg[2]))
	{
		set.setvar(arg[1], arg[2]);
		++userlist.SN;
		return;
	}
	if(!strcmp(arg[0], S_CHSET) && strlen(arg[3]))
	{
		int i;
		i = userlist.FindChannelInList(arg[1]);
		if(i != -1)
		{
			userlist.chanlist[i].chset->setvar(arg[2], arg[3]);
			++userlist.SN;
		}
		return;
	}
	if(!strcmp(arg[0], S_CYCLE) && strlen(arg[1]))
	{
		if(ME.FindChannel(arg[1]))
			quote(ME.servfd, "PART ", arg[1], " :", config.cyclereason, NULL);
		ME.Rejoin(arg[1], set.CYCLE_DELAY);
		return;
	}

	/* S_INVITE <chan> [nick] */
	if(!strcmp(arg[0], S_INVITE) && strlen(arg[1]))
	{
		if(strlen(arg[2])) ME.BotNetInvite(arg[1], arg[2]);
		else ME.BotNetInvite(arg[1], hub.name);
		return;
	}
	if(!strcmp(arg[0], S_NEWNICK))
	{
		if(hub.name) free(hub.name);
		mem_strcpy(hub.name, arg[1]);
		return;
	}
	if(!strcmp(arg[0], S_KEYRPL) && strlen(arg[2]))
	{
		i = userlist.FindChannelInList(arg[1]);
		if(i != -1)
		{
			if(userlist.chanlist[i].pass) free(userlist.chanlist[i].pass);
			mem_strcpy(userlist.chanlist[i].pass, arg[2]);
			if(!ME.FindChannel(arg[1]))	quote(ME.servfd, "JOIN ", arg[1], " ", arg[2], NULL);
		}
		return;
	}
	if(!strcmp(arg[0], S_KEY) && strlen(arg[1]))
	{
		ch = ME.FindChannel(arg[1]);
		if(strlen(arg[2]))
		{
			mem_strcpy(a, arg[2]);
		}
		else mem_strcpy(a, hub.name);

		if(ch)
		{
			if(ch->key)
			{
				quote(hub.fd, S_KEYRPL, " ", arg[1], " ", ch->key, NULL);
			}
		}
		free(a);
		return;
	}
	if(!strcmp(arg[0], S_REOP) && strlen(arg[1]))
	{
		if(ME.FindChannel(arg[1]))
		{
			quote(ME.servfd, "PART ", arg[1], " :", config.partreason, NULL);
			ME.Rejoin(arg[1], set.CYCLE_DELAY);
		}
		return;
	}
}
