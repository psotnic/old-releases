/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#define HAS_A                   1
#define HAS_D                   2
#define HAS_O                   4
#define HAS_F                   8
#define HAS_M                   16
#define HAS_N                   32
#define HAS_ALL					63
/* vacent */
#define HAS_B                   128
#define IS_OP                   256
#define KICK_SENT				512
#define OP_SENT					1024
#define BAN_SENT				2048
#define UNBAN_SENT				4096
#define DEOP_SENT				8192

#define ARG_MODES				"oblkeIv"
#define NONARG_MODES			"imntsp"

#define STATUS_CONNECTED		1
#define STATUS_REGISTERED		2
#define STATUS_SYNSENT			4
#define STATUS_OWNER			8
#define STATUS_BOT				16
#define STATUS_HUB				32
#define STATUS_DOWNLOADINGUL	64
#define STATUS_SYNCED			128

#define MAX_LEN					1024
#define MAX_CONN        		64
#define MAX_BUFS				MAX_CONN+2
#define MAX_SERVERS				16
#define MAX_CHANNELS			16
#define MAX_HOSTS				64
#define MD5_HEXDIGEST_LEN		32
#define AUTHSTR_LEN				32

#define FD_OWNERS				-1000
#define FD_BOTS					-1001

#define TCP_NODELAY				1

#define S_AUTH					"AUTH"
#define S_AUTHRPL				"AUTHRPL"
#define S_AUTHOK				"AUTHOK"

#define S_UL_UPLOAD_START		"UL_UPLOAD_START"
#define S_UL_UPLOAD_END			"UL_UPLOAD_END"
#define S_NEWNICK				"NEWNICK"
#define S_REGISTER				"REGISTER"
#define S_UNKNOWN				"<unknown>"
#define S_SECRET				"-"
#define S_INVITE				"INVITE"
#define S_KEY					"KEY"
#define S_KEYRPL				"KEYRPL"
#define S_REOP					"REOP"
#define S_CYCLE					"CYCLE"

#define S_ADDUSER				"ADDUSER"
#define S_ADDHOST				"ADDHOST"
#define S_ADDBOT				"ADDBOT"
#define S_ADDCHAN				"ADDCHAN"

#define S_RMUSER				"RMUSER"
#define S_RMHOST				"RMHOST"
#define S_RMBOT					"RMBOT"
#define S_RMCHAN				"RMCHAN"

#define S_CHATTR				"CHATTR"
#define S_ULSAVE				"SAVE"
#define S_SN					"SN"
#define S_SET					"SET"
#define S_CHSET					"CHSET"
#define S_KICKBAN				"KB"

#define S_VERSION				"0.0.20"
#define S_BOTNAME				"psotnic"
#define S_COPYRIGHT				"Copyright (C) 2003 Grzegorz Rusin <pks@irc.pl, gg:1569230>"

#define mem_strncpy(__dest, __src, __n)		\
{											\
	__dest = (char *) malloc(__n+1);		\
	strncpy(__dest, __src, __n);			\
	__dest[__n-1] = '\0';					\
}

#define mem_strcpy(__dest, __src)				\
{												\
	__dest = (char *) malloc(strlen(__src)+1);	\
	strcpy(__dest, __src);						\
}

#define mem_strcat(__dest, __src)										\
{																		\
	__dest = (char *) realloc(__dest, strlen(__src)+strlen(__dest)+1);	\
	strcat(__dest, __src);												\
}

#define maskstrip(__mask, __nick, __ident, __host)			\
{															\
	char *__a = strchr(__mask, '!');						\
   	char *__b = strchr(__mask, '@');						\
   	mem_strncpy(__nick, __mask, (int) abs(__mask-__a)+1);	\
   	mem_strncpy(__ident, __a+1, (int) abs(__a - __b));		\
   	mem_strcpy(__host, __b+1);								\
}

#define UserMask(__mask, __user)							\
{															\
	strcpy(__mask, __user->nick);							\
	strcat(__mask, "!");									\
	strcat(__mask, __user->ident);							\
	strcat(__mask, "@");									\
	strcat(__mask, __user->host);							\
}

#define set(__a, __b)			if(!(__a & __b)) __a += __b
#define unset(__a, __b)			if(__a & __b) __a -= __b
#define debug()					printf("[D] [%s:%d] %s(): %s\n", __FILE__, __LINE__, __FUNCTION__, strerror(errno))
#define	bk()					printf("### %s(): %s:%d\n", __FUNCTION__, __FILE__, __LINE__)
#define AdditionalPenality()	((NOW - ME.NextAction) < 3 ? 3 : 0)
