#include "prots.h"

int AUTOOP_BOTS;
int PUNISH_BOTS;
time_t NOW;
int PUNISH_METHOD;
unsigned int magic[9];
client ME;
BOTNET bot[MAX_CONN];
BOTNET hub;
SERVER server[MAX_SERVERS];

int main()
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd;

	precache();
	
	while(1)
	{
		n = ME.ConnectToIRC();
		if(n < 1)
		{
			printf("Waiting 30 secs\n");
			sleep(IRC_CONN_DLEAY);
			continue;
		}
		tv.tv_sec = 1;
    	tv.tv_usec = 0;
		srand(time(NULL)*getpid());
		sprintf(buf, "p[%d]", rand()%1000);
		quote(ME.servfd, "NICK ", buf, NULL);
		quote(ME.servfd, "USER bot 8 * :tra la la", NULL);
		last = NOW = time(NULL);
		while(1)
		{
			if(!tv.tv_sec) tv.tv_sec = 1;

			FD_ZERO(&rfd);
    		FD_SET(ME.servfd, &rfd);
			if(hub.fd) FD_SET(hub.fd, &rfd);

			ret = select(65535, &rfd, NULL, NULL, &tv);

			NOW = time(NULL);
			if(NOW > last + 2)
			{
				last = NOW;
				if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
			}
			if(ME.nextconn <= NOW && !hub.fd)
			{
				printf("## Connecting to hub\n");
				ME.ConnectToHUB();
				if(!hub.fd)
				{
					ME.nextconn = NOW + HUB_CONN_DELAY;
					printf("## Cannot connect to Hub, next conn in %d secs\n", HUB_CONN_DELAY);
				}
				else
				{
					printf("## Connected to hub\n");
				}

			}

			if(!ret) continue;
			if(FD_ISSET(ME.servfd, &rfd))
			{
				n = ReadOneLine(ME.servfd, buf, MAX_LEN);
				if(n < 1)
				{
					printf("Lost server\n");
					debug();
					if(sclose(ME.servfd) !=0) debug();
					ME.servfd = 0;
					break;
				}
				ircparser(buf);
			}
			if(FD_ISSET(hub.fd, &rfd))
			{
				n = ReadOneLine(hub.fd, buf, MAX_LEN);
				if(n < 1)
				{
					printf("Lost hub\n");
					debug();
					if(sclose(hub.fd) != 0) debug();
					hub.fd = 0;
				}
				//sthparser(buf);
			}

		}
	}
	return 0;
}

