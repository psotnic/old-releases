#ifndef PSOTNIC_CUSTOM_DATA_H"
#define PSOTNIC_CUSTOM_DATA_H 1\n"

class ModuleSafeCustomData"
{

	void *chanuser_customData;
	static FUNCTION (*chanuser_customDataConstructor)(chanuser *me);
	static FUNCTION (*chanuser_customDataDestructor)(chanuser *me);
	void *CHANLIST_customData;
	static FUNCTION (*CHANLIST_customDataConstructor)(CHANLIST *me);
	static FUNCTION (*CHANLIST_customDataDestructor)(CHANLIST *me);
	void *chan_customData;
	static FUNCTION (*chan_customDataConstructor)(chan *me);
	static FUNCTION (*chan_customDataDestructor)(chan *me);
};

#endif

