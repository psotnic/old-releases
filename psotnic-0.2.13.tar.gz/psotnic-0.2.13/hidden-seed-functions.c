void gen_cfg_seed(unsigned char *out)
{
    int i;
    out[0] = 191;
    out[1] = 181;
    out[2] = 187;
    out[3] = 139;
    out[4] = 48;
    out[5] = 16;
    out[6] = 102;
    out[7] = 251;
    out[8] = 140;
    out[9] = 151;
    out[10] = 152;
    out[11] = 220;
    out[12] = 102;
    out[13] = 245;
    out[14] = 224;
    out[15] = 50;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 102;
    }
}

void gen_ul_seed(unsigned char *out)
{
    int i;
    out[0] = 102;
    out[1] = 199;
    out[2] = 116;
    out[3] = 79;
    out[4] = 84;
    out[5] = 206;
    out[6] = 28;
    out[7] = 19;
    out[8] = 201;
    out[9] = 232;
    out[10] = 138;
    out[11] = 221;
    out[12] = 63;
    out[13] = 100;
    out[14] = 112;
    out[15] = 144;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 61;
    }
}

