#ifndef PSOTNIC_SVN_REV_H
#define PSOTNIC_SVN_REV_H 1

#define SVN_REVISION "68"
#endif
