#include "prots.h"
unsigned int magic[8];

int main()
{
	server x;
	chan *piwo;
	precache();

	x.JoinChannel("#piwo");

	piwo = x.FindChannel("#piwo");
	printf("piwo: %p\n", piwo);

	piwo->GotJoin("pks!pks@irc.pl");
	printf("ble1\n");
    piwo->GotJoin("jaru!jaru@localhost");
	piwo->GotJoin("ZZeZZ!psotnic@ssie.at");
	piwo->GotJoin("Bolek!ble@ble.com");
	piwo->GotJoin("agregat!x@bla.bla.pl");
	piwo->GotJoin("ZZyZZ!psotnic@ssie.at");
	piwo->GotJoin("a!jaru@a.com");

	piwo->DebugDisplay();
	//printf("-----------------\n");
	piwo->GotKick("pks", "agregat");
	//printf("removed\n");
	piwo->GotMode("-oi+b", "a *!jola@sex.pl", "jaru");
	//piwo.DebugDisplay();
	piwo->GotNickChange("jaru", "ziomek");
	printf("#########################\n");
	piwo->DebugDisplay();

	x.RemoveChannel(piwo->name);


	return 0;
}

