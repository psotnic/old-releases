extern unsigned int magic[8];
