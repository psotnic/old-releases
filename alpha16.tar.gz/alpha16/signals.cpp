/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int SigTerm()
{
	printf("[*] Got termination signal\n");
	userlist.Save(config.userlist_file);
	printf("[*] Calling exit(1) \n");
	exit(1);
}

int SigInt()
{
	printf("[*] Terminated by user\n");
	userlist.Save(config.userlist_file);
	printf("[*] Calling exit(1) \n");
	exit(1);
}

int SigHup()
{
	userlist.Save(config.userlist_file);
}

int SigSegv()
{
	printf("[E] !!! SEGMENTATION VIOLATION !!!\n");
	printf("[E] Plase send log (10 to 30 lines) to pks@irc.pl\n");
	printf("[E] Thank you\n");
	printf("[*] Calling exit(2)\n");
	exit(2);
}

int SafeExit()
{
	printf("[*] Abnormal program termination\n");
	userlist.Save(config.userlist_file);
	printf("[*] Calling exit(3)\n");
	exit(3);
}

int SignalHandling()
{
	signal(SIGPIPE, SIG_IGN);

 	signal(SIGTERM, (sighandler_t) SigTerm);
	signal(SIGINT, (sighandler_t) SigInt);
	signal(SIGHUP, (sighandler_t) SigHup);

	signal(SIGSEGV, (sighandler_t) SigSegv);
	return 0;
}



