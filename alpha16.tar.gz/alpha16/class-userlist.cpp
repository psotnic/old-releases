/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void ul::Update()
{
	int i, n;
	char arg[10][MAX_LEN], buf[MAX_LEN], *a, *b;
	HANDLE *h;

	b = ulbuf;

	a = NULL;
	userlist.reset();

	for(n=0; n<ulbuflines; ++n)
	{
		memset(buf, 0, MAX_LEN);
		a = strchr(b, '\n');
		strncpy(buf, b, abs(b-a));
		b = a + 1;
		printf("[%2d/%2d]-> %s\n", n, ulbuflines, buf);
		for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  										 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

		if(!strcmp(arg[0], ".+user") && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chattr") && strlen(arg[1]))
		{
			h = userlist.FindHandle(arg[1]);
			if(h) userlist.ChangeFlags(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".+chan") && strlen(arg[1]))
		{
			if(strlen(arg[2])) ME.AddChannelToList(arg[1], arg[2]);
   			else ME.AddChannelToList(arg[1], "");
		}
		if(!strcmp(arg[0], ".+bot") && strlen(arg[2]))
		{
			userlist.AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], "SERIAL_NUMBER") && strlen(arg[1]))
		{
			SN = atoll(arg[1]);
			continue;
		}
	}
	printf("[+] Rehashed\n");
	Save(config.userlist_file);
}


void ul::Send(int fd)
{
	char buf[MAX_LEN];
	HANDLE *h = first;
	BOT *b = Bfirst;
	int i;

	if(fd < 1) return;

	quote(fd, S_UL_UPLOAD_START, NULL);
	sprintf(buf, "%d", SN);
	quote(fd, "SERIAL_NUMBER ", buf, NULL);
	while(1)
	{
		if(!h) break;
		quote(fd, ".+user ", h->name, NULL);
		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i] != NULL) quote(fd, ".+host ", h->name, " ", h->host[i], NULL);
		GetFlags(h, buf);
		quote(fd, ".chattr ", h->name, " ", buf, NULL);
		h = h->next;
	}
	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(ME.chanlist[i].name)
		{
			if(strlen(ME.chanlist[i].pass)) quote(fd, ".+chan ", ME.chanlist[i].name, " ", ME.chanlist[i].pass, NULL);
			else quote(fd, ".+chan ", ME.chanlist[i].name, NULL);
		}
	}

	while(1)
	{
		if(!b) break;
		quote(fd, ".+bot ", b->mask, " ", S_SECRET, " ", S_SECRET, NULL);
		b = b->next;
	}
	quote(fd, S_UL_UPLOAD_END, NULL);
}

int ul::CheckBotPass(char *ip, char *pass)
{
	BOT *b = Bfirst;

	while(1)
	{
		if(!b) return 0;
		if(match(ip, b->ip) && !strcmp(pass, b->pass)) return 1;
		b = b->next;
	}
}

int ul::IsOwner(char *mask)
{
	HANDLE *h = first;
	int i;

	if(match(mask, config.owner)) return 1;
	while(1)
	{
		if(!h) return 0;
		if(h->flags & HAS_N)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(h->host[i])
				{
					if(match(mask, h->host[i]))
					{
						return 1;
					}
				}
			}
		}
		h = h->next;
	}
}

int ul::IsBot(char *ip)
{
	BOT *b = Bfirst;

	while(1)
	{
		if(!b) return 0;
		if(match(ip, b->ip)) return 1;
		b = b->next;
	}
}

BOT *ul::FindBot(char *mask)
{
	BOT *p;

	p = Bfirst;
	while(1)
	{
		if(!p) return NULL;
		if(!strcasecmp(p->mask, mask)) return p;
		p = p->next;
	}
}

void ul::RemoveAllBotData(BOT *p)
{
	free(p->mask);
	free(p->ip);
	free(p->pass);
}

BOT *ul::AddBot(char *mask, char *ip, char *pass)
{
    BOT *p;

	if(FindBot(mask)) return NULL;
    if(!bots)
    {
		Blast = Bfirst = new(BOT);
		Bfirst->next = Bfirst->prev = NULL;
	}
    else
    {
		p = Blast->next = new(BOT);
		p->prev = Blast;
		p->next = NULL;
		Blast = p;
    }
	bots++;
	mem_strcpy(Blast->mask, mask);
	mem_strcpy(Blast->ip, ip);
	mem_strcpy(Blast->pass, pass);
	return Blast;
}

int ul::RemoveBot(char *mask)
{
	BOT *p;
	p = Bfirst;

	if(!Bfirst) return 0;
	if(!strcasecmp(Bfirst->mask, mask))
	{
		Bfirst = Bfirst->next;
		if(Bfirst) Bfirst->prev = NULL;
		RemoveAllBotData(p);
		delete(p);
		bots--;
		return 1;
	}
	else if(!strcasecmp(Blast->mask, mask))
	{
		p = Blast->prev;
		p->next = NULL;
		RemoveAllBotData(Blast);
		delete(Blast);
		bots--;
		Blast = p;
		return 1;
	}
	else
	{
		while(1)
		{
			if(!p)
			{
				return 0;
			}
			if(!strcasecmp(p->mask, mask))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				RemoveAllBotData(p);
				delete(p);
				bots--;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

int ul::GetFlags(char *mask)
{
	HANDLE *p = first;
	BOT *b = Bfirst;
	int need = HAS_ALL, got, i;

	while(1)
	{
		if(!b) break;
		if(match(mask, b->mask))
		{
			need -= HAS_A + HAS_O + HAS_F + HAS_M + HAS_B;
			break;
		}
		b = b->next;
	}

	while(1)
	{
		if(!p) break;
		got = need & p->flags;
		if(got)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(p->host[i])
				{
					if(match(mask, p->host[i]))
					{
						need -= got;
						break;
					}
				}
			}
		}
		p = p->next;
	}
	return HAS_ALL - need;
}

int ul::Save(char *file)
{
	char buf[MAX_LEN];
	FILE *f;
	HANDLE *h = first;
	BOT *b = Bfirst;
	int i;

	printf("[*] Saving userlist\n");
	f = fopen(file, "w");
	if(!f)
	{
		printf("[-] Error: %s\n", strerror(errno));
		exit(1);
	}
	fprintf(f, "#userlist generated by %s version %s\n", S_BOTNAME, S_VERSION);
	fprintf(f, "#if you want to hand edit please change value of SERIAL_NUMBER\n\n");
	fprintf(f, "SERIAL_NUMBER %d\n\n", SN);
	while(1)
	{
		if(!h) break;
		fprintf(f, ".+user %s\n", h->name);
		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i] != NULL) fprintf(f, ".+host %s %s\n", h->name, h->host[i]);
		GetFlags(h, buf);
		fprintf(f, ".chattr %s %s\n\n", h->name, buf);
		h = h->next;
	}
	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(ME.chanlist[i].name)
		{
			if(strlen(ME.chanlist[i].pass)) fprintf(f, ".+chan %s %s\n", ME.chanlist[i].name, ME.chanlist[i].pass);
			else fprintf(f, ".+chan %s\n", ME.chanlist[i].name);
		}
	}
	fprintf(f, "\n");
	while(1)
	{
		if(!b) break;
		fprintf(f, ".+bot %s %s %s\n", b->mask, b->ip, b->pass);
		b = b->next;
	}
	fclose(f);
	printf("[+] Done\n");
}

int ul::Load(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN];
	HANDLE *h;
	FILE *f;
	int i;

	printf("[*] Loading userlist from '%s'\n", config.userlist_file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[W] Userlist file not present (new bot?)\n");
		return 0;
	}
	while(1)
	{
		if(feof(f)) break;

		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);

		for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  										 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

		if(!strcmp(arg[0], ".+user") && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
		{
			h = userlist.FindHandle(arg[1]);
			if(h) userlist.ChangeFlags(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".+chan") && strlen(arg[1]))
		{
			ME.AddChannelToList(arg[1], arg[2]);
		}
		if(!strcmp(arg[0], ".+bot") && strlen(arg[3]))
		{
			userlist.AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], "SERIAL_NUMBER") && strlen(arg[1]))
		{
			SN = atoll(arg[1]);
			continue;
		}
	}
	fclose(f);
	printf("[+] Userlist loaded\n");
	return 1;
}

void ul::GetFlags(HANDLE *p, char *buf)
{
	int i = 0;

	if(p->flags & HAS_A) buf[i++] = 'a';
	//if(p->flags & HAS_B) buf[i++] = 'b';
	if(p->flags & HAS_O) buf[i++] = 'o';
	if(p->flags & HAS_F) buf[i++] = 'f';
	if(p->flags & HAS_M) buf[i++] = 'm';
	if(p->flags & HAS_N) buf[i++] = 'n';
	if(p->flags & HAS_D) buf[i++] = 'd';
	if(i == 0) buf[i++] = '-';
	buf[i] = '\0';
}

int ul::FindHost(HANDLE *p, char *host)
{
	int i;

	if(!p) return -1;

	for(i=0; i<MAX_HOSTS; i++)
		if(p->host[i])
			if(!strcasecmp(p->host[i], host)) return i;

	return -1;
}

int ul::ChangeFlags(char *name, char *flags)
{
	HANDLE *p;

	p = FindHandle(name);
	if(!p) return 0;
	return ChangeFlags(p, flags);
}


HANDLE *ul::FindHandle(char *name)
{
	HANDLE *p;

	p = first;
	while(1)
	{
		if(!p) return NULL;
		if(!strcasecmp(p->name, name)) return p;
		p = p->next;
	}
}

int ul::ChangeFlags(HANDLE *p, char *flags)
{
	p->flags = 0;
	if(strchr(flags, 'a')) p->flags += HAS_A;
	//if(strchr(flags, 'b')) p->flags += HAS_B;
	if(strchr(flags, 'o')) p->flags += HAS_O;
	if(strchr(flags, 'f')) p->flags += HAS_F;
	if(strchr(flags, 'm')) p->flags += HAS_M;
	if(strchr(flags, 'n')) p->flags += HAS_N;
	if(strchr(flags, 's')) p->flags += HAS_S;
	if(strchr(flags, 'd')) p->flags += HAS_D;
	return p->flags;
}

int ul::RemoveHost(HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			if(!strcasecmp(p->host[i], host))
			{
				free(p->host[i]);
				p->host[i] = NULL;
				return i;
			}
		}
	}
	return -1;
}

int ul::AddHost(HANDLE *p, char *host)
{
	int i;

	if(FindHost(p, host) != -1) return -1;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] == NULL)
		{
			mem_strcpy(p->host[i], host);
			return i;
		}
	}
	return -1;
}

void ul::RemoveAllData(HANDLE *p)
{
	int i;

	free(p->name);
	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			free(p->host[i]);
			p->host[i] = NULL;
		}
	}
}

int ul::RemoveHandle(char *name)
{
	HANDLE *p;
	p = first;

	if(!first) return 0;
	if(!strcasecmp(first->name, name))
	{

		first = first->next;
		if(first) first->prev = NULL;
		RemoveAllData(p);
		delete(p);
		ent--;
		return 1;
	}
	else if(!strcasecmp(last->name, name))
	{
		p = last->prev;
		p->next = NULL;
		RemoveAllData(last);
		delete(last);
		ent--;
		last = p;
		return 1;
	}
	else
	{
		while(1)
		{
			if(!p)
			{
				return 0;
			}
			if(!strcasecmp(p->name, name))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				RemoveAllData(p);
				delete(p);
				ent--;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

HANDLE *ul::AddHandle(char *name)
{
    HANDLE *p;
	int i;

	if(FindHandle(name)) return NULL;
    if(!ent)
    {
		last = first = new(HANDLE);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(HANDLE);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
	ent++;
	mem_strcpy(last->name, name);
	for(i=0; i<MAX_HOSTS; ++i) memset(&last->host[i], 0, sizeof(last->host[i]));
	last->flags = 0;
	return last;
}

ul::ul()
{
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
}

ul::~ul()
{
	HANDLE *h;

	h = first;
	while(1)
	{
		if(!h) break;
		RemoveAllData(h);
		h = h->next;
	}
}

void ul::reset()
{
	HANDLE *h;

	h = first;
	while(1)
	{
		if(!h) break;
		RemoveAllData(h);
		h = h->next;
	}
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
}
