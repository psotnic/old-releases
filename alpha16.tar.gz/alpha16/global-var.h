/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

extern int AUTOOP_BOTS;
extern int PUNISH_BOTS;
extern time_t NOW;
extern int PUNISH_METHOD;
extern unsigned int magic[9];
extern client ME;
extern ul userlist;
extern SOCK sock[MAX_CONN];
extern int errno;
extern int I_AM_HUB;
extern int listenfd;
extern HUB hub;
extern CONFIG config;
extern SOCKBUF readbuf[MAX_CONN+2];
extern SOCKBUF writebuf[MAX_CONN+2];
