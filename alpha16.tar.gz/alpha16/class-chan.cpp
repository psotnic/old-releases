/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void chan::Op(CHANUSER **MultHandle, int num)
{
	char *a;
	int i, j;

	if(!num) return;
	a = push(NULL, "MODE ", name, " +ooo ", NULL);
	for(i=j=0; i<num; i++)
	{
		if(!(MultHandle[i]->flags & OP_SENT))
		{
			a = push(a, MultHandle[i]->nick, " ", NULL);
			MultHandle[i]->flags += OP_SENT;
			++j;
		}
	}
	if(j) quote(ME.servfd, a, NULL);
	free(a);
}

void chan::DeOp(CHANUSER **MultHandle, int num)
{
	char *a;
	int i;

	if(!num) return;
	a = push(NULL, "MODE ", name, " -ooo ", NULL);
	for(i=0; i<num; i++)
	{
		a = push(a, MultHandle[i]->nick, " ", NULL);
		unset(MultHandle[i]->flags, OP_SENT);
	}
	quote(ME.servfd, a, NULL);
	free(a);
}

void chan::Kick(CHANUSER **MultHandle, int num)
{
	char *a;
	int i, j;

	if(!num) return;
	if(num < 5)
	{
		a = push(NULL, "KICK ", name, " ", NULL);
		for(i=0, j=0; i<num; i++)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j) quote(ME.servfd, a, " :\003064x cya\003", NULL);
		free(a);
	}
	else
	{
		a = push(NULL, "KICK ", name, " ", NULL);
		for(i=0, j=0; i<2; i++)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j) quote(ME.servfd, a, " :\003092x papa\003", NULL);
		free(a);

		a = push(NULL, "KICK ", name, " ", NULL);
		for(i=0, j=0; i<num; i++)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j) quote(ME.servfd, a, " :\003044x papa\003", NULL);
		free(a);
	}
}

void chan::GotNickChange(char *from, char *to)
{
	CHANUSER *p = GetUser(from);
	int status = 0;

	if(!p) return;

	if(ToOp.Remove(p->nick)) status += LIST_TOOP;
	if(BotsToOp.Remove(p->nick)) status += LIST_BOTSTOOP;
	if(OpedBots.Remove(p->nick)) status += LIST_BOTS;
	if(ToKick.Remove(p->nick)) status += LIST_TOKICK;

	free(p->nick);
	mem_strcpy(p->nick, to);

	if(status & LIST_TOOP) ToOp.SortAdd(p);
	if(status & LIST_BOTSTOOP) BotsToOp.SortAdd(p);
	if(status & LIST_BOTS) OpedBots.SortAdd(p);
	if(status & LIST_TOKICK) ToKick.SortAdd(p);
}

void chan::RemoveAll(CHANUSER *handle)
{
	int flags = handle->flags;

	ToKick.Remove(handle->nick);

	if(flags & HAS_B)
	{
		OpedBots.Remove(handle->nick);
		BotsToOp.Remove(handle->nick);
		return;
	}
	if(flags & HAS_O) ToOp.Remove(handle->nick);
	free(handle->nick);
	free(handle->ident);
	free(handle->host);
}

CHANUSER *chan::GetUser(char *nick)
{
	CHANUSER *p;
	p = first;
	while(1)
	{
		if(!p) return NULL;
		if(!strcasecmp(nick, p->nick)) return p;
		p = p->next;
	}
}

void chan::GotKick(char *victim, char *offender)
{
	CHANUSER *kicked, *kicker;
	char *nick, *a;

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicked = GetUser(victim);
	kicker = GetUser(nick);

	if((kicked->flags & HAS_F) && !(kicker->flags & HAS_F))
	{
		ToKick.SortAdd(kicker);
		if(MyTurn(&OpedBots, hash32(kicker->nick), PUNISH_BOTS) && NextCheck <= NOW)
		{
			quote(ME.servfd, "MODE ", name, " -o ", kicker->nick, NULL);
			NextCheck = NOW + 1;
		}
	}
	GotPart(victim, 0);
	free(nick);
}

void chan::GotPart(char *nick, int quit)
{
	CHANUSER *p;
	p = first;
	int bot = 0;

	if(!first) return;
	if(!strcasecmp(first->nick, nick))
	{
		bot = first->flags & HAS_B;
		first = first->next;
		if(first) first->prev = NULL;
		RemoveAll(p);
		delete(p);
		users--;
	}
	else if(!strcasecmp(last->nick, nick))
	{
		bot = last->flags & HAS_B;
		p = last->prev;
		p->next = NULL;
		RemoveAll(last);
		delete(last);
		users--;
		last = p;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcasecmp(p->nick, nick))
			{
				bot = p->flags & HAS_B;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				RemoveAll(p);
				delete(p);
				users--;
				break;
			}
			p = p->next;
		}
	}
	if(users == 1 && !(ptr->flags & IS_OP))
	{
		if(status & STATUS_SYNCED)
		{
			quote(ME.servfd, "PART ", name, NULL);
			quote(ME.servfd, "JOIN ", name, NULL);
		}
	}
	else if(BotsToOp.ent == users)
	{
		if(I_AM_HUB && status & STATUS_SYNCED && (!bot || quit))
		{
			quote(FD_BOTS, S_REOP, " ", name, NULL);
			quote(FD_OWNERS, "*** Reoping ", name, NULL);
		}
	}
	else if(!modes && !ToKick.ent) quote(ME.servfd, "MODE ", name, NULL);

}

void chan::Display()
{
    CHANUSER *p;
    int i=0;
    p = first;
    while(1)
    {
		if(p == NULL) break;
		printf("[%d]: %s!%s@%s, flags: %d\n", i, p->nick, p->ident, p->host, p->flags);
		p=p->next;
		i++;
    }
    p = last;
    i = users-1;
	printf("ToOp:\n");
	ToOp.Display();
	printf("BotsToOp:\n");
	BotsToOp.Display();
	printf("ToKick:\n");
	ToKick.Display();
	printf("OpedBots:\n");
	OpedBots.Display();
	printf("Modes: %s\n", modes);
	printf("Limit: %s\n", limit);
	printf("Key: %s\n", key);
}


CHANUSER *chan::GotJoin(char *mask, int op)
{
    CHANUSER *p, **MultHandle;
    char *a, *b;
	int i, crc, j;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }

    a = strchr(mask, '!');
    b = strchr(mask, '@');
    mem_strncpy(last->nick, mask, (int) abs(mask - a) +1);
    mem_strncpy(last->ident, a+1, (int) abs(a - b));
    mem_strcpy(last->host, b+1);

    users++;

    last->flags = userlist.GetFlags(mask);

	if(last->flags & HAS_O + HAS_A && !op)
	{
		if(last->flags & HAS_B) BotsToOp.SortAdd(last);
		else ToOp.SortAdd(last);
		if(ptr && OpedBots.ent && NextCheck <= NOW)
		{
			if(MyTurn(&OpedBots, hash32(last->nick)+hash32(name), AUTOOP_BOTS))
			{
				if(BanOverride)
				{
					if(last->flags & HAS_F)
					{
						quote(ME.servfd, "MODE ", name, " +o-b ", last->nick, " ", BanOverride, NULL);
						NextCheck = NOW + 2;
						set(last->flags, OP_SENT);
					}
				}
				else
				{
					quote(ME.servfd, "MODE ", name, " +o ", last->nick, NULL);
					NextCheck = NOW + 2;
					set(last->flags, OP_SENT);
				}
			}
		}
	}
	if(op)
	{
		last->flags += IS_OP;
		if(!(last->flags & HAS_F || last->flags & HAS_O)) ToKick.SortAdd(last);
		if(last->flags & HAS_B) OpedBots.SortAdd(last);
	}
	else if(BanOverride && ptr->flags & IS_OP && (MyTurn(&OpedBots, hash32(last->nick), AUTOOP_BOTS)) && !(last->flags & HAS_F))
	{
		quote(ME.servfd, "KICK ", name, " ", last->nick, " :\002Will you please go out?\002", NULL);
		NextCheck = NOW + 1;
	}

	if(BanOverride)
	{
		free(BanOverride);
		BanOverride = NULL;
	}

	if(BotsToOp.ent == users)
	{
		if(I_AM_HUB  && status & STATUS_SYNCED) quote(FD_BOTS, S_REOP, " ", name, NULL);
	}

	return last;
}

chan::chan()
{
    last = first = NULL;
    status = users = NextCheck = 0;
	ptr = NULL;
	name = BanOverride = modes = key = limit  = NULL;
}

chan::~chan()
{
	CHANUSER *p, *q;

	p = first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		free(q->nick);
		free(q->ident);
		free(q->host);
		free(q);
	}
}
