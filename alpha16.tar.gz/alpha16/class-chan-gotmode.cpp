/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void chan::GotMode(char *modes, char *args, char *mask)
{
	char mode[2][4] = {0};
	char *arg[4] = {0};
	char *a, *b, sign, *nick, *oldkey;
	CHANUSER *NickHandle, *ArgHandle, **MultHandle, ServerHandle;
	PTRLIST *p, *q;
	int i,j, just_opped, needop, oped, mypos, n[6], hash;

	oped = just_opped = 0;
	mypos = -1;
	oldkey = NULL;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);
	NickHandle = GetUser(nick);

	if(!NickHandle)
	{
		memset(&ServerHandle, 0, sizeof(CHANUSER));
		NickHandle = &ServerHandle;
	}

	/* mode striper */
	for(i=0, j=0; i<4 && j<strlen(modes); i++, j++)
	{
		if(modes[j] == '+' || modes[j] == '-')
		{
			sign = modes[j];
			j++;
		}
		mode[0][i] = sign;
		mode[1][i] = modes[j];
	}

	/* arg striper */
	for(i=0; i<4; i++)
	{
		if(strchr(ARG_MODES, mode[1][i]))
		{
			a = strchr(args, ' ');
			if(a)
			{
				mem_strncpy(arg[i], args, abs(args - a)+1);
			}
			else
			{
				mem_strncpy(arg[i], args, strlen(args));
			}
			args = a+1;
		}
		else arg[i] = NULL;
	}

	/* reaction on modes */
	for(i=0; i<4; i++)
	{
		if(mode[0][i] == '+')
		{
   			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_B)
				{
					BotsToOp.Remove(arg[i]);
					OpedBots.SortAdd(ArgHandle);
					oped++;
				}

				if(ArgHandle->flags & HAS_O) ToOp.Remove(arg[i]);
				set(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);
				if(!(NickHandle->flags & HAS_M))
				{
					if(!(ArgHandle->flags & HAS_O) && !(ArgHandle->flags & HAS_F))
					{
						ToKick.SortAdd(ArgHandle);
						if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					}
				}
				if(ArgHandle->flags & HAS_D) ToKick.SortAdd(ArgHandle);
				if(ptr == ArgHandle && !just_opped)	mypos = oped - 1;
				mode[0][i] = 0;
				continue;
   			}
			if(mode[1][i] == 'k')
			{
				if(!(NickHandle->flags & HAS_M))
				{
					if(key)
					{
						if(!oldkey && strlen(key)) mem_strcpy(oldkey, key);
						free(key);
					}

					mem_strcpy(key, arg[i]);
					mode[0][i] = '-';
				}
				else
				{
					if(key) free(key);
					mem_strcpy(key, arg[i]);
					j = ME.FindChannelInList(name);
					if(j != -1)
					{
						if(ME.chanlist[j].pass) free(ME.chanlist[j].pass);
						mem_strcpy(ME.chanlist[j].pass, arg[i]);
					}
					mode[0][i] = 0;
				}
				continue;
			}
			if(mode[1][i] == 'l')
			{
				if(!(NickHandle->flags & HAS_M))
				{
					if(limit)
					{
						if(strlen(limit))
						{
							mem_strcpy(a, limit);
							free(limit);
							mem_strcpy(limit, arg[i]);
							free(arg[i]);
							mem_strcpy(arg[i], a);
							free(a);
							if(strcmp(limit, arg[i])) mode[0][i] = '+';
							else mode[0][i] = 0;
							continue;
						}
						free(limit);
					}
					mem_strcpy(limit, arg[i]);
					mode[0][i] = '-';
					free(arg[i]);
					arg[i] = NULL;
				}
				else
				{
					if(limit) free(limit);
					mem_strcpy(limit, arg[i]);
					mode[0][i] = 0;
				}
				continue;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '-';
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}

		if(mode[0][i] == '-')
		{
			if(mode[1][i] == 'o')
			{
				ToKick.Remove(arg[i]);
				ArgHandle = GetUser(arg[i]);
				unset(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);
				if(ArgHandle->flags & HAS_B)
				{
					OpedBots.Remove(arg[i]);
					oped--;
				}
				if(ArgHandle->flags & HAS_F)
				{
					if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					if(ArgHandle->flags & HAS_A && ArgHandle->flags & HAS_O)
					{
						if(ArgHandle->flags & HAS_B) BotsToOp.SortAdd(ArgHandle);
						else ToOp.SortAdd(ArgHandle);
					}
				}
				if(ptr == ArgHandle)
				{
					mypos = -1;
					p = ToKick.first;
					while(1)
					{
						if(!p) break;
						if(p->ptr->flags & KICK_SENT) p->ptr->flags -= KICK_SENT;
						p = p->next;
					}
				}
				mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'k')
			{
				if(!(NickHandle->flags & HAS_M))
				{
					if(key) free(key);
					mem_strcpy(key, "");
					mode[0][i] = '+';
				}
				else
				{
					if(key) free(key);
					mem_strcpy(key, "");
					mode[0][i] = 0;
				}
				continue;
			}
			if(mode[1][i] == 'l')
			{
				if(!(NickHandle->flags & HAS_M))
				{
					if(limit)
					{
						arg[i] = limit;
						//free(limit);
						mem_strcpy(limit, "");
						mode[0][i] = '+';
					}
					else mode[0][i] = 0;
				}
				else
				{
					if(limit) free(limit);
					mem_strcpy(limit, "");
					mode[0][i] = 0;
				}
				continue;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '+';
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}
	}

	/* channel modes protection */
	if(MyTurn(&OpedBots, hash32(nick), PUNISH_BOTS))
	{
		mem_strcpy(a, "");
		mem_strcpy(b, "");
		for(i=j=0; i<4; ++i)
		{
			if(mode[0][i])
			{
				a = (char *) realloc(a, strlen(a) + 3);
				j = strlen(a);
				a[j+2] = '\0';
				//a[j+2] = ' ';
				a[j+1] = mode[1][i];
				a[j] = mode[0][i];
				if(arg[i]) b = push(b, arg[i], " ", NULL);
				++j;
			}
		}
		if(j)
		{
			quote(ME.servfd, "KICK ", name, " ", NickHandle->nick, " :", config.kickreason, NULL);
			set(NickHandle->flags, KICK_SENT);

			quote(ME.servfd, "MODE ", name, " ", a, " ", b, NULL);
			if(oldkey) quote(ME.servfd, "MODE ", name, " +k ", oldkey, NULL);
		}
		free(a);
		free(b);
	}
	if(oldkey) free(oldkey);
	if(j && !(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);


	/* Executeted only during initail opping (takeover code) */
	if(mypos != -1 && NextCheck <= NOW)
	{
		j=0;
		if(PUNISH_METHOD == 1) Divide((int *) &n, BotsToOp.ent, oped, 3);
		else if(PUNISH_METHOD == 2) Divide((int *) &n, BotsToOp.ent, oped, 2);

		if(n[mypos])
		{
			/* +ooo & 4 KICK */
			if(PUNISH_METHOD == 1)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				if(mypos == 0) j = GetRandomItems(MultHandle, BotsToOp.first, n[mypos], 3);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1]), n[mypos], 3);
				else j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 3);
				Op(MultHandle, j);
				free(MultHandle);
				if(j) NextCheck = NOW + 2;

				Divide((int *) &n, ToKick.ent, oped, 4);
				if(n[mypos])
				{
					MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
					if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 4);
					else if(mypos == 1)	j =GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 4);
					else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 4);
					Kick(MultHandle, j);
					free(MultHandle);
					NextCheck += j;
				}
			}
			/* +oo & -ooo */
			else if(PUNISH_METHOD == 2)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*2);
				Divide((int *) &n, BotsToOp.ent, oped, 2);
				if(mypos == 0) j = GetRandomItems(MultHandle, BotsToOp.first, n[mypos], 2);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1]), n[mypos], 2);
				Op(MultHandle, j);
				free(MultHandle);
				if(j) NextCheck = NOW + 2;

				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				Divide((int *) &n, BotsToOp.ent, oped, 3);
				if(n[mypos])
				{
					if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 3);
					else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 3);
					else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 3);
					DeOp(MultHandle, j);
					free(MultHandle);
					if(j) NextCheck = NOW + 3;
				}
			}

		}
		/* 6 KICK */
		else if(ToKick.ent)
		{
			/* do kick6 */
			Divide((int *) &n, ToKick.ent, oped, 6);
			if(n[mypos])
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*6);
				if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 6);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 6);
				else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 6);
				Kick(MultHandle, j);
				free(MultHandle);
				NextCheck = NOW + j;
			}
		}
	}
	/* executed when somebody is playing with modes */
	if(mypos == -1 && NextCheck <= NOW)
	{

		if(ToKick.ent)
		{
			hash = 0;
			if(PUNISH_METHOD == 1)
			{
			    MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
			    j = GetRandomItems(MultHandle, ToKick.first, ToKick.ent, 4);
			}
			else if(PUNISH_METHOD == 2)
			{
			    MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
			    j = GetRandomItems(MultHandle, ToKick.first, ToKick.ent, 3);
			}
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick);
			if(MyTurn(&OpedBots, hash, PUNISH_BOTS))
			{
				if(PUNISH_METHOD == 1) Kick(MultHandle, j);
				if(PUNISH_METHOD == 2) DeOp(MultHandle, j);
				NextCheck = NOW + j;
			}
			free(MultHandle);
		}
		if(BotsToOp.ent < 4)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
			j = GetRandomItems(MultHandle, BotsToOp.first, BotsToOp.ent, 3);
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick);
			if(MyTurn(&OpedBots, hash, AUTOOP_BOTS))
			{
				Op(MultHandle, j);
				NextCheck = NOW + j;
			}
			free(MultHandle);
		}
	}
	free(nick);
	for(i=0; i<4; i++) if(arg[i]) free(arg[i]);
}
