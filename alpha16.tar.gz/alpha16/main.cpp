/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"

int AUTOOP_BOTS, PUNISH_BOTS, PUNISH_METHOD, I_AM_HUB, listenfd;
unsigned int magic[9];
time_t NOW;
client ME;
ul userlist;
SOCK sock[MAX_CONN];
SOCKBUF readbuf[MAX_CONN+2];
SOCKBUF writebuf[MAX_CONN+2];
CONFIG config;
HUB hub;
extern int errno;

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd, wfd;
	
	propaganda();
	if(argc != 2 && argc != 3) badparameters("Bad number of parameters");
	if(argc == 2)
	{
		if(!strcmp(argv[1], "--hub")) badparameters("No config file");
		precache();
		LoadConfig(argv[1]);
	}
	else
	{
		if(strcmp(argv[1], "--hub")) badparameters("'--hub' expected as first argument");
		precache();
		I_AM_HUB = 1;
		LoadConfig(argv[2]);
	}

	userlist.Load(config.userlist_file);
	SignalHandling();

	if(I_AM_HUB)
	{
		if((listenfd = StartListening(hub.host, hub.port)) < 1)
		{
			printf("[-] Cannot open socket\n");
			SafeExit();
		}
	}
	last = NOW = time(NULL);
	tv.tv_sec = 1;

	while(1)
	{
		if(!tv.tv_sec) tv.tv_sec = 1;
		tv.tv_usec = 0;

		FD_ZERO(&rfd);
	   	if(ME.servfd > 0) FD_SET(ME.servfd, &rfd);
		if(I_AM_HUB)
		{
			FD_SET(listenfd, &rfd);
			for(i=0; i<MAX_CONN; ++i) if(sock[i].fd > 0) FD_SET(sock[i].fd, &rfd);
		}
		else if(hub.fd > 0)	FD_SET(hub.fd, &rfd);

		FD_ZERO(&wfd);
		for(i=0; i<MAX_BUFS; ++i) if(writebuf[i].fd) FD_SET(writebuf[i].fd, &wfd);

		ret = select(65535, &rfd, &wfd, NULL, &tv);

		NOW = time(NULL);
		if(NOW > last + 2)
		{
			last = NOW;
			if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
		}
		if(ME.nextconn_hub <= NOW && hub.fd < 1 && !I_AM_HUB)
		{
			ME.ConnectToHUB();
			ME.nextconn_hub = NOW + HUB_CONN_DELAY;
		}
		if(ME.nextconn_serv <= NOW && ME.servfd < 1)
		{
			ME.ConnectToIRC();
			ME.nextconn_serv = NOW + 3;
		}
		if(ME.nextjoin <= NOW && ME.status & STATUS_REGISTERED)
		{
			ME.JoinChannels();
			ME.nextjoin = NOW + CHAN_CHECK_DELAY;
		}

		if(ret < 1) continue;


		for(i=0; i<MAX_BUFS; ++i)
		{
			if(FD_ISSET(writebuf[i].fd, &wfd))
			{
				write(writebuf[i].fd, writebuf[i].buf + writebuf[i].pos++, 1);
				if(writebuf[i].pos == writebuf[i].len)
				{
					//printf("## del buf ##\n");
					free(writebuf[i].buf);
					memset(&writebuf[i], 0, sizeof(writebuf[i]));
				}
			}
		}

		if(FD_ISSET(ME.servfd, &rfd))
		{
			n = ReadOneLine(ME.servfd, buf, MAX_LEN);
			if(n > 0)
			{
				parse_irc(buf);
			}
			else if(n == -1)
			{
				debug();
				printf("[-] Lost server\n");
				if(sclose(ME.servfd) != 0) debug();
				ME.reset();
			}
		}
		if(FD_ISSET(hub.fd, &rfd))
		{
			n = ReadOneLine(hub.fd, buf, MAX_LEN);
			if(n > 0)
			{
				parse_hub(buf);
			}
			else if(n == -1)
			{
				//debug();
				if(sclose(hub.fd) != 0) debug();
				hub.fd = 0;
				printf("[-] Disconnected from HUB\n");
			}
		}
		if(FD_ISSET(listenfd, &rfd))
		{
			n = AcceptConnection(listenfd);
		}
		if(I_AM_HUB)
		{
			for(i=0; i<MAX_CONN; i++)
			{
				if(sock[i].fd > 0)
				{
					if(FD_ISSET(sock[i].fd, &rfd))
					{
						n = ReadOneLine(sock[i].fd, buf, sizeof(buf));
						if(n > 0)
						{
							if(sock[i].status & STATUS_OWNER)
							{
								parse_owner(&sock[i], buf);
							}
							else if(!(sock[i].status & STATUS_REGISTERED))
							{
								RegisterBot(&sock[i], buf);
							}
							else parse_bot(&sock[i], buf);
						}
						else if(n == -1)
						{
							printf("[-] Dead socket: sock[%d].fd = %d, Shuting down\n", i, sock[i].fd);
							if(sock[i].status & STATUS_REGISTERED)
							{
								if(sock[i].status & STATUS_OWNER) quote(FD_OWNERS, "*** ", sock[i].name, " has left the partyline (", strerror(errno), ")", NULL);
								else quote(FD_OWNERS, "*** ", sock[i].name, " has left the botnet (", strerror(errno), ")", NULL);
							}
							CloseSock(&sock[i]);
						}
                	}
            	}
			}
		}
	}
	return 0;
}

