/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void LoadConfig(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	FILE *f;
	int line, i, errors;
	CFG_DB db[] =
	{
		{ "nick", NULL, &config.nick, 1 , 1 },
		{ "ident", NULL, &config.ident, 1, 1 },
		{ "nickappend", NULL, &config.nickappend, 1, 1 },
		{ "realname", NULL, &config.realname, -1, 1 },
		{ "myipv4", NULL, &config.myipv4, 1, 1 },
		{ "vhost", NULL, &config.vhost, 1, 1 },
		{ "owner", NULL, &config.owner, 1, 1 ,0 },
		{ "userlist", NULL, &config.userlist_file, 1, 1 },
		{ "reason[kick]", NULL, &config.kickreason, -1, 0 },
		{ "reason[part]", NULL, &config.partreason, -1, 0 },
		{ "reason[quit]", NULL, &config.quitreason, -1, 0 },
		{ "reason[cycle]", NULL, &config.cyclereason, -1, 0 },
		{ "hub[ident]", NULL, &hub.ident, 1, 1 },
		{ "hub[host]", NULL, &hub.host, 1, 1 },
		{ "hub[port]", &hub.port, NULL, 0, 1 },
		{ "hub[pass]", NULL, &hub.pass, 1, 1 },
		{ "", NULL, NULL, 0, 0 }
	};

	printf("[*] Loading config from '%s'\n", file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[-] Cannot open config file!!!\n");
		exit(1);
	}

	for(line=0; ; ++line)
	{
		lame:
		//getchar();
		if(feof(f)) break;
		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);
		for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4], &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

		if(arg[0][0] == '#') continue;

		/* look for option in DB */
		for(i=0; ; ++i)
		{
			if(!strlen(db[i].name)) break;
			if(!strcasecmp(db[i].name, arg[0]))
			{
				if(!strlen(arg[1]))
				{
					printf("%s:%d: Error: Inavlid argument for option '%s'\n", file, line, db[i].name);
					goto lame;
				}
				if(db[i].i != NULL)
				{
					*db[i].i = atoi(arg[1]);
				}
				if(db[i].c != NULL)
				{
					mem_strcpy(*db[i].c, arg[1]);
				}
				goto lame;
			}
		}

		/* non standard options */
		if(!strcmp(arg[0], "server"))
		{
			if(!strlen(arg[2]))
			{
				printf("%s:%d: Error: Inavlid argument for option 'server'\n");
				exit(1);
			}
			for(i=0; i<MAX_SERVERS; i++)
			{
				if(config.server[i].host == NULL)
				{
					mem_strcpy(config.server[i].host, arg[1]);
					config.server[i].port = atoi(arg[2]);
					break;
				}
			}
			continue;
		}
		if(!strcmp(arg[0], "channel"))
        {
            if(!strlen(arg[1]))
            {
                printf("%s:%d: Error: Inavlid argument for option 'channel'\n");
                exit(1);
            }
            ME.AddChannelToList(arg[1], arg[2]);
            continue;
        }

		if(strlen(arg[0])) printf("[W] %s:%d: unknown option '%s'\n", file, line, arg[0]);
	}

	for(errors=i=0; ; ++i)
	{
		if(!strlen(db[i].name)) break;
		if(db[i].req)
		{
			if(db[i].c)
			{
				if(!*db[i].c)
				{
					printf("[-] Mandatory option not set: %s\n", db[i].name);
					++errors;
				}
			}
			if(db[i].i)
			{
				if(!*db[i].i)
				{
					printf("[-] Mandatory option not set: %s\n", db[i].name);
					++errors;
				}
			}
		}
	}


	if(errors)
	{
		printf("[-] Failed to load config\n");
		exit(1);
	}

	/* defaults for not set values */
	if(!config.partreason) mem_strcpy(config.partreason, "[\002TmT\002] Beam me up scotty [\002TmT\002]");
	if(!config.quitreason) mem_strcpy(config.quitreason,"[\002TmT\002] Ping Timeout [\002TmT\002]");
	if(!config.kickreason) mem_strcpy(config.kickreason, "\0039Psotnic-X Baby\003");
	if(!config.cyclereason) mem_strcpy(config.cyclereason, "[\002TmT\002] Be right back [\002TmT\002]");
	printf("[+] Config loaded\n");
}
