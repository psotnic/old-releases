/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void client::Rejoin(char *name, int t)
{
	int i;

	i = ME.FindChannelInList(name);
	if(i != -1)
	{
		ME.chanlist[i].nextjoin = NOW + t;
		ME.chanlist[i].joinsent = 0;
	}
}

void client::RejoinCheck()
{
	int i;
	if(!(ME.status & STATUS_REGISTERED)) return;
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(chanlist[i].name && chanlist[i].nextjoin <= NOW && !chanlist[i].joinsent)
		{
			if(!FindChannel(chanlist[i].name))
			{
				if(strlen(chanlist[i].pass)) quote(servfd, "JOIN ", chanlist[i].name, " ", chanlist[i].pass, NULL);
				else quote(servfd, "JOIN ", chanlist[i].name, NULL);
				chanlist[i].joinsent = 1;
			}
		}
	}
}

void client::ScheludeJoinToAllChannels()
{
	int i, j;

	for(i=j=0; i<MAX_CHANNELS; i++)
	{
		if(chanlist[i].name)
		{
			chanlist[i].nextjoin = j*10 + NOW + 1;
			chanlist[i].joinsent = 0;
			j++;
		}
	}
}

void client::GotNickChange(char *from, char *to)
{
	char *a = strchr(from, '!');
	char *fromnick;
	CHANNEL *p = first;

	mem_strncpy(fromnick, from, abs(a - from) + 1);
	while(1)
	{
		if(!p) break;
		p->channel.GotNickChange(fromnick, to);
		p = p->next;
	}
	free(fromnick);
}

void client::Display()
{
	CHANNEL *p;

	p = first;

	printf("### Channels:\n");
	while(1)
	{
		if(!p) break;
		printf("### '%s'\n", p->channel.name);
		p = p->next;
	}
}

void client::RecheckFlags()
{
	CHANNEL *ch;
	CHANUSER *p;
	BOT *b;
	chan *c;
	int oped;
	char *mask;

	ch = ME.first;

	while(1)
	{
		if(!ch) break;
		c = &ch->channel;
		c->BotsToOp.reset();
		c->ToKick.reset();
		c->ToOp.reset();
		c->OpedBots.reset();
		p = c->first;
		while(1)
		{
			if(!p) break;
			oped = p->flags & IS_OP;
			mask = push(NULL, p->nick, "!", p->ident, "@", p->host, NULL);
			p->flags = userlist.GetFlags(mask);
			if(oped) p->flags += IS_OP;
			//printf("### %s: %s flags: %d\n", c->name, mask, p->flags);
			free(mask);
			if(p->flags & HAS_B && !oped) c->BotsToOp.SortAdd(p);
			if(!(p->flags & HAS_O) && !(p->flags & HAS_F) && oped) c->ToKick.SortAdd(p);
			if(p->flags & HAS_B && oped) c->OpedBots.SortAdd(p);
			p = p->next;
		}
		ch = ch->next;
	}
}

int client::AddChannelToList(char *name, char *pass)
{
	int i;

	if((i = FindChannelInList(name)) != -1)
	{
		if(!strcmp(chanlist[i].pass, pass)) return -1;
		free(chanlist[i].pass);
		mem_strcpy(chanlist[i].pass, pass);
		return -2;
	}
	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(!chanlist[i].name)
		{

			mem_strcpy(chanlist[i].name, name);
			mem_strcpy(chanlist[i].pass, pass);
			chanlist[i].joinsent = 0;
			return i;
		}

	}
	return -3;
}

int client::FindChannelInList(char *name)
{
	int i;

	for(i=0; i<MAX_CHANNELS; i++)
		if(chanlist[i].name)
			if(!strcasecmp(chanlist[i].name, name)) return i;
	return -1;
}

int client::RemoveChannelFromList(char *name)
{
	int i;
	if(FindChannelInList(name) == -1) return 0;

	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(chanlist[i].name != NULL)
		{
			if(!strcasecmp(chanlist[i].name, name))
			{
				free(chanlist[i].name);
				free(chanlist[i].pass);
				chanlist[i].name = NULL;
				chanlist[i].pass = NULL;
				chanlist[i].joinsent = 0;
				return i+1;
			}
		}
	}
}

int client::ConnectToHUB()
{
	int n, i, fd;
	struct sockaddr_in peer, us;
	socklen_t peersize;
	const int one = 1;
	char port[2][16], auth_reply[MAX_LEN], ident[16], buf[MAX_LEN], *a;

	hub.fd = 0;
	printf("[*] Connecting to HUB at %s:%d\n", hub.host, hub.port);
	fd = DoConnect(hub.host, hub.port, config.myipv4, -1);

	
	if(fd > 0)
	{
		printf("[*] Validating hub\n");
		n = DoConnect(hub.host, 113, config.myipv4, 0);
		if(n > 0)
		{
			peersize = sizeof(struct sockaddr_in);
			getpeername(fd, (sockaddr *) &peer, &peersize);

			peersize = sizeof(struct sockaddr_in);
			getsockname(fd, (sockaddr *) &us, &peersize);

			sprintf(buf, "%d , %d\n", ntohs(peer.sin_port),  ntohs(us.sin_port));
			write(n, buf, strlen(buf));

			memset(auth_reply, 0, MAX_LEN);
			i = read(n, auth_reply, MAX_LEN);
			if(sclose(n) != 0) debug();
			if(i > 0)
			{
				memset(ident, 0, sizeof(ident));
				a = strrchr(auth_reply, ' ') + 1;
				for(i=0; i<sizeof(ident)-1; i++)
				{
					if(isspace(a[i])) break;
					ident[i] = a[i];
				}
				if(!strcasecmp(ident, hub.ident))
				{
					printf("[+] Ident respons is OK\n");
					printf("[+] Connection to HUB established\n");
					hub.fd = fd;
					printf("[*] Registering\n");
					sprintf(buf, "%u", userlist.SN);
					if(ME.status & STATUS_REGISTERED) quote(fd, S_REGISTER , " ", ME.nick, " ", hub.pass, " ", S_VERSION, " ", buf, NULL);
					else quote(fd, S_REGISTER, " <", config.nick, "> ", hub.pass, " ", S_VERSION, " ", buf, NULL);
					return fd;
				}
				printf("[-] Bad ident response\n");
				printf("[W] Somebody is doing something nasty\n");
			}
			else
			{
				debug();
				printf("[-] No ident response (%s)\n", strerror(errno));
			}
		}
		else printf("[-] Ident service is not running on the server (%s)\n", strerror(errno));
	}

	printf("[-] Couldn't connect to HUB (%s)\n", strerror(errno));
	printf("[*] Next try in %d secconds\n", VAR.HUB_CONN_DELAY);
	if(fd > 0) sclose(fd);
	return -1;

}

int client::ConnectToIRC()
{
	int i, n, tmp = 1;

	ME.status = 0;
	ME.servid = -1;
	ME.servfd = 0;

	for(i=0; i<MAX_SERVERS; i++)
	{
		if(config.server[i].port)
		{
			printf("[*] Connecting to IRC: %s port %d\n", config.server[i].host, config.server[i].port);
			if(strchr(config.server[i].host, ':'))
				n = DoConnect6(config.server[i].host, config.server[i].port, config.vhost, 1);
			else
				n = DoConnect(config.server[i].host, config.server[i].port, config.vhost, 1);
			if(n > 0)
			{
				printf("[+] IRC connection established\n");
				/*
				if(setsockopt(n, IPPROTO_TCP, TCP_NODELAY, (char *) &tmp,sizeof(int)) == 0)
					printf("[+] Socket is running in TCP_NODELAY mode\n");
				else printf("[-] Couldn't set socket in TCP_NODELAY mode\n");
				*/
				ME.servid = i;
				ME.servfd = n;
				ME.status = STATUS_CONNECTED;
				quote(n, "NICK ", config.nick, NULL);
				quote(n, "USER ", config.ident, " 8 * :", config.realname, NULL);
				return n;
			}
			else
			{
				printf("[-] Couldn't connect to IRC (%s)\n", strerror(errno));
				printf("[*] Next try in %d seconds\n", VAR.IRC_CONN_DELAY);
			}
		}
	}
	return 0;
}

void client::CheckQueue()
{
	time_t now;
	chan *ch;
	CHANNEL *p;
	int j;
	CHANUSER **MultHandle;

	p = first;

	now = time(NULL);
	while(1)
	{

		if(!p) return;
		ch = &p->channel;
		if(!ch)
		{
			p = p->next;
			continue;
		}
		if(!ch->ptr)
		{
			p = p->next;
			continue;
		}
		if(!(ch->ptr->flags & IS_OP))
		{
			p = p->next;
			continue;
		}
		if(ch->NextCheck <= now)
		{
			if(ch->BotsToOp.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				j = GetRandomItems(MultHandle, ch->BotsToOp.first, ch->BotsToOp.ent, 3);
				ch->Op(MultHandle, j);
				ch->NextCheck += 5;
				free(MultHandle);
			}
			else if(ch->ToKick.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
				j = GetRandomItems(MultHandle, ch->ToKick.first, ch->ToKick.ent, 4);
				ch->Kick(MultHandle, j);
				free(MultHandle);
				ch->NextCheck += j;
			}
		}
		p = p->next;
	}
}

void client::GotUserQuit(char *mask)
{
	char *a, *nick;
	CHANNEL *p;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);

	p = first;
	while(1)
	{
		if(!p) break;
		p->channel.GotPart(nick, 1);
		p = p->next;
	}
	free(nick);
}

void client::RemoveChannel(char *name)
{
	CHANNEL *p;
	int n;

	if(!first) return;
	p = first;

	if(channels == 1)
	{
		delete(p);
		channels = 0;
		first = last = NULL;
	}
	else if(!strcasecmp(first->channel.name, name))
	{
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		channels--;
	}
	else if(!strcasecmp(last->channel.name, name))
	{
		p = last->prev;
		p->next = NULL;
		delete(last);
		channels--;
		last = p;
	}
	else
	{
		p = first->next;
		while(1)
		{
			if(!p) break;
			if(!strcasecmp(p->channel.name, name))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
				channels--;
			}
			p = p->next;
		}
	}
	current = first;

	n = ME.FindChannelInList(name);
	if(n != -1) ME.chanlist[n].joinsent = 0;
}


chan *client::FindChannel(char *name)
{

	if(current)
		if(!strcasecmp(current->channel.name, name)) return &current->channel;

	current = first;
	while(1)
	{
		if(!current) return NULL;
		if(!strcasecmp(current->channel.name, name)) return &current->channel;
		current = current->next;
	}
}

chan *client::CreateNewChannel(char *name)
{
	int n;
	if(!channels)
	{
		first = current = last = new(CHANNEL);
		current->prev = current->next = NULL;
		mem_strcpy(current->channel.name, name);
	}
	else
	{
		current = last->next = new(CHANNEL);
  		current->prev = last;
		current->next = NULL;
		mem_strcpy(current->channel.name, name);
		last = current;
	}

	n = ME.FindChannelInList(name);
	if(n != -1) ME.chanlist[n].joinsent = 0;

	channels++;
	return &current->channel;
}

client::client()
{
	int i;
	
	first = last = current = NULL;
	channels = servfd = servid = nextconn_hub = nextconn_serv = nextjoin = status = 0;
	nick = ident = host = mask = servname = NULL;
	for(i=0; i<MAX_CHANNELS; i++) memset(&chanlist[i], 0, sizeof(chanlist[i]));
}

client::~client()
{
	CHANNEL *p;

	p = first;
	while(1)
	{
		if(!p) break;
		RemoveChannel(p->channel.name);
		p = p->next;
	}

	if(nick) free(nick);
	if(ident) free(ident);
	if(host) free(host);
	if(mask) free(mask);
}

void client::reset()
{
	CHANNEL *p;
	int i;

	p = first;
	while(1)
	{
		if(!p) break;
		RemoveChannel(p->channel.name);
		p = p->next;
	}
	if(nick) free(nick);
	if(ident) free(ident);
	if(host) free(host);
	if(mask) free(mask);

	first = last = current = NULL;
	channels = servfd = servid = nextconn_hub = nextconn_serv = nextjoin = status = 0;
	nick = ident = host = mask = servname = NULL;
	for(i=0; i<MAX_CHANNELS; i++) memset(&chanlist[i], 0, sizeof(chanlist[i]));
}
