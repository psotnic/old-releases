/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/* irssi like */
void parse_ctcp(char *mask, char *data)
{
	char arg[11][MAX_LEN], *a, buf[MAX_LEN], who[MAX_LEN];
	int i, n;

	if(!strlen(data)) return;

	a = strchr(mask, '!');
	strncpy(who, mask, abs(a-mask));

	for (i=0; i < 11; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4], &arg[5], &arg[6], &arg[7], &arg[8], &arg[9], &arg[10]);

	printf("ctcp: %s\n", data);

	if(!strcmp(arg[0], "PING") && strlen(arg[2]))
	{
		if(strlen(data) > 40) return;
		quote(ME.servfd, "NOTICE ", who, " :\001PING ", arg[1], " ", arg[2], "\001", NULL);
		return;
	}
	if(!strcmp(arg[0], "VERSION"))
	{
		struct utsname name;
		uname(&name);
		quote(ME.servfd, "NOTICE ", who, " :\001VERSION irssi v0.8.6 - running on ", name.sysname, " ", name.machine, "\001", NULL);
		return;
	}
	if(!strcmp(arg[0], "USERINFO"))
	{
		quote(ME.servfd, "NOTICE ", who, " :\001USERINFO ", config.realname, "\001", NULL);
		return;
	}
	if(!strcmp(arg[0], "TIME"))
	{
		struct tm *TM;
		TM = (struct tm *) malloc(sizeof(struct tm));
		TM = gmtime(&NOW);
		strftime(buf, MAX_LEN, "%a %b %d %T %Y", TM);
		quote(ME.servfd, "NOTICE ", who, " :\001TIME ", buf, "\001", NULL);
		free(TM);
		return;
	}
	if(!strcmp(arg[0], "CLIENTINFO"))
	{
		quote(ME.servfd, "NOTICE ", who, " :\001CLIENTINFO PING VERSION TIME USERINFO CLIENTINFO\001", NULL);
		return;
	}
	if(!strcmp(arg[0], "DCC") && !strcmp(arg[1], "CHAT") && strlen(arg[4]))
	{
		if(userlist.IsOwner(mask) && I_AM_HUB)
  		{
			sprintf(buf, "%s", inet2char(htonl(atol(arg[3]))));

			printf("[*] Dcc chat request from owner, connecting to: %s:%s\n", buf, arg[4]);
			n = DoConnect(buf, atoi(arg[4]), config.myipv4, 1);
			if(n > 0)
			{
				printf("[+] Connected\n");
				i = AddSock(n);
				if(i != -1)
				{
					sock[i].status = STATUS_CONNECTED + STATUS_OWNER + STATUS_REGISTERED;
					mem_strcpy(sock[i].name, who);
					SendLogo(n, who);
				}
				else
				{
					quote(ME.servfd, "PRIVMSG ", who, " Cannot establish connection (No free slots)", NULL);
					printf("[-] Droping connection (No free slots)\n");
				}
			}
			else
			{
				quote(ME.servfd, "PRIVMSG ", who, " :Cannot establish connection (", strerror(errno), ")", NULL);
				printf("[-] Cannot establish connection (%s)\n", strerror(errno));
			}
		}
 		return;
	}
}
