/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fnmatch.h>
#include <arpa/inet.h>
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/utsname.h>
#include <math.h>

#define mem_strncpy(__dest, __src, __n)		\
{											\
	__dest = (char *) malloc(__n+1);		\
	strncpy(__dest, __src, __n);			\
	__dest[__n-1] = '\0';					\
}

#define mem_strcpy(__dest, __src)				\
{												\
	__dest = (char *) malloc(strlen(__src)+1);	\
	strcpy(__dest, __src);						\
}

#define mem_strcat(__dest, __src)										\
{																		\
	__dest = (char *) realloc(__dest, strlen(__src)+strlen(__dest)+1);	\
	strcat(__dest, __src);												\
}

#define maskstrip(__mask, __nick, __ident, __host)			\
{															\
	a = strchr(__mask, '!');								\
   	b = strchr(__mask, '@');								\
   	mem_strncpy(__nick, __mask, (int) abs(__mask - a) + 1);	\
   	mem_strncpy(__ident, a+1, (int) abs(a - b));			\
   	mem_strcpy(__host, b+1);								\
}

#define set(__a, __b)			if(!(__a & __b)) __a += __b
#define unset(__a, __b)			if(__a & __b) __a -= __b
#define debug()					printf("[D] [%s:%d] %s(): %s\n", __FILE__, __LINE__, __FUNCTION__, strerror(errno));
#define sclose(n)				shutdown(n, SHUT_RDWR)
#define	bk()					printf("### %s(): %s:%d\n", __FUNCTION__, __FILE__, __LINE__);

#define HAS_A                   1
#define HAS_D                   2
#define HAS_O                   4
#define HAS_F                   8
#define HAS_M                   16
#define HAS_N                   32
#define HAS_ALL					63
#define HAS_S                   64
#define HAS_B                   128
#define IS_OP                   256
#define KICK_SENT				512
#define OP_SENT					1024

#define ARG_MODES				"oblkeIv"
#define NONARG_MODES			"imntsp"

#define STATUS_CONNECTED		1
#define STATUS_REGISTERED		2
#define STATUS_SYNSENT			4
#define STATUS_OWNER			8
#define STATUS_BOT				16
#define STATUS_HUB				32
#define STATUS_DOWNLOADINGUL	64
#define STATUS_SYNCED			128

#define LIST_TOOP				1
#define LIST_BOTSTOOP			2
#define LIST_BOTS				4
#define LIST_TOKICK				8

#define MAX_LEN					1024
#define MAX_CONN        		64
#define MAX_BUFS				MAX_CONN+2
#define MAX_SERVERS				16
#define MAX_CHANNELS			16
#define MAX_HOSTS				64

#define FD_OWNERS				-1000
#define FD_BOTS					-1001

#define TCP_NODELAY				1

#define S_UL_UPLOAD_START		"UL_UPLOAD_START"
#define S_UL_UPLOAD_END			"UL_UPLOAD_END"
#define S_NEWNICK				"NEWNICK"
#define S_REGISTER				"REGISTER"
#define S_VERSION				"0.0.17"
#define S_UNKNOWN				"<unknown>"
#define S_BOTNAME				"psotnic"
#define S_SECRET				"-"
#define S_INVITE				"INVITE"
#define S_KEY					"KEY"
#define S_KEYRPL				"KEYRPL"
#define S_REOP					"REOP"
#define S_CYCLE					"CYCLE"

#define S_ADDUSER				"ADDUSER"
#define S_ADDHOST				"ADDHOST"
#define S_ADDBOT				"ADDBOT"
#define S_ADDCHAN				"ADDCHAN"

#define S_RMUSER				"RMUSER"
#define S_RMHOST				"RMHOST"
#define S_RMBOT					"RMBOT"
#define S_RMCHAN				"RMCHAN"

#define S_CHATTR				"CHATTR"
#define S_ULSAVE				"SAVE"
#define S_SN					"SN"
#define S_SET					"SET"

struct CFG_DB
{
	char name[32];
	int *i;
	char **c;
	int words;
	short int req;
	short int loaded;
};

struct SOCK
{
    int fd;
	char *name;
	int status;
};

struct SERVER
{
	char *host;
	int port;
	char *pass;
};

struct CHANUSER
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	CHANUSER *next;
    CHANUSER *prev;
};

struct HANDLE
{
	char *name;
	char *host[MAX_HOSTS];
	int flags;
	HANDLE *next;
	HANDLE *prev;
};

struct PTRLIST
{
	CHANUSER *ptr;
	PTRLIST *next;
	PTRLIST *prev;
};

struct HUB
{
	int fd;
	char *nick;
	char *ident;
	char *host;
	char *pass;
	int port;
	int status;
};

struct BOT
{
	char *ip;
	char *mask;
	char *pass;
	BOT *next;
	BOT *prev;
};

struct CONFIG
{
	char *nick;
	char *ident;
	char *nickappend;
	char *realname;
	char *myipv4;
	char *vhost;
	char *owner;
	char *userlist_file;
	char *kickreason;
	char *partreason;
	char *quitreason;
	char *cyclereason;
	char *hubhost;
	int hubport;
	int listenport;

	SERVER server[MAX_SERVERS];
};

struct CHANLIST
{
	char *name;
	char *pass;
	int joinsent;
	int nextjoin;
};

struct SOCKBUF
{
    int fd;
    char *buf;
    int len;
    int pos;
};

class ptrlist
{
	public:

	PTRLIST *first;
	int ent;

	PTRLIST *GetItem(int num);
	int SortAdd(CHANUSER *ptr);
	int Remove(char *nick);
	int Find(CHANUSER *ptr);
	void Display();
	void reset();
	ptrlist();
	~ptrlist();
};


class chan
{
   	public:
	ptrlist ToOp, BotsToOp, OpedBots, ToKick;
	CHANUSER *first, *last, *ptr;
	char *name, *BanOverride, *modes, *key, *limit;
	int users;
	int NextCheck;
	int status;

	void DeOp(CHANUSER **MultHandle, int num);
	void Op(CHANUSER **MultHandle, int num);
	void Kick(CHANUSER **MultHandle, int num);
	void RemoveAll(CHANUSER *handle);
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *mask);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick, int quit);
    void Display();
	void QuoteBots(char *str);
	void ReOp();
	void Rejoin(int t);
	CHANUSER *GotJoin(char *mask, int op);
	CHANUSER *GetUser(char *nick);
	int NumberOfBots(int num);
	chan();
	~chan();
};

struct CHANNEL
{
	chan channel;
	CHANNEL *next;
	CHANNEL *prev;
};


class client
{
	public:
	CHANNEL *first, *last, *current;
	client();
	~client();
	int channels, servfd, servid, nextconn_hub, nextconn_serv, nextjoin, status;
	char *nick, *ident, *host, *mask, *servname;
	CHANLIST chanlist[MAX_CHANNELS];

	chan *CreateNewChannel(char *name);
	chan *FindChannel(char *name);
	void RemoveChannel(char *name);
	void GotUserQuit(char *mask);
	void CheckQueue();
	int ConnectToIRC();
	int ConnectToHUB();
	void reset();
	int AddChannelToList(char *name, char *pass);
	int RemoveChannelFromList(char *name);
	int FindChannelInList(char *name);
	void RejoinCheck();
	void Rejoin(char *name, int t);
	void ScheludeJoinToAllChannels();
	void RecheckFlags();
	void Display();
	void GotNickChange(char *from, char *to);
};

class ul
{
	public:
	HANDLE *first, *last;
	BOT *Bfirst, *Blast;
	int ent, bots, ulbuflines;
	unsigned long long int SN; // ;-)
	char *ulbuf;

	HANDLE *AddHandle(char *name);
	int RemoveHandle(char *name);
	void RemoveAllData(HANDLE *p);
	int FindHost(HANDLE *p, char *host);
	int AddHost(HANDLE *p, char *host);
	int RemoveHost(HANDLE *p, char *host);
	int ChangeFlags(HANDLE *p, char *flags);
	HANDLE *FindHandle(char *name);
	int ChangeFlags(char *name, char *flags);
	void GetFlags(HANDLE *p, char *buf);
	int Save(char *file);
	int Load(char *file);
	int GetFlags(char *mask);
	BOT *AddBot(char *mask, char *ip, char *pass);
	int RemoveBot(char *mask);
	void RemoveAllBotData(BOT *p);
	BOT *FindBot(char *mask);
	int IsOwner(char *mask);
	int IsBot(char *ip);
	int CheckBotPass(char *ip, char *pass);
	void Update();
	void reset();
	void Send(int fd);
	ul();
	~ul();
};

struct _var
{
	char *name;
	int *i;
	int from;
	int to;
};

class var
{
	public:
	int ent;
	_var varent[8];

	int AUTOOP_BOTS;
	int PUNISH_BOTS;
	int PUNISH_METHOD;
	int CYCLE_DELAY;
	int REJOIN_DELAY;
	int REJOIN_FAIL_DELAY;
	int HUB_CONN_DELAY;
	int IRC_CONN_DELAY;

	var();
	void addvar(char *name, int def, int *iptr, int a, int b);
	int getvar(char *name);
	int setvar(char *name, char *val);
};

/* parse functions */
void parse_irc(char *data);
void parse_owner(SOCK *s, char *data);
void parse_bot(SOCK *s, char *data);
void parse_hub(char *data);
void parse_ctcp(char *mask, char *data);

/* net functions  */
int DoConnect(char *server, int port, char *vhost, int noblock);
int DoConnect6(char *server, int port, char *vhost, int options);
int ReadOneLine(int fd, char *buf, int len);
int AcceptConnection(int fd);
int StartListening(char *ip, int port);
int getpeerport(int fd);
int AddSock(int fd);
void CloseSock(SOCK *s);
void RemoveBuffers(int fd);
void quote(int file, char *lst, ...);
void RegisterBot(SOCK *s, char *data);
void BufWrite(int fd, char *data, int len);
char *getpeerip(int fd);
char *inet2char(int inetip);

/* random stuff */
void Divide(int *ret, int value, int parts, int part_size);
int GetRandomNumbers(int *n, int start, int end, int num);
int MyTurn(ptrlist *p, int hash, int num);
int GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num);

/* string functions */
int match(char *str, char *pattern);
int MagicNickCreator(char *nick);
int extendhost(char *host, char *buf, int len);
char *push(char *ptr, char *lst, ...);
unsigned int hash32(char *word);

/* rest */
int precache();
int SignalHandling();
int SafeExit();
void propaganda();
void badparameters(char *str);
void LoadConfig(char *file);
void SendLogo(int fd, char *who);
