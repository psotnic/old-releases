#include "prots.h"
#include "global-var.h"

void client::CheckQueue()
{
	time_t now;
	chan *ch;
	CHANNEL *p;
	int j;
	CHANUSER **MultHandle;

	p = first;

	now = time(NULL);
	while(1)
	{

		if(!p) return;
		ch = &p->channel;
		if(!ch)
		{
			p = p->next;
			continue;
		}
		if(!ch->ptr)
		{
			p = p->next;
			continue;
		}
		if(!(ch->ptr->flags & IS_OP))
		{
			p = p->next;
			continue;
		}
		if(ch->NextCheck <= now)
		{
			if(ch->BotsToOp.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				j = GetRandomItems(MultHandle, ch->BotsToOp.first, ch->BotsToOp.ent, 3);
				ch->Op(MultHandle, j);
				ch->NextCheck += 2;
				free(MultHandle);
			}
			else if(ch->ToKick.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
				j = GetRandomItems(MultHandle, ch->ToKick.first, ch->ToKick.ent, 4);
				ch->Kick(MultHandle, j);
				free(MultHandle);
				ch->NextCheck += j;
			}
		}
		p = p->next;
	}
}

void client::GotUserQuit(char *mask)
{
	char *a, *nick;
	CHANNEL *p;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);

	p = first;
	while(1)
	{
		if(!p) break;
		p->channel.GotPart(nick);
		p = p->next;
	}
	free(nick);
}

void client::RemoveChannel(char *name)
{
	CHANNEL *p;

	if(!strcmp(first->channel.name, name))
	{
		p = first;
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		channels--;

	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->channel.name, name))
			{
				channels--;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
			}
		}
	}
	current = first;
}


chan *client::FindChannel(char *name)
{
 	if(!current) return NULL;
		if(!strcmp(current->channel.name, name)) return &current->channel;
	current = first;
	while(1)
	{
		if(!current) break;
		if(!strcmp(current->channel.name, name)) return &current->channel;
		current = current->next;
	}
	return NULL;
}

chan *client::CreateNewChannel(char *name)
{
	if(!channels)
	{
		first = current = last = new(CHANNEL);
		current->prev = current->next = NULL;
		mem_strcpy(current->channel.name, name);
		current->channel.modes = 0;
		channels++;
		return &current->channel;
	}
	else
	{
		current = last->next = new(CHANNEL);
  		current->prev = last;
		current->next = NULL;
		current->channel.modes = 0;
		mem_strcpy(current->channel.name, name);
		last = current;
		channels++;
		return &current->channel;
	}

}

client::client()
{
	first = last = current = NULL;
	channels = 0;
	status = 0;
	nick = NULL;

}
