#include "prots.h"
#include "global-var.h"

void chan::GotMode(char *modes, char *args, char *mask)
{
	char mode[2][4], *arg[4], *a, sign, *nick;
	CHANUSER *NickHandle, *ArgHandle, **MultHandle;
	PTRLIST *p, *q;
	int i,j, just_opped, needop, oped, mypos, n[6], hash;

	oped = just_opped = 0;
	mypos = -1;

	memset(mode, 0, sizeof(mode));
	memset(arg, 0, sizeof(arg));
	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);
	NickHandle = GetUser(nick);

	/* mode striper */
	for(i=0, j=0; i<4 && j<strlen(modes); i++, j++)
	{
		if(modes[j] == '+' || modes[j] == '-')
		{
			sign = modes[j];
			j++;
		}
		mode[0][i] = sign;
		mode[1][i] = modes[j];
	}

	/* arg striper */
	for(i=0; i<4; i++)
	{
		if(strchr(ARG_MODES, mode[1][i]))
		{
			a = strchr(args, ' ');
			if(a)
			{
				mem_strncpy(arg[i], args, abs(args - a)+1);
			}
			else
			{
				mem_strncpy(arg[i], args, strlen(args));
			}
			args = a+1;
		}
		else arg[i] = NULL;
	}

	/* reaction on modes */
	for(i=0; i<4; i++)
	{
		if(mode[0][i] == '+')
		{
			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_B)
				{
					BotsToOp.Remove(arg[i]);
					OpedBots.SortAdd(ArgHandle);
					oped++;
				}

				if(ArgHandle->flags & HAS_O) ToOp.Remove(arg[i]);
				if(!(ArgHandle->flags & IS_OP)) ArgHandle->flags += IS_OP;

				if(!(NickHandle->flags & HAS_M))
				{
					if(!(ArgHandle->flags & HAS_O) && !(ArgHandle->flags & HAS_F))
					{
						ToKick.SortAdd(ArgHandle);
						if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					}
				}
				else if(ArgHandle->flags & HAS_D) ToKick.SortAdd(ArgHandle);
				if(ptr == ArgHandle && !just_opped)	mypos = oped - 1;
			}
		}

		if(mode[0][i] == '-')
		{
			if(mode[1][i] == 'o')
			{
				ToKick.Remove(arg[i]);
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_B)
				{
					OpedBots.Remove(arg[i]);
					oped--;
				}
				if(ArgHandle->flags & HAS_F)
				{
					if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					if(ArgHandle->flags & HAS_A && ArgHandle->flags & HAS_O)
					{
						if(ArgHandle->flags & HAS_B) BotsToOp.SortAdd(ArgHandle);
						else ToOp.SortAdd(ArgHandle);
					}
				}
				if(ptr == ArgHandle) mypos = -1;
			}
		}
	}

	/* Executeted only during initail opping (takeover code) */
	if(mypos != -1 && NextCheck <= NOW)
	{
		j=0;
		if(PUSNISH_METHOD == 1) Divide((int *) &n, BotsToOp.ent, oped, 3);
		else if(PUSNISH_METHOD == 2) Divide((int *) &n, BotsToOp.ent, oped, 2);

		if(n[mypos])
		{
			/* +ooo & 4 KICK */
			if(PUSNISH_METHOD == 1)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				if(mypos == 0) j = GetRandomItems(MultHandle, BotsToOp.first, n[mypos], 3);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1]), n[mypos], 3);
				else j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 3);
				Op(MultHandle, j);
				free(MultHandle);
				if(j) NextCheck = NOW + 2;

				Divide((int *) &n, ToKick.ent, oped, 4);
				if(n[mypos])
				{
					MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
					if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 4);
					else if(mypos == 1)	j =GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 4);
					else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 4);
					Kick(MultHandle, j);
					free(MultHandle);
					NextCheck += j;
				}
			}
			/* +oo & -ooo */
			else if(PUSNISH_METHOD == 2)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*2);
				Divide((int *) &n, BotsToOp.ent, oped, 2);
				if(mypos == 0) j = GetRandomItems(MultHandle, BotsToOp.first, n[mypos], 2);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1]), n[mypos], 2);
				Op(MultHandle, j);
				free(MultHandle);
				if(j) NextCheck = NOW + 2;

				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				Divide((int *) &n, BotsToOp.ent, oped, 3);
				if(n[mypos])
				{
					if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 3);
					else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 3);
					else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 3);
					DeOp(MultHandle, j);
					free(MultHandle);
					if(j) NextCheck = NOW + 3;
				}
			}

		}
		/* 6 KICK */
		else if(ToKick.ent)
		{
			/* do kick6 */
			Divide((int *) &n, ToKick.ent, oped, 6);
			if(n[mypos])
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*6);
				if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 6);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 6);
				else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 6);
				Kick(MultHandle, j);
				free(MultHandle);
				NextCheck = NOW + j;
			}
		}
	}
	/* executed when somebody is playing with the modes */
	if(mypos == -1 && NextCheck <= NOW)
	{

		if(ToKick.ent)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
			j = GetRandomItems(MultHandle, ToKick.first, ToKick.ent, 4);
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick);
			if(MyTurn(&OpedBots, hash, PUNISH_BOTS))
			{
				Kick(MultHandle, j);
				NextCheck = NOW + j;
			}
			free(MultHandle);
		}
		if(BotsToOp.ent < 4)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
			j = GetRandomItems(MultHandle, BotsToOp.first, BotsToOp.ent, 3);
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick);
			if(MyTurn(&OpedBots, hash, AUTOOP_BOTS))
			{
				Op(MultHandle, j);
				NextCheck = NOW + j;
			}
			free(MultHandle);
		}
	}
	free(nick);
	for(i=0; i<4; i++) if(arg[i]) free(arg[i]);
}
