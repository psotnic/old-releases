#define _GNU_SOURCE	1

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fnmatch.h>
#include <arpa/inet.h>
#include <time.h>
#include <fcntl.h>
#include <sys/time.h>

#define mem_strncpy(dest, src, n) \
        dest = (char *) malloc(n+1); \
        strncpy(dest, src, n); \
	    dest[n-1] = '\0'

#define mem_strcpy(dest, src) \
        dest = (char *) malloc(strlen(src)+1); \
        strcpy(dest, src);

#define mem_strcat(dest, src) \
		dest = realloc(dest, sizeof(char)*(strlen(src)+strlen(dest)+1)); \
		strcat(dest, src)

#define maskstrip(mask, nick, ident, host) \
		a = strchr(mask, '!'); \
    	b = strchr(mask, '@'); \
    	mem_strncpy(nick, mask, (int) abs(mask - a) +1); \
    	mem_strncpy(ident, a+1, (int) abs(a - b)); \
    	mem_strcpy(host, b+1)

#define HAS_A                   1
#define HAS_B                   2
#define HAS_O                   4
#define HAS_F                   8
#define HAS_M                   16
#define HAS_N                   32
#define HAS_S                   64
#define HAS_D                   128
#define IS_OP                   256

#define ARG_MODES				"oblkeIv"

#define LIST_TOOP					1
#define LIST_BOTSTOOP				2
#define LIST_BOTS					4
#define LIST_TOKICK					8

#define STATUS_CONNECTED			1
#define STATUS_REGISTERED			2

#define MAX_LEN						1024

#define PENALTY_OP3					2
#define PENALTY_KICK2				2
#define PENALTY_KICK4				4

struct _chanuser
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	struct _chanuser *next;
    struct _chanuser *prev;
};

struct _ptrlist
{
	struct _chanuser *ptr;
	struct _ptrlist *next;
	struct _ptrlist *prev;
};

typedef struct _chanuser CHANUSER;
typedef struct _ptrlist PTRLIST;

class ptrlist
{
	public:

	PTRLIST *first;
	int ent;

	PTRLIST *GetItem(int num);
	int SortAdd(CHANUSER *ptr);
	void Remove(char *nick);
	int Find(CHANUSER *ptr);
	void DebugDisplay();
	ptrlist();
	~ptrlist();
};


class chan
{
   	public:
	ptrlist ToOp, BotsToOp, OpedBots, ToKick;
	CHANUSER *first, *last, *ptr;

	char *name;

	int modes, users;
	int NextCheck;
	void DeOp(CHANUSER **MultHandle, int num);
	void Op(CHANUSER **MultHandle, int num);
	void Kick(CHANUSER **MultHandle, int num);
	int GetFlagsFromUserList(char *mask);
	void AddToPtrList(CHANUSER *p);
	void RemoveAll(CHANUSER *handle);
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *mask);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick);
    void DebugDisplay();
	CHANUSER *GotJoin(char *mask, int op);
	CHANUSER *GetUser(char *nick);
	chan();
	~chan();
};

struct _channel
{
	class chan channel;
	struct _channel *next;
	struct _channel *prev;
};

typedef struct _channel CHANNEL;

class client
{
	public:
	CHANNEL *first, *last, *current;
	client();
	int channels, status, serv;
	char *nick, *ident, *host, *mask;

	chan *CreateNewChannel(char *name);
	chan *FindChannel(char *name);
	void RemoveChannel(char *name);
	void GotUserQuit(char *mask);
	void CheckQueue();
};

int DoConnect(char *server, int port);
int match(char *str, char *pattern);
int precache();
unsigned int hash32(char *word);
void quote(int file, char *lst, ...);
char *push(char *ptr, char *lst, ...);
void Divide(int *ret, int value, int parts, int part_size);
int GetRandomNumbers(int *n, int start, int end, int num);
int MyTurn(ptrlist *p, int hash, int num);
int GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num);

