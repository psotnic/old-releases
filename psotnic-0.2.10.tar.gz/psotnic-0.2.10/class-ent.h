#ifndef PKS_CLASS_ENT_H
#define PKS_CLASS_ENT_H 1

#include "pstring.h"
#include "ptrlist.h"
#include "prots.h"
#include "common.h"

class ent;
class inetconn;

class options
{
	public:
	class event
	{
		public:
		pstring<> reason;
		bool ok;
		bool notFound;
		ent *entity;

		void setOk(ent *e, const char *format, ...);
		void setError(ent *e, const char *format, ...);
		void setError(ent *e);
		void setNotFound(const char *format, ...);
		event();
	};

	ptrlist<ent> list;

	options();

	event *setVariable(const char *var, const char *value);
	void sendToOwner(const char *owner, const char *var, const char *prefix);
	bool parseUser(const char *from, const char *var, const char *value, const char *prefix);
	void reset();
	void sendToFile(inetconn *c, pstring<> prefix);

#ifdef HAVE_DEBUG
	void display();
#endif

	protected:
	void registerObject(const ent &e);
	int maxVarLen;
};

class ent
{
	public:
	const char *name;
	static options::event _event;
	bool dontPrintIfDefault;
	bool readOnly;

	ent(const char *n=NULL) : name(n), dontPrintIfDefault(false), readOnly(false) { };
	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0) = 0;
	virtual options::event *set(const char *arg, const bool justTest=0);
	virtual const char *getValue() const = 0 ;
	virtual const char *getName() const;
	virtual const char *print(const int n=0) const;
	virtual void reset() = 0;
	virtual bool isDefault()  const = 0;
	virtual bool isPrintable() const;
	virtual bool isReadOnly() const { return readOnly; };
	virtual void setDontPrintIfDefault(bool value) { dontPrintIfDefault = value; };
	virtual void setReadOnly(bool value) { readOnly = value; };
	bool operator<(const ent &e) const;
	bool operator==(const ent &e) const;
};


class entBool : public ent
{
	public:
	int value;
	int defaultValue;

	virtual options::event *setValue(const char *arg1, const char *arg2="", const bool justTest=0);
	operator int() const;
	entBool() : ent(NULL), value(false), defaultValue(false) { };
	entBool(const char *n, const bool def) : ent(n), value(def), defaultValue(def) { };

	bool str2int(const char *str, bool &ok) const;
	virtual const char *getValue() const;
	virtual void reset();
	virtual bool isDefault() const;
	int operator=(int n)	{ value = (n == 1); return value; };
};

class entInt : public entBool
{
	public:
	int min, max;

	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
	virtual int str2int(const char *str, bool &ok) const;
	entInt() : min(0), max(0) { name = NULL; };
	entInt(const char *n, const int minimum, const int maximum, const int def)
		: min(minimum), max(maximum) { name = n, value = defaultValue = def; };
	virtual const char *getValue() const;
	virtual const char *getMin() const;
	virtual const char *getMax() const;
	operator int() const;
	int operator==(int n) const;
};

class entTime : public entInt
{
	public:
	entTime() : entInt() { };
	entTime(const char *n, const int minimum, const int maximum, const int def) :
		entInt(n, minimum, maximum, def) { };

	virtual int str2int(const char *str, bool &ok) const;
	virtual const char *getValue() const;
	virtual const char *getMin() const;
	virtual const char *getMax() const;
};

class entPerc : public entInt
{
	public:
	entPerc() : entInt() { };
	entPerc(const char *n, const int minimum, const int maximum, const int def) :
		entInt(n, minimum, maximum, def) { };

	virtual int str2int(const char *str, bool &ok) const;
	virtual const char *getValue() const;
	virtual const char *getMin() const;
	virtual const char *getMax() const;
};

class entIp : public ent
{
	protected:
	int type;

	public:
	pstring<8> ip;

	enum types { ipv4 = 0x01, ipv6 = 0x02, bindCheck = 0x04, resolve = 0x08 };
	entIp(const char *n="", const int t=ipv4) : ent(n), type(t), ip("0.0.0.0") { };
	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
	virtual const char *getValue() const;
	virtual void reset();
	virtual bool isDefault() const;
	virtual operator const char*() const;
	virtual operator unsigned int() const;
	virtual ~entIp() { };

};

class entString : public ent
{
	public:
	int min, max;
	pstring <16> string;
	pstring <16> defaultString;


	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
	virtual const char *getValue() const;
	virtual void reset();
	virtual bool isDefault() const;
	virtual operator const char*() const;
	virtual int getLen() const;
	entString(const char *n="", const int minimum=0, const int maximum=MAX_INT, const char *def="") :
			ent(n), min(minimum), max(maximum), string(def), defaultString(def) { }
	virtual ~entString() { };
};

class entWord : public entString
{
	public:
	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
		entWord(const char *n="", const int minimum=0, const int maximum=MAX_INT, const char *def="")
	: entString(n, minimum, maximum, def) { };

	virtual ~entWord() { };
};

class entMD5Hash : public entWord
{
	public:
	unsigned char hash[16];

	public:
	entMD5Hash(const char *n="") : entWord(n)	{ memset(hash, 0, 16); };
	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
	virtual void reset();
	virtual bool isDefault() const;
	virtual const unsigned char *getHash() const;
	virtual operator const unsigned char*() const;
	virtual ~entMD5Hash() { };
};

class entIPPH : public ent	//ip port password handle
{
	protected:
	entIp *_ip;
	entInt *_port;
	entWord *_pass;
	entWord *_handle;
	virtual options::event *_setValue(const char *arg1, const char *arg2, const char *arg3, const char *arg4, const char *arg5, const bool justTest);

	public:
	virtual options::event *setValue(const char *arg1, const char *arg2, const bool justTest=0);
	entIPPH(const char *n="", entIp *ip=0, entInt *port=0, entWord *pass=0, entWord *handle=0) :
			ent(n), _ip(ip), _port(port), _pass(pass), _handle(handle) { };
	virtual const char *getValue() const;
	virtual ~entIPPH();
	virtual entIp &getIp()		{ return *_ip; };
	virtual entInt &getPort()	{ return *_port; };
	virtual entWord &getPass()	{ return *_pass; };
	virtual entWord &getHandle(){ return *_handle; };
	virtual entIPPH &operator=(const entIPPH &e);
	virtual void reset();
	virtual bool isDefault() const;

	friend class CONFIG;
};

class entHub : public entIPPH
{
	public:
	int failures;
	entHub(char *n="", entIp *ip=0, entInt *port=0, entMD5Hash *pass=0, entWord *handle=0) :
		entIPPH(n, ip, port, pass, handle), failures(0) { };
	virtual ~entHub() { };
};


class entServer : public entIPPH
{
#ifdef HAVE_SSL
	private:
	bool ssl;
#endif
	
	public:
#ifdef HAVE_SSL
	entServer(char *n="", entIp *ip=0, entInt *port=0, bool sslCrypted=0) :
		entIPPH(n, ip, port, 0, 0), ssl(sslCrypted) { };
#else
	entServer(char *n="", entIp *ip=0, entInt *port=0) :
		entIPPH(n, ip, port, 0, 0) { };
#endif
	virtual options::event *set(const char *ip, const char *port, const bool justTest=0);
	virtual ~entServer() { };

#ifdef HAVE_SSL
	bool isSSL() const;
#endif
};

class entMult : public ent
{
	private:
	ptrlist<ent> list;

	public:
	entMult(const char *n=""): ent(n) { };
	virtual options::event *setValue(const char *arg1, const char *arg2, bool justTest=0);
	virtual const char *getValue() const { return NULL; };
	virtual void reset();
	virtual bool isDefault() const { return 1; };
	virtual bool isPrintable() const { return 0; };
	virtual void add(ent *e);
	virtual ~entMult() { };
};

class entLoadModules : public ent
{
	private:
	bool md5;

	virtual options::event *_setValue(const char *arg1, const char *arg2, const char *arg3, bool justTest=0);

	public:
		entLoadModules(char *n="", bool needValidMD5=1) : ent(n), md5(needValidMD5) { };
	virtual ~entLoadModules() { };

	virtual options::event *setValue(const char *arg1, const char *arg2, bool justTest=0);
	virtual const char *getValue() const { return NULL; };
	virtual void reset() { };
	virtual bool isDefault() const { return 1; };
	virtual bool isPrintable() const { return 0; };
	ptrlist<module>::iterator findModule(const char *str);
	//bool rehash
};

#endif
