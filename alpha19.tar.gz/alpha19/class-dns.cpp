/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void dns::RecvPacket()
{
	sockaddr_in from;
	socklen_t fromlen = sizeof(sockaddr);
	char buf[MAX_LEN];
	int len;

	/* only IPv4 nameservers are supported */
	len = recvfrom(resfd, buf, MAX_LEN, 0, (sockaddr *) &from, &fromlen);

	printf("[*] Recieved packet (%d bytes)\n", len);
	if(VerifyPacket(buf, len, &from, &fromlen))
	{
		printf("[+] Packet verified\n");
	}
	else printf("[-] Veryfication faild\n");
}


int dns::VerifyPacket(char *packet, int len, sockaddr_in *from, socklen_t *fromlen)
{
	int i=0;

	if(len <= (int) sizeof(DNSHEADER)) return 0;
	if(!from) return 0;

	for(i=0; i < _res.nscount; ++i)
		if(_res.nsaddr_list[i].sin_addr.s_addr == from->sin_addr.s_addr) return 1;

	return 0;
}


void dns::ParsePacket(char *packet, int len)
{

	DNSHEADER *h;

	h = (DNSHEADER *) packet;
	printf("-> id: %d\n", h->id);
}

void dns::SendQuery(char *domain, int type)
{
	u_char buf[MAX_LEN];
	int i, n, s;
	DNSHEADER *h;

	bk();
	printf("quering: %s\n", domain);
	printf("resfd: %d\n", resfd);
	n = res_mkquery(QUERY, domain, C_IN, 1, NULL, 0, NULL, buf, MAX_LEN);
	if(n < (int) sizeof(DNSHEADER)) debug();
	else
	{
		h = (DNSHEADER *) buf;
		h->id = 32;
		printf("header size: %d\n", sizeof(DNSHEADER));
		printf("query size:  %d\n", n-sizeof(DNSHEADER));
		printf("packet size: %d\n", n);


		for (i=0; i < _res.nscount; ++i)
		{
			s = sendto(resfd, buf, n, 0, (sockaddr *) &_res.nsaddr_list[i], sizeof(sockaddr));
			printf("wrote: %d of %d bytes\n", s, n);
		}
	}
}

dns::dns()
{
	int i;
	resfd = socket(AF_INET, SOCK_DGRAM, 0);

	if(resfd <= 0)
	{
		propaganda();
		printf("[-] Cannot create udp socket (%s)\n", strerror(errno));
		printf("[*] Calling exit(4)\n");
		exit(4);
	}

	res_init();
	if (!_res.nscount)
	{
		printf("[-] No nameservers found\n");
		printf("[*] Calling exit(4)\n");
		exit(4);
	}
    _res.options |= RES_RECURSE | RES_DEFNAMES | RES_DNSRCH;

	for (i=0; i<_res.nscount; i++)
		_res.nsaddr_list[i].sin_family = AF_INET;
}
