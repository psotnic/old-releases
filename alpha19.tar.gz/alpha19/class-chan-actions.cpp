/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/* MULTIUSER ACTIONS */
void chan::Op(CHANUSER **MultHandle, int num)
{
	char *a = NULL;
	int i, j;

	if(!num) return;

	if(ME.NextAction <= NOW)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & OP_SENT))
			{
				a = push(a, " ", MultHandle[i]->nick, NULL);
   				MultHandle[i]->flags += OP_SENT;
				++j;
			}
		}
		if(j)
		{
			quote(ME.servfd, "MODE ", name, j == 3 ? " +ooo" : j == 2 ? " +oo" : " +o", a, NULL);
			/* FIXME: good asumptions? */
			if(j == 3) ME.NextAction = NOW + 1;
			else ME.NextAction = NOW;
			free(a);
		}
	}
}

void chan::Kick4(CHANUSER **MultHandle, int num)
{
	if(!num) return;
	if(num > 4) num = 4;

	char *a = NULL;
	int i, j;

	if(ME.NextAction <= NOW)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j)
		{
			quote(ME.servfd, "KICK ", name, " ", a, " :", config.kickreason, NULL);
			ME.NextAction = NOW + (int) (j * 1.7) ;
			free(a);
		}
	}
}

void chan::Kick6(CHANUSER **MultHandle, int num)
{
	if(!num) return;
	if(num < 5) Kick4(MultHandle, num);
	else
	{
		time_t T;

		if(num > 6) num = 6;

		Kick4(MultHandle, 2);
		T = ME.NextAction - NOW;
		ME.NextAction = NOW;
		Kick4(MultHandle+2, num-2);
		ME.NextAction = NOW + (int) (num * 1.7);
	}
}

/* SINGLEUSER */
void chan::Op(CHANUSER *p, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(VAR.PUNISH_BOTS)))
		Op(p);
}

void chan::Op(CHANUSER *p)
{
	if(!(p->flags & OP_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			quote(ME.servfd, "MODE ", name, " +o ", p->nick, NULL);
			ME.NextAction = NOW + 1;
			p->flags += OP_SENT;
		}
	}
}

void chan::DeOp(CHANUSER *p, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(VAR.PUNISH_BOTS)))
		DeOp(p);
}

void chan::DeOp(CHANUSER *p)
{
	if(!(p->flags & DEOP_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			quote(ME.servfd, "MODE ", name, " -o ", p->nick, NULL);
			ME.NextAction = NOW + 1;
			p->flags += DEOP_SENT;
		}
	}
}


void chan::Kick(CHANUSER *p, unsigned int hash, char *reason)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(VAR.PUNISH_BOTS)))
		Kick(p, reason);
}

void chan::Kick(CHANUSER *p, char *reason)
{
	if(!(p->flags & KICK_SENT))
	{
		if(ME.NextAction <= NOW)
		{
			quote(ME.servfd, "KICK ", name, " ", p->nick, " :", reason, NULL);
			ME.NextAction = NOW + 1;
			p->flags += KICK_SENT;
		}
	}
}

void chan::KickBan(CHANUSER *p, char *mask, char *reason)
{
	if(ME.NextAction <= NOW)
	{
		ME.NextAction = NOW;
		if(!(p->flags & BAN_SENT))
		{
			quote(ME.servfd, "MODE ", name, " +b ", mask, NULL);
			p->flags += BAN_SENT;
			++ME.NextAction;
		}
		if(!(p->flags & KICK_SENT))
		{
			if(strlen(reason)) quote(ME.servfd, "KICK ", name, " ", p->nick, " :", reason, NULL);
			else quote(ME.servfd, "KICK ", name, " ", p->nick, " :", config.banreason, NULL);
			p->flags += KICK_SENT;
			++ME.NextAction;
		}
	}
}

void chan::Unban(char *str, unsigned int hash)
{
	if(MyTurn(&OpedBots, hash, NumberOfBots(VAR.UNBAN_BOTS)) && ME.NextAction <= NOW)
	{
		char ban[5] = "-b";
		int i;

		for(i=2; i<5; )
		{
			if(*str == '\0') break;
			if(*str == ' ')	ban[i++] = 'b';
		}
		ban[i] = '\0';
		quote(ME.servfd, "MODE ", ban, " ", str, NULL);
	}
}

int chan::Invite(char *nick, int f)
{
	if(ME.NextAction <= NOW)
	{
		if(ME.NextMsg <= NOW)
		{
			if(ptr->flags & IS_OP)
			{
				quote(ME.servfd, "INVITE ", nick, " ", name, NULL);
				ME.NextMsg = NOW + f ? VAR.FRIEND_ACTION_PENALITY : VAR.ACTION_PENALITY;
				return 1;
			}
		}
	}
	return 0;
}
