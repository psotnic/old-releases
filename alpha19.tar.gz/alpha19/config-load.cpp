/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void LoadConfig(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	FILE *f;
	int line, i;
	int errors = 0;
	int YES = 1;
	int NO = 0;

	CFG_DB db[] =
	{
	/*		 name			int *				char **					words	req					  */
	/*00*/ { "nick",		NULL,				&config.nick,			 1,		&YES,				0 },
	/*01*/ { "ident",		NULL,				&config.ident,			 1,		&YES,				0 },
	/*02*/ { "nickappend",	NULL,				&config.nickappend,		 1,		&YES,				0 },
	/*03*/ { "realname",	NULL,				&config.realname,		-1,		&YES,				0 },
	/*04*/ { "myipv4",		NULL,				&config.myipv4,			 1,		&YES,				0 },
	/*05*/ { "vhost",		NULL,				&config.vhost,			 1,		&NO,				0 },
	/*06*/ { "owner",		NULL,				&config.owner,			 1,		&YES ,				0 },
	/*07*/ { "userlist",	NULL,				&config.userlist_file,	 1,		&YES,				0 },
	/*08*/ { "kickreason",	NULL,				&config.kickreason,		-1,		&NO,				0 },
	/*09*/ { "partreason",	NULL,				&config.partreason,		-1,		&NO,				0 },
	/*10*/ { "quitreason",	NULL,				&config.quitreason,		-1,		&NO,				0 },
	/*11*/ { "cyclereason",	NULL,				&config.cyclereason,	-1,		&NO,				0 },
	/*12*/ { "havehub",		&config.havehub,	NULL,					 0,		&YES,				0 },
	/*13*/ { "hubhost",		NULL,				&config.hubhost,		 1,		&config.havehub,	0 },
	/*14*/ { "hubport",		&config.hubport,	NULL,					 0,		&config.havehub,	0 },
	/*15*/ { "hubpass",		NULL,				&config.hubpass,		 1,		&config.havehub,	0 },
	/*16*/ { "listen",		&config.listenport,	NULL,					 0,		&YES,				0 },
	/*17*/ { "botnetword",	NULL,				&config.botnetword,		 1,		&NO,				0 },
	/*19*/ { "banreason",	NULL,				&config.banreason,		-1,		&NO,				0 },
	/*20*/ { "limitreason",	NULL,				&config.limitreason,	-1,		&NO,				0 },
	/*21*/ { "",			NULL,				NULL,					 0,		NULL,				0 }
	};

	printf("[*] Loading config from '%s'\n", file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[-] Cannot open config file!!!\n");
		exit(1);
	}

	for(line=0; ; ++line)
	{
		lame:
		if(feof(f)) break;
		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);

		str2words(arg[0], buf, 10, MAX_LEN);

		if(arg[0][0] == '#') continue;

		/* look for option in DB */
		for(i=0; ; ++i)
		{
			if(!strlen(db[i].name)) break;
			if(!strcasecmp(db[i].name, arg[0]))
			{
				if(db[i].loaded)
				{
					printf("[-] %s:%d: Redefinition of '%s'\n", file, line, db[i].name);
					++errors;
					goto lame;
				}
				if(!strlen(arg[1]))
				{
					printf("[-] %s:%d: Inavlid argument for option '%s'\n", file, line, db[i].name);
					++errors;
					goto lame;
				}
				if(db[i].i != NULL)
				{
					*db[i].i = atoi(arg[1]);
				}
				else if(db[i].c != NULL)
				{
					if(db[i].words == 1)
					{
						mem_strcpy(*db[i].c, arg[1]);
					}
					else if(db[i].words == -1)
					{
						a = buf;
						a[strlen(a) - 1] = '\0';
						while(!isspace(*a)) ++a;
						while(isspace(*a)) ++a;
						mem_strcpy(*db[i].c, a);
					}

				}
				else
				{
					printf("[-] Wrong parameter database !!!\n");
					exit(1);
				}
				db[i].loaded = 1;
				goto lame;
			}
		}

		/* non standard options */
		if(!strcmp(arg[0], "server"))
		{
			if(!strlen(arg[2]))
			{
				printf("[-] %s:%d: Error: Inavlid argument for option 'server'\n", __FILE__, __LINE__);
				exit(1);
			}
			for(i=0; i<MAX_SERVERS; i++)
			{
				if(config.server[i].host == NULL)
				{
					mem_strcpy(config.server[i].host, arg[1]);
					config.server[i].port = atoi(arg[2]);
					break;
				}
			}
			continue;
		}
		if(!strcmp(arg[0], "channel"))
        {
            if(!strlen(arg[1]))
            {
                printf("[-] %s:%d: Error: Inavlid argument for option 'channel'\n", __FILE__, __LINE__);
                exit(1);
            }
            ME.AddChannelToList(arg[1], arg[2]);
            continue;
        }

		if(strlen(arg[0])) printf("[!] %s:%d: unknown option '%s'\n", file, line, arg[0]);
	}

	for(i=0; ; ++i)
	{
		if(!strlen(db[i].name)) break;
		if(*db[i].req && !db[i].loaded)
		{
			printf("[-] Mandatory option not set: %s\n", db[i].name);
			++errors;
		}
	}

	if(errors)
	{
		printf("[-] Failed to load config\n");
		exit(1);
	}

	if(config.listenport == config.hubport && !strcmp(config.hubhost, config.myipv4) && config.havehub)
	{
		printf("[-] ROTFL: Why should I connect to myself? ;-)\n");
		++errors;
	}

	/* defaults for not set values */
	if(!config.partreason) mem_strcpy(config.partreason, "\002### The Psotnic Project ###\002");
	if(!config.quitreason) mem_strcpy(config.quitreason,"\002### The Psotnic Project ###\002");
	if(!config.kickreason) mem_strcpy(config.kickreason, "\002Psotnic-X Baby\002");
	if(!config.banreason) mem_strcpy(config.banreason, "\002Will you please go out?\002");
	if(!config.cyclereason) mem_strcpy(config.cyclereason, "\002### The Psotnic Project ###\002");
	if(!config.botnetword) mem_strcpy(config.botnetword, "###\001The\001Psotnic\001Project\001###");
	if(!config.limitreason) mem_strcpy(config.limitreason, "\002Sorry, but we are full\002");
	if(!config.vhost) mem_strcpy(config.vhost, "");
	fclose(f);

	printf("[+] Config loaded\n");
}
