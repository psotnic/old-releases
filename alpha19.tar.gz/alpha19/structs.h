/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

struct CFG_DB
{
	char name[32];
	int *i;
	char **c;
	int words;
	int *req;
	int loaded;
};

struct SOCK
{
    int fd;
	char *name;
	int status;

	char *authstr;
	char *pass;
	short int authstep;
	int killtime;
};

struct SERVER
{
	char *host;
	int port;
	char *pass;
};

struct CHANUSER
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	CHANUSER *next;
    CHANUSER *prev;
};

struct HANDLE
{
	char *name;
	char *host[MAX_HOSTS];
	int flags;
	HANDLE *next;
	HANDLE *prev;
};

struct PTRLIST
{
	CHANUSER *ptr;
	PTRLIST *next;
	PTRLIST *prev;
};

struct BOT
{
	char *ip;
	char *mask;
	char *pass;
	BOT *next;
	BOT *prev;
};

struct CONFIG
{
	char *nick;
	char *ident;
	char *nickappend;
	char *realname;
	char *myipv4;
	char *vhost;
	char *owner;
	char *userlist_file;
	char *kickreason;
	char *banreason;
	char *partreason;
	char *quitreason;
	char *cyclereason;
	char *limitreason;
	char *hubhost;
	char *hubpass;
	char *botnetword;
	int hubport;
	int listenport;
	int havehub;

	SERVER server[MAX_SERVERS];
};

struct CHANLIST
{
	char *name;
	char *pass;
	int joinsent;
	int nextjoin;
};

struct SOCKBUF
{
    int fd;
    char *buf;
    int len;
    int pos;
};

struct MASKLIST
{
	char *mask;
	char *info[2];
	MASKLIST *next;
	MASKLIST *prev;
};

struct DNSHEADER {
	unsigned short int			id;			/* Packet id */
	unsigned char 				databyte_a;
	/* rd:1						recursion desired
	 * tc:1						truncated message
	 * aa:1						authoritive answer
	 * opcode:4					purpose of message
	 * qr:1						response flag
	 */
	unsigned char				databyte_b;
	/* rcode:4					response code
	 * unassigned:2				unassigned bits
	 * pr:1						primary server required (non standard)
	 * ra:1						recursion available
	 */
	unsigned short int			qdcount;	/* Query record count */
	unsigned short int			ancount;	/* Answer record count */
	unsigned short int			nscount;	/* Authority reference record count */
	unsigned short int			arcount;	/* Resource reference record count */
};
