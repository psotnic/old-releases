/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

class ptrlist
{
	public:
	PTRLIST *first;
	int ent;

	PTRLIST *GetItem(int num);
	void SortAdd(CHANUSER *ptr);
	//void Add(CHANUSER *u);
	//int Remove(char *nick);
	int Find(CHANUSER *ptr);
	int Remove(CHANUSER *ptr);
	//CHANUSER *Find(char *name);
	void Display();


	/* Constructor */
	ptrlist();

	/* Destruction derby */
	~ptrlist();
	void reset();
};

class masklist
{
	public:
	MASKLIST *first, *last;
	int ent;

	int Add(char *mask, char *info, char *info2);
	int Remove(char *mask);
	MASKLIST *Find(char *mask);
	MASKLIST *Find(char *mask, char *info, char *info2);
	MASKLIST *WildFind(char *mask);
	void Display();

	/* Constructor */
	masklist();

	/* Destruction derby */
	~masklist();
	void Destroy(MASKLIST *p);
};

class chan
{
   	public:
	ptrlist ToOp, BotsToOp, OpedBots, ToKick;
	masklist ToBan;
	CHANUSER *first, *last, *ptr;
	chan *next, *prev;
	char *name, *BanOverride, *modes, *key;
	int users, status, limit;

	/* Actions */
	void Op(CHANUSER **MultHandle, int num);
	void Op(CHANUSER *p, unsigned int hash);
	void Op(CHANUSER *p);
	void DeOp(CHANUSER *p, unsigned int hash);
	void DeOp(CHANUSER *p);
	void Kick4(CHANUSER **MultHandle, int num);
	void Kick6(CHANUSER **MultHandle, int num);
	void Kick(CHANUSER *p, unsigned int hash, char *reason);
	void Kick(CHANUSER *p, char *reason);
	void KickBan(CHANUSER *p, char *mask, char *reason);
	void Unban(char *str, unsigned int hash);
	int Invite(char *nick, int f);

	/* Got something */
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *mask);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick, int quit);
	int GotBan(char *ban, CHANUSER *caster);
	CHANUSER *GotJoin(char *mask, int op);
	CHANUSER *GetUser(char *nick);

	/* other */
	void QuoteBots(char *str);
	int QuoteOpedBots(char *str, int num);
	void ReOp();
	void Rejoin(int t);
	int NumberOfBots(int num);

	/* Debug */
	void Display();

	/* Constructor */
	chan();

	/* Destruction derby */
	~chan();
	void Destroy(CHANUSER *p);
	void RemoveFromAllPtrLists(CHANUSER *handle);
};

class client
{
	public:
	chan *first, *last, *current;
	int channels, servfd, servid, nextconn_hub, nextconn_serv, nextjoin, status;
	char *nick, *ident, *host, *mask, *servname;
	CHANLIST chanlist[MAX_CHANNELS];
	time_t NextAction, NextMsg;

	/* Irc chanels */
	chan *CreateNewChannel(char *name);
	chan *FindChannel(char *name);
	void RemoveChannel(char *name);
	void GotUserQuit(char *mask);
	void RecheckFlags();
	void Rejoin(char *name, int t);
	void RejoinCheck();
	void ScheludeJoinToAllChannels();
	void GotNickChange(char *from, char *to);
	void CheckQueue();

	/* Ul channels */
	int AddChannelToList(char *name, char *pass);
	int RemoveChannelFromList(char *name);
	int FindChannelInList(char *name);

	/* Net */
	int ConnectToIRC();
	int ConnectToHUB();
	void BotNetInvite(char *channel, char *nick);

	/* Debug */
	void Display();

	/* Constructor */
	client();

	/* Destruction derby */
	~client();
	void reset();
};

class ul
{
	public:
	HANDLE *first, *last;
	BOT *Bfirst, *Blast;
	int ent, bots, ulbuflines;
	unsigned long long int SN; // ;-)
	char *ulbuf;

	/* Handle */
	HANDLE *AddHandle(char *name);
	HANDLE *FindHandle(char *name);
	int RemoveHandle(char *name);

	/* Bot */
	BOT *AddBot(char *mask, char *ip, char *pass);
	BOT *FindBot(char *mask);
	int RemoveBot(char *mask);

	/* Host */
	int AddHost(HANDLE *p, char *host);
	int FindHost(HANDLE *p, char *host);
	int RemoveHost(HANDLE *p, char *host);

	/* Flags */
	int ChangeFlags(HANDLE *p, char *flags);
	int ChangeFlags(char *name, char *flags);
	int GetFlags(char *mask);
	void GetFlags(HANDLE *p, char *buf);
	int IsOwner(char *mask);
	int IsBot(char *ip);

	/* other */
	int Save(char *file);
	int Load(char *file);
	void Update();
	void Send(int fd);
	char *CheckBotMD5Digest(char *ip, char *digest, char *authstr);

	/* Constructor */
	ul();

	/* Destruction derby */
	~ul();
	void reset();
	void DestroyHandle(HANDLE *p);
	void DestroyBot(BOT *p);
};

class var
{
	public:
	struct _var
	{
		char *name;
		int *i;
		int from;
		int to;
	};

	int ent;
	_var varent[17];

	int AUTOOP_BOTS;
	int PUNISH_BOTS;
	int UNBAN_BOTS;
	int INVITE_BOTS;
	int SHIT_BOTS;
	int PUNISH_METHOD;
	int CYCLE_DELAY;
	int REJOIN_DELAY;
	int REJOIN_FAIL_DELAY;
	int HUB_CONN_DELAY;
	int IRC_CONN_DELAY;
	int AUTH_TIME;
	int ACTION_PENALITY;
	int FRIEND_ACTION_PENALITY;
	int LIMIT_CHAN_USERS;
	int NO_GLOBAL_CTCP;
	int NO_PRIVATE_CTCP;

	int pl_bots;
	int pl_owners;

	void addvar(char *name, int def, int *iptr, int a, int b);
	int getvar(char *name);
	int setvar(char *name, char *val);

	/* Constructor */
	var();
};

class dns
{
	public:
	int resfd;

	void SendQuery(char *domain, int type);
	void ParsePacket(char *packet, int len);
	void RecvPacket();
	int VerifyPacket(char *packet, int len, sockaddr_in *from, socklen_t *fromlen);

	/* Constructor */
	dns();
};
