/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void masklist::Display()
{
	MASKLIST *m = first;

	while(m)
	{
		printf("[%s] [%s] [%s]\n", m->mask, m->info[0], m->info[1]);
		m = m->next;
	}
}

MASKLIST *masklist::WildFind(char *mask)
{
	MASKLIST *p = first;

	while(1)
	{
		if(!p) return NULL;
		if(match(mask, p->mask)) return p;
		p = p->next;
	}
	return NULL;
}

MASKLIST *masklist::Find(char *mask, char *info, char *info2)
{
	MASKLIST *p = first;

	while(p)
	{
		if(mask)
		{
			if(strcmp(p->mask, mask)) continue;
		}
		if(info)
		{
			if(strcmp(p->info[0], info)) continue;
		}
		if(info2)
		{
			if(strcmp(p->info[1], info)) continue;
		}
		return p;
	}
	return NULL;
}


MASKLIST *masklist::Find(char *mask)
{
	MASKLIST *p = first;

	while(p)
	{
		//if(!p) return NULL;
		if(!strcasecmp(mask, p->mask)) return p;
		p = p->next;
	}
	return NULL;
}

int masklist::Add(char *mask, char *info, char *info2)
{
	MASKLIST *p;

	if(Find(mask)) return 0;
	if(!ent)
	{
		first = last = new(MASKLIST);
		first->prev = first->next = NULL;
		mem_strcpy(first->mask, mask);
		mem_strcpy(first->info[0], info);
		mem_strcpy(first->info[1], info2);
	}
	else
	{
		p = last->next = new(MASKLIST);
  		p->prev = last;
		p->next = NULL;
		mem_strcpy(p->mask, mask);
		mem_strcpy(p->info[0], info);
		mem_strcpy(p->info[1], info2);
		last = p;
	}
	++ent;
	return 1;
}

int masklist::Remove(char *mask)
{
	MASKLIST *p;

	if(!first) return 0;
	p = first;

	if(ent == 1)
	{
		Destroy(p);
		ent = 0;
		first = last = NULL;
		return 1;
	}
	else if(!strcasecmp(first->mask, mask))
	{
		first = first->next;
		if(p) first->prev = NULL;
		Destroy(p);
		--ent;
		return 1;
	}
	else if(!strcasecmp(last->mask, mask))
	{
		p = last->prev;
		p->next = NULL;
		Destroy(p);
		--ent;
		last = p;
		return 1;
	}
	else
	{
		p = first->next;
		while(p)
		{
			if(!strcasecmp(p->mask, mask))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--ent;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

masklist::masklist()
{
	first = last = NULL;
	ent = 0;
}

/* Destruction derby */
masklist::~masklist()
{
	MASKLIST *p = first;
	MASKLIST *q;

	while(p)
	{
		q = p;
		p = p->next;
		Destroy(q);
	}
}

void masklist::Destroy(MASKLIST *p)
{
	free(p->mask);
	free(p->info[0]);
	free(p->info[1]);
	free(p);
}
