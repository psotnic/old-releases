/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int var::setvar(char *name, char *val)
{
	int i, v;
	i = getvar(name);
	if(i == -1) return -1;
	v = atoi(val);
	if(v >= varent[i].from && v <= varent[i].to)
	{
		*varent[i].i = atoi(val);
		return i;
	}
	return i*(-1)-2;
}

int var::getvar(char *name)
{
	int i;
	for(i=0; i<ent; ++i)
		if(!strcmp(varent[i].name, name)) return i;
	return -1;
}

void var::addvar(char *name, int def, int *iptr, int a, int b)
{
	//varent[ent].name = name;
	mem_strcpy(varent[ent].name, name);
	varent[ent].i = iptr;
	*varent[ent].i = def;
	varent[ent].from = a;
	varent[ent].to = b;
	++ent;
}

var::var()
{
	pl_bots = pl_owners = ent = 0;

	/* 14 */
	addvar("autoop-bots", 3, &AUTOOP_BOTS, -100, 65535);
	addvar("punish-bots", 3, &PUNISH_BOTS, -100, 65535);
	addvar("unban-bots", 3, &UNBAN_BOTS, -100, 65535);
	addvar("shit-bots", 3, &SHIT_BOTS, -100, 65535);
	addvar("invite-bots", 3, &INVITE_BOTS, -100, 65535);
	addvar("punish-method",1 , &PUNISH_METHOD, 1, 2);
	addvar("cycle-delay", 10, &CYCLE_DELAY, 0, 65535);
	addvar("rejoin-delay", 2, &REJOIN_DELAY, 0, 65535);
	addvar("rejoin-fail-delay", 30, &REJOIN_FAIL_DELAY, 0, 65535);
	addvar("hub-conn-delay", 60, &HUB_CONN_DELAY, 30, 65535);
	addvar("irc-conn-delay", 30, &IRC_CONN_DELAY, 10, 65535);
	addvar("bot-auth-time", 10, &AUTH_TIME, 1, 65535);
	addvar("action-penality", 3, &ACTION_PENALITY, 0, 65535);
	addvar("friend-action-penality", 1, &FRIEND_ACTION_PENALITY, 0, 65535);


}
