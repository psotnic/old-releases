/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/*
void ptrlist::Add(CHANUSER *u)
{
	PTRLIST *p;

	if(!ent)
	{
		first = new(PTRLIST);
		first->next = first->prev = NULL;
		first->ptr = ptr;
	}
	else
	{
		p = first->prev = new(PTRLIST);
		p->next = first;
		p->prev = NULL;
		p->ptr = ptr;
		first = p;
	}
	++ent;
}
*/
/*
int ptrlist::Remove(char *nick)
{
	PTRLIST *p;
	p = first;

	if(!ent) return 0;
	if(!strcmp(first->ptr->nick, nick))
	{
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		ent--;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcmp(p->ptr->nick, nick))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
				ent--;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}
*/
/*
CHANUSER *ptrlist::Find(char *name)
{
	PTRLIST *p = first;

	while(1)
	{
		if(!p) break;
		if(!strcasecmp(name, p->ptr->nick)) return p->ptr;
		p = p->next;
	}
	return NULL;
}
*/

PTRLIST *ptrlist::GetItem(int num)
{
	PTRLIST *p;
	int i;

	if(num + 1 > ent) return NULL;
	p = first;
	i = 0;

	while(1)
	{
		if(i == num) return p;
		p = p->next;
		i++;
	}
}

int ptrlist::Find(CHANUSER *ptr)
{
	PTRLIST *p = first;
	int i=0;

	while(p)
	{
		if(ptr == p->ptr) return i;
		i++;
		p = p->next;
	}
	return -1;
}

int ptrlist::Remove(CHANUSER *ptr)
{
	PTRLIST *p = first;

	if(!ent) return 0;
	if(first->ptr == ptr)
	{
		first = first->next;
		if(first) first->prev = NULL;
		free(p);
		--ent;
		return 1;
	}
	else
	{
		while(p)
		{
			if(p->ptr == ptr)
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				free(p);
				--ent;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

void ptrlist::SortAdd(CHANUSER *ptr)
{
	PTRLIST *p, *q;

	if(!ptr) return;
	if(ptr->nick == NULL) return;
	
	if(!ent)
	{
		first = new(PTRLIST);
		first->next = first->prev = NULL;
		first->ptr = ptr;
		++ent;
		return;
	}
	else
	{	if(strcmp(ptr->nick, first->ptr->nick) < 0)
  		{
			q = new(PTRLIST);
			q->ptr = ptr;
			first->prev = q;
			q->prev = NULL;
			q->next = first;
			first = q;
			++ent;
			return;
		}
		else
		{
			p = first;
			while(1)
			{
				if(!strcmp(ptr->nick, p->ptr->nick)) return;
				if(strcmp(ptr->nick, p->ptr->nick) < 0)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = p;
					q->prev = p->prev;
					p->prev->next = q;
					p->prev = q;
					++ent;
					return;
				}
				else if(p->next == NULL)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = NULL;
					q->prev = p;
					p->next = q;
					++ent;
					return;
				}
				p = p->next;
				//++i;
			}
		}
	}
}

void ptrlist::Display()
{
	PTRLIST *p = first;

	while(1)
	{
		if(p == NULL) break;
		printf("[%d]: %s!%s@%s \n", p->ptr->flags, p->ptr->nick, p->ptr->ident, p->ptr->host);
		p = p->next;
	}
}

/* Constructor */
ptrlist::ptrlist()
{
	first = NULL;
	ent = 0;
}

/* Destruction derby */
ptrlist::~ptrlist()
{
	PTRLIST *p = first;
	PTRLIST *q;

	while(p)
	{
		q = p;
		p = p->next;
		free(q);
	}
}

void ptrlist::reset()
{
	this->~ptrlist();

	first = NULL;
	ent = 0;
}
