/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void chan::gotMode(char *modes, char *args, char *mask)
{
	char mode[2][MODES_PER_LINE];
	char *arg[MODES_PER_LINE];
	char *a, *b, *nick = NULL;
	char sign = '+';
	CHANUSER *NickHandle = NULL, *ArgHandle, ServerHandle;
	CHANUSER **MultHandle = NULL;
	PTRLIST<CHANUSER> *p;
	int i, j, just_opped, oped, mypos, n[6], hash, ops, forceKick = 0;

	oped = just_opped = 0;
	mypos = -1;

	/* user */
	a = strchr(mask, '!');
	if(a)
	{
		mem_strncpy(nick, mask, abs(a - mask) + 1);
		NickHandle = getUser(nick);
	}
	if(!NickHandle || !a)
	{
		memset(&ServerHandle, 0, sizeof(CHANUSER));
		NickHandle = &ServerHandle;
		mem_strcpy(nick, "");
	}

	/* mode striper */

 	memset(mode, 0, sizeof(mode));
	memset(arg, 0, sizeof(arg));

	for(i=j=0,ops=0; i<MODES_PER_LINE && (unsigned int) j < strlen(modes); i++, j++)
	{
		if(modes[j] == '+' || modes[j] == '-')
  		{
			sign = modes[j];
   			j++;
		}
		mode[0][i] = sign;
		mode[1][i] = modes[j];
		if(sign == '+' && mode[1][i] == 'o') ops++;
	}

	/* arg striper */
	for(i=0; i<MODES_PER_LINE; i++)
	{
		if(strchr(ARG_MODES, mode[1][i]) && !(mode[0][i] == '-' && mode[1][i] == 'l'))
		{
			a = strchr(args, ' ');
			if(a) mem_strncpy(arg[i], args, abs(args - a)+1);
			else
			{
				if(strlen(args)) mem_strcpy(arg[i], args);
				break;
			}
			args = a+1;
		}
	}

	/* reaction on modes */
	for(i=0; i<MODES_PER_LINE; i++)
	{
		if(mode[0][i] == '+')
		{
   			if(mode[1][i] == 'o')
			{
				ArgHandle = getUser(arg[i]);
				if(ArgHandle->flags & HAS_B)
				{
					botsToOp.remove(ArgHandle);
					opedBots.sortAdd(ArgHandle);
					oped++;
					toReOp.remove(ArgHandle);
					initialOp = NOW;
				}

				if(ArgHandle->flags & HAS_O) toOp.remove(ArgHandle);
				set(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);

				if((!(NickHandle->flags & HAS_M) || (ops > 1 && !(NickHandle->flags & HAS_N)))
				 && ((NickHandle == &ServerHandle) ?
				 	(chset->STOP_NETHACK ? (chset->WASOPTEST ? !wasop->remove(ArgHandle) : 0) : 0) : chset->BITCH))
				{
					if(!(ArgHandle->flags & HAS_O) && !(ArgHandle->flags & HAS_F))
					{
						toKick.sortAdd(ArgHandle);
						if(!(NickHandle->flags & HAS_F)) toKick.sortAdd(NickHandle);
					}
				}
				if(ArgHandle->flags & HAS_D) toKick.sortAdd(ArgHandle);
				if(ptr == ArgHandle)
				{
					if(chset->TAKEOVER || since + set.ASK_FOR_OP_DELAY <= NOW ||
							opedBots.ent < 5 || toKick.ent > 4)
								mypos = oped - 1;
				}

				mode[0][i] = 0;
				continue;
   			}
			if(mode[1][i] == 'b')
			{
				if(gotBan(arg[i], NickHandle)) mode[0][i] = '-';
				else mode[0][i] = 0;
				list[BAN].add(arg[i], NickHandle->nick, set.BIE_MODE_BOUNCE_TIME);
				continue;
			}
			if(mode[1][i] == 'k')
			{
				updateKey(arg[i]);
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					mode[0][i] = '-';
					forceKick = 1;
				}
				else mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'l')
			{
				j = limit;
				limit = strtol(arg[i], NULL, 10);
				if(errno == ERANGE || limit == j)
				{
					mode[0][i] = 0;
					continue;
				}
				//+n, +b or irc server has changed the limit
				if((NickHandle->flags & (HAS_N + HAS_B)) || NickHandle == &ServerHandle)
				{
					//are we in control of the limit?
					if(chset->LIMIT)
					{
						//bot has changd the limit
						if(NickHandle->flags & HAS_B)
						{
							if(limit == -1) nextlimit = -1;
							else if(NickHandle == ptr) nextlimit = NOW + chset->LIMIT_TIME * chset->LIMIT_BOTS;
							else nextlimit = NOW + chset->LIMIT_TIME;
						}
						//owner has changed the limit
						else if(NickHandle->flags & HAS_N)
						{
							if(limit == -1) nextlimit = -1;
							else nextlimit = NOW + chset->OWNER_LIMIT_TIME;

							//enforce this limit
							enforceLimits();
						}
						//server has changed the limit
						else if(NickHandle == &ServerHandle)
							nextlimit = NOW + chset->OWNER_LIMIT_TIME;
					}
					mode[0][i] = 0;
				}
				//lame has changed the limit
				else
				{
					free(arg[i]);
					if(j)
					{
						arg[i] = (char *) malloc(32);
						sprintf(arg[i], "%d", j);
						mode[0][i] = '+';
					}
					else
					{
						mode[0][i] = '-';
						arg[i] = NULL;
					}
					forceKick = 1;
				}
				continue;
			}
			if(mode[1][i] == 'I' || mode[1][i] == 'e')
			{
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					mode[0][i] = '-';
					forceKick = 1;
				}
				else mode[0][i] = 0;
				list[mode[1][i] == 'I' ? INVITE : EXEMPT].add(arg[i], NickHandle->nick, set.BIE_MODE_BOUNCE_TIME);
				continue;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				char buf[2];
				buf[0] = mode[1][i];
				buf[1] = 0;
				addFlags(buf);
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					mode[0][i] = '-';
					forceKick = 1;
				}
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}

		if(mode[0][i] == '-')
		{
			if(mode[1][i] == 'o')
			{
				ArgHandle = getUser(arg[i]);
				toKick.remove(ArgHandle);
				unset(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);
				if(ArgHandle->flags & HAS_B)
				{
					opedBots.remove(ArgHandle);
					if(oped > 0) --oped;
					toReOp.sortAdd(ArgHandle);
				}

				if(ArgHandle->flags & HAS_F)
				{
					if(!(NickHandle->flags & HAS_F)) toKick.sortAdd(NickHandle);
					if(ArgHandle->flags & HAS_A && ArgHandle->flags & HAS_O)
					{
						if(ArgHandle->flags & HAS_B) botsToOp.sortAdd(ArgHandle);
						//else ToOp.SortAdd(ArgHandle);
					}
				}
				if(ptr == ArgHandle)
				{
					mypos = -1;
					p = toKick.first;
					while(p)
					{
						unset(p->ptr->flags, KICK_SENT);
						p = p->next;
					}
					if(opedBots.ent) initialOp = NOW;
					else initialOp = 0;
				}
				mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'k')
			{
				updateKey(arg[i]);
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					mode[0][i] = '+';
					forceKick = 1;
				}
				else mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'l')
			{
				j = limit;
				limit = 0;
				if(j == limit)
				{
					mode[0][i] = 0;
					continue;
				}
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					arg[i] = (char *) malloc(16);
					sprintf(arg[i], "%d", j);
					mode[0][i] = '+';
					forceKick = 1;
					continue;
				}
				else
				{
					mode[0][i] = 0;
					if(chset->LIMIT && NickHandle->flags & HAS_N) nextlimit = NOW + chset->OWNER_LIMIT_TIME;
				}
				continue;
			}
			switch(mode[1][i])
			{
				case 'b': list[BAN].remove(arg[i]); mode[0][i] = 0; break;
				case 'e': list[EXEMPT].remove(arg[i]); mode[0][i] = 0; break;
				case 'I': list[INVITE].remove(arg[i]); mode[0][i] = 0; break;
				default: break;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				char buf[2];
				buf[0] = mode[1][i];
				buf[1] = 0;
				removeFlags(buf);
				if(!(NickHandle->flags & (HAS_N + HAS_B)))
				{
					mode[0][i] = '+';
					forceKick = 1;
				}
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}
	}

	/* channel modes protection */
	if(myTurn(chset->CHMODE_PROT_BOTS, hash32(NickHandle->nick)))
	{
		mem_strcpy(a, "");
		mem_strcpy(b, "");

		for(j=i=0; i<MODES_PER_LINE; ++i)
		{
			if(mode[0][i])
			{
				a = (char *) realloc(a, strlen(a) + 3);
				j = strlen(a);
				a[j+2] = '\0';
				a[j+1] = mode[1][i];
				a[j] = mode[0][i];
				if(arg[i]) b = push(b, arg[i], " ", NULL);
				++j;
			}
		}
		if(j)
		{
			if(forceKick) kick(NickHandle, config.kickreason);

			/* TODO: QUEUE */
			net.irc.send("MODE ", name, " ", a, " ", b, NULL);
		}
		free(a);
		free(b);
	}

	//reop deoped bots
	if(!oped && toReOp.ent)
	{
		MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * 3);
		PTRLIST<CHANUSER> *p = toReOp.first;

		for(i=0; i<3 && p; ++i)
		{
			MultHandle[i] = p->ptr;
			toReOp.remove(p->ptr);
			p = p->next;
		}
		if(myTurn(chset->BOT_AOP_BOTS, hash32(NickHandle->nick)))
			op(MultHandle, i);
	}

	//defense op code
	if(toKick.ent < 4 && ptr->flags & IS_OP)
	{
		if(mypos == 0 && botsToOp.ent)
		{
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * 3);
			j = getRandomItems(MultHandle, botsToOp.first, botsToOp.ent, 3);
			op(MultHandle, j);
			free(MultHandle);
		}
	}
	//takeover op
	else if(mypos != -1 && ptr->flags & IS_OP)
	{
		divide((int *) &n, botsToOp.ent, oped, set.OPS_PER_MODE);
		if(n[mypos])
		{
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * set.OPS_PER_MODE);
			if(mypos == 0) j = getRandomItems(MultHandle, botsToOp.first, n[mypos], set.OPS_PER_MODE);
			else if(mypos == 1)	j = getRandomItems(MultHandle, botsToOp.getItem(n[mypos-1]), n[mypos], set.OPS_PER_MODE);
			else j = getRandomItems(MultHandle, botsToOp.getItem(n[mypos-1] + n[mypos-2]), n[mypos], set.OPS_PER_MODE);
			op(MultHandle, j);
			free(MultHandle);
		}
	}

	//big kick
	if(toKick.ent > 6 && ptr->flags & IS_OP)
	{
		MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * 6);
		j = getRandomItems(MultHandle, toKick.first, toKick.ent, 6);

		kick6(MultHandle, j);
		free(MultHandle);
	}

	//kick for sth bad
	else if(toKick.ent && ptr->flags & IS_OP)
	{
		MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * 6);
		PTRLIST<CHANUSER> *p = toKick.first;

		i = hash = 0;
		while(p)
		{
			MultHandle[i] = p->ptr;
			hash += hash32(p->ptr->nick);
			p = p->next;
			if(++i == 6) break;
		}

		if(myTurn(chset->PUNISH_BOTS, hash))
			kick6(MultHandle, i);
		free(MultHandle);
	}

	free(nick);
	for(i=0; i<MODES_PER_LINE; i++) if(arg[i]) free(arg[i]);
}
