/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

char __itoa[16];

int isValidIp(char *str)
{
	struct sockaddr_in sin;
#ifdef HAVE_IPV6
	struct sockaddr_in6 sin6;

	if(inet_pton(AF_INET6, str, (void *) &sin6.sin6_addr) > 0)
		return 6;
#endif
	if(inet_pton(AF_INET, str, (void *) &sin.sin_addr) > 0)
		return 4;

	return 0;
}

void mem_strncpy(char *&dest, char *src, int n)
{
	dest = (char *) malloc(n + 1);
	strncpy(dest, src, n);
	dest[n-1] = '\0';
}

void mem_strcpy(char *&dest, char *src)
{
	dest = (char *) malloc(strlen(src) + 1);
	strcpy(dest, src);
}

void mem_strcat(char *&dest, char *src)
{
	dest = (char *) realloc(dest, strlen(src) + strlen(dest) + 1);
	strcat(dest, src);
}

int isNullString(char *str, int len)
{
	int i;

	for(i=0; i<len; ++i)
		if(*str++) return 0;
	return 1;
}

int imUp(int argc, char *arg[])
{
	char *p, buf[MAX_LEN], tmp[MAX_LEN], pid[MAX_LEN];
	int i, n, fd;

	for(p=buf, i=0; i<argc; ++i, ++p)
	{
		memcpy(p, arg[i], n = strlen(arg[1]) +1);
		p += n;
		*p = 0;
	}
	--p;

	//read pid
	snprintf(pid, MAX_LEN, "pid.%s", config.nick);
	if((fd = open(pid, O_RDONLY)) < 1) return 0;
	memset(pid, 0, MAX_LEN);
	read(fd, pid, MAX_LEN);
	close(fd);

	//read /proc/$pid/cmdline
	snprintf(tmp, MAX_LEN, "/proc/%d/cmdline", atoi(pid));
	if((fd = open(tmp, O_RDONLY)) < 1) return 0;
	memset(tmp, 0, MAX_LEN);
	n = read(fd, tmp, MAX_LEN);
	close(fd);

	//size match ?
	if(n != abs(buf - p)) return 0;

	//data match ?
	return !memcmp(buf, tmp, n);
}

void lurk()
{
	pid_t pid = fork();
	if(pid == -1)
	{
		printf("[-] Fork faild: %s\n", strerror(errno));
	}
	else if(!pid) return;
	else
	{
		printf("[+] Going into background [pid: %d]\n", pid);
		inetconn p;
		char buf[MAX_LEN];
		snprintf(buf, MAX_LEN, "pid.%s", config.nick);
		p.open(buf, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
		p.send(itoa(pid), NULL);
		exit(0);
	}
}

void parse_cmdline(int argc, char *argv[])
{
	int i;

	if(argc == 1)
	{
		#ifdef HAVE_DEBUG
		printf("Syntax: %s [-v] [-d] [-p] [-c decypted config] [cryped config]\n", argv[0]);
		#else
		printf("Syntax: %s [-v] [-p] [-c decypted config] [cryped config]\n", argv[0]);
		#endif

		exit(1);
	}

	if(!strcmp(argv[1], "-v")) exit(0);

	for(i=1; i<argc; ++i)
	{
		if(!strcmp(argv[i], "-p"))
		{
			char buf[MAX_LEN], hash[33];
			printf("Bot is now running in MD5 hash generator mode\n");

			while(1)
			{
				printf("string to hash: ");
				scanf("%s", buf);
				MD5HexHash(hash, buf, strlen(buf), NULL, 0);
				printf("MD5 hash      : %s\n", hash);
			}
		}
		#ifdef HAVE_DEBUG
		else if(!strcmp(argv[i], "-d")) set.debug = 1;
		#endif

		else if(!strcmp(argv[i], "-v")) exit(0);
		else if(!strcmp(argv[i], "-c")) set.creation = 1;
		else if(i == argc - 1) loadConfig(argv[i]);
		else
		{
			printf("Unknown option `%s`\n", argv[i]);
			exit(1);
		}
	}
}

char *memmem(void *vsp, size_t len1, void *vpp, size_t len2)
{
	char *sp = (char *) vsp, *pp = (char *) vpp;
	char *eos   = sp + len1 - len2;

	if(!(sp && pp && len1 && len2))	return NULL;

	while (sp <= eos)
	{
		if (*sp == *pp)
		if (memcmp(sp, pp, len2) == 0) return sp;
		sp++;
	}
    return NULL;
}

long int nanotime()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_usec;
}

char *srewind(char *str, int word)
{
	int i;

	if(!str) return NULL;

	while(isspace(*str))
	{
		if(*str == '\0') return NULL;
		++str;
	}
	for(i=0; i<word; ++i)
	{
		while(!isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
		while(isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
	}
	return str;
}

void str2words(char *word, char *str, int x, int y, int ircstrip)
{
	int i, j, strip = 1;

	for(i=0; i<x; ++i)
	{
		while(isspace(*str))
		{
			if(*str == '\0') break;
			++str;
		}
		if(*str == '\0') break;


		for(j=0; j<y-1 && !isspace(*str); ++str)
		{
			if(*str == '\0') break;
			if(ircstrip && !j && *str == ':' && strip) ;
			else
			{
				*word = *str;
				++word;
				++j;
			}
		}
		memset(word, 0, y - j - 1);
		//if(i == 1) printf("lastword: %s\n", word-j);

		if(ircstrip && i == 1 && (!strcmp(word-j, "MODE") || !strcmp(word-j, "JOIN")))
		{
			strip = 0;
			//printf("--- not strpinig---");
		}
		word += y - j;
		if(*str == '\0') break;
	}

	for(++i; i<x; ++i)
	{
		memset(word, 0, y - 1);
		word += y;
	}

}

void sendLogo(inetconn *c)
{
	char *timestr;
	struct utsname name;

	timestr = ctime(&NOW);
	timestr[strlen(timestr) - 1] = '\0';

	uname(&name);

	c->send("", NULL);
	c->send("\002    _/_/_/   _/_/_/   _/_/_/  _/_/_/_/ _/      _/  _/   _/_/_/\002", NULL);
	c->send("\002   _/   _/ _/       _/    _/    _/    _/_/    _/  _/  _/\002", NULL);
	c->send("\002  _/_/_/   _/_/_/  _/    _/    _/    _/  _/  _/  _/  _/\002", NULL);
	c->send("\002 _/            _/ _/    _/    _/    _/    _/_/  _/  _/\002", NULL);
	c->send("\002_/       _/_/_/   _/_/_/     _/    _/      _/  _/   _/_/_/\002", NULL);
	c->send("", NULL);
	c->send("   Copyright (c) 2003-2004 Grzegorz Rusin <pks@irc.pl>", NULL);
	c->send("", NULL);
	c->send("Psotnic version: \002", S_VERSION , "\002", NULL);
	c->send("Local time: \002", timestr, "\002", NULL);
	c->send("Machine info: \002", name.sysname, " ", name.release, " ", name.machine, "\002", NULL);
	c->send("Owners on-line: \002", itoa(net.owners()), "\002 (type .owners to see list)", NULL);
	c->send("Bots on-line: \002", itoa(net.bots()), "\002 (type .upbots to see list)", NULL);
	c->send("", NULL);

	net.send(OWNERS, "[*] ", c->name, " has joined the partyline", NULL);
}

#ifdef HAVE_IPV6
int doConnect6(char *server, int port, char *vhost, int options)
{
    struct sockaddr_in6 sin6;
	int s;

	s = socket(AF_INET6, SOCK_STREAM, 0);
	if(!s) return -1;

	memset(&sin6, 0, sizeof(sin6));
	sin6.sin6_family = AF_INET6;
	if(strlen(vhost)) inet_pton(AF_INET6, vhost, (void *) &sin6.sin6_addr);
	else sin6.sin6_addr = in6addr_any;

	if(bind (s, (struct sockaddr *) &sin6, sizeof (sin6)) == -1)
	{
		killSocket(s);
		return -1;
	}

	memset(&sin6, 0, sizeof (struct sockaddr_in6));
	sin6.sin6_family = AF_INET6;
	sin6.sin6_port = htons(port);
	inet_pton(AF_INET6, server, (void *) &sin6.sin6_addr);

	if(connect(s, (struct sockaddr *) &sin6, sizeof(sin6)) == -1)
	{
		killSocket(s);
		return -1;
	}

	if(options > 0) if(fcntl(s, F_SETFL, options) == -1)
	{
		killSocket(s);
		return -1;
	}
	return s;
}
#endif

void propaganda()
{
	printf("\n");
#ifdef HAVE_IPV6
	printf("Psotnic C++ edition, version %s-ipv6 (%s %s)", S_VERSION,__DATE__, __TIME__);
#else
	printf("Psotnic C++ edition, version %s (%s %s)", S_VERSION,__DATE__, __TIME__);
#endif
	printf("\n");
	printf(S_COPYRIGHT);
	printf("\n\n");
}

int extendhost(char *host, char *buf, unsigned int len)
{
    char *ex, *at;

    if(strlen(host) + 10 > len) return 0;

    ex = strchr(host, '!');
    at = strchr(host, '@');

    if(ex != strrchr(host, '!') || at != strrchr(host, '@')) return 0;

    if(at)
    {
        if(!ex)
        {
            if(at == host) strcpy(buf, "*!*");
            else strcpy(buf, "*!");
            strcat(buf, host);
        }
        else if(ex == host)
        {
            strcpy(buf, "*");
            strcat(buf, host);
        }
        else strcpy(buf, host);
        if(*(at + 1) == '\0') strcat(buf, "*");
        return 1;
    }
    else
    {
        if(ex) return 0;
        if(strchr(host, '.') || strchr(host, ':'))
        {
            strcpy(buf, "*!*@");
            strcat(buf, host);
            return 1;
        }
        strcpy(buf, "*!");
        strcat(buf, host);
        strcat(buf, "@*");
        return 1;
    }
}

int magicNickCreator(char *nick)
{
	int nicklen, applen;
	char *n;

	srand();
	nicklen = strlen(nick);
	applen = strlen(config.nickappend);

	if(nicklen >= 9 && (!strchr(config.nickappend, nick[8]) || nick[8] == config.nickappend[applen-1]))
		return 0;

	n = strchr(config.nickappend, nick[nicklen-1]);

	if(n)
	{
		if(nick[nicklen-1] == config.nickappend[rand() % applen]) nick[nicklen] = config.nickappend[0];
		else nick[nicklen-1] = config.nickappend[abs(n - config.nickappend) + 1];
	}
	else nick[nicklen] = config.nickappend[0];

	return 1;
}

char *inet2char(unsigned int inetip)
{
	struct sockaddr_in sin;
	sin.sin_addr.s_addr = inetip;
	return inet_ntoa(sin.sin_addr);
}

int acceptConnection(int fd)
{
	int n, silent;
	struct sockaddr_in from;
	socklen_t fromsize = sizeof(struct sockaddr_in);
	const int one = 1;
	inetconn *c;

	if((n = accept(fd, (sockaddr *) &from, &fromsize)) > 0)
	{
		if(ignore.underSynFlood || !(silent = ignore.hit(from.sin_addr.s_addr)))
		{
			killSocket(n);
			return -1;
		}

		silent = (silent == -1 ? 1 : 0);

		if(userlist.isSlave(userlist.first->next) || userlist.isMain(userlist.first->next))
        {
        	if(userlist.isBot(from.sin_addr.s_addr) || set.TELNET_OWNERS)
			{
				fcntl(n, F_SETOWN);
				fcntl(n, F_SETFL, O_NONBLOCK);
				setsockopt(n, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));
				c = net.addConn(n);
				c->tmpint = 1;
				c->killTime = NOW + set.AUTH_TIME;
				c->status = STATUS_CONNECTED + STATUS_BOT + STATUS_TELNET + (silent ? STATUS_SILENT : 0);

				if(!silent) net.send(OWNERS, "[+] Accepting�connection from:�", inet2char(from.sin_addr.s_addr), " / ", itoa(from.sin_port), NULL);
				logfile.send("[+] Accepting�connection from:�", inet2char(from.sin_addr.s_addr), " / ", itoa(from.sin_port), NULL);
				return n;
			}
			else
			{
                if(!silent) net.send(OWNERS, "[!] Rejecting�connection from:�", inet2char(from.sin_addr.s_addr), " / ", itoa(from.sin_port), NULL);
                logfile.send("[!] Rejecting�connection from:�", inet2char(from.sin_addr.s_addr), " / ", itoa(from.sin_port), NULL);
				killSocket(n);
				return -1;
			}
		}
		else
		{
			logfile.send("[!] I am not SLAVE nor MAIN, disconnecting\n", NULL);
			killSocket(n);
			return -1;
		}
	}
	else
	{
		killSocket(n);
		logfile.send("[-] Connection lost: ", strerror(errno), NULL);
		return -1;
	}
}

char *getpeerip(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int ret, e = errno;
	#endif
	socklen_t peersize = sizeof(struct sockaddr_in);
	ret = getpeername(fd, (sockaddr *) &peer, &peersize);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	if(ret == -1) return NULL;
	else return inet_ntoa(peer.sin_addr);
}

int getpeerport(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int ret, e = errno;
	#endif
	socklen_t peersize = sizeof(struct sockaddr_in);
	ret = getpeername(fd, (sockaddr *) &peer, &peersize);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	if(ret == -1) return 0;
	else return ntohs(peer.sin_port);
}

int startListening(char *ip, int port)
{
    struct sockaddr_in sin;
    int s;
    const int one = 1;

	printf("[*] Opening listening socket at %s:%d\n", ip, port);
    if((s = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		killSocket(s);
		return -1;
	}

    if(setsockopt(s , SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0)
	{
		killSocket(s);
		return -1;
	}

    memset (&sin, 0, sizeof (struct sockaddr_in));
	sin.sin_family = AF_INET;
    if(strlen(ip)) sin.sin_addr.s_addr = inet_addr(ip);
    else sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    if(bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1)
	{
		killSocket(s);
		return -1;
	}

    if(listen(s, SOMAXCONN) == -1)
	{
		killSocket(s);
		return -1;
	}

	/*
	// source of errors on freebsd
	if(strcmp(ip, inet2char(sin.sin_addr.s_addr)) || ntohs(sin.sin_port) != port)
	{
		sclose(s);
		printf("[-] Invalid ip address or port\n");
		return -1;
	}
	*/
	printf("[+] Socket awaits incomming connections\n");

    return s;
}

void precache()
{
    int i;

	srand();
	for(i=0; i<MAX_SERVERS; ++i) memset(&config.server[i], 0, sizeof(config.server[i]));
	memset(&config, 0, sizeof(config));
	validate();
}

void precache_expand()
{
	memset(&expandinfo, 0, sizeof(EXPANDINFO));

	struct utsname name;
	uname(&name);

	mem_strcpy(expandinfo.system, name.sysname);
	mem_strcpy(expandinfo.release, name.release);
	mem_strcpy(expandinfo.arch, name.machine);

	char buf[MAX_LEN];
	switch(config.ctcptype)
	{
		case VER_PSOTNIC: mem_strcpy(expandinfo.version, S_VERSION); break;
		case VER_IRSSI: mem_strcpy(expandinfo.version, fetchVersion(buf, VER_IRSSI)); break;
		case VER_EPIC:
		case VER_LICE: mem_strcpy(expandinfo.version, fetchVersion(buf, VER_EPIC)); break;
		case VER_BITCHX: mem_strcpy(expandinfo.version, fetchVersion(buf, VER_BITCHX)); break;
		default: mem_strcpy(expandinfo.version, ""); break;
	}

	//struct passwd *p = getpwuid(getuid());
	mem_strcpy(expandinfo.realname, "");

}


void divide(int *ret, int value, int parts, int part_size)
{
	if(parts == 1)
	{
		ret[0] = value;
		ret[1] = ret[2] = 0;
		return;
	}

	if(value > part_size*2)
    {
        ret[0] = value / parts;
        ret[1] = (value - ret[0]) / (parts-1);
        if(parts == 3) ret[2] = value - ret[0] - ret[1];
        else ret[2] = 0;
    }
    else if(value > part_size)
    {
        ret[0] = part_size;
        ret[1] = value - ret[0];
        ret[2] = 0;
    }
    else
    {
        ret[0] = value;
        ret[1] = ret[2] = 0;
    }
}

void killSocket(int fd)
{
	#ifdef _NO_LAME_ERRNO
	int e = errno;
	#endif
	shutdown(fd, SHUT_RDWR);
	close(fd);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
}

int doConnect(char *server, int port, char *vhost, int noblock)
{
    struct sockaddr_in sin;
    int s;

	s = socket(AF_INET, SOCK_STREAM, 0);
    if(!s) return -1;

	memset (&sin, 0, sizeof (sin));
	sin.sin_family = AF_INET;
    if(strlen(vhost)) sin.sin_addr.s_addr = inet_addr(vhost);
	else sin.sin_addr.s_addr = INADDR_ANY;
    if(bind (s, (struct sockaddr *) &sin, sizeof (sin)) == -1)
	{
		killSocket(s);
		return -1;
	}

    memset (&sin, 0, sizeof (sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);

	if(noblock == -1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		killSocket(s);
		return -1;
	}
    if(connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1)
	{
		if(noblock == -1 && errno == EINPROGRESS) return s;
		killSocket(s);
		return -1;
	}
	if(noblock == 1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		killSocket(s);
		return -1;
	}
	return s;
}

unsigned int hash32(char *word)
{
	if(!word) return 0;
    char c;
    unsigned bit_hi = 0;
    int bit_low = 0;
    int len = strlen(word);

    if(len > 64) len = 63;

	/* i barrowed this code from epic ;-) */
    for(; *word && len; ++word, --len)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
    return ((bit_hi & 8191) << 3) + (bit_low & 0x7);
}

int va_getlen(va_list ap, char *lst)
{
	int size = strlen(lst);
	char *p;

	while((p = va_arg(ap, char *)))
		size += strlen(p);

	return size;
}

char *push(char *ptr, char *lst, ...)
{
	va_list ap;

	va_start(ap, lst);
    ptr = va_push(ptr, ap, lst, va_getlen(ap, lst) + 1);
	va_end(ap);

    return ptr;
}

char *va_push(char *ptr, va_list ap, char *lst, int size)
{
	char *p;

	if(ptr)
	{
        size += strlen(ptr);
        ptr = (char *) realloc(ptr, size*sizeof(char));
        strcat(ptr, lst);
    }
    else
    {
        ptr = (char *) malloc(size*sizeof(char));
        strcpy(ptr, lst);
    }

    /* strcat rest */
	while((p = va_arg(ap, char *)))
	{
		strcat(ptr, p);
	}
	return ptr;
}


char *itoa(int value)
{
	sprintf(__itoa, "%d", value);
	return __itoa;
}

int userLevel(CHANUSER *u)
{
	if(u->flags & HAS_N || u->flags & HAS_B) return 3;
	if(u->flags & HAS_M) return 2;
	if(u->flags & HAS_O) return 1;
	return 0;
}

char *expand(char *str, char *buf, int len, char *args)
{
	int i, j;

    memset(buf, 0, len--);

    for(i=j=0; ; ++i, ++str)
    {
        if(*str == '\0') break;
        if(*str == '%')
        {
            ++str;
            if(*str == '\0') break;
            switch(*str)
            {
                case 'V': strncat(buf, expandinfo.version, len - j); j += strlen(expandinfo.version); break;
                case 'O': strncat(buf, expandinfo.system, len - j); j += strlen(expandinfo.system); break;
				case 'R': strncat(buf, expandinfo.release, len - j); j += strlen(expandinfo.release); break;
                case 'A': strncat(buf, expandinfo.arch, len - j); j += strlen(expandinfo.arch); break;
				case 'N': strncat(buf, ME.nick, len - j); j += strlen(ME.nick); break;
				case 'I': strncat(buf, ME.ident, len - j); j += strlen(ME.ident); break;
				case 'H': strncat(buf, ME.host, len - j); j += strlen(ME.host); break;
				case '*': strncat(buf, args, len - j); j += strlen(args); break;
				case 'F': strncat(buf, expandinfo.realname, len - j); j += strlen(expandinfo.realname); break;
				case 'T':
				{
					char *t = ctime(&NOW);
                    t[strlen(t) - 1] = '\0';
					strncat(buf, t, len - j); j += strlen(t);
					break;
				}
				case 'l':
				{
					int t = antiidle.getIdle();
					strncat(buf, itoa(t), len - j); j += strlen(itoa(t));
					break;
				}
				default: break;
            }
        }
        else
        {
            if(j++ < len - 1) strncat(buf, str, 1);
            else return buf;
        }
    }
    return buf;
}

char *getFileName(char *path)
{
	char *last = path;

	while(*path)
	{
		if(*path == '/') last = path + 1;
		++path;
	}
	return last;
}

int sign(int n)
{
	if(!n) return 0;
	if(n > 0) return 1;
	return -1;
}

char *int2units(char *buf, int len, int val, unit_table *ut)
{
    char tmp[32];
    int i, k, v = val;

	if(!ut)
	{
		plain:
		strncpy(buf, itoa(val), MAX_LEN);
		return buf;
	}
	else if(!val)
	{
		for(i=0; ut[i].unit; ++i) ;
		strncpy(buf, itoa(val), MAX_LEN);
		tmp[0] = ut[i-1].unit;
		tmp[1] = '\0';
		strcat(buf, tmp);
		return buf;
	}

	buf[0] = '\0';

	for(i=0; ut[i].unit; i++)
    {
        if(sign(val) == sign(ut[i].ratio) && (k = v/ut[i].ratio))
        {
            strcpy(tmp, itoa(k));
            len -= strlen(tmp) + 3;
			if(len <= 0) return NULL;
			v -= k * ut[i].ratio;
            strcat(buf, tmp);
			tmp[0] = ut[i].unit;
			if(v)
			{
				tmp[1] = ' ';
				tmp[2] = '\0';
			}
			else tmp[1] = '\0';
			strcat(buf, tmp);
		}
    }
	if(!strlen(buf)) goto plain;
	return buf;
}

int units2str(char *str, unit_table *ut, int &out)
{
	char dig[5], *s = str;
	int i, r=0, d, val = 0, ok = 0;

	if(!ut)
	{
		out = atoi(str);
		return 1;
	}
	while(1)
	{
		start:
		//rewind spaces
		for(i=0; ;++i)
		{
			if(!*s)
			{
				if(ok)
				{
					out = val;
					return 1;
				}
				else return -1;
			}
			if(isspace(*s)) ++s;
			else break;
		}

		memset(dig, 0, 5);
		//read digits, max 4 of them
		for(d=0; d<4; ++d)
		{
			if(isdigit(*s)) dig[d] = *s++;
			else if(!d) return -5;
		}

		//too long number
		if((d == 3 && isdigit(*s))) return -2;

		dig[d+1] = '\0';

		//look for ratio
		for(; ut[r].unit; ++r)
		{
			if(ut[r].unit == *s)
			{
				val += atoi(dig) * ut[r].ratio;
				ok = 1;
				++s;
				goto start;
			}
		}
		//no unit found

		//end of str
		if(!*s)
		{
			//we will use last unit
			val +=	atoi(dig) * ut[r-1].ratio;
			out = val;
			return 1;
		}
		//error ;p
		return -3;
	}
}

int count(char *arr[])
{
	int i;
	for(i=0; arr[i]; ++i);
	return i;
}
