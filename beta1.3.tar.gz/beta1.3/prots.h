#define _NO_LAME_ERRNO			1

#define rand hide_this_function
#define srand hide_this_function_too

#include <stdlib.h>
#undef rand
#undef srand

int rand();
void srand(int a=0, int b=0, int c=0);

#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/utsname.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <utime.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <pwd.h>
#include <pthread.h>

#ifdef HAVE_TCL
	#include <tcl.h>
#endif

#include "isaac.h"
#include "numeric_def.h"
#include "match.h"
#include "blowfish.h"
#include "md5.h"
#include "rfc1459.h"
#include "defines.h"
#include "structs.h"
#include "class-ptrlist.cpp"
#include "classes.h"

typedef void (*sighandler_t)(int);
typedef void (*sig_t)(int);

/* parse functions */
void parse_irc(char *data);
void parse_owner(inetconn *c, char *data);
void parse_bot(inetconn *c, char *data);
void parse_hub(char *data);
void parse_ctcp(char *mask, char *data, char *to);
int parse_botnet(inetconn *c, char *data);

/* net functions  */
int doConnect(char *server, int port, char *vhost, int noblock);
#ifdef HAVE_IPV6
int doConnect6(char *server, int port, char *vhost, int options);
#endif
int acceptConnection(int fd);
int startListening(char *ip, int port);
int getpeerport(int fd);
char *getpeerip(int fd);
char *inet2char(unsigned int inetip);
void killSocket(int fd);

/* random stuff */
void divide(int *ret, int value, int parts, int part_size);
int getRandomNumbers(int top, int *ret, int num);
int getRandomItems(CHANUSER **ret, PTRLIST<CHANUSER> *start, int interval, int num);

/* string functions */
int magicNickCreator(char *nick);
int extendhost(char *host, char *buf, unsigned int len);
char *expand(char *str, char *buf, int len, char *args);
unsigned int hash32(char *word);
void str2words(char *word, char *str, int x, int y, int ircstrip=0);
char *srewind(char *str, int word);
char *memmem(void *vsp, size_t len1, void *vpp, size_t len2);
char *push(char *ptr, char *lst, ...);
char *va_push(char *ptr, va_list ap, char *lst, int size);
int va_getlen(va_list ap, char *lst);
int isNullString(char *str, int len);
char *itoa(int val);
char *getFileName(char *path);
int count(char *arr[]);

void mem_strncpy(char *&dest, char *src, int n);
void mem_strcpy(char *&dest, char *src);
void mem_strcat(char *&dest, char *src);

/* rest */
void precache();
void precache_expand();
void signalHandling();
int safeExit();
void propaganda();
void badparameters(char *str);
void loadConfig(char *file);
void sendLogo(inetconn *c);
long int nanotime();
void validate();
void parse_cmdline(int argc, char *argv[]);
void lurk();
int userLevel(CHANUSER *u);
int isValidIp(char *str);
int imUp(int argc, char *arg[]);
int listcmd(char what, char *from, char *arg1=NULL, char *arg2=NULL, inetconn *c=NULL);
char *h_strerror(int error);
char *fetchVersion(char *buf, int client);
char *int2units(char *buf, int len, int val, unit_table *ut);
int units2str(char *str, unit_table *ut, int &out);

