/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

ign::ign()
{
	underSynFlood = ipConnsCount = 0;
	conns = ptrlist<ptrlist <IPDATA> >(1);
	ipIgnores = ptrlist<IPDATA>(1);
}

/*
void ign::destroy(ptrlist<IPDATA> *p)
{
	PTRLIST<IPDATA> *q;

	q = p->first;

	while(q)
	{
		delete q->ptr;
		q = q->next;
	}
}
*/


ign::~ign()
{
	/*
	PTRLIST<ptrlist <IPDATA> > *p = conns.first;

	while(p)
	{
		destroy(p->ptr);
		p = p->next;
	}
	*/
}

void ign::expire(ptrlist<IPDATA> *p, int t)
{
	PTRLIST<IPDATA> *q = p->first;

	while((q = p->first))
	{
		if(q->ptr->when + t <= NOW)
			p->remove(q->ptr);
		else break;
	}
}
void ign::expire()
{
	/* expire connections */
	PTRLIST<ptrlist<IPDATA> > *q, *p = conns.first;
	ipConnsCount = 0;

	while(p)
	{
		q = p->next;
		expire(p->ptr, set.PERIP_BURST_TIME);
		if(!p->ptr->ent) conns.remove(p->ptr);
		else ipConnsCount += p->ptr->ent;
		p = q;
	}

	/* expire ignores */
	expire(&ipIgnores, set.PERIP_IGNORE_TIME);

	/* expire synflood */
	if(underSynFlood && underSynFlood + set.SYNFLOOD_IGNORE_TIME <= NOW) underSynFlood = 0;
}

int ign::hit(unsigned int ip)
{
	expire();

	/* too many unreg conns */
	if(ipConnsCount > set.SYNFLOOD_MAX_CONNS)
	{
		/* set ignore */
		if(!underSynFlood)
		{
			underSynFlood = NOW;
			net.send(OWNERS, "[!] Synflood detected, ignoring *@* for ", itoa(set.SYNFLOOD_IGNORE_TIME), " seconds", NULL);
			logfile.send("[!] Synflood detected, ignoring *@* for ", itoa(set.SYNFLOOD_IGNORE_TIME), " seconds", NULL);
			return 0;
		}
	}

	/* look for given ip in ignore list */
	PTRLIST<IPDATA> *p = ipIgnores.first;

	while(p)
	{
		if(p->ptr->ip == ip) return 0;
		p = p->next;
	}

	/* look for given ip in conn list */
	PTRLIST<ptrlist <IPDATA> > *q = conns.first;

	IPDATA *d = new IPDATA;
	d->ip = ip;
	d->when = NOW;

	while(q)
	{
		if(q->ptr->first->ptr->ip == ip)
		{
			/* add to ip to bucket */
			q->ptr->addLast(d);

			/* add to ignore list */
			if(q->ptr->ent > set.PERIP_BURST_SIZE)
			{
				ipIgnores.addLast(d);
				net.send(OWNERS, "[!] Ignoring ", inet2char(ip), " for ", itoa(set.PERIP_IGNORE_TIME), " seconds", NULL);
				logfile.send("[!] Ignoring ", inet2char(ip), " for ", itoa(set.PERIP_IGNORE_TIME), " seconds", NULL);
				return 0;
			}
			else if(q->ptr->ent > set.PERIP_MAX_SHOWN_CONNS) return -1;
			return 1;
		}
		q = q->next;
	}
	ptrlist<IPDATA> *y = new ptrlist<IPDATA>;
	y->addLast(d);
	conns.add(y);
	return 1;
}
