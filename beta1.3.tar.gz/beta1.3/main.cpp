/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"

time_t NOW;
client ME;
settings set;
ul userlist;
inet net;
CONFIG config;
char *thisfile;
inetconn logfile;
penal penality;
EXPANDINFO expandinfo;
ign ignore;
time_t fifo::lastFlush = NOW;
fifo ctcp(10, 3);
fifo invite(5, 3);
QTIsaac<8, int> Isaac;
idle antiidle;

unit_table ut_time[] = {
	{'w', 7*24*3600 },
	{'d', 24*3600 },
    {'h', 3600 },
    {'m', 60 },
    {'s', 1 },
	{ 0 , 0 }
};

unit_table ut_perc[] = {
	{'%', -1 },
	{ 0 , 0}
};

#ifdef HAVE_TCL
tcl tclparser;
#endif

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd, wfd;
	inetconn *c;
	set.creation = 0;

	thisfile = argv[0];

	srand();
	propaganda();
	precache();
	parse_cmdline(argc, argv);

	if(imUp(argc, argv))
	{
		printf("[-] Signs on the sky tell me that i am already up\n");
		printf("[*] Terminating\n");
		exit(1);
	}

    userlist.addHandle("idiots");
	userlist.addHandle(config.handle, 0, BOT_FLAGS);
	userlist.first->flags[MAX_CHANNELS] = HAS_D;

	logfile.send("[+] Starting bot...", NULL);

	if(config.bottype != BOT_LEAF)
	{
		printf("[*] Loading userlist from '%s'\n", config.userlist_file);
		n = userlist.load(config.userlist_file);

		if(!n)
		{
        	if(config.bottype == BOT_MAIN)
			{
				userlist.first->next->flags[MAX_CHANNELS] |= HAS_H;
				printf("[*] Userlist not found, running in owner creation mode\n");
				set.creation = 1;
			}
			else if(config.bottype == BOT_SLAVE)
				printf("[*] Userlist not found (new slave?)\n");
		}
		else if(n == -1)
		{
			if(config.bottype == BOT_MAIN)
			{
				printf("[-] Userlist is broken, please import it from your backup\n");
				exit(1);
			}
			else if(config.bottype == BOT_SLAVE)
				printf("[*] Userlist is broken, i will fetch it later\n");
		}
		else if(n == 1)
		{
			printf("[+] Userlist loaded (sn: %llu)\n", userlist.SN);
		}
	}
	if(!set.debug && !set.creation) lurk();

    signalHandling();
	precache_expand();

	last = NOW = time(NULL);
	tv.tv_sec = 1;

	antiidle = idle();
	if((rand() % 2) == 0) antiidle.togleStatus();

	/* MAIN LOOP */
	while(1)
	{
		penality.calc();
		net.resize();
		if(tv.tv_sec > 1 || tv.tv_sec <= 0) tv.tv_sec = 1;
		tv.tv_usec = 0;

		/* Add sockets to SETs */
		FD_ZERO(&rfd);
		FD_ZERO(&wfd);
		net.maxFd = 0;

	   	if(net.irc.fd && !net.irc.timedOut())
		{
			if(net.irc.status & STATUS_SYNSENT) FD_SET(net.irc.fd, &wfd);
			FD_SET(net.irc.fd, &rfd);
			net.bidMaxFd(net.irc.fd);
		}
	    if(net.hub.fd && !net.hub.timedOut())
	    {
			if(net.hub.status & STATUS_SYNSENT) FD_SET(net.hub.fd, &wfd);
			FD_SET(net.hub.fd, &rfd);
			net.bidMaxFd(net.hub.fd);
		}

		if(config.listenport)
		{
			FD_SET(net.listenfd, &rfd);
			net.bidMaxFd(net.listenfd);
			for(i=0; i<net.max_conns; ++i)
			{
                if(net.conn[i].fd && !(net.conn[i].status & STATUS_REDIR) && !net.conn[i].timedOut())
				{
                    if(net.conn[i].status & STATUS_SYNSENT) FD_SET(net.conn[i].fd, &wfd);
					FD_SET(net.conn[i].fd, &rfd);
					net.bidMaxFd(net.conn[i].fd);
				}
			}
		}

		for(i=0; i<net.max_conns; ++i)
		{
			if(net.conn[i].write.buf)
			{
				FD_SET(net.conn[i].fd, &wfd);
				net.bidMaxFd(net.conn[i].fd);
			}
		}

		/* SELECT */
		ret = select(net.maxFd+1, &rfd, &wfd, NULL, &tv);

		NOW = time(NULL);
		if(NOW > last + 1)
		{
			last = NOW;
			if(net.irc.status & STATUS_REGISTERED) ME.checkQueue();
			userlist.autoSave();
			ignore.expire();
			if(!penality)
			{
				char *inv = invite.flush();
				if(inv)
				{
					ME.inviteRaw(inv);
					free(inv);
				}
				else
					ctcp.flush(&net.irc);
				antiidle.eval();
			}

#ifdef HAVE_TCL
			tclparser.expireTimers();
#endif
		}
		if(!net.hub.fd && config.havehub && ME.nextconn_hub <= NOW)
		{
			ME.connectToHUB();
			ME.nextconn_hub = NOW + set.HUB_CONN_DELAY;
		}
		if(!net.irc.fd && ME.nextconn_serv <= NOW)
		{
			ME.connectToIRC();
			ME.nextconn_serv = NOW + set.IRC_CONN_DELAY;
		}
		if(net.irc.status & STATUS_REGISTERED && ME.NextNickCheck <= NOW && ME.NextNickCheck)
		{
			if(strcmp(config.nick, ME.nick)) net.irc.send("NICK ", config.nick, NULL);
			ME.NextNickCheck = 0;
		}
		ME.rejoinCheck();

		if(ret < 1) continue;

		/* WRITE BUFFER */
		for(i=0; i<net.max_conns; ++i)
		{
			c = &net.conn[i];
			if(c->write.buf && !(c->status & STATUS_REDIR) && FD_ISSET(c->fd, &wfd))
			{
				write(c->fd, c->write.buf + c->write.pos++, 1);
				if(c->write.pos == c->write.len)
				{
					free(c->write.buf);
					memset(&c->write, 0, sizeof(c->write));
				}
			}
		}

		/* READ from IRC */
		if(FD_ISSET(net.irc.fd, &rfd))
		{
			n = net.irc.readln(buf, MAX_LEN);
			if(n > 0) parse_irc(buf);
			else if(n == -1) net.irc.close("EOF from client");
		}

		/* READ from HUB */
 		if(FD_ISSET(net.hub.fd, &rfd))
		{
			n = net.hub.readln(buf, MAX_LEN);
			if(n > 0 && net.hub.status & STATUS_CONNECTED) parse_hub(buf);
			else if(n == -1) net.hub.close("EOF from client");
		}

		/* ACCEPT connections */
		if(FD_ISSET(net.listenfd, &rfd)) acceptConnection(net.listenfd);

		/* READ from BOTS and OWNERS */
		if(config.listenport)
		{
			for(i=0; i<net.max_conns; i++)
			{
				c = &net.conn[i];
				if(c->fd > 0 && !(c->status & STATUS_REDIR))
				{
					if(c->status & STATUS_CONNECTED && FD_ISSET(c->fd, &rfd))
					{
						n = c->readln(buf, MAX_LEN);
						if(n > 0)
						{
							if(c->status & STATUS_OWNER) parse_owner(c, buf);
							else if(c->status & STATUS_BOT) parse_bot(c, buf);
						}
						else if(n == -1) c->close("EOF from client");
                	}
				}
               	//OWNER SYN/ACT
				if(c->fd && ((c->status & (STATUS_SYNSENT | STATUS_OWNER)) == (STATUS_SYNSENT | STATUS_OWNER)) && FD_ISSET(c->fd, &wfd))
				{
                   	c->status = STATUS_CONNECTED | STATUS_OWNER;
					c->tmpint = 1;
					c->send("Enter owner password: ", NULL);
					if(!(c->status & STATUS_SILENT)) net.send(OWNERS, "[+] Connection to ", c->getIpName(), " port ", c->getPortName(), " established", NULL);
					logfile.send("[+] Connection to ", c->getIpName(), " port ", c->getPortName(), " established", NULL);
				}
			}
		}
		if(net.hub.fd && net.hub.status & STATUS_SYNSENT)
		{
			if(FD_ISSET(net.hub.fd, &wfd))
			{
				logfile.send("[+] Connection to HUB established", NULL);
				net.hub.status = STATUS_CONNECTED;
				net.hub.tmpint = 1;
				net.hub.killTime = NOW + set.AUTH_TIME;
				net.hub.send(config.botnetword, NULL);
			}
        }
		if(net.irc.fd && net.irc.status & STATUS_SYNSENT)
		{
			if(FD_ISSET(net.irc.fd, &wfd))
			{
				logfile.send("[+] Connection to IRC established", NULL);
				net.irc.status = STATUS_CONNECTED;
				net.irc.killTime = NOW + set.AUTH_TIME;
				net.irc.send("NICK ", config.nick, NULL);
				net.irc.send("USER ", config.ident, " 8 * :", config.realname, NULL);
			}
        }
   }
}
