/*************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

//  return values:
//  0 - local
//  1 - remote
// -1 - error
int listcmd(char what, char *from, char *arg1, char *arg2, inetconn *c)
{
	char *tmp = NULL;
	int i;

	switch(tolower(what))
	{
		//remote
		case 'a':
		{
			if(!config.ctcptype)
			{
				net.sendOwner(from, "N/A", NULL);
				return 1;
			}
			char buf[MAX_LEN];
			char elapsed[MAX_LEN], remaining[MAX_LEN];

			int2units(elapsed, MAX_LEN, antiidle.getET(), ut_time);
			int2units(remaining, MAX_LEN, antiidle.getRT(), ut_time);

			if(antiidle.away)
			{
				snprintf(buf, MAX_LEN, "[a] away: on, elapsed: %s, remaining: %s",
					elapsed, remaining);
			}
			else
			{
				char next[MAX_LEN];
				int2units(next, MAX_LEN, int(antiidle.nextMsg - NOW), ut_time);
				snprintf(buf, MAX_LEN, "[a] away: off, elapsed: %s, remaining: %s, nextmsg: %s",
					elapsed, remaining, next);
			}
			net.sendOwner(from, buf, NULL);
			return 1;
		}
		//remote (but return 0; coz we propagate data here)
		case 'p':
		{
			//pass it further
			if(!c || c == &net.hub)
			{
				char buf[MAX_LEN];
				snprintf(buf, MAX_LEN, "%d %d", int(NOW), int(nanotime()));
				net.propagate(c, S_LIST, " P ", from, " ", buf, NULL);
			}

			//question
			if(c && c == &net.hub)
			{
				c->send(S_LIST, " P ", from, " ", arg1, " ", arg2, NULL);
			}
			//reply
			else if(c)
			{
				time_t NANO = nanotime();
				time_t T = atoi(arg1);
				time_t N = atoi(arg2);
				char buf[MAX_LEN];

				if(NANO >= N)
					snprintf(buf, MAX_LEN, "%.3f", float(NOW-T) + float((NANO - N)/1e6));
				else
					snprintf(buf, MAX_LEN, "%.3f", float(NOW - T -1) + float(((1e6 - N + NANO)/1e6)));

				net.sendOwner(from, "[p] reply from ", c->handle->name, " in: ", buf, " secs", NULL);
			}
			return 0;
		}

		//bot side
		case 's':
		{
			if(c && c != &net.hub) return 0;

			for(i=0; i<MAX_SERVERS; ++i)
				if(config.server[i].host)
					tmp = push(tmp, config.server[i].host, ":", itoa(config.server[i].port), tmp ? (char *) ", " : (char *) " ", NULL);

			net.sendOwner(from, "[s] now: ", net.irc.name ? net.irc.name : "none", ", in config: ", tmp, NULL);
			if(tmp) free(tmp);
			return 1;
		}
		//main side
		case 'd':
		{
			if(c) return 0;

			for(i=0; i<net.max_conns; ++i)
				if(net.conn[i].isRegBot() && (!net.conn[i].name || !*net.conn[i].name))
					tmp = push(tmp, net.conn[i].handle->name, tmp ? (char *) ", " : (char *) " ", NULL);
			if(tmp)
			{
				net.sendOwner(from, "[d] ", tmp, NULL);
				free(tmp);
			}
			else net.sendOwner(from, "[d] all bots are on irc", NULL);
			return 0;
		}
		//bot side
		case 'c':
		{
			if(c && c != &net.hub) return 0;

			for(i=0; i<MAX_CHANNELS; ++i)
			{
				if(userlist.chanlist[i].name)
				{
					chan *ch = ME.findChannel(userlist.chanlist[i].name);
					tmp = push(tmp, ch ? (ch->synced() ?
						((ch->ptr->flags & IS_OP) ? (char *) "@" : (char *) "") : (char *) "?")
							: (char *) "-", ch->name, tmp ? (char *) ", " : (char *) " ", NULL);
				}
			}
			if(tmp)
			{
				net.sendOwner(from, "[c] ", tmp, NULL);
				free(tmp);
			}
			else net.sendOwner(from, "[c] no channels", NULL);
			return 1;
		}
	}
	return -1;
}

