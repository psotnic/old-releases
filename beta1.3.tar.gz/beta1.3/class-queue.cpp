/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

fifo::fifo(int size, int delay)
{
	maxEnt = size;
	flushDelay = delay;
}

int fifo::push(char *str)
{
	if(!maxEnt || data.ent <= maxEnt)
	{
		data.addLast(str);
		return 1;
	}
	else return 0;
}

char *fifo::pop()
{
	if(data.first)
	{
		char *tmp = data.first->ptr;
		data.remove(tmp);
		return tmp;
	}
	return NULL;
}

char *fifo::flush()
{
	if(lastFlush >= NOW + flushDelay) return 0;
	return pop();
}

int fifo::flush(inetconn *c)
{
	if(lastFlush >= NOW + flushDelay) return 0;
	char *tmp = pop();
	if(tmp)
	{
		c->send(tmp, NULL);
		free(tmp);
		lastFlush = NOW;
		return 1;
	}
	return 0;
}

int fifo::wisePush(char *str)
{
	PTRLIST<char> *p = data.first;

	while(p)
	{
		if(!strcmp(p->ptr, str)) return 0;
		p = p->next;
	}
	return push(str);
}
