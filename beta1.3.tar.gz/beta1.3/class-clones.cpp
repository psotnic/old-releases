/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

clone_ent::clone_ent()
{
	//delete entries
	node = ptrlist<clone_ent>(1);
}

clone_ent::clone_ent()
{
	free(name);
	name = NULL;
}

