/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_hub(char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;

	if(!strlen(data)) return;
	str2words(arg[0], data, 10, MAX_LEN);

	if(!(net.hub.status & STATUS_REGISTERED))
	{
		switch(net.hub.tmpint)
		{
			case 1:
			{
				if(strlen(arg[0]))
				{
					char hash[33];
					++net.hub.tmpint;
					MD5HexHash(hash, arg[0], AUTHSTR_LEN, config.hubpass, strlen(config.hubpass));
					net.hub.send(config.handle, " ", hash, NULL);

					net.hub.tmpstr = (char *) malloc(AUTHSTR_LEN + 1);
					MD5CreateAuthString(net.hub.tmpstr, AUTHSTR_LEN);
					net.hub.send(net.hub.tmpstr, NULL);
                    return;
				}
				break;
			}
			case 2:
			{
				if(strlen(arg[3]))
				{
                    if(MD5HexValidate(arg[3], net.hub.tmpstr, strlen(net.hub.tmpstr), config.hubpass, strlen(config.hubpass)))
					{
                        char buf[MAX_LEN];

                        ++net.hub.tmpint;
						userlist.addHandle(arg[0], 0, BOT_FLAGS, arg[1], arg[2]);
                        net.hub.handle = userlist.findHandle(arg[0]);
  						free(net.hub.tmpstr);
						net.hub.tmpstr = NULL;

						sprintf(buf, "%llu", userlist.SN);
                        net.hub.send(S_REGISTER, " ", S_VERSION, " ", buf, " ", ME.nick, NULL);
						return;
					}
				}
				break;
			}
			case 3:
			{
				if(!strcmp(arg[0], S_REGISTER))
				{
					mem_strcpy(net.hub.name, arg[1]);
					net.hub.tmpint = 0;
					net.hub.status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_BOT;
					net.hub.killTime = NOW + set.CONN_TIMEOUT;
					net.hub.lastPing = NOW;

					net.hub.enableCrypt((unsigned char *) config.hubpass, strlen(config.hubpass));

					net.sendBotListTo(&net.hub);
					net.propagate(&net.hub, S_BJOIN, " ", net.hub.handle->name, " ", net.hub.name, NULL);
					return;
				}
			}
			default: break;
		}
		/* HUH */
		logfile.send("[-] Failed to register HUB", NULL);
		net.hub.close("Access Denied");
	}

	/* REGISTERED HUB */
	net.hub.killTime = NOW + set.CONN_TIMEOUT;

	if(!strcmp(arg[0], S_UL_UPLOAD_START) && !userlist.ulbuf)
	{
		logfile.send("[*] Fetching Userlist", NULL);
		mem_strcpy(userlist.ulbuf, "");
		return;
	}
	if(!strcmp(arg[0], S_UL_UPLOAD_END) && userlist.ulbuf)
	{
		mem_strcat(userlist.ulbuf, S_UL_UPLOAD_END);
		userlist.update();
		userlist.sendToAll();
		return;
	}
	if(userlist.ulbuf)
	{
		strcat(data, "\n\0");
		mem_strcat(userlist.ulbuf, data);
		return;
	}

 	/* S_KICKBAN <chan> <nick> <mask> [reason] */
	if(!strcmp(arg[0], S_KICKBAN) && strlen(arg[3]))
	{
		ch = ME.findChannel(arg[1]);
		if(ch)
		{
			CHANUSER *u;
			if((u = ch->getUser(arg[2])))
			{
				a = srewind(data, 4);
				if(!a) a = config.banreason;

				if(penality < 2)
				{
					if(u->flags & IS_OP) net.irc.send("MODE ", arg[1], " -o+b ", arg[2], arg[3], NULL);
					else net.irc.send("MODE ", arg[1], " +b ", arg[3], NULL);
					//FIXME: is this necesery?
					net.irc.send("KICK ", arg[1], " ", arg[2], " :", a, NULL);
					penality += 2;
				}
			}
		}
		return;
	}
	if(!strcmp(arg[0], S_CYCLE) && strlen(arg[1]))
	{
		if(ME.findChannel(arg[1]))
		{
			net.irc.send("PART ", arg[1], " :", config.cyclereason, NULL);
			ME.rejoin(arg[1], set.CYCLE_DELAY);

			if(strlen(arg[2]))
				net.send(OWNERS, "[*] Doing cycle on ", arg[1], NULL);
			else
				net.propagate(&net.hub, data, NULL);
		}
		return;
	}
	if(!strcmp(arg[0], S_MKA) && strlen(arg[1]))
	{
		ch = ME.findChannel(arg[1]);
		if(ch) ch->massKick(MK_ALL);
		net.propagate(&net.hub, data, NULL);
		return;
	}
	if(!strcmp(arg[0], S_MKO) && strlen(arg[1]))
	{
		ch = ME.findChannel(arg[1]);
		if(ch) ch->massKick(MK_OPS);
		net.propagate(&net.hub, data, NULL);
		return;
	}
	if(!strcmp(arg[0], S_MKN) && strlen(arg[1]))
	{
		ch = ME.findChannel(arg[1]);
		if(ch) ch->massKick(MK_NONOPS);
		net.propagate(&net.hub, data, NULL);
		return;
	}
	if(!strcmp(arg[0], S_UNLINK) && strlen(arg[1]))
	{
		HANDLE *h = userlist.findHandle(arg[1]);

		if(h && userlist.isBot(h))
		{
			inetconn *bot = net.findConn(h);
			if(bot) bot->close("Forced unlink");
		}
		return;
	}
	if(!strcmp(arg[0], S_NICK) && strlen(arg[1]))
	{
		net.irc.send("NICK ", arg[1], NULL);
		ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		return;
	}
	if(!strcmp(arg[0], S_JUMP) && strlen(arg[2]))
	{
		ME.jump(arg[2], arg[3], arg[1]);
		return;
	}
	if(!strcmp(arg[0], S_RESET) && strlen(arg[1]))
	{
		switch(arg[1][0])
		{
			case 'I': antiidle.reset(); break;
			default: break;
		}
		return;
	}
	if(!strcmp(arg[0], S_RDIE) && strlen(arg[1]))
	{
		net.send(OWNERS, "[!] ", DIE_REASON, NULL);
		net.irc.send("QUIT :", arg[1], " ", DIE_REASON2, NULL);
		safeExit();
	}
	if(parse_botnet(&net.hub, data)) return;

    if(userlist.parse(data))
    {
		++userlist.SN;

		//some things should not be propagated
		if(config.bottype == BOT_SLAVE)
		{
			if(!strcmp(S_ADDBOT, arg[0]))
			{
				net.propagate(&net.hub, S_ADDBOT, " ", arg[1], " ", arg[2], " ", arg[3], " ", S_SECRET, NULL);
				return;
			}
			if(!strcmp(S_PASSWD, arg[0]) && userlist.isBot(arg[1]))
				return;
		}
		net.propagate(&net.hub, data, NULL);
        return;
	}
}
