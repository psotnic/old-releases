/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void var::reset()
{
	for(int i=0; i<ent; ++i) *varent[i].i = varent[i].def;
}

void var::sendVar(int i, char *name, inetconn *c)
{
	if(!c) return;
	if(i < 0 || i >=ent) return;
	if(!name) return;

	char buf[MAX_LEN], spaces[MAX_LEN];
	int j;

	for(j=0; j<align-(signed int) strlen(varent[i].name); ++j) spaces[j] = ' ';
	spaces[j] = '\0';

	int2units(buf, MAX_LEN, *varent[i].i, varent[i].ut);
	c->send(name, ": ", varent[i].name, spaces, " = ", buf, NULL);
}

int var::parseuser(inetconn *c, char *name, char *a, char *b)
{
	char buf[MAX_LEN];
	int i;

	memset(buf, 0, MAX_LEN);

	if(!*a)
	{
		for(i=0; i<ent ;++i)
		{
			if(varent[i].i)
				sendVar(i, name, c);
		}
		return -2;
	}
	else if(!*b)
	{
		i = getvar(a);
		if(i == -1)
		{
			if(c) c->send("No such variable '", a, "'", NULL);
		}
		else
		{
			sendVar(i, name, c);
			return -2;
		}
	}
	else
	{
		switch(setvar(a, b, &i))
		{
			case -1:
			{
				if(c)
					c->send("No such variable '", a, "'", NULL);
				return -1;
			}
			case -2:
			{
				if(c)
					c->send("Invalid data format", NULL);
				return -1;
			}
			case -3:
			{
				if(c)
				{
					char from[MAX_LEN];
					char to[MAX_LEN];
					int2units(from, MAX_LEN, varent[i].from, varent[i].ut);
					int2units(to, MAX_LEN, varent[i].to, varent[i].ut);
					sprintf(buf, "Value does not bellong to range <%s, %s>", from, to);
					c->send(buf, NULL);
				}
				return -1;
			}
			default: break;
		}

		//no errors:
		if(i >= 0)
		{
			int2units(buf, MAX_LEN, *varent[i].i, varent[i].ut);
			if(c && config.bottype == BOT_MAIN) net.send(OWNERS, name, ": variable '", a, "' has been set to ", buf, NULL);
			return i;
		}
	}
	return -1;
}

int var::setvar(char *name, char *val, int *ret)
{
	int i, v, j;
	i = getvar(name);

	if(ret) *ret = i;

	if(i == -1) return -1;

	j = units2str(val, varent[i].ut, v);
	if(j != 1) return -2;

	if(v >= varent[i].from && v <= varent[i].to)
	{
		*varent[i].i = v;
		userlist.nextSave = NOW + 60;
		return i;
	}

	//out of range
	return -3;
}

int var::getvar(char *name)
{
	int i;
	for(i=0; i<ent; ++i)
		if(!strcmp(varent[i].name, name)) return i;
	return -1;
}

void var::addvar(char *name, int def, int *iptr, int a, int b, unit_table *ut)
{
 	varent = (VAR *) realloc(varent, (ent + 1) * sizeof(VAR));
	//mem_strcpy(varent[ent].name, name);
	varent[ent].name = name;
	varent[ent].i = iptr;
	*varent[ent].i = def;
	varent[ent].def = def;
	varent[ent].from = a;
	varent[ent].to = b;
	varent[ent].ut = ut;
	++ent;

	int len = strlen(name);
	if(len > align) align = len;
}

/* Constructors */
var::var()
{
	//printf(">> Var constructor\n");
}

settings::settings()
{
	align = ent = debug = creation = 0;
	varent = NULL;

	addvar("cycle-delay",			10, &CYCLE_DELAY, 			 0, 60,		 	ut_time);
	addvar("rejoin-delay",			 0, &REJOIN_DELAY, 			 0, 60, 		ut_time);
	addvar("rejoin-fail-delay",		25, &REJOIN_FAIL_DELAY,		 7, 60,		 	ut_time);
	addvar("hub-conn-delay",		15, &HUB_CONN_DELAY,		10, 3600,	 	ut_time);
	addvar("irc-conn-delay",		15, &IRC_CONN_DELAY,		10, 3600, 		ut_time);
	addvar("auth-time",				45, &AUTH_TIME,				15, 360, 		ut_time);
	addvar("private-ctcp",		 	 1, &PRIVATE_CTCP,			 0, 1);
	addvar("ops-per-mode",			 2, &OPS_PER_MODE,			 1, 3);
	addvar("ask-for-op-delay",		 4, &ASK_FOR_OP_DELAY,		 1, 60,		 	ut_time);
	addvar("getop-op-check",		 1, &GETOP_OP_CHECK,		 0, 1);
	addvar("conn-timeout",		   180, &CONN_TIMEOUT, 			15, 600,	 	ut_time);
    addvar("keep-nick-check-delay", 10, &KEEP_NICK_CHECK_DELAY,  5, 24*3600, 	ut_time);
	addvar("remember-old-keys",		 0, &REMEMBER_OLD_KEYS,		 0, 1);
	addvar("telnet-owners",			 1, &TELNET_OWNERS,			 0, 1);
	addvar("max-matches",			20, &MAX_MATCHES,			 0, MAX_INT);
	addvar("perip-max-shown-cons",	 6, &PERIP_MAX_SHOWN_CONNS,  0, MAX_INT);
	addvar("perip-burst-size",		30, &PERIP_BURST_SIZE,	 	 6, MAX_INT);
	addvar("perip-burst-time",		60,	&PERIP_BURST_TIME,		30, MAX_INT, 	ut_time);
	addvar("perip-ignore-time",		300,&PERIP_IGNORE_TIME,		 0, MAX_INT), 	ut_time;
	addvar("synflood-max-conns",	100,&SYNFLOOD_MAX_CONNS,	30, MAX_INT);
	addvar("synflood-ignore-time",	300,&SYNFLOOD_IGNORE_TIME,	 0, MAX_INT, 	ut_time);
	addvar("bIe-mode-bounce-time",	600,&BIE_MODE_BOUNCE_TIME,	 0, MAX_INT, 	ut_time);
	addvar("wasop-cache-time",	   1200,&WASOP_CACHE_TIME,		 0, MAX_INT, 	ut_time);
	addvar("away-time",			 8*3600,&AWAY_TIME,		      3600, 24*3600, 	ut_time);
	addvar("chat-time",			 6*3600,&CHAT_TIME,			  3600, 24*3600, 	ut_time);
	addvar("between-msg-delay",	   5*60,&BETWEEN_MSG_DELAY,	    10, 2*3600, 	ut_time);
	addvar("randomness",		    -50,&RANDOMNESS,		  -100, 0,			ut_perc);
	addvar("public-away",		      0,&PUBLIC_AWAY,		  	 0, 1);
}

chanset::chanset()
{
	align = ent = 0;
	varent = NULL;

	//printf(">> Chanset constructor\n");

	addvar("aop-bots", 			1,	 &AOP_BOTS,	 		-100, MAX_INT,	ut_perc);
	addvar("bot-aop-bots",		1,	 &BOT_AOP_BOTS, 	-100, MAX_INT,	ut_perc);
	addvar("punish-bots",		-30, &PUNISH_BOTS,		-100, MAX_INT,	ut_perc);
	addvar("getop-bots",		2,	 &GETOP_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("unban-bots",		2, 	 &UNBAN_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("shit-bots",			3, 	 &SHIT_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("invite-bots",		3, 	 &INVITE_BOTS, 		-100, MAX_INT,	ut_perc);
	addvar("chmode-prot-bots",	2, 	 &CHMODE_PROT_BOTS, -100, MAX_INT,	ut_perc);
	addvar("channel-ctcp",		1, 	 &CHANNEL_CTCP, 	   0, 1);
	addvar("enforce-bans",		1, 	 &ENFORCE_BANS, 	   0, 1);
	addvar("enforce-limits",	1, 	 &ENFORCE_LIMITS,	   0, 1);
	addvar("enforce-bots",		-30, &ENFORCE_BOTS,		-100, MAX_INT,	ut_perc);
	addvar("stop-nethack",		1, 	 &STOP_NETHACK, 	   0, 1);
	addvar("limit",				1, 	 &LIMIT,			   0, 1);
	addvar("limit-time",		120,  &LIMIT_TIME,		   1, MAX_INT, 	ut_time);
	addvar("limit-offset",		5, 	 &LIMIT_OFFSET,		   1, MAX_INT);
	addvar("limit-bots",		1, 	 &LIMIT_BOTS,		   1, 2);
    addvar("limit-tolerance",	-50, &LIMIT_TOLERANCE,	-100, MAX_INT,	ut_perc);
    addvar("owner-limit-time",	15,  &OWNER_LIMIT_TIME,	   0, 60, 		ut_time);
	addvar("takeover",			0,	 &TAKEOVER,			   0, 1);
	addvar("bitch",				1,	 &BITCH,			   0, 1);
	addvar("wasoptest",			1,	 &WASOPTEST,		   0, 1);

}

/* Destruction derby */
void var::DestroyThisShit()
{
	while(--ent)
	{
		//printf(">> destructor: del %s\n", varent[ent-1].name);
		//free(varent[ent-1].name);
	}
	free(varent);
}

settings::~settings()
{
	DestroyThisShit();
}

chanset::~chanset()
{
	DestroyThisShit();
};
