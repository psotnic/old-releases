class wasoptest
{
	class entry
	{
		public:
		char *mask;
		time_t when;

		entry(char *n, char *i, char *h);
		entry(char *m, int alloc=1);
		~entry();
	};

	public:
	ptrlist<entry> data;
	int TOL;
	time_t since;

	int add(CHANUSER *p);
	int add(char *nick, char *ident, char *host);
	int add(char *mask, int alloc=1);

	int remove(CHANUSER *user);
	int remove(char *nick, char *ident, char *host);
	int remove(char *mask);

	static int checkSplit(char *reason);
	void expire();

	wasoptest(int life=60*45);
};

class masklist_ent
{
	public:
	char *mask;
	time_t expire;
	time_t when;
	char *who;

	masklist_ent(char *m, char *w, int t=0);
	~masklist_ent();
};

class masklist
{
	public:
	ptrlist<masklist_ent> masks;

	int add(char *mask, char *who, int t=0);
	int remove(char *mask);
	masklist_ent *find(char *mask);
	masklist_ent *wildFind(char *mask);
	masklist();
};

class inetconn
{
	public:
	char *rev;

	private:
	pthread_mutex_t mutex;
	void _close(char *reason=NULL);
	CBlowFish *blowfish;
	void lock();
	void unlock();

	public:
    int fd;
    int status;
	char *name;
	char *pass;
	char *tmpstr;
	int tmpint;
	int killTime;
	int lastPing;

	IOBUF read;
	IOBUF write;

	HANDLE *handle;

	int enableLameCrypt();
	int enableCrypt(unsigned char *key, int len=-1);
	int disableCrypt();
	int send(char *lst, ...);
	int va_send(va_list ap, char *lst);
	int readln(char *buf, int len);
    int open(const char *pathname, int flags, mode_t mode=0);
	void close(char *reason=NULL);

	int isRegBot();
	int isRegOwner();
	int checkFlag(int flag);

	int sendPing();
	int timedOut();
	char *getIpName();
	char *getPortName();
	unsigned int getIp();
	int getPort();
	inetconn();
	~inetconn();

	int isSlave();
	int isLeaf();
	int isMain();
	friend class inet;// closeConn(int fd);
};

class inet
{

	public:
	int conns, max_conns, listenfd, maxFd;
	inetconn *conn, hub, irc;

	inetconn *addConn(int fd);
	inetconn *findConn(char *name);
	inetconn *findConn(HANDLE *h);
	int closeConn(inetconn *c, char *reason=NULL);
	void send(int who, char *lst, ...);
	void sendexcept(int excp, int who, char *lst, ...);
	void sendBotListTo(inetconn *c);
	void sendBotJoin(inetconn *c);
	void sendOwner(char *who, char *lst, ...);
	void propagate(inetconn *from, char *str, ...);
	inetconn *findRedirConn(inetconn *c);
	int bidMaxFd(int fd);
	void display();
	void resize();
	int bots();
	int owners();

	static int gethostbyname(char *host, char *buf);

	inet();
	~inet();
};

class var
{
	public:
	int ent;
	int align;
 	VAR *varent;

	void addvar(char *name, int def, int *iptr, int a, int b, unit_table *ut=NULL);
	void reset();
	int getvar(char *name);
	int setvar(char *name, char *val, int *ret=NULL);
	int parseuser(inetconn *c, char *name, char *a, char *b);
	void sendVar(int i, char *name, inetconn *c);

	var();
	inline void DestroyThisShit();
};

class settings : public var
{
	public:
	int PRIVATE_CTCP;
	int CYCLE_DELAY;
	int REJOIN_DELAY;
	int REJOIN_FAIL_DELAY;
	int HUB_CONN_DELAY;
	int IRC_CONN_DELAY;
	int AUTH_TIME;
	int OPS_PER_MODE;
	int ASK_FOR_OP_DELAY;
	int CONN_TIMEOUT;
	int KEEP_NICK_CHECK_DELAY;
	int SAVE_NICK;
	int REMEMBER_OLD_KEYS;
	int TELNET_OWNERS;
	int GETOP_OP_CHECK;
	int MAX_MATCHES;
	int PERIP_MAX_SHOWN_CONNS;
	int PERIP_BURST_TIME;
	int PERIP_BURST_SIZE;
	int PERIP_IGNORE_TIME;
	int SYNFLOOD_MAX_CONNS;
	int SYNFLOOD_IGNORE_TIME;
	int BIE_MODE_BOUNCE_TIME;
	int WASOP_CACHE_TIME;
	int CHAT_TIME;
	int AWAY_TIME;
	int RANDOMNESS;
	int BETWEEN_MSG_DELAY;
	int PUBLIC_AWAY;

	int debug;
	int creation;

	settings();
	~settings();
};

class chanset : public var
{
	public:
	int AOP_BOTS;
	int BOT_AOP_BOTS;
	int PUNISH_BOTS;
	int UNBAN_BOTS;
	int INVITE_BOTS;
	int SHIT_BOTS;
	int LIMIT;
	int LIMIT_TIME;
	int LIMIT_OFFSET;
	int LIMIT_BOTS;
    int LIMIT_TOLERANCE;
	int CHANNEL_CTCP;
	int ENFORCE_BANS;
	int ENFORCE_LIMITS;
	int ENFORCE_BOTS;
	int STOP_NETHACK;
	int GETOP_BOTS;
	int CHMODE_PROT_BOTS;
	int OWNER_LIMIT_TIME;
	int TAKEOVER;
	int BITCH;
	int WASOPTEST;

	chanset();
	~chanset();
};

struct CHANLIST
{
	char *name;
	char *pass;
	int joinsent;
	int nextjoin;
	char updated;
	chanset *chset;
	wasoptest *wasop;
	wasoptest *allowedOps;
};

class chan
{
   	public:
	ptrlist<CHANUSER> toOp, botsToOp, opedBots, toKick, toReOp;
	CHANUSER *first, *last, *ptr;
	chan *next, *prev;
	char *name, *key;
	int users, status, limit, channum, nextlimit, synlevel, flags;
	chanset *chset;
	wasoptest *wasop;
	time_t initialOp, since;
	masklist list[3];

	/* Actions */
	int op(CHANUSER **MultHandle, int num);
	int op(CHANUSER *p);
	int deOp(CHANUSER *p);
	int kick4(CHANUSER **MultHandle, int num);
	int kick6(CHANUSER **MultHandle, int num);
	int kick(CHANUSER *p, char *reason);
	int kickBan(CHANUSER *p, char *mask, char *reason);
	//int unBan(char *str);
	int invite(char *nick);
	void enforceLimits();
	void updateLimit();
	void updateKey(char *newkey);
	int massKick(int who);
	void requestOp();

	/* Probabilistics */
	int myTurn(int num, int hash=0);

	/* Got something */
	void gotNickChange(char *from, char *to);
	void gotMode(char *_args, char *_mode, char *mask);
	void gotKick(char *victim, char *offender);
	void gotPart(char *nick, int netsplit);
	int gotBan(char *ban, CHANUSER *caster);
	CHANUSER *gotJoin(char *mask, int def_flags=0);
	CHANUSER *getUser(char *nick);

	/* other */
	void recheckFlags();
	void quoteBots(char *str);
	int quoteOpedBots(char *str, int num);
	void reOp();
	void rejoin(int t);
	int numberOfBots(int num);
	int chops();
	int synced();
	void setFlags(char *str);
	void addFlags(char *str);
	void removeFlags(char *str);
	void buildAllowedOpsList(char *offender);
	char *getModes();

	/* Debug */
	void display();

	/* Constructor */
	chan();

	/* Destruction derby */
	~chan();
	void destroy(CHANUSER *p);
	void removeFromAllPtrLists(CHANUSER *handle);
};

class client
{
	public:
	chan *first, *last, *current;
	int channels, nextconn_hub, nextconn_serv;
	char *nick, *ident, *host, *mask;
	time_t NextNickCheck, startedAt;

	/* Irc chanels */
	chan *createNewChannel(char *name);
	chan *findChannel(char *name);
	chan *findNotSyncedChannel(char *name);
	void removeChannel(char *name);
	void gotUserQuit(char *mask, char *reason=NULL);
	void recheckFlags();
	void recheckFlags(char *channel);
	void rejoin(char *name, int t);
	void rejoinCheck();
	void scheludeJoinToAllChannels();
	void gotNickChange(char *from, char *to);
	void checkQueue();
	void inviteRaw(char *str);

	/* Nick stuff */
 	void registerWithNewNick(char *nick);

	/* Net */
	int connectToIRC(SERVER *s=NULL);
	int connectToHUB();
	int jump(char *host, char *port, char *owner=NULL);

	/* Debug */
	void display();

	/* Constructor */
	client();

	/* Destruction derby */
	~client();
	void reset();
};

class ul
{
	public:
	HANDLE *first, *last;
	CHANLIST chanlist[MAX_CHANNELS];
	int users, bots;
	unsigned long long int SN; // ;-)
	char *ulbuf, bighash[8192];
	time_t nextSave;

	/* Handle */
	HANDLE *addHandle(char *name, unsigned int ip=0, int flags=0, char *sec=NULL, char *nano=NULL);
	HANDLE *findHandle(char *name);
	int removeHandle(char *name);
	void cleanHandle(HANDLE *h);
	void cleanChannel(int i);

	int userLevel(HANDLE *h, int n);
	int hasEmptyFlags(HANDLE *h);

	/* Host */
	int addHost(HANDLE *p, char *host);
	int findHost(HANDLE *p, char *host);
	int removeHost(HANDLE *p, char *host);
	int wildFindHost(HANDLE *p, char *host);
	int wildFindHostExt(HANDLE *p, char *host);
	HANDLE *matchMaskToHandle(char *mask);

	/* Flags */
	int changeFlags(inetconn *c, char *name, char *flags, char *channel);
   	int changeFlags(char *name, char *flags, char *channel);
	int changeFlags(HANDLE *p, char *flags, int channum);

	int getFlags(char *mask, chan *ch);
	void flags2str(int flags, char *str);
	int isOwner(char *mask);
    static int isBot(HANDLE *h);
    int isBot(char *name);
	int isBot(unsigned int ip);
	static int isMain(HANDLE *h);
	static int isSlave(HANDLE *h);
	static int isLeaf(HANDLE *h);
	int isIdiot(char *mask, int channum);

	/* Channels */
	int addChannelToList(char *name, char *pass);
	int removeChannelFromList(char *name);
	int findChannelInList(char *name);
	int globalChset(inetconn *c, char *var, char *value);

	/* other */
	void send(inetconn *c, CHANLIST *chan);
	void send(inetconn *c, HANDLE *h, int strip=0);
	void send(inetconn *c, var *v, char *ch=NULL);
	void sendHandleInfo(inetconn *c, HANDLE *h);

	int save(char *file, int cypher=1, char *key=NULL);
	int load(char *file, int cypher=1, char *key=NULL);
	void update();
	void send(inetconn *c);
	void sendToAll();
	HANDLE *checkBotMD5Digest(unsigned int ip, char *digest, char *authstr);
	HANDLE *checkOwnerPass(char *username, char *pass);

	HANDLE *changePass(char *user, char *pass);
	HANDLE *changeIp(char *user, char *ip);
	void setRawPassword(char *user, char *rawpass);
	int hasWriteAccess(inetconn *c, char *handle);
	HANDLE *matchPassToHandle(char *pass, char *host, int flags);
	void autoSave();
	void sendUsers(inetconn *c);
	void sendBotTree(inetconn *c);
	int parse(char *data);
	int addServer(char *host, int port, int protocol, char *pass);
	SERVER *findServer(char *host, int port=0);

	/* Constructor */
	ul();

	/* Destruction derby */
	~ul();
	void reset();
	void destroy(HANDLE *p);
	void destroy(CHANLIST *p);
};

class ptime
{
    public:
	struct timeval tv;
    ptime();
	ptime(char *s, char *n);
	ptime(time_t s, time_t n);
	char *print();
	int operator==(ptime &p);
};

#ifdef HAVE_TCL
class tcl
{
    Tcl_Interp *tcl_int;
    char *setGlobalVar(char *name, char *value);
    void addCommands();

    public:

    int curid;
    struct timer_t
    {
		char *nick;
		time_t exp;
		int id;
	};

    ptrlist<timer_t> timer;

	int load(char *script);
    Tcl_Interp *getInt();
    int eval(char *cmd);

	void expireTimers();

	tcl();
	~tcl();

};
#endif

class shitlist
{
	public:

	struct shit_t
	{
		char *mask;
		char *reason;
		char *by;
		time_t exp;
	};

	ptrlist<shit_t> shit;

	int add(char *mask, char *reason, char *by, time_t exp);
	int remove(char *mask);
	int remove(int num);

	shitlist();
	~shitlist();
};

class penal
{
	private:
	time_t when;
	int penality;

	public:
	operator int();
	void calc();
	penal operator+(int n);
	penal operator+=(int n);
	penal operator-(int n);
	penal operator-=(int n);
	penal operator++(int);
	penal operator--(int);
	int val() { return penality; };

	penal(int n=0);
};

class ign
{
	public:
	struct IPDATA
	{
		unsigned int ip;
		time_t when;
	};

	ptrlist<ptrlist <IPDATA> > conns;
	ptrlist<IPDATA> ipIgnores;

	int ipConnsCount;
	int underSynFlood;

	int hit(unsigned int ip);
	int isIgnored(unsigned ip);
	void expire();
	ign();
	~ign();

	private:
	//void destroy(ptrlist<IPDATA> *p);
	void expire(ptrlist<IPDATA> *p, int t);
};

class fifo
{
	public:
	int maxEnt;
	static time_t lastFlush;
	int flushDelay;
	ptrlist<char> data;

	fifo(int size=0, int delay=1);
	int push(char *str);
	int wisePush(char *str);
	char *pop();
	int flush(inetconn *c);
	char *flush();
};

class update
{
	public:
	char *data;
	int binSize;
	int fetched;

	int get(char *site, char *version);
	int dumpBin();
	update();
	~update();
};

class idle
{
	public:
	char *away;
	time_t nextStatus;
	time_t lastStatus;
	time_t nextMsg;
	time_t lastMsg;

	char **awayReasons;
	char **backReasons;
	char **awayAdd;
	char **backAdd;

	idle();
	int spread(int x);
	void calcNextStatus();
	void calcNextMsg();
	void sendMsg();
	void eval();
	void togleStatus();
	int getIdle();
	int getET();
	int getRT();
	void reset();
	void load(int fromFile=0);
	char *getRandAwayMsg();
	char *getRandBackMsg();
	char *getRandAwayAdd();
	char *getRandBackAdd();

};

class clone_ent
{
	public:
	char *name;
	ptrlist<CHANUSER> clones;
	ptrlist<clone_ent> node;
	clone_ent();
	~clone_ent();
};
