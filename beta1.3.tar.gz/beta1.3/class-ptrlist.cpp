/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

template <class P>
struct PTRLIST
{
	P *ptr;
	PTRLIST *next;
	PTRLIST *prev;
};


template <class T>
class ptrlist
{
	public:
	PTRLIST<T> *first;
	int ent;
	int removePtrs;

	////////////////////////////////////////
	PTRLIST<T> *getItem(int num)
	{
		PTRLIST<T> *p;
		int i;

		if(num + 1 > ent) return NULL;
		p = first;
		i = 0;

		while(1)
		{
			if(i == num) return p;
			p = p->next;
			i++;
		}
	}

	////////////////////////////
	int find(T *ptr)
	{
		PTRLIST<T> *p = first;
		int i=0;

		while(p)
		{
			if(ptr == p->ptr) return i;
			++i;
			p = p->next;
		}
		return -1;
	}

	//////////////////////////////
	int remove(T *ptr)
	{
		PTRLIST<T> *p = first;

		if(!ent) return 0;
		if(first->ptr == ptr)
		{
			first = first->next;
			if(first) first->prev = NULL;
			if(removePtrs) delete p->ptr;
			delete(p);
			--ent;
			return 1;
		}
		else
		{
			while(p)
			{
				if(p->ptr == ptr)
				{
					p->prev->next = p->next;
					if(p->next) p->next->prev = p->prev;
					if(removePtrs) delete p->ptr;
					delete(p);
					--ent;
					return 1;
				}
				p = p->next;
			}
		}
		return 0;
	}

	////////////////////////////////
	void sortAdd(T *ptr)
	{
		PTRLIST<T> *p, *q;

		if(!ptr || !ptr->nick || !*ptr->nick) return;

		if(!ent)
		{
			first = new(PTRLIST<T>);
			first->next = first->prev = NULL;
			first->ptr = ptr;
			++ent;
			return;
		}
		else
		{
			if(strcmp(ptr->nick, first->ptr->nick) < 0)
  			{
				q = new(PTRLIST<T>);
				q->ptr = ptr;
				first->prev = q;
				q->prev = NULL;
				q->next = first;
				first = q;
				++ent;
				return;
			}
			else
			{
				p = first;
				while(1)
				{
					if(!strcmp(ptr->nick, p->ptr->nick)) return;
					if(strcmp(ptr->nick, p->ptr->nick) < 0)
					{
						q = new(PTRLIST<T>);
						q->ptr = ptr;
						q->next = p;
						q->prev = p->prev;
						p->prev->next = q;
						p->prev = q;
						++ent;
						return;
					}
					else if(p->next == NULL)
					{
						q = new(PTRLIST<T>);
						q->ptr = ptr;
						q->next = NULL;
						q->prev = p;
						p->next = q;
						++ent;
						return;
					}
					p = p->next;
				}
			}
		}
	}

	//////////////////////////////
	void add(T *ptr)
	{
		PTRLIST<T> *p;

		if(!ent)
		{
			first = new PTRLIST<T>;
			first->next = first->prev = NULL;
			first->ptr = ptr;
		}
		else
		{
			p = first->prev = new PTRLIST<T>;
			p->next = first;
			p->prev = NULL;
			p->ptr = ptr;
			first = p;
		}
		++ent;
	}

	//////////////////////////////////
	void addLast(T *ptr)
	{
		if(!ent)
		{
			first = new PTRLIST<T>;
			first->next = first->prev = NULL;
			first->ptr = ptr;
		}
		else
		{
			PTRLIST<T> *p = first;

			while(p->next)
				p = p->next;

			p->next = new PTRLIST<T>;
			p->next->prev = p;
			p->next->next = NULL;
			p->next->ptr = ptr;
		}
		++ent;
	}

	//////////////////////////
	void display()
	{
		PTRLIST<T> *p = first;

		while(1)
		{
			if(p == NULL) break;
			printf("[%d]: %s!%s@%s \n", p->ptr->flags, p->ptr->nick, p->ptr->ident, p->ptr->host);
			p = p->next;
		}
	}

    /////////////////////
	ptrlist(int rm=0)
	{
		first = NULL;
		ent = 0;
		removePtrs = rm;
	}

    //////////////////////
	~ptrlist()
	{
		PTRLIST<T> *p = first;
		PTRLIST<T> *q;

		while(p)
		{
			q = p;
			p = p->next;
			if(removePtrs) delete q->ptr;
			delete(q);
		}
	}

	////////////////////////
	void reset()
	{
		this->~ptrlist();

		first = NULL;
		ent = 0;
	}
	//ptrlist<T> &operator int(int n) { removePtrs = n; return *this; };
};
