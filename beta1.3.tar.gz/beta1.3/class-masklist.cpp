/**************************************************
*  This file is a part of psotnic 0.x.x code.
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

masklist_ent::masklist_ent(char *m, char *w, int t)
{
	mem_strcpy(mask, m);
	mem_strcpy(who, w);
	when = NOW;
	expire = t ? NOW + t : 0;
}

masklist_ent::~masklist_ent()
{
	free(mask);
	free(who);
}

masklist::masklist()
{
	masks = ptrlist<masklist_ent>(1);
}

int masklist::add(char *mask, char *who, int t)
{
	if(find(mask)) return 0;

	masklist_ent *m = new masklist_ent(mask, who, t);
	masks.addLast(m);
	return 1;
}

int masklist::remove(char *mask)
{
	masklist_ent *m = find(mask);

	if(!m) return 0;
	masks.remove(m);
	return 1;
}

masklist_ent *masklist::find(char *mask)
{
	PTRLIST<masklist_ent> *m = masks.first;

	while(m)
	{
		if(!strcmp(m->ptr->mask, mask)) return m->ptr;
		m = m->next;
	}
	return NULL;
}

masklist_ent *masklist::wildFind(char *mask)
{
	PTRLIST<masklist_ent> *m = masks.first;

	while(m)
	{
		if(match(m->ptr->mask, mask) || match(mask, m->ptr->mask)) return m->ptr;
		m = m->next;
	}
	return NULL;
}

//void masklist::expire()
//{


