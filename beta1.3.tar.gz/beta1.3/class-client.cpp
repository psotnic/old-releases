/**************************************************
*  This file is a part of psotnic 0.x.x code.
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"


int client::jump(char *host, char *port, char *owner)
{

	SERVER *s = userlist.findServer(host, strlen(port) ? atoi(port) : 0);
	if(s)
	{
		net.irc.send("QUIT :changing servers", NULL);
		net.send(OWNERS, "[*] Jumping to ", s->host, " [", s->ip, "] port ", itoa(s->port), NULL);
		net.irc.close("changing servers");
		ME.connectToIRC(s);
	}
	else
	{
		char ip[MAX_LEN];
		if(!isValidIp(host))
		{
			if(!inet::gethostbyname(host, ip))
			{
				net.sendOwner(owner, "[-] Cannot resolve ", host, ": ", hstrerror(h_errno), NULL);
				return 0;
			}
		}
		else strncpy(ip, host, MAX_LEN-1);

		net.irc.send("QUIT :changing servers", NULL);
		SERVER d;
		d.host = host;
		d.ip = ip;
		d.port = atoi(port) ? atoi(port) : 6667;
		d.pass = NULL;
		net.send(OWNERS, "[*] Jumping to custom server ", d.host, " [", d.ip, "] port ", itoa(d.port), NULL);
		net.irc.close("changing servers");
		ME.connectToIRC(&d);
	}

	return 1;
}

void client::inviteRaw(char *str)
{
	char arg[3][MAX_LEN];

	str2words(arg[0], str, 3, MAX_LEN, 0);

	if(!strcmp(arg[0], "INVITE"))
	{
		chan *ch = ME.findChannel(arg[2]);
		if(ch && !ch->getUser(arg[1]))
			ch->invite(arg[1]);
	}
}

void client::registerWithNewNick(char *nick)
{
	if(magicNickCreator(nick)) net.irc.send("NICK ", nick, NULL);
	else
	{
		logfile.send("[*] Cannot generate alternative nick for ", nick, NULL);
		sleep(90);
	}
}

void client::rejoin(char *name, int t)
{
	int i;

	i = userlist.findChannelInList(name);
	if(i != -1)
	{
		userlist.chanlist[i].nextjoin = NOW + t;
		userlist.chanlist[i].joinsent = 0;
	}
}

void client::rejoinCheck()
{
	int i;
	if(!(net.irc.status & STATUS_REGISTERED)) return;
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(userlist.chanlist[i].name && userlist.chanlist[i].nextjoin <= NOW && !userlist.chanlist[i].joinsent)
		{
			if(!ME.findNotSyncedChannel(userlist.chanlist[i].name))
			{
				if(strlen(userlist.chanlist[i].pass)) net.irc.send("JOIN ", userlist.chanlist[i].name, " ", userlist.chanlist[i].pass, NULL);
				else net.irc.send("JOIN ", userlist.chanlist[i].name, NULL);
				userlist.chanlist[i].joinsent = 1;
			}
		}
	}
}

void client::scheludeJoinToAllChannels()
{
	int i, j;

	for(i=j=0; i<MAX_CHANNELS; i++)
	{
		if(userlist.chanlist[i].name)
		{
			userlist.chanlist[i].nextjoin = j*10 + NOW + 2;
			userlist.chanlist[i].joinsent = 0;
			j++;
		}
	}
}

void client::gotNickChange(char *from, char *to)
{
	char *a = strchr(from, '!');
	char *fromnick;
	chan *p = first;

	mem_strncpy(fromnick, from, abs(a - from) + 1);
	DEBUG(printf("[*] NICK change %s <-> %s\n", fromnick, to));
	while(p)
	{
		if(p->synced()) p->gotNickChange(fromnick, to);
		p = p->next;
	}
	if(!strcmp(ME.nick, fromnick))
	{
		free(ME.nick);
		free(ME.mask);
		mem_strcpy(ME.nick, to);
		ME.mask = push(NULL, ME.nick, "!", ME.ident, "@", ME.host, NULL);

		net.propagate(NULL, S_CHNICK, " ", config.nick , " ", to, NULL);
		net.send(OWNERS, "[*] I am known as ", to, NULL);
	}
	free(fromnick);
}

#ifdef HAVE_DEBUG
void client::display()
{
	chan *p;

	p = first;

	printf("### Channels:\n");
	while(1)
	{
		if(!p) break;
		printf("### '%s'\n", p->name);
		p = p->next;
	}
}
#endif

void client::recheckFlags()
{
	chan *ch = ME.first;

	while(ch)
	{
		if(ch->synced()) ch->recheckFlags();
		ch = ch->next;
	}
}

void client::recheckFlags(char *channel)
{
	chan *ch = findChannel(channel);
	if(ch) ch->recheckFlags();
}

int client::connectToHUB()
{
	int fd;

	logfile.send("[*] Connecting to HUB: ", config.hubhost, " port ", itoa(config.hubport), NULL);
	fd = doConnect(config.hubhost, config.hubport, config.myipv4, -1);

	if(fd > 0)
	{
		net.hub.fd = fd;
		net.hub.status = STATUS_SYNSENT;
		net.hub.killTime = set.CONN_TIMEOUT + NOW;
		return fd;
	}
	return -1;
}

int client::connectToIRC(SERVER *s)
{
	int i, n, num;

	if(!s)
	{
		//count servers
		for(num=i=0; i<MAX_SERVERS; i++)
			if(config.server[i].host) ++num;

		if(!num) return 0;

		i = rand() % num;
		if(i >= num) return 0;
		s = &config.server[i];
	}

	logfile.send("[*] Connecting to IRC: ", s->host, "[", s->ip, "] port ", itoa(s->port), NULL);
#ifdef HAVE_IPV6
	if(strchr(s->ip, ':'))
		n = doConnect6(s->ip, s->port, config.vhost, -1);
	else
#endif
		n = doConnect(s->ip, s->port, config.vhost, -1);
	if(n > 0)
	{
			memset(&net.irc, 0, sizeof(inetconn));
			net.irc.fd = n;
			net.irc.status = STATUS_SYNSENT;
			net.irc.killTime = set.AUTH_TIME + NOW;
			return n;
	}
	else
	{
		logfile.send("[-] Couldn't connect to IRC: ", strerror(errno), NULL);
	}
	return 0;
}

/* FIXME: is this queue lame? */
void client::checkQueue()
{
	if(penality >= 3) return;
	chan *ch = first;
	int j;
	CHANUSER **MultHandle;

	while(ch)
	{
		if(ch->synced())
		{
			if(!(ch->ptr->flags & IS_OP))
			{
				if(ch->initialOp <= NOW - set.ASK_FOR_OP_DELAY && ch->initialOp)
				{
					ch->requestOp();
					ch->initialOp = NOW + set.ASK_FOR_OP_DELAY;
				}
			}
			else
			{
				if(ch->toKick.ent)
				{
					MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*6);
					j = getRandomItems(MultHandle, ch->toKick.first, ch->toKick.ent, 6);
					ch->kick4(MultHandle, j);
					free(MultHandle);
					return;
				}
				else ch->updateLimit();
			}
			ch->wasop->expire();
		}
		ch = ch->next;
	}

	/* if nothing to do, gather channel informations */
	ch = first;
	while(ch && !penality)
	{
		if(!ch->toKick.ent)
		{
			switch(ch->synlevel)
			{
				case 1: net.irc.send("MODE ", ch->name, NULL); penality++; ch->synlevel++; break;
				case 3: net.irc.send("MODE ", ch->name, " b", NULL); penality++; ch->synlevel++; break;
				case 5: net.irc.send("MODE ", ch->name, " e", NULL); penality++; ch->synlevel++; break;
				case 7: net.irc.send("MODE ", ch->name, " I", NULL); penality++; ch->synlevel++; break;
				default: break;
			}
		}
		ch = ch->next;
	}
}

void client::gotUserQuit(char *mask, char *reason)
{
	char *a, *nick;
	chan *ch = first;
	int netsplit = reason && wasoptest::checkSplit(reason);

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);

	while(ch)
	{
		if(ch->synced()) ch->gotPart(nick, netsplit);
		ch = ch->next;
	}
	free(nick);
}

void client::removeChannel(char *name)
{
	chan *ch = first;
	int n;

	if(!channels) return;

	if(!strcasecmp(first->name, name))
	{
		first = first->next;
		if(first) first->prev = NULL;
		delete(ch);
		--channels;
		if(!channels) last = NULL;
	}
	else if(!strcasecmp(last->name, name))
	{
		ch = last->prev;
		ch->next = NULL;
		delete(last);
		--channels;
		last = ch;
	}
	else
	{
		ch = first->next;
		while(ch)
		{
			if(!strcasecmp(ch->name, name))
			{
				ch->prev->next = ch->next;
				if(ch->next) ch->next->prev = ch->prev;
				delete(ch);
				--channels;
			}
			ch = ch->next;
		}
	}
	current = first;

	n = userlist.findChannelInList(name);
	if(n != -1) userlist.chanlist[n].joinsent = 0;
}

chan *client::findNotSyncedChannel(char *name)
{

	if(current)
		if(!strcasecmp(current->name, name)) return current;

	current = first;
	while(current)
	{
		if(!strcasecmp(current->name, name)) return current;
		current = current->next;
	}
	return NULL;
}

chan *client::findChannel(char *name)
{

	if(current)
		if(!strcasecmp(current->name, name) && current->synced()) return current;

	current = first;
	while(current)
	{
		if(current->synced() && !strcasecmp(current->name, name)) return current;
		current = current->next;
	}
	return NULL;
}


chan *client::createNewChannel(char *name)
{
	int n;
	if(!channels)
	{
		first = current = last = new(chan);
		current->prev = current->next = NULL;
		mem_strcpy(current->name, name);
	}
	else
	{
		current = last->next = new(chan);
  		current->prev = last;
		current->next = NULL;
		mem_strcpy(current->name, name);
		last = current;
	}

	n = userlist.findChannelInList(name);
	if(n != -1)
	{
		userlist.chanlist[n].joinsent = 0;
		current->chset = userlist.chanlist[n].chset;
		current->wasop = userlist.chanlist[n].wasop;
		current->channum = n;
		if(userlist.chanlist[n].allowedOps &&
			userlist.chanlist[n].allowedOps->since + 60 < NOW)
		{
			delete userlist.chanlist[n].allowedOps;
			userlist.chanlist[n].allowedOps = NULL;
		}
	}

	++channels;
	return current;
}

/* Constructor */
client::client()
{
	NOW = time(NULL);
	first = last = current = NULL;
	channels = nextconn_hub = nextconn_serv = 0;
	ident = host = mask = NULL;
	NextNickCheck = 0;
	startedAt = NOW;
	mem_strcpy(ME.nick, "");
}

/* Destruction derby */
client::~client()
{
	chan *ch = first;
	chan *p;

	while(ch)
	{
		p = ch;
		ch = ch->next;
		delete(p);
	}

	if(nick) free(nick);
	if(ident) free(ident);
	if(host) free(host);
	if(mask) free(mask);
	mem_strcpy(ME.nick, "");
}

void client::reset()
{
	this->~client();

	first = last = current = NULL;
	channels = 0;
	ident = host = mask = NULL;
	NextNickCheck = 0;
}
