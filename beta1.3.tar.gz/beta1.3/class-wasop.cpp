/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"


/* entry */
wasoptest::entry::entry(char *n, char *i, char *h)
{
	char *tmp = push(NULL, n, "!", i, "@", h, NULL);
	entry(tmp, 0);
}

wasoptest::entry::entry(char *m, int alloc)
{
	if(alloc) mem_strcpy(mask, m);
	else mask = m;
	when = NOW;
}

wasoptest::entry::~entry()
{
	free(mask);
}

wasoptest::wasoptest(int life)
{
	since = NOW;
	TOL = life;
	data = ptrlist<entry>(1);
}

/* add */
int wasoptest::add(CHANUSER *p)
{
	add(p->nick, p->ident, p->host);
	return data.ent;
}

int wasoptest::add(char *nick, char *ident, char *host)
{
	add(push(NULL, nick, "!", ident, "@", host, NULL), 0);
	return data.ent;
}

int wasoptest::add(char *mask, int alloc)
{
	data.addLast(new entry(mask, alloc));
	DEBUG(printf("### add@: %s\n", mask));
	return data.ent;
}

int wasoptest::remove(CHANUSER *user)
{
	return remove(user->nick, user->ident, user->host);
}

int wasoptest::remove(char *nick, char *ident, char *host)
{
	char *mask = push(NULL, nick, "!", ident, "@", host, NULL);
	int ret = remove(mask);
	free(mask);
	return ret;
}

int wasoptest::remove(char *mask)
{
	PTRLIST<entry> *p = data.first;

	while(p)
	{
		if(!strcmp(p->ptr->mask, mask))
		{
			data.remove(p->ptr);
			return 1;
		}
		p = p->next;
	}
	return 0;
}

int wasoptest::checkSplit(char *str)
{
	char arg[2][MAX_LEN];
	str2words(arg[0], str, 2, MAX_LEN);

	if(match("*.* *.*", str) && strlen(arg[0]) + strlen(arg[1]) + 1 == strlen(str))
		return 1;
	else return 0;
}

void wasoptest::expire()
{
	PTRLIST<entry> *q, *p = data.first;

	while(p)
	{
		if(p->ptr->when + TOL <= NOW)
		{
			q = p->next;
			data.remove(p->ptr);
			p = q;
		}
		else p = p->next;
	}
}



