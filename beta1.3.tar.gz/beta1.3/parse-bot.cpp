/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_bot(inetconn *c, char *data)
{
	char arg[10][MAX_LEN];
	char *reason = NULL;

	if(!strlen(data)) return;
	str2words(arg[0], data, 10, MAX_LEN);

	/* REGISTER CONNECTION */
	if(!(c->status & STATUS_REGISTERED))
	{
		switch(c->tmpint)
		{
			case 1:
			{
				if(!strcmp(arg[0], config.botnetword) && userlist.isBot(c->getIp()))
				{
					c->tmpstr = (char *) malloc(AUTHSTR_LEN + 1);
					++c->tmpint;
					MD5CreateAuthString(c->tmpstr, AUTHSTR_LEN);
					c->send(c->tmpstr, NULL);
					return;
				}
				/* maybe that's owner */
				if(config.bottype == BOT_MAIN && config.ownerpass && set.TELNET_OWNERS && MD5HexValidate(config.ownerpass, arg[0], strlen(arg[0]), 0, 0))
				{
                    c->status = STATUS_CONNECTED | STATUS_OWNER | STATUS_TELNET;
					c->tmpint = 1;
					c->killTime = NOW + set.AUTH_TIME;
					if(set.creation)
					{
						c->send("Welcome ", c->getIpName(), " to the constructor", NULL);
						write(c->fd, "new login: ", strlen("new login: "));
					}
					else
					{
						c->send("Welcome ", c->getIpName(), NULL);
						write(c->fd, "login: ", strlen("login: "));
					}
					return;
				}
				reason = push(NULL, "telnet creep", NULL);
				break;
			}
			case 2:
			{
				if(strlen(arg[1]))
				{
					struct sockaddr_in peer;
					HANDLE *h = userlist.findHandle(arg[0]);

					if(h && net.findConn(h))
					{
                        reason = push(NULL,  arg[0], ": dublicate connection",NULL);
						break;
					}
					if(h && config.bottype == BOT_MAIN && !userlist.isSlave(h))
					{
						reason = push(NULL, arg[0], ": not a slave", NULL);
						break;
					}

					if(h && config.bottype == BOT_SLAVE && !userlist.isLeaf(h))
					{
						reason = push(NULL, arg[0], ": not a leaf", NULL);
						break;
					}

					socklen_t peersize = sizeof(struct sockaddr_in);
                    getpeername(c->fd, (sockaddr *) &peer, &peersize);

                    if(!h)
                    {
						reason = push(NULL, arg[0], ": not a bot", NULL);
                    	break;
					}
                    if(!h->pass)
                    {
						reason = push(NULL, arg[0], ": no password set", NULL);
						break;
					}
					if(peer.sin_addr.s_addr == h->ip && h->ip)
					{
   						if(MD5HexValidate(arg[1], c->tmpstr, strlen(c->tmpstr), h->pass, strlen(h->pass)))
						{
							++c->tmpint;
							c->handle = h;
							free(c->tmpstr);
							c->tmpstr = NULL;
							return;
						}
						else
						{
							reason = push(NULL, arg[0], ": wrong botpass", NULL);
                        	break;
						}
					}
					else
					{
						reason = push(NULL, arg[0], ": invalid botip", NULL);
                    	break;
					}
				}
				break;
			}
			case 3:
			{
				if(strlen(arg[0]))
				{
					char hash[33];

					++c->tmpint;
					MD5HexHash(hash, arg[0], AUTHSTR_LEN, c->handle->pass, strlen(c->handle->pass));
					c->send(config.handle, " ", userlist.first->next->creation->print(), " ", hash, NULL);
					return;
				}
				break;
			}
			case 4:
			{
				/* S_REGISTER <S_VERSION> <userlist.SN> [ircnick] */
				if(!strcmp(arg[0], S_REGISTER) && strlen(arg[2]))
				{
					if(strcmp(arg[1], S_VERSION))
					{
						reason = push(NULL, arg[0], ": wrong version - ", arg[1], NULL);
						break;
					}

					mem_strcpy(c->name, arg[3]);
					c->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_BOT;
					c->tmpint = 0;
					c->killTime = NOW + set.CONN_TIMEOUT;
					c->lastPing = NOW;

					c->send(S_REGISTER, " ", ME.nick, NULL);

					c->enableCrypt((unsigned char*) c->handle->pass, strlen(c->handle->pass));

					/* update ul */
					if(userlist.SN != strtoull(arg[2], NULL, 10))
					{
						net.send(OWNERS, "[*] ", c->handle->name, " is linked (sending userlist)", NULL);
						userlist.send(c);
					}
					else net.send(OWNERS, "[+] ", c->handle->name, " is linked and operational", NULL);


					/* send list of bots */
					net.sendBotListTo(c);
					net.propagate(c, S_BJOIN, " ", c->handle->name, " ", c->name, NULL);
					return;
				}
				break;
			}
			default: break;
		}
		/* HUH */
		if(!reason) reason = push(NULL, "Unknown error", NULL);
		c->close(reason);
		free(reason);
		return;
	}

	/* PARSE DATA FROM REGISTERED BOT */
	c->killTime = NOW + set.CONN_TIMEOUT;

	//OREDIR FROM TO [?] MSG
	if(!strcmp(arg[0], S_OREDIR) && strlen(arg[4]) && config.bottype == BOT_MAIN)
	{
		 char *a = srewind(data, 3);
		 if(a)
		 net.sendOwner(arg[2], "(", arg[1], ") ", a, NULL);
		 return;
	}
	if(!strcmp(arg[0], S_ULOK))
	{
		net.send(OWNERS, "[+] ", c->handle->name, " is operational", NULL);
		return;
	}

	parse_botnet(c, data);
}
