extern time_t NOW;
extern client ME;
extern settings set;
extern ul userlist;
extern CONFIG config;
extern char *thisfile;
extern inet net;
extern inetconn logfile;
extern penal penality;
extern EXPANDINFO expandinfo;
extern ign ignore;
extern fifo ctcp;
extern fifo invite;
extern QTIsaac<8, int> Isaac;
extern idle antiidle;
extern unit_table ut_time[];
extern unit_table ut_perc[];

#ifdef HAVE_TCL
extern tcl tclparser;
#endif

