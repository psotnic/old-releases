/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

char __port[16];

/* Network Connection Handling */

inet::inet()
{
	conn = (inetconn *) malloc(sizeof(inetconn));
	memset(&conn[0], 0, sizeof(inetconn));
	max_conns = 1;
	conns = maxFd = 0;
}

inet::~inet()
{
	free(conn);
	conn = NULL;
}

void inet::resize()
{
	if(max_conns <= conns + 1)
	{
		int size = max_conns * 2;
		int i;

		conn = (inetconn *) realloc(conn, size*sizeof(inetconn));
		for(i=max_conns; i<size; ++i) memset(&conn[i], 0, sizeof(inetconn));
		max_conns = size;
		DEBUG(printf("max_conns(up): %d\n", max_conns));

	}
	else if(conns == max_conns / 4 && conns > 4)
	{
		int size = max_conns / 2;

		inetconn *old = conn;
		conn = (inetconn *) malloc(size*sizeof(inetconn));
		int i, j;

		for(i=j=0; i<max_conns; ++i)
		{
			if(old[i].fd)
			{
				memcpy(&conn[j], &old[i], sizeof(inetconn));
				++j;
			}
		}
		for(; j<size; ++j)
			memset(&conn[j], 0, sizeof(inetconn));

		free(old);
		max_conns = size;

		DEBUG(printf("max_conns(down): %d\n", max_conns));
	}
}


inetconn *inet::addConn(int fd)
{
	int i;

	if(fd < 1) return NULL;

	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].fd < 1)
		{
			memset(&conn[i], 0, sizeof(inetconn));
			conn[i].fd = fd;
			conn[i].status = STATUS_CONNECTED;
			++conns;
	        if(fd > maxFd) maxFd = fd;
            return &conn[i];
        }
    }
	return NULL;
}

/* connection can only have name when is registered, so this function returns only
   registered connections */
inetconn *inet::findConn(char *name)
{
	int i;

	if(!conn) return NULL;

	if(hub.fd > 0 && hub.name) if(!strcmp(hub.name, name)) return &hub;
	for(i=0; i<max_conns; ++i)
		if(conn[i].fd > 0 && conn[i].name && !strcmp(conn[i].name, name)) return &conn[i];
	return NULL;
}

inetconn *inet::findConn(HANDLE *h)
{
	int i;
    if(!conn || !h) return NULL;

	if(hub.handle == h && h) return &hub;
	for(i=0; i<max_conns; ++i)
		if(conn[i].handle == h && h) return &conn[i];
	return NULL;
}

int inet::closeConn(inetconn *c, char *reason)
{
	int i, pos, fd, red, ret;

	if(!c) return 0;

	fd = c->fd;
	red = c->status & STATUS_REDIR;

	/* is this right connection? */
	pos = abs(c - &conn[0]);

	DEBUG(printf("pos: %d\n", pos));

	if(pos >= 0 && pos < max_conns)
	{
		/* close given connection */
		if(c->isRegBot()) net.propagate(c, S_BQUIT, " ", c->name, NULL);
		DEBUG(printf("kill: %s\n", c->name));
		c->_close(reason);
		--conns;
		ret = 1;
	}
	else ret = 0;

	/* close redir conns */
	if(!red)
	{
		for(i=max_conns-1; i != -1; --i)
		{
			if(conn[i].fd == fd)
			{
				if(conn[i].isRegBot()) net.propagate(&conn[i], S_BQUIT, " ", conn[i].name, NULL);
				DEBUG(printf("red kill: %s\n", conn[i].name));
				conn[i]._close(reason);
				--conns;
			}
		}
	}
	return ret;
}

void inet::sendexcept(int excp, int who, char *lst, ...)
{
	va_list ap;
	int i;

	va_start(ap, lst);

	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].fd > 0 && conn[i].status & STATUS_REGISTERED && conn[i].status & who
		 && !(conn[i].status & STATUS_REDIR) && conn[i].fd != excp) conn[i].va_send(ap, lst);
	}
	if(hub.fd && hub.fd != excp && hub.isRegBot()) net.hub.va_send(ap, lst);
	va_end(ap);
}

void inet::sendOwner(char *who, char *lst, ...)
{
	va_list ap;
	va_start(ap, lst);

	if(!who) return;

	if(config.bottype != BOT_MAIN)
	{
		HANDLE *h = userlist.first->next->next;

        while(h)
        {
			if(userlist.isMain(h))
            {
                inetconn *c = findConn(h);
				if(c)
				{
					char *str = va_push(NULL, ap, lst, va_getlen(ap, lst) + 1);
					c->send(S_OREDIR, " ", userlist.first->next->name, " ", who, " ", str, NULL);
					free(str);
				}
    		}
      		h = h->next;
    	}
	}
	else
	{
		for(int i=0; i<max_conns; ++i)
			if(conn[i].isRegOwner() && match(who, net.conn[i].handle->name))
				conn[i].va_send(ap, lst);
	}
}

void inet::send(int who, char *lst, ...)
{
	va_list ap;
	int i;

	va_start(ap, lst);

	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].fd > 0 && conn[i].status & STATUS_REGISTERED && conn[i].status & who
		 && !(conn[i].status & STATUS_REDIR)) conn[i].va_send(ap, lst);
	}

	//owners
	if(who == OWNERS && config.bottype != BOT_MAIN)
	{
		char *str = va_push(NULL, ap, lst, va_getlen(ap, lst) + 1);
		sendOwner("*", str, NULL);
		free(str);
	}
}

void inet::sendBotListTo(inetconn *c)
{
	int i;

	if(c)
	{
		for(i=0; i<max_conns; ++i)
		{
			if(&conn[i] != c && conn[i].isRegBot())
			{
				c->send(S_BJOIN, " ", conn[i].handle->name, " ", conn[i].name, NULL);
			}
		}
		if(net.hub.fd && c != &net.hub && net.hub.isRegBot()) c->send(S_BJOIN, " ", hub.handle->name, " ", hub.name, NULL);
	}
}

void inet::sendBotJoin(inetconn *c)
{
	if(c)
	{
		net.sendexcept(c->fd, FD_BOTS, S_BJOIN, " ", c->handle->name, " ", c->name, NULL);
	}

}

void inet::propagate(inetconn *from, char *str, ...)
{
	va_list ap;
	char *p;

	va_start(ap, str);
	p = va_push(NULL, ap, str, va_getlen(ap, str) + 1);
	va_end(ap);

	net.sendexcept(from ? from->fd : 0, FD_BOTS, p, NULL);
	free(p);

}

#ifdef HAVE_DEBUG
void inet::display()
{
	int i;

	if(hub.fd) printf("hub: %s\n", hub.name);
	for(i=0; i<max_conns; ++i)
		if(conn[i].fd > 0) printf("conn[%d]: %s\n", i, conn[i].name);
}
#endif

inetconn *inet::findRedirConn(inetconn *c)
{
	int i;

	for(i=0; i<max_conns; ++i)
	{
		if(conn[i].fd == c->fd && conn[i].isRegBot() && !(conn[i].status & STATUS_REDIR))
			return &conn[i];
	}
	if(hub.fd == c->fd && hub.isRegBot()) return &hub;

	return NULL;
}

int inet::bidMaxFd(int fd)
{
	if(fd > maxFd) maxFd = fd;
	return maxFd;
}


/*
 *
 * Specific Internet Connection Handling
 *
 */

inetconn::inetconn()
{
	memset(this, 0, sizeof(inetconn));
}

inetconn::~inetconn()
{
	if(status & STATUS_FILE) _close();
}

void inetconn::close(char *reason)
{
	if(fd > 0)
	{
		if(!net.closeConn(this, reason)) _close(reason);
  	}
	if(blowfish)
	{
		delete blowfish;
		blowfish = NULL;
	}
}

void inetconn::_close(char *reason)
{
	/* no sense of killing nothing */
	if(!fd) return;
	int killhim = !(status & STATUS_REDIR);

	if(!(status & STATUS_FILE))
	{
		if(this == &net.irc)
		{
			if(status & STATUS_REGISTERED)
			{
				net.send(OWNERS, "[-] Disconneced from server ", net.irc.name, " (", reason, ")", NULL);
				logfile.send("[-] Disconneced from server ", net.irc.name, " (", reason, ")", NULL);
				net.propagate(NULL, S_CHNICK, " ", config.handle, NULL);
			}
			if(status & STATUS_KLINED)
			{
				net.send(OWNERS, "[-] I am K-lined on ", net.irc.name, " (", reason, ")", NULL);
				logfile.send("[-] I am K-lined on ", net.irc.name, " (", reason, ")", NULL);
			}
			ME.reset();
		}
		else if (this == &net.hub)
		{
			if(net.hub.status &  STATUS_REGISTERED)
			{
				logfile.send("[-] Disconnected from HUB: ", reason, NULL);
				net.propagate(&net.hub, S_BQUIT, " ", net.hub.handle->name, NULL);
			}
			else logfile.send("[-] Cannot establish connection to HUB: ", reason, NULL);
		}
		else
		{
			logfile.send("[*] Closing net.conn[", itoa(this - &net.conn[0]), "] ", handle ? handle->name : "anonymous", " - ", reason, NULL);

			if(status & STATUS_REGISTERED)
			{
				if(status & STATUS_OWNER)
				{
					net.send(OWNERS, "[*] ", handle->name, " has left the partyline (", reason, ")", NULL);
				}
				else if(status & STATUS_BOT)
				{
					if(!(status & STATUS_REDIR)) net.send(OWNERS, "[-] Lost connection to ", handle->name, " (", reason, ")", NULL);
				}
			}
			else if(!(status & STATUS_SILENT)) net.send(OWNERS, "[-] Lost ", getIpName(), " / ", getPortName(), " (", reason, ")", NULL);
		}
	}

	if(read.buf) free(read.buf);
	if(write.buf) free(write.buf);
	if(name) free(name);
	if(tmpstr) free(tmpstr);
	if(fd && killhim) killSocket(fd);
	if(blowfish) delete blowfish;
	memset(this, 0, sizeof(inetconn));
}

int inetconn::va_send(va_list ap, char *lst)
{
	int size = va_getlen(ap, lst) + 3;
	char *p, *q;
	inetconn *conn = status & STATUS_REDIR ? net.findRedirConn(this) : this;

#ifdef HAVE_DEBUG
	if(set.debug)
	{
		if(!conn)
		{
			printf("### class inet is broken\n");
			printf("### info this->name: %s\n", name);
			printf("### exit(1)\n");
			exit(1);
		}

		if(conn->fd < 1)
		{
			printf("### %s|%s: bad fd\n", config.handle, conn->name);
        	conn->close("Bad file descryptor");
			return 0;
		}
	}
#endif

	p = va_push(NULL, ap, lst, size);
	size = strlen(p) + 3;

	if(status & STATUS_REDIR)
	{
		q = push(NULL, S_REDIR, " ", handle->name, " ", p, "###", NULL);
		free(p);
		p = q;
		size = strlen(p);
	}

	if(conn == &net.irc)
	{
		p[size-3] = '\r';
		p[size-2] = '\n';
		p[size-1] = '\0';
		--size;
	}
	else
	{
		p[size-3] = '\n';
		p[size-2] = '\0';
		size -= 2;
	}

	if(conn->blowfish)
	{
		char *blowbuf = (char *) malloc(size + 8);
		char *tmp = (char *) malloc(size + 8);
		memset(tmp, 0, size + 8);
		strcpy(tmp, p);
		free(p);
		p = tmp;
		size = conn->blowfish->Encode((unsigned char *) p, (unsigned char *) blowbuf, size);
		DEBUG(printf("[C] send[%s]: %s", conn->name, p));
		free(p);
		p = blowbuf;
	}
	else
	{
		DEBUG(printf("[*] send[%s]: %s", conn->name, p));
	}

	if(conn->write.buf)
	{
		conn->write.buf = (char *) realloc(conn->write.buf, conn->write.len + size);
		memcpy(conn->write.buf + conn->write.len, p, size);
		conn->write.len += size;

	}
	else
	{

		int n = ::write(conn->fd, p, size);
		if(n == -1) n = 0;
		if(n != size)
		{

			conn->write.len = size-n;
			conn->write.pos = 0;
			conn->write.buf = (char *) malloc(size-n);
			memcpy(conn->write.buf, p+n, size-n);

		}
	}

	free(p);
	return size;
}

int inetconn::send(char *lst, ...)
{
    va_list ap;
	int n;

	va_start(ap, lst);
	n = va_send(ap, lst);
	va_end(ap);
	return n;
}

int inetconn::readln(char *buf, int len)
{
	int n, i;

	if(::read(fd, buf, 1) > 0)
	{
		if(blowfish && !blowfish->smartDecode(buf[0], buf))	return 0;
		//else if(blowfish) printf("buf: %s\n", buf);

		for(i=0; i< (blowfish ? 8 : 1); ++i)
		{
			if(buf[i] == '\n' || buf[i] == '\0')
			{
				if(read.buf)
				{
					da_end:
					n = read.len;
					strncpy(buf, read.buf, n);
					if(n && buf[n-1] == '\r') buf[n-1] = '\0';
					else buf[n] = '\0';
					free(read.buf);
					memset(&read, 0, sizeof(read));
				}
				else
				{
					n = 1;
					buf[1] = '\0';
				}
				DEBUG(printf("[%c] read[%s]: %s\n", blowfish ? 'C' : '*', name, buf));
				return n;
			}
			else
			{
				if(!read.buf)
				{
					read.buf = (char *) malloc(len);
					read.buf[0] = buf[i];
					read.len = 1;
				}
				else
				{
					read.buf[read.len++] = buf[i];
					if(read.len == MAX_LEN - 1)
					{
						//buffer overflow attempt
						//free(read.buf);
						//memset(&read, 0, sizeof(read));
						logfile.send("[!] Buffer overflow attempt from: ", getIpName(), " / " , getPortName(), NULL);
						return -1;
					}
				}
			}
		}
		return 0;
	}
	else if(read.buf) goto da_end;

	return -1;
}

int inetconn::checkFlag(int flag)
{
	if(handle) return handle->flags[MAX_CHANNELS] & flag;
	return 0;
}

int inetconn::isRegBot()
{
	return (status & STATUS_BOT) && (status & STATUS_REGISTERED);
}

int inetconn::isRegOwner()
{
	return (status & STATUS_OWNER) && (status & STATUS_REGISTERED);
}

int inetconn::sendPing()
{
	if(!(status & STATUS_REDIR) && (status & STATUS_REGISTERED) && lastPing && NOW - lastPing > set.CONN_TIMEOUT / 2)
	{
		if(this == &net.irc) send("ison ", ME.nick, NULL);
		else send(S_FOO, NULL);
		lastPing = NOW;
		return 1;
	}
	return 0;
}

int inetconn::timedOut()
{
	if(status & STATUS_REDIR) return 0;
	if(killTime && killTime <= NOW)
	{
		close("Ping timeout");
		return 1;
	}
	sendPing();
	return 0;
}

int inetconn::enableCrypt(unsigned char *key, int len)
{
	if(blowfish || fd < 1) return 0;
	blowfish = new CBlowFish;

	if(len == -1) len = strlen((char *) key);
	if(len > 16) blowfish->Initialize(key, len);
	else
	{
		unsigned char digest[16];
		MD5Hash(digest, (char *) key, len);
    	blowfish->Initialize(digest, len);
	}
	return 1;
}

int inetconn::disableCrypt()
{
	if(blowfish)
	{
		delete blowfish;
		blowfish = NULL;
    	return 1;
	}
	else return 0;
}

char *inetconn::getIpName()
{
	return inet2char(getIp());
}

char *inetconn::getPortName()
{
	return itoa(getPort());
}

unsigned int inetconn::getIp()
{
	if(fd > 0)
	{
		struct sockaddr_in peer;
		#ifdef _NO_LAME_ERRNO
		int ret, e = errno;
		#endif
		socklen_t peersize = sizeof(struct sockaddr_in);
		ret = getpeername(fd, (sockaddr *) &peer, &peersize);
		#ifdef _NO_LAME_ERRNO
		errno = e;
		#endif
		if(ret == -1) return 0;
		else return peer.sin_addr.s_addr;
	}
	else return 0;
}

int inetconn::getPort()
{
    if(fd > 0)
    {
		struct sockaddr_in peer;
		#ifdef _NO_LAME_ERRNO
		int ret, e = errno;
		#endif
		socklen_t peersize = sizeof(struct sockaddr_in);
		ret = getpeername(fd, (sockaddr *) &peer, &peersize);
		#ifdef _NO_LAME_ERRNO
		errno = e;
		#endif
		if(ret == -1) return 0;
		else return ntohs(peer.sin_port);
	}
	else return 0;
}

int inetconn::open(const char *pathname, int flags, mode_t mode)
{
	if(mode) fd = ::open(pathname, flags, mode);
	else fd = ::open(pathname, flags);

	if(fd > 0)
	{
		status = STATUS_FILE;
		mem_strcpy(name, getFileName((char *) pathname));
	}
	return fd;
}

int inetconn::enableLameCrypt()
{
	struct stat info;

	if(blowfish || fd < 1) return 0;

	if(!fstat(fd, &info))
	{
		blowfish = new CBlowFish;
		long long int hash = info.st_dev + info.st_ino;
		unsigned char digest[16];
		MD5Hash(digest, (char *) &hash, sizeof(hash), name, strlen(name));
    	blowfish->Initialize(digest, 16);
		return 1;
	}
	return 0;
}

int inetconn::isSlave()
{
	return (handle ? ul::isSlave(handle) : 0);
}

int inetconn::isLeaf()
{
	return (handle ? ul::isLeaf(handle) : 0);
}

int inetconn::isMain()
{
	return (handle ? ul::isMain(handle) : 0);
}

int inet::bots()
{
	int num = 0;

	for(int i=0; i<max_conns; ++i)
		if(conn[i].isRegBot()) ++num;

	return num;
}

int inet::owners()
{
	int num = 0;

	for(int i=0; i<max_conns; ++i)
		if(conn[i].isRegOwner()) ++num;

	return num;
}

//synchronious lookup
int inet::gethostbyname(char *host, char *buf)
{
	struct hostent *h = gethostbyname2(host, AF_INET);
	if(h)
	{
		strcpy(buf, inet_ntoa(* (struct in_addr *) h->h_addr));
		return 1;
	}
	return 0;
}

void inetconn::lock()
{
	pthread_mutex_lock(&mutex);
}

void inetconn::unlock()
{
	pthread_mutex_unlock(&mutex);
}

//void th_getMyRev(void *ptr)
//{


