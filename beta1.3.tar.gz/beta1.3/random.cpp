/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void randstr(char *str, int n)
{
	int i;
	srand();
	for(i=0; i<n; ++i) str[i] = rand() % 100 + 32;
}

int getRandomItems(CHANUSER **ret, PTRLIST<CHANUSER> *start, int interval, int num)
{
	if(!start) return 0;
	int i, k, *arr = new int[num];
	PTRLIST<CHANUSER> *p = start;

	num = getRandomNumbers(interval, arr, num);

	for(k=0; p; ++k)
	{
		for(i=0; i<num; ++i)
			if(arr[i] == k)
				*(ret++) = p->ptr;
		p = p->next;
	}

	delete [] arr;
	return num;
}

int getRandomNumbers(int top, int *ret, int num)
{
    int i, k;
	char *t = new char[top];

	memset(t, 0, top);

    if(num > top) num = top;
    for(i=0; i<num; )
    {
        k = rand() % top;
   		if(t[k]) continue;
		t[k] = 1;
		++i;
    }

	for(i=k=0; k<top; ++k)
		if(t[k]) ret[i++] = k;

	delete [] t;
	return num;
}


void srand(int a, int b, int c)
{
	if(!a && !b && !c)
		Isaac.srand(nanotime(), hash32(config.handle), 0);
	else Isaac.srand(a, b, c);
}

int rand()
{
	return abs(Isaac.rand());
}
