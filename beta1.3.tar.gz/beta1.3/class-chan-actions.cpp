/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

/* STRANGE ACTIONS */
void chan::updateLimit()
{
	char buf[MAX_LEN];
	int tolerance;

	if(nextlimit == -1) return;
	if(chset->LIMIT_TOLERANCE > 0) tolerance = chset->LIMIT_TOLERANCE;
	else tolerance = (chset->LIMIT_TOLERANCE * chset->LIMIT_OFFSET)/(-100);

	if(chset->LIMIT && nextlimit <= NOW && ptr->flags & IS_OP &&
		myTurn(chset->LIMIT_BOTS))
	{
		if((limit <= users + chset->LIMIT_OFFSET - tolerance) ||
			(limit > users + chset->LIMIT_OFFSET + tolerance))
		{
			sprintf(buf, "%d", users + chset->LIMIT_OFFSET);
			net.irc.send("MODE ", name, " +l ", buf, NULL);
			penality++;
		}
		nextlimit = NOW + chset->LIMIT_TIME * chset->LIMIT_BOTS;

		CHANUSER *p = first;

		while(p)
		{
			unset(p->flags, NET_JOINED);
			p = p->next;
		}
	}
}

void chan::enforceLimits()
{
	if(chset->ENFORCE_LIMITS && limit)
	{
		int n = users - limit;
		CHANUSER *u = last;

		if(n > 0)
		{
			while(n && u)
			{
				if(!(u->flags & HAS_F))
				{
					toKick.sortAdd(u);
					--n;
				}
				u = u->prev;
			}
		}
	}
}

/* MULTIUSER ACTIONS */
int chan::massKick(int who)
{
	CHANUSER *u = first;
	int i = 0;

	while(u)
	{
		if(!(u->flags & HAS_F))
		{
			if((who & MK_OPS && u->flags & IS_OP) || (who & MK_NONOPS && !(u->flags & IS_OP)))
			{
				toKick.sortAdd(u);
				++i;
			}
		}
		u = u->next;
	}
	return i;
}

int chan::op(CHANUSER **MultHandle, int num)
{
	char *a = NULL;
	int i, j=0;

	if(!num) return 0;

	if(penality < 3)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & OP_SENT))
			{
				a = push(a, " ", MultHandle[i]->nick, NULL);
   				MultHandle[i]->flags += OP_SENT;
				++j;
			}
		}
		if(j)
		{
			net.irc.send("MODE ", name, j == 3 ? " +ooo" : j == 2 ? " +oo" : " +o", a, NULL);
			penality += j;
			free(a);
		}
	}
	return j;
}

int chan::kick4(CHANUSER **MultHandle, int num)
{
	if(!num) return 0;
	if(num > 4) num = 4;

	char *a = NULL;
	int i, j=0;

	if(penality < 3)
	{
		for(i=j=0; i<num; ++i)
		{
			if(!(MultHandle[i]->flags & KICK_SENT))
			{
				a = push(a, MultHandle[i]->nick, ",", NULL);
				MultHandle[i]->flags += KICK_SENT;
				++j;
			}
		}
		if(j)
		{
			net.irc.send("KICK ", name, " ", a, " :", config.kickreason, NULL);
			penality += j;
			free(a);
		}
	}
	return j;
}

int chan::kick6(CHANUSER **MultHandle, int num)
{
	if(!num) return 0;
	if(num < 5) return kick4(MultHandle, num);
	else
	{
		if(num > 6) num = 6;

		if(!penality)
			return kick4(MultHandle, 2) + kick4(MultHandle+2, num-2);
		else if(penality == 1)
			return kick4(MultHandle, 1) + kick4(MultHandle+1, num-3);
		else
			return kick4(MultHandle, num);
	}
	return 0;
}

/* SINGLEUSER */
int chan::op(CHANUSER *p)
{
	if(!p || !p->nick || !*p->nick) return 0;

	if(!(p->flags & OP_SENT))
	{
		if(penality < 3)
		{
			net.irc.send("MODE ", name, " +o ", p->nick, NULL);
			p->flags |= OP_SENT;
			penality++;
			return 1;
		}
	}
	return 0;
}

int chan::deOp(CHANUSER *p)
{
	if(!p || !p->nick || !*p->nick) return 0;

	if(!(p->flags & DEOP_SENT))
	{
		if(penality < 3)
		{
			net.irc.send("MODE ", name, " -o ", p->nick, NULL);
			p->flags += DEOP_SENT;
			penality++;
			return 1;
		}
	}
	return 0;
}


int chan::kick(CHANUSER *p, char *reason)
{
	if(!p || !p->nick || !*p->nick) return 0;

	if(!(p->flags & KICK_SENT))
	{
		if(penality < 3)
		{
			if(reason) net.irc.send("KICK ", name, " ", p->nick, " :", reason, NULL);
			else net.irc.send("KICK ", name, " ", p->nick, " :", config.kickreason, NULL);
			penality++;
			p->flags += KICK_SENT;
			return 1;
		}
	}
	return 0;
}

int chan::kickBan(CHANUSER *p, char *mask, char *reason)
{
	/*
	if(ME.NextAction <= NOW)
	{
		ME.NextAction = NOW;
		if(!(p->flags & BAN_SENT))
		{
			net.irc.send("MODE ", name, " +b ", mask, NULL);
			p->flags += BAN_SENT;
			++ME.NextAction;
		}
		if(!(p->flags & KICK_SENT))
		{
			if(reason) net.irc.send("KICK ", name, " ", p->nick, " :", reason, NULL);
			else net.irc.send("KICK ", name, " ", p->nick, " :", config.banreason, NULL);
			p->flags += KICK_SENT;
			ME.NextAction += AdditionalPenality();
		}
	}
	*/
	return 0;
}

int chan::invite(char *nick)
{
	if(!nick) return 0;

	if(!getUser(nick))
	{
		char *a = strchr(nick, '!');
		if(a) *a = '\0';

		::invite.wisePush(push(NULL, "INVITE ", nick, " ", name, NULL));
		if(!penality) if(::invite.flush(&net.irc)) penality++;
		return 1;
	}
	return 0;
}
