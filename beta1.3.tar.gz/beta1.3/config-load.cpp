/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void loadConfig(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	int line, i, n;
	int errors = 0;
	int YES = 1;
	int NO = 0;

	CFG_DB db[] =
	{
	/*		 name			int *				char **					words	req					  */
	/*00*/ { "nick",		NULL,				&config.nick,			 1,		&YES,				0 },
	/*01*/ { "ident",		NULL,				&config.ident,			 1,		&NO,				0 },
	/*02*/ { "nickappend",	NULL,				&config.nickappend,		 1,		&YES,				0 },
	/*03*/ { "realname",	NULL,				&config.realname,		-1,		&YES,				0 },
	/*04*/ { "myipv4",		NULL,				&config.myipv4,			 1,		&YES,				0 },
	/*05*/ { "vhost",		NULL,				&config.vhost,			 1,		&NO,				0 },
	/*06*/ { "logfile",		NULL,				&config.logfile,		 1,		&NO,				0 },
	/*07*/ { "userlist",	NULL,				&config.userlist_file,	 1,		&NO,				0 },
	/*08*/ { "kickreason",	NULL,				&config.kickreason,		-1,		&NO,				0 },
	/*09*/ { "partreason",	NULL,				&config.partreason,		-1,		&NO,				0 },
	/*10*/ { "quitreason",	NULL,				&config.quitreason,		-1,		&NO,				0 },
	/*11*/ { "cyclereason",	NULL,				&config.cyclereason,	-1,		&NO,				0 },
	/*12*/ { "havehub",		&config.havehub,	NULL,					 0,		&NO,				0 },
	/*13*/ { "hubhost",		NULL,				&config.hubhost,		 1,		&config.havehub,	0 },
	/*14*/ { "hubport",		&config.hubport,	NULL,					 0,		&config.havehub,	0 },
	/*15*/ { "hubpass",		NULL,				&config.hubpass,		 1,		&config.havehub,	0 },
	/*16*/ { "listen",		&config.listenport,	NULL,					 0,		&NO,				0 },
	/*17*/ { "botnetword",	NULL,				&config.botnetword,		 1,		&NO,				0 },
	/*18*/ { "banreason",	NULL,				&config.banreason,		-1,		&NO,				0 },
	/*19*/ { "limitreason",	NULL,				&config.limitreason,	-1,		&NO,				0 },
	/*20*/ { "ownerpass",	NULL,				&config.ownerpass,		-1,		&YES,				0 },
	/*21*/ { "keepnick",	&config.keepnick,	NULL,					-1,		&NO,				0 },
	/*22*/ { "ctcptype",	&config.ctcptype,	NULL,					 1,		&NO,				0 },
	/*23*/ { "handle",	    NULL,               &config.handle,	         1,		&NO,				0 },
	/*24*/ { "",			NULL,				NULL,					 0,		NULL,				0 }
	};

	if(set.creation) printf("[*] Loading decrypted config from '%s'\n", file);
	inetconn f;
	if(f.open(file, O_RDONLY) < 1)
	{
		printf("[-] Cannot open config file: %s\n", strerror(errno));
		exit(1);
	}
	if(!set.creation) f.enableLameCrypt();

	for(line=0; ; ++line)
	{
		lame:
		n = f.readln(buf, MAX_LEN);
		if(n == -1) break;
		if(!n) continue;

		str2words(arg[0], buf, 10, MAX_LEN);
		if(arg[0][0] == '#') continue;

		/* look for option in DB */
		for(i=0; ; ++i)
		{
			if(!strlen(db[i].name)) break;
			if(!strcasecmp(db[i].name, arg[0]))
			{
				if(db[i].loaded)
				{
					printf("[-] %s:%d: Redefinition of '%s'\n", file, line, db[i].name);
					++errors;
					goto lame;
				}
				if(!strlen(arg[1]))
				{
					printf("[-] %s:%d: Inavlid argument for option '%s'\n", file, line, db[i].name);
					++errors;
					goto lame;
				}
				if(db[i].i != NULL)
				{
					*db[i].i = atoi(arg[1]);
				}
				else if(db[i].c != NULL)
				{
					if(db[i].words == 1)
					{
						mem_strcpy(*db[i].c, arg[1]);
					}
					else if(db[i].words == -1)
					{
						int pos = strlen(buf) - 1;
						a = buf;
						if(a[pos] == '\n') a[pos] = '\0';
						while(!isspace(*a)) ++a;
						while(isspace(*a)) ++a;
						mem_strcpy(*db[i].c, a);
					}

				}
				else
				{
					printf("[-] Wrong parameter database !!!\n");
					exit(1);
				}
				db[i].loaded = 1;
				goto lame;
			}
		}

		/* non standard options */
		if(!strcmp(arg[0], "server"))
		{
			if(!strlen(arg[2]))
			{
				printf("[-] %s:%d: Error: Inavlid argument for option 'server'\n", file, line);
				exit(1);
			}
			userlist.addServer(arg[1], atoi(arg[2]), AF_INET, arg[3]);
			continue;
		}
#ifdef HAVE_IPV6
		if(!strcmp(arg[0], "server6"))
		{
			if(!strlen(arg[2]))
			{
				printf("[-] %s:%d: Error: Inavlid argument for option 'server6'\n", file, line);
				exit(1);
			}
			userlist.addServer(arg[1], atoi(arg[2]), AF_INET6, arg[3]);
			continue;
		}
#endif
#ifdef HAVE_TCL
		if(!strcmp(arg[0], "script") && arg[1])
		{
			if(tclparser.load(arg[1]))
			{
				printf("[+] Loading tcl script: %s... OK\n", arg[1]);
			}
			else
			{
				printf("[-] Loading tcl script: %s... FAILED\n", arg[1]);
				exit(1);
			}
			continue;
		}
#endif
		if(strlen(arg[0])) printf("[!] %s:%d: unknown option '%s'\n", file, line, arg[0]);
	}

	/* Basic checks */
	for(i=0; ; ++i)
	{
		if(!strlen(db[i].name)) break;
		if(*db[i].req && !db[i].loaded)
		{
			printf("[-] Mandatory option not set: %s\n", db[i].name);
			++errors;
		}
	}
	/* Depth checks */
	if(config.havehub && config.listenport == config.hubport && !strcmp(config.hubhost, config.myipv4))
	{
		printf("[-] ROTFL: Why should I connect to myself? ;-)\n");
		++errors;
	}
	if(!config.listenport && !config.havehub)
	{
		printf("[-] I need listen or havehub to run\n");
		++errors;
	}
	if(errors)
	{
		printf("[-] Failed to load config\n");
		exit(1);
	}

	if(set.creation)
	{
		printf("[*] Crypting config file\n");
		snprintf(buf, MAX_LEN, "%s.dec", file);
		unlink(buf);
		if(rename(file, buf))
		{
			printf("[-] Cannot create backup file '%s': %s\n", buf, strerror(errno));
			exit(1);
		}
		inetconn conf;
		if(conf.open(file, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR) < 1)
		{
			printf("[-] Cannot create crypted config '%s': %s\n", file, strerror(errno));
			exit(1);
		}
		f.close();
		if(f.open(buf, O_RDONLY) < 1)
		{
			printf("[-] Cannot open backup config, wtf?\n");
			exit(1);
		}

		conf.enableLameCrypt();

		while(1)
		{
			n = f.readln(buf, MAX_LEN);
			if(n == -1)	break;
			else if(n) conf.send(buf, NULL);
		}

		f.close();
		conf.close();

		if(set.creation)
		{
			printf("[+] All done\n");
			printf("[*] Please move %s.dec to safe place and start bot without -c option\n", file);
			printf("[+] Terminating.\n");
			exit(0);
		}
	}
	/* now when we are done we can set defaults for not set values */

	if(!config.partreason) mem_strcpy(config.partreason, "");
	if(!config.quitreason) mem_strcpy(config.quitreason,"");
	if(!config.kickreason) mem_strcpy(config.kickreason, "");
	if(!config.banreason) mem_strcpy(config.banreason, "");
	if(!config.cyclereason) mem_strcpy(config.cyclereason, "");
	if(!config.limitreason) mem_strcpy(config.limitreason, "");

	if(!config.botnetword) mem_strcpy(config.botnetword, "###\001The\001Psotnic\001Project\001###");
	if(!config.vhost) mem_strcpy(config.vhost, "");
	if(!config.ident) mem_strcpy(config.ident, config.nick);
	if(!config.handle) mem_strcpy(config.handle, config.nick);
	if(!config.userlist_file) config.userlist_file = push(NULL, config.nick, ".ul",NULL);
	if(!config.logfile) config.logfile = push(NULL, config.nick, ".log",NULL);
	if(!db[22].loaded) config.ctcptype = (rand() % 8) + 1;

	if(config.listenport)
	{
		if(config.havehub)
		{
			printf("[*] Acting as SLAVE\n");
			config.bottype = BOT_SLAVE;
		}
		else
		{
			printf("[*] Acting as MAIN\n");
			config.bottype = BOT_MAIN;
		}
	}
	else
	{
		printf("[*] Acting as LEAF\n");
		config.bottype = BOT_LEAF;
	}

	printf("[+] Config loaded\n");

	chmod(config.logfile, S_IRUSR | S_IWUSR);
	if(logfile.open(config.logfile, O_APPEND | O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR) < 1)
	{
		printf("[-] Cannot open logfile (%s)\n", strerror(errno));
		exit(1);
	}
	if(config.listenport)
	{
		if((net.listenfd = startListening(config.myipv4, config.listenport)) < 1)
		{
			printf("[-] Cannot open socket (%s)\n", strerror(errno));
			exit(1);
		}
	}
}
