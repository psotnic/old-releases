/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int parse_botnet(inetconn *c, char *data)
{
	char arg[10][MAX_LEN];
	chan *ch;
	inetconn *bot;
	CHANUSER *p;

	if(!strlen(data)) return 0;
	str2words(arg[0], data, 10, MAX_LEN);

	/* CHNICK <handle> <nick> */
	if(!strcmp(arg[0], S_CHNICK) && strlen(arg[1]))
	{
		bot = net.findConn(userlist.findHandle(arg[1]));
		if(bot)
		{
            if(bot->name) free(bot->name);
			mem_strcpy(bot->name, arg[2]);
			net.propagate(c, data, NULL);
		}
		return 1;
	}
	/* BJOIN <handle> [ircnick] */
	if(!strcmp(arg[0], S_BJOIN) && strlen(arg[1]))
	{
		HANDLE *h = userlist.findHandle(arg[1]);
		if(h && userlist.isBot(h) && strcmp(ME.nick, arg[1]) && !net.findConn(h))
		{
			bot = net.addConn(c->fd);
			if(bot)
			{
				mem_strcpy(bot->name, arg[2]);
                bot->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_BOT + STATUS_REDIR;
				bot->handle = h;
    			net.propagate(c, data, NULL);
			}
		}
		return 1;
	}
	if(!strcmp(arg[0], S_BQUIT) && strlen(arg[1]))
	{
		bot = net.findConn(userlist.findHandle(arg[1]));
		if(bot)
		{
			bot->close();
			net.propagate(c, data, NULL);
		}
		return 1;
	}
	/* REDIR <handle> <text> */
	if(!strcmp(arg[0], S_REDIR) && strlen(arg[2]))
	{
		/* $1 who, $2- string */
		bot = net.findConn(userlist.findHandle(arg[1]));
		if(bot)
		{
			char *a = srewind(data, 2);
			bot->send(a, NULL);
		}
		return 1;
	}
	if(!strcmp(arg[0], S_BOP) && strlen(arg[2]))
	{
		ch = ME.findChannel(arg[1]);
		if(ch)
		{
			p = ch->getUser(arg[2]);
			if(p && (p->flags & HAS_B) && (set.GETOP_OP_CHECK ? !(p->flags & IS_OP) : 1))
					ch->op(p);

		}
		return 1;
	}
	/* S_INVITE <handle> <seed> <channel> */
	if(!strcmp(arg[0], S_INVITE) && strlen(arg[3]))
	{
		net.propagate(c, data, NULL);
		ch = ME.findChannel(arg[3]);
		if(ch)
		{
			if(ch->ptr->flags & IS_OP && ch->myTurn(ch->chset->INVITE_BOTS, atoi(arg[2])))
			{
				inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
				if(bot && !ch->getUser(bot->name))
					ch->invite(bot->name);
			}
		}
		return 1;
	}

	/* S_UNBANME <handle> <seed> <nick!ident@host> <channel> */
	if(!strcmp(arg[0], S_UNBANME) && strlen(arg[4]))
	{
		net.propagate(c, data, NULL);
		if(penality > 3) return 1;
		ch = ME.findChannel(arg[4]);
		if(ch)
		{
			if(ch->ptr->flags & IS_OP && ch->myTurn(ch->chset->UNBAN_BOTS, atoi(arg[2])))
			{
				masklist_ent *m = ch->list[BAN].wildFind(arg[3]);
				if(m)
				{
					//FIXME: add to queue
					net.irc.send("MODE ", arg[4], " -b ", m->mask, NULL);
					penality++;
					inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
					if(bot) bot->send(S_COMEON, " ", arg[4], NULL);
				}
			}
		}
		return 1;
	}

	/* S_BIDLIMIT <handle> <seed> <channel> */
	if(!strcmp(arg[0], S_BIDLIMIT) && strlen(arg[3]))
	{
		net.propagate(c, data, NULL);
		if(penality > 3) return 1;

		ch = ME.findChannel(arg[3]);
		if(ch && ch->ptr->flags & IS_OP && ch->myTurn(ch->chset->LIMIT_BOTS, atoi(arg[2])))
		{
			inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
			if(ch->nextlimit != -1)
			{
				if(ch->limit <= ch->users)
				{
					net.irc.send("MODE ", ch->name, " +l ", itoa(ch->users + ch->chset->LIMIT_OFFSET), NULL);
					if(bot) bot->send(S_COMEON, " ", arg[3], NULL);
					penality++;
				}
			}
			else
			{
				if(bot)
				{
					ch->invite(bot->name);
					penality++;
				}
			}
		}
		return 1;
	}

	/* S_KEY <handle> <seed> <channel> */
	if(!strcmp(arg[0], S_KEY) && strlen(arg[3]))
	{
		net.propagate(c, data, NULL);

		ch = ME.findChannel(arg[3]);
		if(ch && ch->key && *ch->key && ch->myTurn(ch->chset->INVITE_BOTS, atoi(arg[2])))
		{
			inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
			if(bot)
				bot->send(S_KEYRPL, " ", arg[3], " ", ch->key, NULL);
		}
		return 1;
	}

	/* S_KEYRPL <channel> <key> */
	if(!strcmp(arg[0], S_KEYRPL) && strlen(arg[2]))
	{
		int i;
		if(!ME.findChannel(arg[1]) && (i = userlist.findChannelInList(arg[1])) != -1)
		{
			if(userlist.chanlist[i].pass) free(userlist.chanlist[i].pass);
			mem_strcpy(userlist.chanlist[i].pass, arg[2]);
			if(!userlist.chanlist[i].joinsent)
			{
				userlist.chanlist[i].joinsent = 1;
				net.irc.send("JOIN ", arg[1], " ", arg[2], NULL);
				penality++;
			}
		}
		return 1;
	}

	/* S_COMEONE <channel> */
	if(!strcmp(arg[0], S_COMEON) && strlen(arg[1]))
	{
		int i;
		if(!ME.findChannel(arg[1]) && (i = userlist.findChannelInList(arg[1])) != -1)
		{
			if(userlist.chanlist[i].nextjoin + 2 >= NOW)
			{
				ME.rejoin(arg[1], 2);
			}
			else bk;
		}
		return 1;
	}
	/* S_LIST ? <owner> arg1 arg2 */
	if(!strcmp(arg[0], S_LIST) && strlen(arg[2]))
	{
		if(listcmd(arg[1][0], arg[2], arg[3], arg[4], c))
			net.propagate(c, data, NULL);
		return 1;
	}

	return 0;
}
