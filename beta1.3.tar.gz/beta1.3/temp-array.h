template <class _type>
class array
{
	public :
	int entries;
	int size;
	_type **entry;

	array()
	{
		//entry = new *_type[8];
		entry = (_type **) malloc(8 * sizeof(_type));
		size = 1;
		entries = 0;
	}
	~array()
	{
		delete(entry);
	}
	void Add(_type *ptr)
	{
		CheckSize();
		entry[entries++] = ptr;
	}
	void Remove(int pos)
	{
		if(pos != --entries)
			entry[pos] = entry[entries];
		CheckSize();
	}
	_type *operator[](int num)
	{
		return entry[num];
	}

	private:
	void CheckSize()
	{
		if(size == entries)
		{
			size *= 2;
			//entry = new _type[size];
			entry = (_type **) realloc(entry, size * sizeof(_type));
		}
		else if(entries > 8 && entries < size/4)
		{
			//entry = new _type[entries*2];
			entry = (_type **) realloc(entry, entries * 2 * sizeof(_type));
		}
	}
};
