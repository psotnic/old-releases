/***************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"
char _chmodes[MAX_LEN];

char *chan::getModes()
{
	/* imnpstaqr */
	memset(_chmodes, 0, MAX_LEN);

	//overflow
	if(key && strlen(key) > MAX_LEN - 50)
	{
		strcpy(_chmodes, "buffer overflow attempt");
		return _chmodes;
	}
	strcpy(_chmodes, "+");
	if(key && *key)	strcat(_chmodes, "k");
	if(limit) strcat(_chmodes, "l");
	if(flags & FLAG_I) strcat(_chmodes, "i");
	if(flags & FLAG_M) strcat(_chmodes, "m");
	if(flags & FLAG_N) strcat(_chmodes, "n");
	if(flags & FLAG_P) strcat(_chmodes, "p");
	if(flags & FLAG_S) strcat(_chmodes, "s");
	if(flags & FLAG_T) strcat(_chmodes, "t");
	if(flags & FLAG_Q) strcat(_chmodes, "q");
	if(flags & FLAG_R) strcat(_chmodes, "r");

	if(key && *key)
	{
		strcat(_chmodes, " ");
		strcat(_chmodes, key);
	}
	if(limit)
	{
		strcat(_chmodes, " ");
		strcat(_chmodes, itoa(limit));
	}
	return _chmodes;
}

int chan::myTurn(int num, int hash)
{
	CHANUSER **MultHandle;
	int i, j;

	num = numberOfBots(num);
	if(num < 1) return 0;

	MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*num);
	srand(hash, hash32(name));
	j = getRandomItems(MultHandle, opedBots.first, opedBots.ent, num);
	for(i=0; i<j; ++i)
	{
		if(!strcmp(MultHandle[i]->nick, ME.nick))
		{
			free(MultHandle);
			srand();
			return 1;
		}
	}
	srand();
	free(MultHandle);
	return 0;
}

void chan::buildAllowedOpsList(char *offender)
{
	CHANUSER *p = first;
	CHANUSER *kicker;
	char *a, *nick;

	if(userlist.chanlist[channum].allowedOps)
		delete userlist.chanlist[channum].allowedOps;

	if(chset->TAKEOVER)
	{
		userlist.chanlist[channum].allowedOps = NULL;
		return;
	}
	else
		userlist.chanlist[channum].allowedOps = new wasoptest(60);

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicker = getUser(nick);
	if(kicker && !(kicker->flags & HAS_F)) toKick.sortAdd(kicker);
	free(nick);

	while(p)
	{
		if((p->flags & IS_OP) && !(p->flags & HAS_O) && toKick.find(p) == -1)
		{
			userlist.chanlist[channum].allowedOps->add(p);
		}
		p = p->next;
	}
}

void chan::setFlags(char *str)
{
	flags = 0;
	addFlags(str);
}

void chan::addFlags(char *str)
{
	/* imnpstaqr */
	strchr(str, 'i') ? flags |= FLAG_I : 0;
	strchr(str, 'n') ? flags |= FLAG_N : 0;
	strchr(str, 's') ? flags |= FLAG_S : 0;
	strchr(str, 'm') ? flags |= FLAG_M : 0;
	strchr(str, 't') ? flags |= FLAG_T : 0;
	strchr(str, 'r') ? flags |= FLAG_R : 0;
	strchr(str, 'p') ? flags |= FLAG_P : 0;
	strchr(str, 'q') ? flags |= FLAG_Q : 0;

}

void chan::removeFlags(char *str)
{
	strchr(str, 'i') ? flags &= ~FLAG_I : 0;
	strchr(str, 'n') ? flags &= ~FLAG_N : 0;
	strchr(str, 's') ? flags &= ~FLAG_S : 0;
	strchr(str, 'm') ? flags &= ~FLAG_M : 0;
	strchr(str, 't') ? flags &= ~FLAG_T : 0;
	strchr(str, 'r') ? flags &= ~FLAG_R : 0;
	strchr(str, 'p') ? flags &= ~FLAG_P : 0;
	strchr(str, 'q') ? flags &= ~FLAG_Q : 0;
}


int chan::synced()
{
	return synlevel;
}

int chan::chops()
{
	int ops = 0;
	CHANUSER *u = first;

	while(u)
	{
		if(u->flags & IS_OP) ++ops;
		u = u->next;
	}
	return ops;
}

void chan::updateKey(char *newkey)
{
	if(key) free(key);
	mem_strcpy(key, newkey);

	if(strlen(newkey) || set.REMEMBER_OLD_KEYS)
	{
  		if(userlist.chanlist[channum].pass) free(userlist.chanlist[channum].pass);
		mem_strcpy(userlist.chanlist[channum].pass, newkey);
	}
	else
	{
		if(userlist.chanlist[channum].pass) free(userlist.chanlist[channum].pass);
		mem_strcpy(userlist.chanlist[channum].pass, "");
	}
}


void chan::requestOp()
{

	CHANUSER **multHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * chset->GETOP_BOTS);
	int i, j;
	inetconn *c;

	j = getRandomItems(multHandle, opedBots.first, opedBots.ent, chset->GETOP_BOTS);

	for(i=0; i<j; ++i)
	{
		c = net.findConn(multHandle[i]->nick);
		if(c && c->isRegBot())
		{
			c->send(S_BOP, " ", name, " ", ME.nick, NULL);
		}
	}
	free(multHandle);
}

void chan::recheckFlags()
{
	CHANUSER *p = first;
	int oped;
	char *mask;

	botsToOp.reset();
	//ToKick.reset();
	toOp.reset();
	opedBots.reset();

	while(p)
	{
		oped = p->flags & IS_OP;
		mask = push(NULL, p->nick, "!", p->ident, "@", p->host, NULL);
		p->flags = userlist.getFlags(mask, this);
		if(oped) p->flags += IS_OP;
		//printf("### %s: %s flags: %d\n", c->name, mask, p->flags);
		free(mask);
		if(p->flags & HAS_B && !oped) botsToOp.sortAdd(p);
		//if(!(p->flags & HAS_O) && !(p->flags & HAS_F) && oped) ToKick.SortAdd(p);
		if(p->flags & HAS_B && oped) opedBots.sortAdd(p);
		p = p->next;
	}
}

/*
int chan::quoteOpedBots(char *str, int num)
{
	int *n = (int *) malloc(num * sizeof(int));
	int i, j, k;
	int r = 0;
	PTRLIST<CHANUSER> *p = opedBots.first;


	j = getRandomNumbers((int *) n, 0, opedBots.ent, num);

	for(k=0; ;++k)
	{
		if(!p) break;
		for(i=0; i<j; ++i)
		{
			if(n[i] == k)
			{
				if(p->ptr == ptr && ptr) r = 1;
				else
				{
					inetconn *c = net.findConn(p->ptr->nick);
					if(c && c->isRegBot()) c->send(str, NULL);
				}
			}
		}
		p = p->next;
	}
	return r;
}
*/

int chan::gotBan(char *ban, CHANUSER *caster)
{
	if(!ban) return 0;

	CHANUSER *u;
	char mask[MAX_LEN];

	for(u = first; u; u = u->next)
	{
		if(u->flags & HAS_F && userLevel(caster) <= userLevel(u))
		{
			userMask(mask, u);
   			if(match(ban, mask))
			{
				if(!(caster->flags & HAS_F)) toKick.sortAdd(caster);
				return 1;
			}
		}
	}

	if(chset->ENFORCE_BANS)
	{
		for(u = first; u; u = u->next)
		{
			if(!(u->flags & HAS_F) && userLevel(caster) > userLevel(u))
			{
				userMask(mask, u);
				if(match(ban, mask)) toKick.sortAdd(u);
			}
		}
	}
	return 0;
}

void chan::rejoin(int t)
{
	int i;

	i = userlist.findChannelInList(name);
	if(i != -1)	userlist.chanlist[i].nextjoin = NOW + t;
}

int chan::numberOfBots(int num)
{
	if(num >= 0) return num;
	if(num == -100) return opedBots.ent;
	return (num * opedBots.ent * (-1)) / 100  + 1;
}

void chan::reOp()
{
	logfile.send("[*] Reoping ", name, NULL);
	if(users == 1)
	{
		net.irc.send("PART ", name, NULL);
		net.irc.send("JOIN ", name, NULL);
	}
	else if(users > 1 && config.listenport)
	{
		char *buf = push(NULL, S_CYCLE, name, NULL);
		quoteBots(buf);
		net.send(OWNERS, "[*] Reoping ", name, NULL);
		free(buf);
	}
}

void chan::quoteBots(char *str)
{
	CHANUSER *p = first;
	inetconn *c;

	while(p)
	{
		if(p->flags & HAS_B)
		{
			c = net.findConn(p->nick);
			if(c && c->isRegBot()) c->send(str, NULL);
			p = p->next;
		}
	}
}

void chan::gotNickChange(char *from, char *to)
{
	CHANUSER *p = getUser(from);
	int status = 0;

	if(!p) return;

	if(toOp.remove(p)) status += 1;
	if(botsToOp.remove(p)) status += 2;
	if(opedBots.remove(p)) status += 4;
	if(toKick.remove(p)) status += 8;
	if(toReOp.remove(p)) status += 16;

	free(p->nick);
	mem_strcpy(p->nick, to);

	if(status & 1) toOp.sortAdd(p);
	if(status & 2) botsToOp.sortAdd(p);
	if(status & 4) opedBots.sortAdd(p);
	if(status & 8) toKick.sortAdd(p);
	if(status & 16) toReOp.sortAdd(p);
}

CHANUSER *chan::getUser(char *nick)
{
	if(!nick) return NULL;

	CHANUSER *p = first;
	char *a = strchr(nick, '!');
	int n;
	if(a)
	{
		n = abs(a - nick);
		while(p)
		{
			if(!strncmp(nick, p->nick, n)) return p;
			p = p->next;
		}
	}
	else
	{
		while(p)
		{
			if(!strcmp(nick, p->nick)) return p;
			p = p->next;
		}
	}
	return NULL;
}

void chan::gotKick(char *victim, char *offender)
{
	CHANUSER *kicked, *kicker;
	char *nick, *a;
	int wasbot;

	a = strchr(offender, '!');
	mem_strncpy(nick, offender, abs(a - offender) + 1);

	kicked = getUser(victim);
	kicker = getUser(nick);

	if(kicker)
	{
		if((kicked->flags & HAS_F) && !(kicker->flags & HAS_F))
		{
			toKick.sortAdd(kicker);
			if(myTurn(chset->PUNISH_BOTS, hash32(kicker->nick)))
			{
				kick(kicker, config.kickreason);
			}
		}
	}

	wasbot = kicked->flags & HAS_B;
	gotPart(victim, 0);

	if((limit <= users || flags & FLAG_I) && wasbot &&
		myTurn(chset->GETOP_BOTS, hash32(kicker->nick)))
	{
			invite(victim);
			if(toKick.ent < 2 && penality < 2) ::invite.flush(&net.irc);
	}

	free(nick);
}

void chan::gotPart(char *nick, int netsplit)
{
	CHANUSER *p = first;

	int bot = 0;

	if(!first) return;
	if(!strcasecmp(first->nick, nick))
	{
		if(netsplit && first->flags & IS_OP)
			wasop->add(first);

		bot = first->flags & HAS_B;
		first = first->next;
		if(first) first->prev = NULL;
		removeFromAllPtrLists(p);
		destroy(p);
		--users;
		if(!users) last = NULL;
	}
	else if(!strcasecmp(last->nick, nick))
	{
		if(netsplit && last->flags & IS_OP)
			wasop->add(last);
		bot = last->flags & HAS_B;
		p = last->prev;
		p->next = NULL;
		removeFromAllPtrLists(last);
		destroy(last);
		--users;
		last = p;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->nick, nick))
			{
				if(netsplit && p->flags & IS_OP)
					wasop->add(p);
				bot = p->flags & HAS_B;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				removeFromAllPtrLists(p);
				destroy(p);
				--users;
				break;
			}
			p = p->next;
		}
	}
}

#ifdef HAVE_DEBUG
void chan::display()
{
    CHANUSER *p = first;
    int i;
	char buf[32];

    while(1)
    {
		if(p == NULL) break;
		i=0;
		if(p->flags & HAS_A) buf[i++] = 'a';
		if(p->flags & HAS_B) buf[i++] = 'b';
		if(p->flags & HAS_O) buf[i++] = 'o';
		if(p->flags & HAS_F) buf[i++] = 'f';
		if(p->flags & HAS_M) buf[i++] = 'm';
		if(p->flags & HAS_N) buf[i++] = 'n';
		if(p->flags & HAS_D) buf[i++] = 'd';
		if(i == 0) buf[i++] = '-';
		buf[i] = '\0';
		printf("[%d]: %s!%s@%s, flags: %s[%d]\n", i, p->nick, p->ident, p->host, buf, p->flags);
		p=p->next;
		i++;
    }
    p = last;
    i = users-1;
	printf("ToOp:\n");
	toOp.display();
	printf("BotsToOp:\n");
	botsToOp.display();
	printf("ToKick:\n");
	toKick.display();
	printf("OpedBots:\n");
	opedBots.display();
	//printf("Modes: %s\n", modes);
	printf("Limit: %d\n", limit);
	printf("Key: %s\n", key);
}
#endif

CHANUSER *chan::gotJoin(char *mask, int def_flags)
{
    CHANUSER *p;
    char *a, *b;

    if(!users)
    {
		last = first = new(CHANUSER);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(CHANUSER);
		p->prev = last;
		p->next = NULL;
		last = p;
    }

    a = strchr(mask, '!');
    b = strchr(mask, '@');
    mem_strncpy(last->nick, mask, (int) abs(mask - a) +1);
    mem_strncpy(last->ident, a+1, (int) abs(a - b));
    mem_strcpy(last->host, b+1);
    ++users;
    last->flags = userlist.getFlags(mask, this);
    last->flags |= def_flags;

	if(!(def_flags & NET_JOINED) && chset->LIMIT && limit && users > limit && !(last->flags & HAS_F))
	{
		toKick.sortAdd(last);
		if(myTurn(chset->PUNISH_BOTS, hash32(last->nick)))
			kick(last, config.limitreason);
	}
	else if((last->flags & (HAS_O + HAS_A + IS_OP)) == (HAS_O + HAS_A))
	{
		if(last->flags & HAS_B)	botsToOp.sortAdd(last);
		else toOp.sortAdd(last);

		if((chset->TAKEOVER ? 1 : !(def_flags & NET_JOINED)) && ptr && opedBots.ent && ((last->flags & HAS_B) ? net.findConn(last->nick) : (inetconn *) 1))
		{
			if(myTurn(last->flags & HAS_B ? chset->BOT_AOP_BOTS : chset->AOP_BOTS, hash32(last->nick)))
			{
				op(last);
			}
		}
	}

	if(last->flags & IS_OP)
	{
		if(!(last->flags & (HAS_O)))
		{
			if(chset->TAKEOVER || (userlist.chanlist[channum].allowedOps &&
				!userlist.chanlist[channum].allowedOps->remove(last)))
					toKick.sortAdd(last);
		}

		if(last->flags & HAS_B)
		{
			opedBots.sortAdd(last);
			if(!initialOp) initialOp = NOW;
		}
	}
	if(botsToOp.ent == users && config.listenport && synced()) reOp();

	if(!(def_flags & NET_JOINED)) wasop->remove(mask);

	return last;
}

/* Constructor */
chan::chan()
{
    last = first = NULL;
    flags = limit = status = users = synlevel = 0;
	ptr = NULL;
	name = key = NULL;
	initialOp = 0;
	since = NOW;
	nextlimit = -1;
}

/* Destruction derby */
chan::~chan()
{
	CHANUSER *p = first;
	CHANUSER *q;

	while(p)
	{
		q = p;
		p = p->next;
		destroy(q);
	}
	if(name) free(name);
	if(key) free(key);
}

void chan::destroy(CHANUSER *p)
{
   	free(p->nick);
	free(p->ident);
	free(p->host);
	delete(p);
}

void chan::removeFromAllPtrLists(CHANUSER *handle)
{
	toKick.remove(handle);
	opedBots.remove(handle);
	botsToOp.remove(handle);
	toOp.remove(handle);
	toReOp.remove(handle);
}
