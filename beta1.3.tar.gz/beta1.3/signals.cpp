/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int sigTerm()
{
	signal(SIGTERM, SIG_IGN);
	if(net.irc.fd > 0) net.irc.send("QUIT :", config.quitreason, NULL);
	net.send(OWNERS, "[!] Got termination signal", NULL);
	logfile.send("[*] Got termination signal", NULL);
	userlist.save(config.userlist_file);
	exit(1);
}

int sigInt()
{
	signal(SIGINT, SIG_IGN);
	if(net.irc.fd > 0) net.irc.send("QUIT :", config.quitreason, NULL);
	net.send(OWNERS, "[!] Terminated by user", NULL);
	logfile.send("[*] Terminated by user", NULL);
	userlist.save(config.userlist_file);
	exit(1);
}

int sigHup()
{
	userlist.save(config.userlist_file);
	return 0;
}

int sigSegv()
{
	signal(SIGSEGV, SIG_IGN);
	net.irc.send("QUIT :Yet another bug found, please send log to pks@irc.pl", NULL);
	net.send(OWNERS, "[!] Segmentation fault", NULL);
	logfile.send("[!] Segmentation fault", NULL);
	logfile.send("[!] Please send log (10 to 30 lines) to pks@irc.pl", NULL);
	logfile.send("[!] Thank you", NULL);
	exit(2);
}

int safeExit()
{
	logfile.send("[*] Abnormal program termination", NULL);
	userlist.save(config.userlist_file);
	exit(3);
}

void signalHandling()
{
	signal(SIGPIPE, SIG_IGN);

 	signal(SIGTERM, (sighandler_t) sigTerm);
	signal(SIGINT, (sighandler_t) sigInt);
	signal(SIGHUP, (sighandler_t) sigHup);
#ifdef HAVE_DEBUG
#else
	signal(SIGSEGV, (sighandler_t) sigSegv);
#endif
}



