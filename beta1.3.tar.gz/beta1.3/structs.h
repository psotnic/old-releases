struct unit_table
{
    char unit;
    int  ratio;
};

struct CFG_DB
{
	char name[32];
	int *i;
	char **c;
	int words;
	int *req;
	int loaded;
};

struct IOBUF
{
	char *buf;
	int pos;
	int len;
};

struct SERVER
{
	char *host;
	char *ip;
	int port;
	char *pass;
};

struct CHANUSER
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	CHANUSER *next;
    CHANUSER *prev;
};

class ptime;

struct HANDLE
{
	char *name;
	char *host[MAX_HOSTS];
	char *pass;
	int flags[MAX_CHANNELS+1];
	unsigned int ip;
	HANDLE *next;
	HANDLE *prev;
	char updated;
    ptime *creation;
};

struct CONFIG
{
	char *nick;
	char *ident;
	char *nickappend;
	char *realname;
	char *myipv4;
	char *vhost;
	char *userlist_file;
	char *kickreason;
	char *banreason;
	char *partreason;
	char *quitreason;
	char *cyclereason;
	char *limitreason;
	char *hubhost;
	char *hubpass;
	char *botnetword;
	char *ownerpass;
	char *logfile;
	char *handle;
	int bottype;
	int hubport;
	int listenport;
	int havehub;
	int keepnick;
	int ctcptype;

	SERVER server[MAX_SERVERS];
};

/* CHANLIST is defined in classes.h */

struct SOCKBUF
{
    int fd;
    char *buf;
    int len;
    int pos;
};

struct DNSHEADER {
	unsigned short int			id;			/* Packet id */
	unsigned char 				databyte_a;
	/* rd:1						recursion desired
	 * tc:1						truncated message
	 * aa:1						authoritive answer
	 * opcode:4					purpose of message
	 * qr:1						response flag
	 */
	unsigned char				databyte_b;
	/* rcode:4					response code
	 * unassigned:2				unassigned bits
	 * pr:1						primary server required (non standard)
	 * ra:1						recursion available
	 */
	unsigned short int			qdcount;	/* Query record count */
	unsigned short int			ancount;	/* Answer record count */
	unsigned short int			nscount;	/* Authority reference record count */
	unsigned short int			arcount;	/* Resource reference record count */
};

struct VAR
{
	char *name;
	int *i;
	int def;
	int from;
	int to;
	unit_table *ut;
};

struct EXPANDINFO
{
	char *system;
	char *release;
	char *arch;
	char *version;
	char *realname;
};
