//channel flags
#define FLAG_I					0x0000001
#define FLAG_N					0x0000002
#define FLAG_S					0x0000004
#define FLAG_M					0x0000008
#define FLAG_T					0x0000010
#define FLAG_R					0x0000020
#define FLAG_P					0x0000040
#define FLAG_Q					0x0000080

//user flags
#define HAS_A					0x0000001
#define HAS_D					0x0000002
#define HAS_O					0x0000004
#define HAS_F					0x0000008
#define HAS_M					0x0000010
#define HAS_N					0x0000020
#define HAS_S					0x0000040
#define HAS_T					0x0000080
#define HAS_V					0x0000100
#define HAS_Q					0x0000200
#define HAS_ALL					0x0000400 - 1

#define HAS_B                 	0x0000400
#define HAS_L					0x0000800
#define HAS_H					0x0001000
#define BOT_FLAGS				HAS_B | HAS_O | HAS_A | HAS_F

#define IS_OP                 	0x0002000
#define KICK_SENT				0x0004000
#define OP_SENT					0x0008000
#define BAN_SENT              	0x0010000
#define UNBAN_SENT				0x0020000
#define DEOP_SENT				0x0040000
#define CREATOR					0x0080000
#define NET_JOINED				0x0100000

#define ARG_MODES				"oblkeIv"
#define NONARG_MODES			"imntsp"

//inetconn flags
#define STATUS_CONNECTED		0x0000001
#define STATUS_REGISTERED		0x0000002
#define STATUS_SYNSENT			0x0000004
#define STATUS_OWNER			0x0000008
#define STATUS_BOT				0x0000010
#define STATUS_SILENT			0x0000020
#define STATUS_KLINED			0x0000040
#define STATUS_TELNET			0x0000080
#define STATUS_REDIR			0x0000100
#define STATUS_FILE				0x0000200

#define MAX_LEN					1024
#define MAX_SERVERS				16
#define MAX_CHANNELS			32
#define MAX_HOSTS				64
#define MD5_HEXDIGEST_LEN		32
#define AUTHSTR_LEN				32
#define MAX_INT					0x7fffffff
#define MODES_PER_LINE			10

#define BOT_LEAF				1
#define BOT_SLAVE				2
#define BOT_MAIN				3

#define MK_OPS					1
#define MK_NONOPS				2
#define MK_ALL					3

#define BAN						0
#define EXEMPT					1
#define INVITE					2

#define OWNERS					STATUS_OWNER
#define FD_BOTS					STATUS_BOT

#define TCP_NODELAY				1

#define S_UL_UPLOAD_START		"USTART"
#define S_UL_UPLOAD_END			"UEND"
#define S_CHNICK				"CHNICK"
#define S_REGISTER				"REG"
#define S_UNKNOWN				"<?>"
#define S_SECRET				"-"
#define S_INVITE				"INV"
#define S_KEY					"KEY"
#define S_KEYRPL				"KEYRPL"
#define S_REOP					"REOP"
#define S_CYCLE					"CYCLE"

#define S_ADDUSER				"ADDUSER"
#define S_ADDHOST				"ADDHOST"
#define S_ADDBOT				"ADDBOT"
#define S_ADDCHAN				"ADDCHAN"

#define S_RMUSER				"RMUSER"
#define S_RMHOST				"RMHOST"
#define S_RMBOT					"RMBOT"
#define S_RMCHAN				"RMCHAN"

#define S_CHATTR				"CHATTR"
#define S_ULSAVE				"SAVE"
#define S_SN					"SN"
#define S_SET					"SET"
#define S_CHSET					"CHSET"
#define S_GCHSET				"GCHSET"
#define S_KICKBAN				"KB"
#define S_GETOP					"GETOP"
#define S_OP					"OP"
#define S_BOP					"BOP"
#define S_FOO					"FOO"
#define S_NICK					"NICK"
#define S_PASSWD				"PASSWD"
#define S_MKO					"MKO"
#define S_MKN					"MKN"
#define S_MKA					"MKA"
#define S_LIST					"LIST"
#define S_REDIR					"REDIR"
#define S_OREDIR				"OREDIR"
#define S_BJOIN					"BJOIN"
#define S_BQUIT					"BQUIT"
#define S_ADDR					"ADDR"
#define S_ULOK					"ULOK"
#define S_UNLINK				"UNLINK"
#define S_JUMP					"JMP"
#define S_COMEON				"CO"
#define S_BIDLIMIT				"BL"
#define S_UNBANME				"UBM"
#define S_RESET					"RST"
#define S_RDIE					"RDIE"

#define S_NOPERM				strerror(EACCES)
#define S_VERSION				"0.1.3"
#define S_BOTNAME				"psotnic"
#define S_COPYRIGHT				"Copyright (C) 2003-2004 Grzegorz Rusin <pks@irc.pl, gg:1569230>"

#define DIE_REASON				"Taking the blue pill"
#define DIE_REASON2				"told me to take the blue pill"

#define maskstrip(__mask, __nick, __ident, __host)			\
{															\
	char *__a = strchr(__mask, '!');						\
   	char *__b = strchr(__mask, '@');						\
   	mem_strncpy(__nick, __mask, (int) abs(__mask-__a)+1);	\
   	mem_strncpy(__ident, __a+1, (int) abs(__a - __b));		\
   	mem_strcpy(__host, __b+1);								\
}

#define userMask(__mask, __user)							\
{															\
	strcpy(__mask, __user->nick);							\
	strcat(__mask, "!");									\
	strcat(__mask, __user->ident);							\
	strcat(__mask, "@");									\
	strcat(__mask, __user->host);							\
}

#define set(__a, __b)			if(!(__a & __b)) __a += __b
#define unset(__a, __b)			if(__a & __b) __a -= __b
#define debug()					printf("[D] [%s:%d] %s(): %s\n", __FILE__, __LINE__, __FUNCTION__, strerror(errno))
#define	bk						printf("### %s(): %s:%d\n", __FUNCTION__, __FILE__, __LINE__)
#define ircstrip(str)			(str[0] == ':') ? (str+1) : (str)
#define match(mask, str)		!ircd_match(mask, str)
#define strcmp(s1, s2)			ircd_strcmp(s1, s2)
#define strncmp(s1, s2, n)		ircd_strncmp(s1, s2, n)
#define strcasecmp(s1, s2)		ircd_strcmp(s1, s2)
#define strncasecmp(s1, s2, n)	ircd_strncmp(s1, s2, n)


#define VER_NONE		0
#define VER_PSOTNIC		1
#define VER_IRSSI		2
#define VER_EPIC		3
#define VER_LICE		4
#define VER_BITCHX		5
#define VER_DZONY		6
#define VER_LUZIK		7
#define VER_MIRC		8

#ifdef HAVE_DEBUG
	#define DEBUG(x)	if(set.debug) x
#else
	#define DEBUG(x)
#endif

