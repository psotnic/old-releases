/***************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

update::update()
{
	data = NULL;
}