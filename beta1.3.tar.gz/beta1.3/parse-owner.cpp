/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_owner(inetconn *c, char *data)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a, *reason = NULL;
	HANDLE *h;
	int i, n;

	if(!strlen(data)) return;
	memset(buf, 0, MAX_LEN);
	str2words(arg[0], data, 10, MAX_LEN);

	/* NOT REGISTERED OWNER */

	if(!(c->status & STATUS_REGISTERED))
	{
		if(!(c->status & STATUS_TELNET))
		{
			switch(c->tmpint)
			{
				case 1:
				{
					if(MD5HexValidate(config.ownerpass, arg[0], strlen(arg[0]), 0, 0))
					{
						c->killTime = NOW + set.AUTH_TIME;
						++c->tmpint;
						c->send("Enter user password: ", NULL);
						return;
					}
					else
					{
						reason = push(NULL, c->tmpstr, ": bad ownerpass", NULL);
						break;
					}
				}
				case 2:
				{
					if(strlen(arg[0]) && (h = userlist.matchPassToHandle(arg[0], c->tmpstr, HAS_N)))
					{
						c->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_OWNER;
						c->tmpint = 0;
						c->killTime = 0;
						c->handle = h;
						mem_strcpy(c->name, h->name);
						sendLogo(c);
						return;
					}
					else
					{
						reason = push(NULL, c->tmpstr, ": bad userpass", NULL);
						break;
					}
				}
				default: break;
			}
	       	free(c->tmpstr);
	        c->tmpstr = NULL;
		}
		else
		{
			switch(c->tmpint)
			{
				case 1:
				{
					mem_strcpy(c->name, arg[0]);
					++c->tmpint;
					if(set.creation) write(c->fd, "future password: ", strlen("future password: "));
					else write(c->fd, "password: ", strlen("password: "));
					return;
				}
                case 2:
				{
					if(set.creation && strlen(arg[0]))
					{
						if(strlen(arg[0]) < 8)
						{
							c->send("Password must be at least 8 characters long", NULL);
							c->send("Better luck next time", NULL);
							c->close();
							return;
						}
						else
						{
							HANDLE *h = userlist.addHandle(c->name);
							if(h)
							{
								userlist.changePass(c->name, arg[0]);
                				userlist.changeFlags(c->name, "aofmnstx", "");
								c->send("Account created", NULL);
								printf("[*] Account created");

                				userlist.save(config.userlist_file);
                				if(!set.debug)
                    				lurk();
                				set.creation = 0;
                				++userlist.SN;
							}
						}
					}
					if((h = userlist.checkOwnerPass(c->name, arg[0])))
					{
						c->status = STATUS_CONNECTED + STATUS_OWNER + STATUS_REGISTERED;
						c->tmpint = 0;
						c->killTime = 0;
						c->handle = h;
						if(c->tmpstr) free(c->tmpstr);
						c->tmpstr = NULL;
						sendLogo(c);
						return;
					}
					else
					{
						if((h = userlist.findHandle(c->name)))
						{
							if(!(h->flags[MAX_CHANNELS] & HAS_T))
								reason = push(NULL, c->name, ": no owner privileges", NULL);
							else
								reason = push(NULL, c->name, ": wrong owner password", NULL);
						}
						else
							reason = push(NULL, c->name, ": bad owner handle", NULL);

						break;
					}
				}
				default: break;
			}
		}
		if(!reason) reason = push(NULL, "Unknown error", NULL);
		c->close(reason);
		free(reason);
		return;
	}
	/* REGISTERED OWNER */

	if(arg[0][0] != '.')
	{
		net.send(OWNERS, "\002<", c->name, ">\002 ", data, NULL);
	}
	else
	{
		struct tm *ltime= localtime(&NOW);
		strftime(buf, MAX_LEN, "[\002%H\002:\002%M\002] ", ltime);

		if((!strcmp(arg[0], ".chpass") || !strcmp(arg[0], ".chaddr") ||
			!strcmp(arg[0], ".export") || !strcmp(arg[0], ".import")) && strlen(arg[2]))
			net.send(OWNERS, buf, "\002#\002", c->name, "\002#\002 ", arg[0]+1, " ", arg[1], " [something]", NULL);
		else
			net.send(OWNERS, buf, "\002#\002", c->name, "\002#\002 ", data+1, NULL);
	}

	if(!strcmp(arg[0], ".bye") || !strcmp(arg[0], ".exit") || !strcmp(arg[0], ".quit"))
	{
		a = srewind(data, 1);
		c->close(a ? a : c->handle->name);
		return;
	}
	if(!strcmp(arg[0], ".+user") && strlen(arg[1]))
	{
		if((h = userlist.addHandle(arg[1])))
		{
			c->send("Adding user '", arg[1], "'", NULL);
			net.send(FD_BOTS, S_ADDUSER, " ", arg[1], " ", h->creation->print(), NULL);
			++userlist.SN;
		}
		else c->send("Handle '", arg[1], "' allready exists", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-user") && strlen(arg[1]))
	{
		h = userlist.findHandle(arg[1]);
	   	if(!h || userlist.isBot(h))
	    {
			c->send("User '", arg[1], "' does not exist", NULL);
			return;
		}
		switch(userlist.hasWriteAccess(c, arg[1]))
		{
			case -1:
			{
				c->send("User '", arg[1], "' does not exist", NULL);
				break;
			}
			case 0:
			{
				c->send(S_NOPERM, NULL);
				break;
			}
			case 1:
			{
				if(userlist.removeHandle(arg[1]) == -1)
				{
					c->send("This handle is immortal", NULL);
					return;
				}
				c->send("Removing user '", arg[1], "'", NULL);
				net.send(FD_BOTS, S_RMUSER, " ", arg[1], NULL);
				ME.recheckFlags();
				++userlist.SN;
				break;
			}
		}
		return;
	}
	if(!strcmp(arg[0], ".users"))
	{
		if(!userlist.users) c->send("No users in userlist", NULL);
		else userlist.sendUsers(c);
		return;
	}
	if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
	{
		if(!extendhost(arg[2], buf, MAX_LEN))
		{
			c->send("Invalid hostname", NULL);
			return;
		}
		h = userlist.findHandle(arg[1]);
		if(h)
		{
			if(userlist.hasWriteAccess(c, arg[1]) == 1)
			{
				if(userlist.addHost(h, buf) != -1)
				{
					c->send("Adding host '", buf, "' to handle '", arg[1], "'", NULL);
					net.send(FD_BOTS, S_ADDHOST, " ", arg[1], " ", buf, NULL);
					ME.recheckFlags();
					++userlist.SN;
				}
				else c->send("Host '", buf, "' exists", NULL);
			}
			else c->send(S_NOPERM, NULL);
		}
		else c->send("Handle '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-host") && strlen(arg[2]))
	{
		h = userlist.findHandle(arg[1]);
		if(h)
		{
			if(userlist.hasWriteAccess(c, arg[1]) == 1)
			{
				if(userlist.removeHost(h, arg[2]) != -1)
				{
					c->send("Removing host '", arg[2], "' from handle '", arg[1], "'", NULL);
					net.send(FD_BOTS, S_RMHOST, " ", arg[1], " ", arg[2], NULL);
					ME.recheckFlags();
					++userlist.SN;
				}
				else c->send("Host '", arg[2], "' does not exists", NULL);
			}
			else c->send(S_NOPERM, NULL);
		}
		else c->send("Handle '", arg[1], "' does not exist", NULL);
		return;
	}
	if((!strcmp(arg[0], ".whois") || !strcmp(arg[0], ".wi")) && strlen(arg[1]))
	{
		h = userlist.findHandle(arg[1]);
		if(h) userlist.sendHandleInfo(c, h);
		else c->send("User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".match") && strlen(arg[1]))
	{
		h = userlist.first;
		i = 0;

		while(h)
		{
			if(userlist.isBot(h) && !c->checkFlag(HAS_S))
			{
				h = h->next;
				continue;
			}
			else if(arg[1][0] != '+')
			{
				if(match(arg[1], h->name) || userlist.wildFindHostExt(h, arg[1]) != -1)
				{
                	if(i < set.MAX_MATCHES || !set.MAX_MATCHES)
                	{
                		if(i) c->send("---", NULL);
						userlist.sendHandleInfo(c, h);
					}
					++i;
				}
			}
			h = h->next;
		}
		if(i >= set.MAX_MATCHES && set.MAX_MATCHES)
        	c->send("(more�than�", itoa(set.MAX_MATCHES), "�matches,�list�truncated)", NULL);

		if(!i) c->send("No matches found", NULL);
		else c->send("--- Found ", itoa(i), " match", i == 1 ? "" : "es", " for '", arg[1], "'", NULL);
    	return;
	}
	if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
	{
		n = userlist.changeFlags(c, arg[1], arg[2], arg[3]);
		switch(n)
		{
			case -1: c->send("Invalid handle", NULL);
			return;

			case -2: c->send("Invalid channel", NULL);
			return;

			case -3: c->send("Main owner *must* be +ns", NULL);
			return;

			case -4: c->send("'aofmn' are *only* valid channel flags", NULL);
			return;

			case -5: c->send(S_NOPERM, NULL);
			return;

			case -6: c->send("Bot channel flags are unchangable", NULL);
           return;

			default: break;
		}
		userlist.flags2str(n, buf);
		if(strlen(arg[3]))
		{
			c->send("Changing ", arg[3], " flags for '", arg[1], "' to '", buf, "'", NULL);
			net.send(FD_BOTS, S_CHATTR, " ", arg[1], " ", arg[2], " ", arg[3], NULL);
			ME.recheckFlags(arg[3]);
		}
		else
		{
			if(!userlist.isBot(arg[1])) c->send("Changing global flags for '", arg[1], "' to '", buf, "'", NULL);
			else c->send("Changing botnet flags for '", arg[1], "' to '", buf, "'", NULL);
           	net.send(FD_BOTS, S_CHATTR, " ", arg[1], " ", arg[2], NULL);
			ME.recheckFlags();
		}
       	++userlist.SN;
		return;
	}
	if((!strcmp(arg[0], ".mjoin") || !strcmp(arg[0], ".tkmjoin")) && strlen(arg[1]))
	{
        char flags[2];
        if(!strcmp(arg[0], ".tkmjoin"))	flags[0] = 'T';
        else flags[0] = '*';

        flags[1] = '\0';

		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(arg[1][0] != '#' && arg[1][0] != '+' && arg[1][0] != '&' && arg[1][0] != '!')
		{
			c->send("Invalid channel name", NULL);
			return;
		}
		n = userlist.addChannelToList(arg[1], arg[2]);
		if(n == -2)
		{
			c->send("Changing password for channel '", arg[1], "' to '", arg[2], "'", NULL);
			net.send(FD_BOTS, S_ADDCHAN, " ", flags, " ", arg[1], " ", arg[2], NULL);
			++userlist.SN;
		}
		else if(n > -1)
		{
			c->send("Channel '", arg[1], "' has been added to channel list", NULL);
            if(strchr(flags, 'T')) userlist.chanlist[n].chset->TAKEOVER = 1;
			int k = atoi(arg[3]);
			if(k < 0)
			{
				k *= -1;
				snprintf(arg[3], MAX_LEN, "%d", k);
  				net.send(FD_BOTS, S_ADDCHAN, " ", flags, " ", arg[1], " ", arg[2], " ", arg[3], NULL);
				ME.rejoin(arg[1], k);
				c->send("Delaying mass join by ", arg[3], " seconds", NULL);
			}
			else if(k > 0)
			{
				int j = k;
				for(i=0; i<net.max_conns; ++i)
				{
					if(net.conn[i].isRegBot())
					{
						sprintf(buf, "%d", j);
						net.conn[i].send(S_ADDCHAN, " ", flags, " ", arg[1], " ", arg[2], " ", buf, NULL);
						j += k;
					}
				}
				c->send("Setting delay between bots joins to ", arg[3], " seconds", NULL);
				ME.rejoin(arg[1], 0);
			}
			else
			{
				net.send(FD_BOTS, S_ADDCHAN, " ", flags, " ", arg[1], " ", arg[2], NULL);
				ME.rejoin(arg[1], 0);
			}
			++userlist.SN;
		}
		else if(n == -1) c->send("Channel exists in channel list", NULL);
		else c->send("Maximum number of channels joined", NULL);

        return;
	}
	if(!strcmp(arg[0], ".-chan") || !strcmp(arg[0], ".mpart") && strlen(arg[1]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.removeChannelFromList(arg[1]))
		{
			c->send("Channel '", arg[1], "' removed from channel list", NULL);
			net.send(FD_BOTS, S_RMCHAN, " ", arg[1], NULL);
			net.irc.send("PART ", arg[1], " :", config.partreason, NULL);
			++userlist.SN;
		}
		else c->send("Channel does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".+bot") && strlen(arg[2]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if((inet_addr(arg[2]) == INADDR_NONE || !match("*.*.*.*", arg[2])) && strcmp(arg[2], "-"))
		{
			c->send("Invalid IPv4 address", NULL);
			return;
		}
		if((h = userlist.addHandle(arg[1], !strcmp(arg[2], "-") ? 0 : inet_addr(arg[2]), BOT_FLAGS)))
		{
			c->send("Adding new bot '", arg[1], "'", NULL);
			net.send(FD_BOTS, S_ADDBOT, " ", arg[1], " ", h->creation->print(), " ", arg[2], NULL);
			ME.recheckFlags();
			++userlist.SN;
		}
		else c->send("Handle '", buf, "' already exits", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-bot") && strlen(arg[1]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if((n = userlist.removeHandle(arg[1])) == 1)
		{
			c->send("Removing handle '", arg[1], "'", NULL);
            net.send(FD_BOTS, S_RMUSER, " ", arg[1], NULL);
			ME.recheckFlags();
			++userlist.SN;
		}
		else if (n == -1)
		{
			c->send("This handle is immortal", NULL);
			return;
		}
		else c->send("Handle '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".channels"))
	{
		for(n=i=0; i<MAX_CHANNELS; i++)
		{
			if(userlist.chanlist[i].name)
			{
				if(!n) a = push(NULL, userlist.chanlist[i].name, NULL);
				else a = push(a, ", ", userlist.chanlist[i].name, NULL);
				if(strlen(userlist.chanlist[i].pass)) a = push(a , " (key: ", userlist.chanlist[i].pass, ")", NULL);
				++n;
			}
		}
		if(n) c->send("Channels: ", a, NULL);
		else c->send("No channels found", NULL);
		return;
	}
	if(!strcmp(arg[0], ".save"))
	{
		c->send("Saving userlist", NULL);
		userlist.save(config.userlist_file);
		net.send(FD_BOTS, S_ULSAVE, NULL);
		return;
	}
	if(!strcmp(arg[0], ".export") && strlen(arg[1]))
	{
		if(c->checkFlag(CREATOR))
		{
			if(strlen(arg[2])) n = userlist.save(arg[1], 1, arg[2]);
			else n = userlist.save(arg[1], 0);
			if(n) c->send("[+] Exported", NULL);
		}
		else c->send(S_NOPERM, NULL);
		return;
	}
	if(!strcmp(arg[0], ".import") && strlen(arg[1]))
	{
		if(c->checkFlag(CREATOR))
		{
			net.send(OWNERS, "[*] Importing", NULL);
			userlist.reset();
			if(strlen(arg[2])) n = userlist.load(arg[1], 1, arg[2]);
			else n = userlist.load(arg[1], 0);

			if(n == 1)
			{
				net.irc.send("QUIT :Userfile imported", NULL);
				userlist.save(config.userlist_file);
			}
			else if(n == -1)
			{
				net.irc.send("QUIT :Broken userlist", NULL);
				exit(1);
			}
			else if(n == 0)
			{
				net.irc.send("QUIT :Cannot import: ", strerror(errno));
				exit(1);
			}
		}
	}
	if(!strcmp(arg[0], ".bots"))
	{
		if(userlist.bots)
	    {
            h = userlist.first->next;
            a = NULL;

			while(h)
			{
				if(userlist.isBot(h))
					a = push(a, h->name, " ", NULL);
				h = h->next;
			}
		   	c->send("Bots(", itoa(userlist.bots), "): ", a, NULL);
			if(a) free(a);
		}
		else c->send("No bot handles present", NULL);
		return;
	}
	if(!strcmp(arg[0], ".owners") || !strcmp(arg[0], ".who") || !strcmp(arg[0], ".whom"))
	{
		a = NULL;
		for(i=0; i<net.max_conns; ++i)
		{
			if(net.conn[i].isRegOwner())
				a = push(a, net.conn[i].name, " ", NULL);
		}
		c->send("Owners on-line(", itoa(net.owners()), "): ", a, NULL);
		if(a) free(a);
		if(strcmp(arg[0], ".who")) return;
	}
	if(!strcmp(arg[0], ".upbots") || !strcmp(arg[0], ".up") || !strcmp(arg[0], ".who"))
	{
		if(userlist.bots)
		{
			h = userlist.first->next->next;
            a = NULL;
            i = 0;
            while(h)
            {
				if(userlist.isBot(h) && net.findConn(h) && net.findConn(h)->isRegBot())
				{
					a = push(a, h->name, " ", NULL);
					++i;
				}
				h =h->next;
			}
			if(i)
			{
				sprintf(buf, "%d", i);
				c->send("Bots on-line(", buf, "): ", a, NULL);
			}
			else c->send("All bots are down", NULL);
        	if(a) free(a);
		}
		else c->send("No bot handles present", NULL);
		return;
	}
	if(!strcmp(arg[0], ".downbots") || !strcmp(arg[0], ".down"))
	{
		if(userlist.bots)
		{
			h = userlist.first->next->next;
            a = NULL;
            i = 0;

            while(h)
            {
				if(userlist.isBot(h) && (!net.findConn(h) || !net.findConn(h)->isRegBot()))
				{
					a = push(a, h->name, " ", NULL);
					++i;
				}
				h = h->next;
			}
			if(i)
			{
				sprintf(buf, "%d", i);
				c->send("Bots off-line(", buf, "): ", a, NULL);
			}
			else c->send("All bots are up", NULL);
        	if(a) free(a);
		}
		else c->send("No bot handles present", NULL);
		return;
	}
	if(!strcmp(arg[0], ".set"))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		i = set.parseuser(c, "set", arg[1], arg[2]);
		if(i > -1)
		{
			net.send(FD_BOTS, S_SET, " ", arg[1], " ", itoa(*set.varent[i].i), NULL);
			++userlist.SN;
		}
		return;
	}
	if((!strcmp(arg[0], ".chset") || !strcmp(arg[0], ".chanset") || !strcmp(arg[0], ".cset")) && strlen(arg[1]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		i = userlist.findChannelInList(arg[1]);
		if(i != -1)
		{
			n = userlist.chanlist[i].chset->parseuser(c, arg[1], arg[2], arg[3]);
			if(n > -1)
			{
				net.send(FD_BOTS, S_CHSET, " ", arg[1], " ", arg[2], " ", itoa(*userlist.chanlist[i].chset->varent[i].i), NULL);
				++userlist.SN;
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".gset") && strlen(arg[1]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(strlen(arg[2]))
		{
			if(userlist.globalChset(c, arg[1], arg[2]) != -1)
			{
				net.send(FD_BOTS, S_GCHSET, " ", arg[1], " ", arg[2], NULL);
				++userlist.SN;
			}
			return;
		}
		else
		{
			if(!userlist.chanlist[0].name)
			{
				c->send("I dont have any channels in my list", NULL);
				return;
			}
			if(userlist.chanlist[0].chset->parseuser(c, userlist.chanlist[0].name, arg[1], arg[2]) == -1)
				return;

			for(i=1; i<MAX_CHANNELS; ++i)
			{
				if(userlist.chanlist[i].name)
				{
					userlist.chanlist[i].chset->parseuser(c, userlist.chanlist[i].name, arg[1], arg[2]);
				}
			}
			return;
		}
		return;
	}

	if(!strcmp(arg[0], ".mcycle") && strlen(arg[1]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.findChannelInList(arg[1]) != -1)
		{
			if(ME.findChannel(arg[1]))
			{
				net.irc.send("PART ", arg[1], " :", config.cyclereason, NULL);
				ME.rejoin(arg[1], set.CYCLE_DELAY);
			}
			net.send(FD_BOTS, S_CYCLE, " ", arg[1], NULL);
			c->send("[*] Doing mass cycle on ", arg[1], NULL);
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".rcycle") && strlen(arg[2]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(userlist.findChannelInList(arg[2]) != -1)
		{
			if(!strcmp(arg[1], config.handle))
			{
				net.irc.send("PART ", arg[2], " :", config.cyclereason, NULL);
				ME.rejoin(arg[1], set.CYCLE_DELAY);
				net.send(OWNERS, "[*] Doing cycle on ", arg[2], NULL);
			}
			else
			{
				inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
				if(bot && bot->isRegBot()) bot->send(S_CYCLE, " ", arg[2], " ", S_FOO, NULL);
				else c->send("Invalid bot", NULL);
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".rjump") && strlen(arg[2]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(!strcmp(arg[1], config.handle))
		{
			ME.jump(arg[2], arg[3], c->name);
			return;
		}

		inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
		if(bot && bot->isRegBot()) bot->send(S_JUMP, " ", c->name, " ", arg[2], " ", arg[3], NULL);
		else c->send("Invalid bot", NULL);

		return;
	}
	if(!strcmp(arg[0], ".chnick") && strlen(arg[2]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		if(!strcmp(arg[1], config.handle))
		{
			net.irc.send("NICK ", arg[2], NULL);
			ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		}
		else
		{
			inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
			if(bot && bot->isRegBot())
			{
				bot->send(S_NICK, " ", arg[2], NULL);
			}
			else c->send("Invalid bot", NULL);
		}
		return;
	}
	if(!strcmp(arg[0], ".chpass") && strlen(arg[2]))
	{
        if(userlist.hasWriteAccess(c, arg[1]) == 1)
        {
			if(strlen(arg[2]) < 8)
			{
				c->send("Password must be at least 8 charactes long", NULL);
				return;
			}
			if(!(h = userlist.changePass(arg[1], arg[2]))) c->send("Invalid handle", NULL);
			else
			{
				c->send("Changing password for '", arg[1], "'", NULL);
				net.send(FD_BOTS, S_PASSWD, " ", arg[1], " ", h->pass, NULL);
				++userlist.SN;
            }
    	}
		else c->send(S_NOPERM, NULL);
		return;
	}
	if(!strcmp(arg[0], ".chaddr") && strlen(arg[2]))
	{
        if(userlist.hasWriteAccess(c, arg[1]) == 1)
        {
			if(!(h = userlist.changeIp(arg[1], arg[2]))) c->send("Invalid handle or ip", NULL);
			else
			{
				c->send("Changing ip address of '", arg[1], "'", NULL);
				net.send(FD_BOTS, S_ADDR, " ", arg[1], " ", arg[2], NULL);
				++userlist.SN;
            }
    	}
		else c->send(S_NOPERM, NULL);
		return;
	}
	if(!strcmp(arg[0], ".status") || !strcmp(arg[0], ".stat"))
	{
		c->send("- about me:", NULL);
		c->send("Hi. I'm ", ME.nick, " and I'm running psotnic ", S_VERSION, NULL);

		int2units(buf, MAX_LEN, int(NOW - ME.startedAt), ut_time);
		c->send("Up for: ", buf, NULL);
		sprintf(buf, "%d bots and %d owners", net.bots(), net.owners());
		c->send("I have ", buf, " on-line", NULL);

		if(ME.channels)
		{
			c->send("- my channels: ", NULL);
			chan *ch = ME.first;
			while(ch)
			{
				sprintf(buf, ", %d ops, %d total", ch->chops(), ch->users);
				c->send(ch->name, " (", ch->getModes(), buf, ")", NULL);
				ch = ch->next;
			}
		}
		return;
	}
	if(!strcmp(arg[0], ".mk") && strlen(arg[2]))
	{
		if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}

		chan *ch = ME.findChannel(arg[2]);
		if(ch)
		{
			if(!strcmp(arg[1], "a") || !strcmp(arg[1], "all"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_ALL);
				net.send(FD_BOTS, S_MKA, " ", arg[2], NULL);
				c->send("Doing mass kick all on ", arg[2], NULL);
			}
			else if(!strcmp(arg[1], "o") || !strcmp(arg[1], "ops"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_OPS);
				net.send(FD_BOTS, S_MKO, " ", arg[2], NULL);
				c->send("Doing mass kick ops on ", arg[2], NULL);
			}
			else if(!strcmp(arg[1], "n") || !strcmp(arg[1], "nonops") || !strcmp(arg[1], "lames"))
			{
				if(!strcmp(arg[3], "close") || !strcmp(arg[3], "lock"))
					net.irc.send("MODE ", ch->name, " +i", NULL);

				ch->massKick(MK_NONOPS);
				net.send(FD_BOTS, S_MKN, " ", arg[2], NULL);
				c->send("Doing mass kick nonops on ", arg[2], NULL);
			}
			else
			{
				c->send("No such user class", NULL);
			}
		}
		else c->send("Invalid channel", NULL);
		return;
	}



	if(!strcmp(arg[0], ".list") && strlen(arg[1]))
	{
		switch(listcmd(arg[1][0], c->name))
		{
			case 1:
			net.send(FD_BOTS, S_LIST, " ", arg[1], " ", c->name, NULL);
			break;
			case -1:
			c->send("Unknown option: '", arg[1], "'", NULL);
		}
		return;
	}

	if(!strcmp(arg[0], ".verify"))
	{
		/* verify passwds */
		a = NULL;
		h = userlist.first->next;
		i = 0;

		while(h)
		{
			if(!h->pass)
			{
				a = push(a, h->name, " ", NULL);
				++i;
			}
			h = h->next;
		}
		if(i)
		{
			sprintf(buf, "%d", i);
			c->send("Found ", buf, " handle", i == 1 ? "" : "s", " with no password set: ", a, NULL);
			free(a);
		}
    	return;
	}
	if(!strcmp(arg[0], ".bottree") || !strcmp(arg[0], ".bt"))
	{
		userlist.sendBotTree(c);
		return;
	}
	if(!strcmp(arg[0], ".unlink") && strlen(arg[1]))
	{
        if(!c->checkFlag(HAS_S))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		h = userlist.findHandle(arg[1]);
        if(h)
        {
			if(userlist.isSlave(h) || userlist.isLeaf(h))
			{
				inetconn *c = net.findConn(h);
				if(c)
				{
					if(c->status & STATUS_REDIR)
					{
						inetconn *slave = net.findRedirConn(c);
						if(slave) slave->send(S_UNLINK, " ", arg[1], NULL);
					}
					else c->close("Forced unlink");
				}
				return;
    		}
      		else
        	{
				c->send("Not valid bot", NULL);
				return;
			}
		}
		else c->send("No such handle", NULL);
    	return;
	}
	if(!strcmp(arg[0], ".boot") && strlen(arg[2]))
	{
		h = userlist.findHandle(arg[1]);
		if(h)
		{
			inetconn *o = net.findConn(h);
			if(o && o->isRegOwner())
			{
				if((o->checkFlag(CREATOR) && !c->checkFlag(CREATOR)) ||
				   (o->checkFlag(HAS_S) && !c->checkFlag(HAS_S)) ||
				   (o->checkFlag(HAS_N) && !c->checkFlag(HAS_N)))
				{
					c->send(S_NOPERM, NULL);
					return;
				}

				a = srewind(data, 2);
				if(a) o->close(a);
				else o->close("Booted");
			}
			else c->send("Invalid owner", NULL);
		}
		else c->send("Invalid owner", NULL);
		return;
	}
	if(!strcmp(arg[0], ".rdie") && strlen(arg[1]))
	{
		if(!strcmp(arg[1], config.handle))
		{
			if(!c->checkFlag(CREATOR))
			{
				c->close("What? You need '.help'?");
				return;
			}
			net.send(OWNERS, "[!] ", DIE_REASON, NULL);
			net.irc.send("QUIT :", c->handle->name, " ", DIE_REASON2, NULL);
			safeExit();
		}
		inetconn *bot = net.findConn(userlist.findHandle(arg[1]));
		if(bot)
		{
			if(!c->checkFlag(CREATOR))
			{
				c->close("What? You need '.help'?");
				return;
			}
			bot->send(S_RDIE, " ", c->handle->name, NULL);
		}
		return;
	}

	if(!strcmp(arg[0], ".reset") && !strcmp(arg[1], "idle"))
	{
		if(!c->checkFlag(CREATOR))
		{
			c->send(S_NOPERM, NULL);
			return;
		}
		net.propagate(NULL, S_RESET, " I", NULL);
		antiidle.reset();
		c->send("Reseting antiidle timers", NULL);
		return;
	}
	if(!strcmp(arg[0], ".abuse"))
	{
		if(c->checkFlag(CREATOR))
		{
			net.send(OWNERS, "* ", config.handle, " slaps ", c->name, " with Unix User Manual", NULL);
			return;
		}
		c->close("You have just been abused");
		return;
	}

	if(!strcmp(arg[0], ".help"))
	{
		c->send("Available commands:", NULL);
		c->send(".+user   <handle>                  .-user   <handle>", NULL);
		c->send(".+host   <handle> <host>           .-host   <handle> <host>", NULL);
		c->send(".+bot    <handle> <ip>             .-bot    <handle>", NULL);
		c->send(".mjoin   <chan>   [key]   [delay]  .mpart   <chan>", NULL);
		c->send(".chattr  <handle> <flags> [chan]   .chpass  <handle> <pass>", NULL);
        c->send(".botattr <handle> <flags>          .chaddr  <handle> <ip>", NULL);
        c->send(".match   <expr>                    .whois   <handle>", NULL);
		c->send(".set     [var]    [value]          .gset    [var]    [value]", NULL);
		c->send(".chset   <chan>   [var]   [value]  .chnick  <bot>    <nick>", NULL);
		c->send(".mcycle  <chan>                    .rcycle  <bot>    <chan>", NULL);
		c->send(".mk      <o|n|a>  <chan>  [lock]   .bye     [reason]", NULL);
        c->send(".export  <file>   [pass]           .import  <file>   [pass]", NULL);
		c->send(".rjump   <bot>    <host>  [port]   .boot    <handle> <reason>", NULL);
		c->send(".list    <a|p|c|d|s>               .reset   idle", NULL);
		c->send(".rdie    <bot>", NULL);
		c->send(".bots   .upbots   .downbots .bottree  .verify", NULL);
		c->send(".owners .channels .users    .save     .abuse", NULL);
		c->send("allowed global flags: -aofmndst (flag 'd' overrides all flags)", NULL);
        c->send("allowed channel flags: -aofmnd (flag 'd' overrides all flags)", NULL);
        c->send("allowed bot flags: -lsh", NULL);
		c->send("Built-in handles: idiots", NULL);
		c->send("Read CHANGELOG for more details", NULL);
		return;
	}
	if(arg[0][0] == '.')
	{
		c->send("What? You need .help?", NULL);
		return;
	}
}
