/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

penal::penal(int n)
{
	penality = n;
	when = NOW;
}

penal::operator int()
{
	return (int) penality;
}

void penal::calc()
{
	int pen = penality - NOW + when;

	when = NOW;
	penality = pen > 0 ? pen : 0;
}

penal penal::operator+(int n)
{
	penal temp(penality);

	temp.penality += n;

	return temp;
}

penal penal::operator-(int n)
{
	penal temp(penality);

	temp.penality -= n;

	return temp;
}

penal penal::operator +=(int n)
{
	penality += n;
	return *this;
}

penal penal::operator -=(int n)
{
	penality -= n;
	return *this;
}

penal penal::operator++(int)
{
	penality++;
	return *this;
}

penal penal::operator--(int)
{
	penality--;
	return *this;
}
