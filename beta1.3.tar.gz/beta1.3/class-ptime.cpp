/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

static char __dupa[32];

ptime::ptime()
{
	gettimeofday(&tv, NULL);
}

ptime::ptime(char *s, char *n)
{
	tv.tv_sec = strtoul(s, NULL, 10);
	tv.tv_usec = strtoul(n, NULL, 10);
}

ptime::ptime(time_t s, time_t n)
{
	tv.tv_sec = s;
	tv.tv_usec = n;
}

char *ptime::print()
{
	sprintf(__dupa, "%lu %lu", tv.tv_sec, tv.tv_usec);
	return __dupa;
}
/*
int ptime::operator==(ptime &p)
{
    int i = tv.tv_sec == p.tv.tv_sec;
    int j = tv.tv_usec == p.tv.tv_usec;
    printf("time: %s (%p)\ntime: %s (%p)\n--- %d %d\n", print(), this, p.print(), &p, i, j);
	return i && j;
}
*/

