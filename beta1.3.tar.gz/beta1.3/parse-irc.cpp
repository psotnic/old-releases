/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_irc(char *data)
{
    char arg[11][MAX_LEN], *a, *b, buf[MAX_LEN];
    chan *ch;
    CHANUSER *p;
    int i;

    if(!strlen(data))
        return;
    str2words(arg[0], data, 11, MAX_LEN, 1);

    net.irc.killTime = NOW + set.CONN_TIMEOUT;

    /* debug */
#ifdef HAVE_DEBUG

    if(set.debug && !strcmp(arg[1], "PRIVMSG"))
    {
        ch = ME.findChannel(arg[2]);
        if(ch)
        {
            if(!strcasecmp(arg[3], "!debug"))
            {
                printf("### DEBUG ###\n");
                printf("CHANNELS: %d\n", ME.channels);
                ME.display();
                ch->display();
            }
        }
        else if(!strcasecmp(arg[3], "!re"))
            ME.recheckFlags();
    }
#endif

    /* reaction */
    if(!strcmp(arg[1], "JOIN"))
    {
        int netjoin = arg[2][0] != ':';
        if(netjoin)
            a = arg[2];
        else
            a = arg[2] + 1;
        if(!strcasecmp(ME.mask, arg[0]))
        {
            if(userlist.findChannelInList(a) != -1)
            {
                ME.createNewChannel(a);
                net.irc.send("WHO ", a, NULL);
                penality++;
            }
        }
        else
        {
            ch = ME.findChannel(a);
            if(ch)
                ch->gotJoin(arg[0], netjoin ? NET_JOINED : 0);
        }
        return;
    }
    if(!strcmp(arg[1], "MODE"))
    {
        ch = ME.findChannel(arg[2]);
        if(ch)
        {
            a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
            ch->gotMode(arg[3], a, arg[0]);
            free(a);
        }
        return;
    }
    if(!strcmp(arg[1], "KICK"))
    {
        if(!strcasecmp(ME.nick, arg[3]))
        {
			ch = ME.findChannel(arg[2]);
			if(ch)
				ch->buildAllowedOpsList(arg[0]);
			ME.removeChannel(arg[2]);
           	ME.rejoin(arg[2], set.REJOIN_DELAY);
        }
        else
        {
            ch = ME.findChannel(arg[2]);
            if(ch)
                ch->gotKick(arg[3], arg[0]);
        }
        return;
    }
    if(!strcmp(arg[1], "PART"))
    {
        if(!strcasecmp(ME.mask, arg[0]))
        {
            ME.removeChannel(arg[2]);
        }
        else
        {
            ch = ME.findChannel(arg[2]);
            if(ch)
            {
                mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
                ch->gotPart(a, 0);
                free(a);
            }

        }
        return;
    }
    if(!strcmp(arg[1], "NICK"))
    {
        ME.gotNickChange(arg[0], arg[2]);
        return;
    }
    if(!strcasecmp(arg[1], "352"))
    {
        ch = ME.findNotSyncedChannel(arg[3]);
        if(ch)
        {
            a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
            p = ch->gotJoin(a, match("*@*", arg[8]) ? IS_OP : 0);
            if(!strcasecmp(arg[7], ME.nick))
            {
                ch->ptr = p;
                set
                    (p->flags, HAS_B);
            }
            free(a);
        }
        return;
    }
    if(!strcmp(arg[1], "315"))
    {
        ch = ME.findNotSyncedChannel(arg[3]);
        if(ch)
		{
            ch->synlevel = 1;
			if(userlist.chanlist[ch->channum].allowedOps)
			{
				delete userlist.chanlist[ch->channum].allowedOps;
				userlist.chanlist[ch->channum].allowedOps = NULL;
			}
		}
        return;
    }
    if(!strcmp(arg[1], "324"))
    {
        ch = ME.findChannel(arg[3]);
        if(ch)
        {
            ch->limit = 0;
            ch->setFlags(arg[4]);

			a = strchr(arg[4], 'l');
            b = strchr(arg[4], 'k');
            if(a > b)
            {
                ch->updateKey(arg[6]);
                if(*arg[5])
                    ch->limit = atol(arg[5]);
            }
            else if(b > a)
            {
                ch->updateKey(arg[5]);
                if(*arg[6])
                    ch->limit = atol(arg[6]);
            }
            else
                ch->updateKey("");
            ++ch->synlevel;
        }
		if(ch->limit == -1) ch->nextlimit = -1;
		else ch->nextlimit = NOW + set.ASK_FOR_OP_DELAY;

        return;
    }
    if(!strcmp(arg[1], "QUIT"))
    {
		ME.gotUserQuit(arg[0], srewind(data, 2));
        return;
    }
    if(!strcmp(arg[0], "PING"))
    {
        net.irc.send("PONG ", arg[1], NULL);
        return;
    }
    if(!strcmp(arg[1], "433"))
    {
        if(net.irc.status & STATUS_REGISTERED)
            ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
        else
        {
            ME.registerWithNewNick(arg[3]);
            sleep(1);
        }
        return;
    }
    if(!strcmp(arg[1], "437"))
    {
        if(net.irc.status & STATUS_REGISTERED)
        {
            i = userlist.findChannelInList(arg[3]);
            if(i == -1)
            {
                /* Nick is temp...*/
                ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
            }
            else
            {
                /* Channel is temp... */
                ME.rejoin(arg[3], set.REJOIN_FAIL_DELAY);
            }
        }
        else
            ME.registerWithNewNick(arg[3]);
    }
	if(!strcmp(arg[1], "001") && !(net.irc.status & STATUS_REGISTERED))
    {
        mem_strcpy(net.irc.name, arg[0]);
        net.irc.status = STATUS_CONNECTED + STATUS_REGISTERED;
        net.irc.lastPing = NOW;
        if(ME.nick)
            free(ME.nick);
        maskstrip(arg[9], ME.nick, ME.ident, ME.host);
        mem_strcpy(ME.mask, arg[9]);
        srand();
        net.propagate(NULL, S_CHNICK, " ", config.handle, " ", ME.nick, NULL);
        if(strcmp(ME.nick, config.nick))
            ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
        else
            ME.NextNickCheck = 0;
        ME.scheludeJoinToAllChannels();
        if(set.creation)
        {
            printf("[*] Please do `/msg %s mainowner <handle> <password>'\n", ME.nick);
            printf("[*] eg. `/msg %s mainowner %s foobar'\n", ME.nick, getenv("USER"));
        }
		else
			net.send(OWNERS, "[*] Connected to server ", net.irc.name, " as ", ME.nick, NULL);

		if(antiidle.away) net.irc.send("AWAY :", antiidle.away, NULL);
        return;
    }
    if(!strcmp(arg[1], "INVITE"))
    {
        if((i = userlist.findChannelInList(arg[3])) != -1 && !ME.findChannel(arg[3]))
        {
            if(!userlist.chanlist[i].joinsent)
            {
                net.irc.send("JOIN ", arg[3], " ", userlist.chanlist[i].pass, NULL);
                userlist.chanlist[i].joinsent = 1;
            }
        }
        return;
    }
    /*
    if(!strcmp(arg[1], "NOTICE") && !strcasecmp(arg[0], net.irc.origin))
    {
    	if(!strcasecmp(arg[6], "invitation"))
    	{
    		ch = ME.FindChannel(arg[2]);
    		if(ch) mem_strncpy(ch->BanOverride, arg[10], strlen(arg[10]) - 1);
    	}
    	return;
    }
    */
    if(!strcmp(arg[1], "PRIVMSG"))
    {
        /* CTCP */
        if(arg[3][0] == '\001')
        {
            if(data[strlen(data)-1] != '\001')
                return;
            data[strlen(data)-1] = '\0';
            for(i=0; i<3; )
                if(*data++ == ' ')
                    ++i;
            parse_ctcp(arg[0], data + 2, arg[2]);
            return;
        }
        /* op pass #chan */
        if(!strcmp(arg[3], "op") && strlen(arg[5]))
        {
            ch = ME.findChannel(arg[5]);
            if(ch)
            {
                p = ch->getUser(arg[0]);
                if(p && p->flags & HAS_O && !(p->flags & IS_OP))
                {
                    HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
                    if(h)
                        ch->op(p);
                }
            }
            return;
        }
        /* invite pass #chan */
        if(!strcmp(arg[3], "invite") && strlen(arg[5]))
        {
            ch = ME.findChannel(arg[5]);
            if(ch)
            {
                HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
                if(h && (h->flags[MAX_CHANNELS] & HAS_F || h->flags[ch->channum] & HAS_F))
                {
                    ch->invite(arg[0]);
                }
            }
            return;
        }
        /* key pass chan */
        if(!strcmp(arg[3], "key") && strlen(arg[5]))
        {
            ch = ME.findChannel(arg[5]);
            //TODO: add to queue
            if(ch && ch->key && *ch->key)
            {
                HANDLE *h = userlist.matchPassToHandle(arg[4], arg[0], 0);
                if(h && (h->flags[MAX_CHANNELS] & HAS_F || h->flags[ch->channum] & HAS_F))
                    ctcp.push(push(NULL, "NOTICE ", arg[0], " :", arg[5], "'s key: ", ch->key, NULL));
            }
        }

        /*
        if(!strcmp(arg[3], "pass") && strlen(arg[4]) && (ch = ME.FindChannel(arg[2])))
        {
        	a = strchr(arg[0], '!');
        	strncpy(buf, arg[0], abs(a - arg[0]));
        	buf[abs(a - arg[0])] = '\0';
        	p = ch->GetUser(buf);
        	if(p && p->flags & HAS_O)
        	{
        		USER_HANDLE *h = userlist.matchMaskToHandle(arg[0]);
        		if(h)
        		{
        			if(isNullString(h->pass, AUTHSTR_LEN))
        			{
        				MD5HexHash(h->pass, arg[4], strlen(arg[4]), NULL, 0);
        				net.irc.send("PRIVMSG ", buf, " :Password changed to ", arg[4], NULL);
        			}
        			else
        			{
        				net.irc.send("PRIVMSG ", buf, " :You allready have password set", NULL);
        			}
        			ME.NextMsg = NOW + set.ACTION_PENALITY;
        		}
        	}
        }
        */
        /* +n hub */
        /*
        if(!strcmp(arg[3], "!hub") && config.listenport)
        {
        	ch = ME.FindChannel(arg[2]);
        	if(ch)
        	{
        		a = strchr(arg[0], '!');
        		strncpy(buf, arg[0], abs(a - arg[0]));
        		buf[abs(a - arg[0])] = '\0';
        		p = ch->GetUser(buf);
        		if(p && p->flags & HAS_N)
        			net.irc.send("NOTICE ", arg[0], " :Hub version ", S_VERSION, " reporting for duty, sir", NULL);
        	}
        	return;
        }
        */
        /* mainowner */
        if(set.creation && !strcmp(arg[3], "mainowner") && strlen(arg[5]))
        {
            if(!strcmp(arg[4], "idiots"))
            {
                net.irc.send("PRIVMSG ", arg[0], " :Invalid handle", NULL);
                return;
            }
            if(strlen(arg[5]) < 8)
            {
                net.irc.send("PRIVMSG ", arg[0], " :Password must be at least 8 characters long", NULL);
                return;
            }

            HANDLE *h = userlist.addHandle(arg[4]);
            if(h)
            {
                sprintf(buf, "*%s", strchr(arg[0], '!'));
                userlist.addHost(h, buf);
                userlist.changePass(arg[4], arg[5]);
                userlist.changeFlags(arg[4], "aofmnstx", "");

                net.irc.send("PRIVMSG ", arg[0], " :Account created", NULL);
                printf("[*] Added user `%s' with host `%s' and password `%s'\n", arg[4], buf, arg[5]);
                printf("[*] Now do `/chat %s' and supply owner pass from the config file and %s's password\n", ME.nick, arg[4]);

                ++userlist.SN;
                userlist.save(config.userlist_file);
                if(!set.debug)
                    lurk();
                set.creation = 0;
                ++userlist.SN;
            }
        }
        return;
    }
    /* some numeric replies */
    if((i = atoi(arg[1])))
    {
        ch = ME.findChannel(arg[3]);
        if(ch)
        {
            switch(i)
            {
            	case RPL_BANLIST:
	                ch->list[BAN].add(arg[4], "", set.BIE_MODE_BOUNCE_TIME);
    	            return;
				case RPL_ENDOFBANLIST:
            	    ++ch->synlevel;
                	return;
            	case RPL_EXCEPTLIST:
                	ch->list[EXEMPT].add(arg[4], "", set.BIE_MODE_BOUNCE_TIME);
                	return;
            	case RPL_ENDOFEXCEPTLIST:
                	++ch->synlevel;
                	return;
            	case RPL_INVITELIST:
                	ch->list[INVITE].add(arg[4], "", set.BIE_MODE_BOUNCE_TIME);
                	return;
            	case RPL_ENDOFINVITELIST:
                	++ch->synlevel;
                	return;
				default:
					break;
			}
		}
		//not on channel
		else
		{	//if arg[3] is channel name set rejoin delay
			if(userlist.findChannelInList(arg[3]) != -1)
				ME.rejoin(arg[3], set.REJOIN_FAIL_DELAY);

			srand();

			switch(i)
			{
				//+i: S_INVITE <handle> <seed> <channel>
				case ERR_INVITEONLYCHAN:
				{
					if(userlist.findChannelInList(arg[3]) != -1)
						net.propagate(NULL, S_INVITE, " ", config.handle, " ", itoa(rand() % 2048), " ", arg[3], NULL);
					return;
				}
				//+b: S_UNBANME <handle> <seed> <nick!ident@host> <channel>
				case ERR_BANNEDFROMCHAN:
				{
					if(userlist.findChannelInList(arg[3]) != -1)
						net.propagate(NULL, S_UNBANME, " ", config.handle, " ",
							itoa(rand() % 2048), " ", ME.nick, "!", ME.ident, "@", ME.host,
							" ", arg[3], NULL);
					return;
				}
				//+l: S_BIDLIMIT <handle> <seed> <channel>
				case ERR_CHANNELISFULL:
				{
					if(userlist.findChannelInList(arg[3]) != -1)
						net.propagate(NULL, S_BIDLIMIT, " ", config.handle,
							" ", itoa(rand() % 2048), " ", arg[3], NULL);
					return;
				}
				//+k: S_KEY <handle> <seed> <channel>
				case ERR_BADCHANNELKEY:
				{
					if(userlist.findChannelInList(arg[3]) != -1)
						net.propagate(NULL, S_KEY, " ", config.handle, " ", itoa(rand() % 2048), " ", arg[3], NULL);
					return;
				}
				//k:lined
				case ERR_YOUREBANNEDCREEP:
				{
					net.irc.status |= STATUS_KLINED;
					mem_strcpy(net.irc.name, arg[0]);
					a = srewind(data, 10);
					if(a) net.irc.close(a);
					else net.irc.close("K-lined");
					return;
				}
				default:
                	break;
            }
        }
    }

    if(!strcmp(arg[0], "NOTICE"))
    {

        /* P time nano */
        /*
        if(strlen(arg[5]) && !strcmp(arg[2], "P") && strncmp(arg[0], ME.nick, strlen(ME.nick)))
        {
        	if(config.listenport) c

        	*/
    }
}
