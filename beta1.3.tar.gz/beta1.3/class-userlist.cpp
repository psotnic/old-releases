/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003-2004 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

SERVER *ul::findServer(char *host, int port)
{
	for(int i=0; i<MAX_SERVERS; ++i)
		if(config.server[i].host && (!strcmp(config.server[i].host, host) ||
			!strcmp(config.server[i].ip, host)) &&
				(port ? (config.server[i].port == port) : 1))
					return &config.server[i];
	return NULL;
}

int ul::addServer(char *host, int port, int protocol, char *pass)
{
	struct hostent *h = gethostbyname2(host, protocol);

	if(h)
	{
		int i;

		//look for the server
		if(findServer(host, port)) return 0;

		else
		{
			for(i=0; i<MAX_SERVERS; ++i)
			{
				if(!config.server[i].host)
				{
					mem_strcpy(config.server[i].host, host);
					if(protocol == AF_INET)
					{

						mem_strcpy(config.server[i].ip, inet_ntoa(* (struct in_addr *) h->h_addr));
						config.server[i].port = port;
						printf("[+] Resolved: %s -> %s\n", host, config.server[i].ip);
						return 1;
					}
				}
			}
		}
	}
	printf("[-] Unknown host: %s\n", host);
	return 0;
}

int ul::isLeaf(HANDLE *h)
{
	return isBot(h) && ((h->flags[MAX_CHANNELS] & (HAS_H + HAS_L)) == HAS_L);
}

int ul::isSlave(HANDLE *h)
{
	return isBot(h) && ((h->flags[MAX_CHANNELS] & (HAS_H + HAS_L)) == (HAS_H + HAS_L));
}

int ul::isMain(HANDLE *h)
{
	return isBot(h) && ((h->flags[MAX_CHANNELS] & (HAS_H + HAS_L)) == HAS_H);
}

void ul::sendHandleInfo(inetconn *c, HANDLE *h)
{
    int i, n;
    char *a, buf[MAX_LEN];

	c->send("Matching ", userlist.isBot(h) ? "bot '" : "user '", h->name, "'", NULL);
	if(!userlist.isBot(h))
	{
		userlist.flags2str(h->flags[MAX_CHANNELS], buf);
		c->send("global flags: ", buf, h->pass ? ", password is set" : "", NULL);
	}
	else if(c->checkFlag(HAS_S))
	{
		userlist.flags2str(h->flags[MAX_CHANNELS], buf);
		c->send("flags: ", buf, ", ip: ", inet2char(h->ip), h->pass ? ", password is set" : "", NULL);
	}
	else
	{
		c->send(S_NOPERM, NULL);
		return;
	}

	a = push(NULL, "channel flags: ", NULL);
	for(n=i=0; i<MAX_CHANNELS; ++i)
	{
		if(h->flags[i] && userlist.chanlist[i].name)
		{
			userlist.flags2str(h->flags[i], buf);
			if(!n) a = push(a, userlist.chanlist[i].name, "(", buf, ")", NULL);
			else a = push(a, ", ", userlist.chanlist[i].name, "(", buf, ")", NULL);
			++n;
		}
	}
	if(n) c->send(a, NULL);
	free(a);
	for(i=0, n=0; i<MAX_HOSTS; i++)
	{
		if(h->host[i] != NULL)
		{
			sprintf(buf, "[#%d]: ", ++n);
			c->send(buf, h->host[i], NULL);
		}
	}
	if(!n) c->send("No hosts has been found", NULL);
}

HANDLE *ul::changeIp(char *user, char *ip)
{
	HANDLE *h = findHandle(user);

    if(h && isBot(h))
    {
		unsigned int addr = inet_addr(ip);
		if(!strcmp(inet2char(addr), ip))
		{
			h->ip = addr;
			return h;
		}
	}
	return NULL;
}

/* by Pawe� (Googie) Salawa, boogie@myslenice.one.pl */
void ul::sendBotTree(inetconn *c)
{
	int slaves = 0;

	for (int i = 0; i < net.max_conns; ++i )
    {
        if (net.conn[i].isSlave())
            slaves++;
    }

	c->send(config.handle, " (has ", itoa(slaves), " slave",
		slaves == 1 ? (char *) "" : (char *) "s", ")", NULL);

    for ( int i = 0; i < net.max_conns; ++i )
    {
        if (net.conn[i].isSlave())
        {
            int leafs = 0;
            for ( int j = 0; j < net.max_conns; ++j )
            {
                if (net.conn[j].isLeaf() && net.conn[j].fd == net.conn[i].fd)
                    leafs++;
            }

			slaves--;
			c->send(slaves ? (char *) " |" : (char *) " `", "-", net.conn[i].handle->name,
				" (has ", itoa(leafs), " leaf", leafs == 1 ? (char *) "" : (char *) "s", ")", NULL);

            for ( int j = 0; j < net.max_conns; ++j )
            {
                if (net.conn[j].isLeaf() && net.conn[j].fd == net.conn[i].fd)
                {
                    leafs--;
					if (slaves)
					   	c->send(leafs ? (char *) " |   |" : (char *) " |   `", "-", net.conn[j].handle->name, NULL);
					else
                    	c->send(leafs ? (char *) "     |" : (char *) "     `", "-", net.conn[j].handle->name, NULL);
			    }
			}
            //break;
        }
    }
	int n = net.bots();

	c->send("[*] ", itoa(n), " bot",
		n == 1 ? (char *) "" : (char *) "s", " on-line", NULL);

}
/* end of by Googie */

void ul::cleanChannel(int i)
{
    if(!chanlist[i].name) return;
	if(chanlist[i].pass)
	{
        free(chanlist[i].pass);
		chanlist[i].pass = NULL;
	}
	delete chanlist[i].chset;
	chanlist[i].chset  = new chanset;
    chan *ch = ME.findChannel(chanlist[i].name);
    if(ch) ch->chset = chanlist[i].chset;
	chanlist[i].updated = 0;
}

void ul::cleanHandle(HANDLE *h)
{
	int i=0;

	if(h->pass)
	{
		free(h->pass);
		h->pass = NULL;
	}

	for(i=0; i<MAX_HOSTS; ++i)
	{
		if(h->host[i])
		{
			free(h->host[i]);
			h->host[i] = NULL;
		}
	}

	h->updated = 0;

	for(i=0; i<MAX_CHANNELS; ++i)
	{
		h->flags[i] = 0;
	}
	h->flags[MAX_CHANNELS] = (h->flags[MAX_CHANNELS] & HAS_B) ? BOT_FLAGS : 0;
}

int ul::parse(char *data)
{
	char arg[10][MAX_LEN];
	HANDLE *h;

	if(!data || !strlen(data)) return 0;

	str2words(arg[0], data, 10, MAX_LEN);

    if((!strcmp(arg[0], S_ADDUSER) || !strcmp(arg[0], S_ADDBOT)) && strlen(arg[3]))
	{
		if((h = userlist.findHandle(arg[1])))
		{
            ptime t(arg[2], arg[3]);

			if(!memcmp(&t.tv, &h->creation->tv, sizeof(timeval)))
			{
                h->updated = 1;
				return 0;
			}
			else
			{
                userlist.removeHandle(arg[1]);
			}
		}

		if(!strcmp(arg[0], S_ADDUSER)) userlist.addHandle(arg[1], 0, 0);
		else userlist.addHandle(arg[1], inet_addr(arg[4]), BOT_FLAGS);
        h = userlist.findHandle(arg[1]);
        if(h)
		{
			h->updated = 1;
			delete h->creation;
			h->creation = new ptime(arg[2], arg[3]);
            return 1;
		}
		return 0;
	}
	if(!strcmp(arg[0], S_ADDHOST) && strlen(arg[2]))
	{
		h = userlist.findHandle(arg[1]);
		if(h)
		{
			userlist.addHost(h, arg[2]);
			ME.recheckFlags();
            return 1;
		}
		return 0;
	}
	if(!strcmp(arg[0], S_ADDCHAN) && strlen(arg[2]))
	{
      	userlist.addChannelToList(arg[2], arg[3]);

		int i = userlist.findChannelInList(arg[2]);
		if(i > -1)
		{
			if(!strcmp(arg[1], "T")) chanlist[i].chset->TAKEOVER = 1;
			int n = atoi(arg[4]);
			ME.rejoin(arg[2], n);
			chanlist[i].updated = 1;
			return 1;
		}
		return 0;
	}
	if(!strcmp(arg[0], S_RMUSER) && strlen(arg[1]))
	{
		userlist.removeHandle(arg[1]);
		ME.recheckFlags();
		return 1;
	}
	if(!strcmp(arg[0], S_RMHOST) && strlen(arg[2]))
	{
		h = userlist.findHandle(arg[1]);
		if(h)
		{
			userlist.removeHost(h, arg[2]);
			ME.recheckFlags();
			return 1;
		}
		return 0;
	}
	if(!strcmp(arg[0], S_RMCHAN) && strlen(arg[1]))
	{
		userlist.removeChannelFromList(arg[1]);
		net.irc.send("PART ", arg[1], " :", config.partreason, NULL);
		return 1;
   	}

	/* other */
	if(!strcmp(arg[0], S_CHATTR) && strlen(arg[2]))
	{
		userlist.changeFlags(arg[1], arg[2], arg[3]);
		ME.recheckFlags();
		return 1;
	}
	if(!strcmp(arg[0], S_ULSAVE))
	{
		userlist.save(config.userlist_file);
		return 0;
	}

	if(!strcmp(arg[0], S_SET) && strlen(arg[2]))
	{
		set.setvar(arg[1], arg[2]);
		return 1;
	}
	if(!strcmp(arg[0], S_CHSET) && strlen(arg[3]))
	{
		int i = userlist.findChannelInList(arg[1]);
		if(i != -1)
		{
			userlist.chanlist[i].chset->setvar(arg[2], arg[3]);
			return 1;
		}
		return 0;

	}
	if(!strcmp(arg[0], S_GCHSET) && strlen(arg[2]))
	{
		userlist.globalChset(NULL, arg[1], arg[2]);
		return 1;
	}
	if(!strcmp(arg[0], S_PASSWD) && strlen(arg[2]))
	{
		userlist.setRawPassword(arg[1], arg[2]);
		return 1;
	}
	if(!strcmp(arg[0], S_ADDR) && strlen(arg[2]))
	{
		userlist.changeIp(arg[1], arg[2]);
		return 1;
	}
	if(!strcmp(arg[0], S_SN) && strlen(arg[1]))
	{
		SN = strtoul(arg[1], 0, 10);
		return 0;
	}
	return 0;
}
void ul::sendToAll()
{
	int i;
	for(i=0; i<net.max_conns; ++i)
		if(net.conn[i].isRegBot() && net.conn[i].fd > 0) send(&net.conn[i]);
}

int ul::hasEmptyFlags(HANDLE *h)
{
	int i;

	for(i=0; i<MAX_CHANNELS+1; ++i)
		if(h->flags[i]) return 0;

	return 1;
}


int ul::userLevel(HANDLE *h, int n)
{
	if(!h) return 0;

	if(h->flags[n] & CREATOR) return 9;
	if(h->flags[n] & HAS_S) return 8;
	if(h->flags[n] & HAS_N) return 7;
	if(h->flags[n] & HAS_M) return 6;
	if(h->flags[n] & HAS_F) return 5;
	if(h->flags[n] & HAS_O) return 4;
	if(h->flags[n] & HAS_V) return 3;
	if(h->flags[n] & HAS_Q) return 2;
	if(h->flags[n] & HAS_D) return 1;
	return 0;
}



void ul::sendUsers(inetconn *c)
{
	HANDLE *h;
	int j, i, lvl, display;
	char *group[10], buf[MAX_LEN];
	int count[10];

    for(i=MAX_CHANNELS; i != -1; --i)
	{
		if(i == MAX_CHANNELS) c->send("--- global users ---", NULL);
		else if(!chanlist[i].name) continue;

		display = 0;

		h = first->next;
		memset(group, 0, sizeof(group));
		memset(count, 0, sizeof(count));
		while(h)
		{
			if(!(h->flags[MAX_CHANNELS] & HAS_B))
			{
				lvl = userLevel(h, i);
				if(lvl)
				{
					group[lvl] = push(group[lvl], h->name, " ", NULL);
					++count[lvl];
					if(i != MAX_CHANNELS) display = 1;
				}
			}
			h = h->next;
		}
		if(display) c->send("--- ", chanlist[i].name, " users ---", NULL);
		for(j=9; j; --j)
		{
			if(!count[j]) continue;
			switch(j)
			{
				case 9: sprintf(buf, "perms(%d): ", count[j]); break;
				case 8: sprintf(buf, "super owners(%d): ", count[j]); break;
				case 7: sprintf(buf, "owners(%d): ", count[j]); break;
				case 6: sprintf(buf, "masters(%d): ", count[j]); break;
				case 5: sprintf(buf, "friends(%d): ", count[j]); break;
				case 4: sprintf(buf, "chops(%d): ", count[j]); break;
				case 3: sprintf(buf, "voices(%d): ", count[j]); break;
				case 2: sprintf(buf, "quiet(%d): ", count[j]); break;
				case 1: sprintf(buf, "chdeops(%d): ", count[j]); break;
			}
			c->send(buf, group[j], NULL);
			free(group[j]);
		}
	}

	h = first->next;
	group[0] = NULL;
	count[0] = 0;
	while(h)
	{
		if(hasEmptyFlags(h))
		{
			group[0] = push(group[0], h->name, " ", NULL);
			++count[0];
		}
		h = h->next;
	}
	if(count[0])
	{
		sprintf(buf, "no flags(%d): ", count[0]);
		c->send("--- no flags ---", NULL);
		c->send(buf, group[0], NULL);
		free(group[0]);
	}
}

/*
HANDLE *ul::matchMaskToHandle(char *mask)
{
	HANDLE *h = first;
	HANDLE	*found = NULL;
	int i;

	while(h)
	{
		for(i=0; i<MAX_HOSTS; ++i)
		{
			if(match(h->host[i], mask))
			{
				if(found)
				{
					net.send(FD_OWNERS, "*** Mask conflict between ", h->name, " and ", found->name, ", cannot automaticly set password", NULL);
					return NULL;
				}
				else found = h;
			}
		}
		h = h->next;
	}
	return h;
}
*/

void ul::autoSave()
{
	if(nextSave && config.userlist_file && nextSave <= NOW)
	{
		save(config.userlist_file);
		nextSave = 0;
		if(config.bottype == BOT_MAIN) net.send(OWNERS, "[*] Autosaving userlist", NULL);
	}
}

int ul::wildFindHostExt(HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; ++i)
		if(p->host[i] && (match(host, p->host[i]) || match(p->host[i], host)))
			return i;
	return -1;
}

int ul::wildFindHost(HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; ++i)
		if(p->host[i] && match(p->host[i], host)) return i;
	return -1;
}


HANDLE *ul::matchPassToHandle(char *pass, char *host, int flags)
{
	HANDLE *h = first;

	while(h)
	{
		if(!isBot(h) && h->pass && strlen(h->pass) == 32 &&
			((h->flags[MAX_CHANNELS] & flags) == flags) &&
			MD5HexValidate(h->pass, pass, strlen(pass), 0 ,0) &&
			wildFindHost(h, host) != -1)
				return h;

		h = h->next;
	}
	return NULL;
}


int ul::hasWriteAccess(inetconn *c, char *handle)
{
	HANDLE *h = findHandle(handle);

	if(!h) return -1;

    if(!c->checkFlag(HAS_N)) return 0;

	/* modyfining my handle or we are the creator of a bot*/
    if(c->handle == h || c->checkFlag(CREATOR)) return 1;

	/* we are super owner */
	if(c->checkFlag(HAS_S))
	{
		if(!(h->flags[MAX_CHANNELS] & HAS_S)) return 1;
		else return 0;
	}
	return 0;
}

void ul::setRawPassword(char *user, char *rawpass)
{
	HANDLE *h = findHandle(user);
	if(h)
	{
		if(h->pass) free(h->pass);
		mem_strcpy(h->pass, rawpass);
	}
	nextSave = NOW + 60;
}

HANDLE *ul::changePass(char *user, char *pass)
{
	HANDLE *h = findHandle(user);

	if(!h) return NULL;
	if(h->pass) free(h->pass);
	if(isBot(h)) mem_strcpy(h->pass, pass);
	else
	{
        h->pass = (char *) malloc(33);
        MD5HexHash(h->pass, pass, strlen(pass), 0, 0);
    }
	nextSave = NOW + 60;
	return h;
}


HANDLE *ul::checkOwnerPass(char *username, char *pass)
{
	HANDLE *h = findHandle(username);

	if(h && h->pass && (h->flags[MAX_CHANNELS] & HAS_N) && (h->flags[MAX_CHANNELS] & HAS_T)
		&& MD5HexValidate(h->pass, pass, strlen(pass), 0, 0))
			return h;
	else return NULL;
}

int ul::isIdiot(char *mask, int channum)
{
	if(HAS_D & (first->flags[MAX_CHANNELS] | first->flags[channum]))
	{
		for(int i=0; i<MAX_HOSTS; ++i)
			if(first->host[i])
				if(match(first->host[i], mask))
					return 1;
	}
	return 0;
}

int ul::globalChset(inetconn *c, char *var, char *value)
{
	int i;

	if(!chanlist[0].name)
	{
		c->send("I dont have any channels in my list", NULL);
		return -1;
	}
	if(chanlist[0].chset->parseuser(c, "all channels", var, value) == -1)
		return -1;

	for(i=1; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			chanlist[i].chset->parseuser(NULL, "all channels", var, value);

	nextSave = NOW + 60;
	return 0;
}

int ul::addChannelToList(char *name, char *pass)
{
	int i;
	HANDLE *u = first;

	/* change pass */
	if((i = findChannelInList(name)) > -1)
	{
		if(chanlist[i].pass)
        {
			if(!strcmp(chanlist[i].pass, pass)) return -1;
			free(chanlist[i].pass);
		}
		mem_strcpy(chanlist[i].pass, pass);
		nextSave = NOW + 60;
		return -2;
	}

	/* add new channel */
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(!chanlist[i].name)
		{
			memset(&chanlist[i], 0, sizeof(CHANLIST));
			mem_strcpy(chanlist[i].name, name);
			mem_strcpy(chanlist[i].pass, pass);
			chanlist[i].chset = new chanset;
			chanlist[i].wasop = new wasoptest(set.WASOP_CACHE_TIME);
			chanlist[i].joinsent = 0;
			while(u)
			{
				u->flags[i] = 0;
				u = u->next;
			}
			nextSave = NOW + 60;
			return i;
		}
	}
	return -3;
}

int ul::findChannelInList(char *name)
{
	int i;

	for(i=0; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			if(!strcasecmp(chanlist[i].name, name)) return i;
	return -1;
}

int ul::removeChannelFromList(char *name)
{
	int i;
	HANDLE *u = first;

	i = findChannelInList(name);
	if(i == -1) return 0;

    ME.removeChannel(name);
	while(u)
	{
		u->flags[i] = 0;
		u = u->next;
	}
	destroy(&chanlist[i]);

	nextSave = NOW + 60;
	return 1;
}

void ul::update()
{
	int n;
	char *b = ulbuf;
	char *a = NULL;
	HANDLE *h = first->next;
    char buf[MAX_LEN];

	set.reset();

	while(h)
	{
        cleanHandle(h);
		h = h->next;
	}

	for(n=0; n<MAX_CHANNELS; ++n)
		cleanChannel(n);

	while(1)
	{
		memset(buf, 0, MAX_LEN);
 		a = strchr(b, '\n');
		if(a)
		{
			strncpy(buf, b, abs(b-a));
			b = a + 1;
            //printf("parse(\"%s\");\n", buf);
			parse(buf);
		}
		else
		{
			//parse(b);
			break;
		}
	}

    for(n=0; n<MAX_CHANNELS; ++n)
    	if(chanlist[n].name && !chanlist[n].updated) removeChannelFromList(chanlist[n].name);

	h = first->next;
	while(h)
	{
		if(!h->updated) removeHandle(h->name);
		h = h->next;
	}
	free(ulbuf);
	ulbuf = NULL;
	logfile.send("[+] Userlist transfer completed", NULL);
	for(n=0; n < net.conns; ++n)
	{
		if(net.conn[n].fd && net.conn[n].isRegBot() && !(net.conn[n].status & STATUS_REDIR)) ++n;
	}

	net.hub.send(S_ULOK, " ", itoa(n), NULL);
    nextSave = 0;
	save(config.userlist_file);
}

void ul::send(inetconn *c)
{
    int i;
    char buf[MAX_LEN];
    int strip = isLeaf(c->handle);

    c->send(S_UL_UPLOAD_START, NULL);

    HANDLE *h = first->next->next;

    for(i=0; i<MAX_CHANNELS; i++)
		if(chanlist[i].name) send(c, &chanlist[i]);

	send(c, first, strip);
	send(c, first->next->next, strip);
	send(c, first->next, strip);

	while(h)
	{
		send(c, h, strip);
		h = h->next;
	}

	send(c, &set);

	sprintf(buf, "%llu", SN);
	c->send(S_SN, " ", buf, NULL);
	c->send(S_UL_UPLOAD_END, NULL);
}

HANDLE *ul::checkBotMD5Digest(unsigned int ip, char *digest, char *authstr)
{
	HANDLE *h = first;

	while(h)
	{
		if(isBot(h) && ip == h->ip && h->pass &&
			MD5HexValidate(digest, authstr, strlen(authstr), h->pass, strlen(h->pass)))
				return h;
		h = h->next;
	}
	return NULL;

}

int ul::isOwner(char *mask)
{
	HANDLE *h = first;
	int i;

	while(h)
	{
		if(h->flags[MAX_CHANNELS] & HAS_N)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(h->host[i])
				{
					if(match(h->host[i], mask))
					{
						if(h->flags[MAX_CHANNELS] & HAS_S) return 2;
						else return 1;
					}
				}
			}
		}
		h = h->next;
	}
	return 0;
}

int ul::isBot(char *name)
{
	HANDLE *h = findHandle(name);

	if(h && isBot(h)) return 1;
	else return 0;
}

int ul::isBot(HANDLE *h)
{
	return h->flags[MAX_CHANNELS] & HAS_B;
}

int ul::isBot(unsigned int ip)
{
	HANDLE *h = first;

	while(h)
	{
		if(isBot(h) && h->ip == ip) return 1;
		h = h->next;
	}
	return 0;
}

int ul::getFlags(char *mask, chan *ch)
{
	HANDLE *p = first;
	int need = HAS_ALL, got;

	if(isIdiot(mask, ch->channum)) return HAS_D;

	while(p)
	{
        if(isBot(p))
        {
			if(wildFindHost(p, mask) != -1)
				return BOT_FLAGS;
		}
        else
        {
			got = need & (p->flags[MAX_CHANNELS] | p->flags[ch->channum]);
			if(got)
			{
				if(wildFindHost(p, mask) != -1)
					need -= got;
      		}
		}
		p = p->next;
	}
	got = HAS_ALL - need;

	if(got & HAS_D) got = HAS_D;
	else if(got & HAS_O) got &= ~(HAS_V | HAS_Q);
	else if(got & HAS_Q) got &= ~HAS_V;

	return got;
}

void ul::send(inetconn *c, CHANLIST *chan)
{
	c->send(S_ADDCHAN, " * ", chan->name, " ", chan->pass, NULL);
	send(c, chan->chset, chan->name);
}

void ul::send(inetconn *c, HANDLE *h, int strip)
{
    if(h)
    {
	    int i;
    	char buf[MAX_LEN];

		if(isBot(h)) c->send(S_ADDBOT, " ", h->name, " ",  h->creation->print(), " ", strip ? "-" : inet2char(h->ip), NULL);
		else c->send(S_ADDUSER, " ", h->name, " ", h->creation->print(), NULL);

		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i]) c->send(S_ADDHOST, " ", h->name, " ", h->host[i], NULL);

		if(h->flags[MAX_CHANNELS])
		{
            flags2str(h->flags[MAX_CHANNELS], buf);
			c->send(S_CHATTR, " ", h->name, " ", buf, NULL);
	    }
		if(!isBot(h))
		{
			for(i=0; i<MAX_CHANNELS; ++i)
			{
				if(chanlist[i].name && h->flags[i])
				{
					flags2str(h->flags[i], buf);
					c->send(S_CHATTR, " ", h->name, " ", buf, " ", chanlist[i].name, NULL);
				}
			}
		}
		if(h->pass && strip ? !isBot(h) : 1) c->send(S_PASSWD, " ", h->name, " ", h->pass, NULL);
	}
}

void ul::send(inetconn *c, var *v, char *ch)
{
    if(v)
    {
		char buf[MAX_LEN];
    	int i;

	    for(i=0; i<v->ent; ++i)
		{
			if(v->varent[i].def != *v->varent[i].i)
			{
    	        sprintf(buf, "%d", *v->varent[i].i);
        	    if(ch) c->send(S_CHSET, " ", ch, " ", v->varent[i].name, " ", buf, NULL);
            	else c->send(S_SET, " ", v->varent[i].name, " ", buf, NULL);
			}
		}
	}
}

int ul::save(char *file, int cypher, char *key)
{
    inetconn uf;
    char buf[MAX_LEN];
	HANDLE *h = first;
	int i;

	if(config.bottype == BOT_LEAF) return 1;
	if(!SN) return 0;

	logfile.send("[*] Saving userlist", NULL);
	if((uf.open(file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR)) < 1)
	{
		logfile.send("[-] Cannot open ", file, " for writing: ", strerror(errno), NULL);
		net.send(OWNERS, "[-] Cannot open ", file, " for writing: ", strerror(errno), NULL);
		nextSave = NOW + 60;
		return 0;
	}

	if(cypher)
	{
		if(key) uf.enableCrypt((unsigned char *)key, strlen(key));
		else uf.enableLameCrypt();
	}
    else
	{
		uf.send("# Userlist generated by ", S_BOTNAME, " version ", S_VERSION, ".", NULL);
		uf.send("# Please do not hand edit.", NULL);
		uf.send("#                       Thank you --pks", NULL);
	}
	for(i=0; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name) send(&uf, &chanlist[i]);

	while(h)
	{
		send(&uf, h);
		h = h->next;
	}

    send(&uf, &set);

    sprintf(buf, "%llu", SN);
    uf.send(S_SN, " ", buf, NULL);

	logfile.send("[+] Done", NULL);
	nextSave = 0;
	return 1;
}

int ul::load(char *file, int cypher, char *key)
{
    char buf[MAX_LEN];
	inetconn uf;
    int n;

	if(uf.open(file, O_RDONLY) < 1)	return 0;

	if(cypher)
	{
		if(key) uf.enableCrypt((unsigned char *) key, strlen(key));
		else uf.enableLameCrypt();
	}

	while(1)
	{
		n = uf.readln(buf, MAX_LEN);
		if(n > 0)
		{
			if(*buf == '\0' || *buf == '#' || *buf == ';') continue;
			parse(buf);
		}
		else if (n == -1) break;
	}

	if(!SN) return -1;

	nextSave = 0;

	return 1;
}

void ul::flags2str(int flags, char *str)
{
	int i = 0;

	if(flags & HAS_A) str[i++] = 'a';
	if(flags & HAS_O) str[i++] = 'o';
	if(flags & HAS_F) str[i++] = 'f';
	if(flags & HAS_M) str[i++] = 'm';
	if(flags & HAS_N) str[i++] = 'n';
	if(flags & HAS_D) str[i++] = 'd';
	if(flags & HAS_T) str[i++] = 't';
	if(flags & HAS_S) str[i++] = 's';
	if(flags & HAS_B) str[i++] = 'b';
	if(flags & HAS_Q) str[i++] = 'q';
	if(flags & HAS_V) str[i++] = 'v';
	if(flags & CREATOR) str[i++] = 'x';

	/* bot flags */
    if(flags & HAS_L)
    {
		if(flags & HAS_H) str[i++] = 's';
		else str[i++] = 'l';
	}
	else if(flags & HAS_H) str[i++] = 'h';

	if(i == 0) str[i++] = '-';
	str[i] = '\0';
}

int ul::changeFlags(HANDLE *p, char *flags, int channum)
{
    if(!isBot(p))
    {
		/* forbiden channel flags: st */
		if(channum != MAX_CHANNELS && (strchr(flags, 's') || strchr(flags, 't') || strchr(flags, 'x')))
			return -4;

		p->flags[channum] = (p->flags[MAX_CHANNELS] & CREATOR) ? (HAS_N | HAS_S | CREATOR) : 0;

		//not idiot handle
		if(p != first)
		{
			if(strchr(flags, 'a')) p->flags[channum] |= HAS_A;
			if(strchr(flags, 'q')) p->flags[channum] |= HAS_Q;
			if(strchr(flags, 'o')) p->flags[channum] |= HAS_O;
			if(strchr(flags, 'f')) p->flags[channum] |= HAS_F | HAS_O;
			if(strchr(flags, 'm')) p->flags[channum] |= HAS_M | HAS_F | HAS_O;
			if(strchr(flags, 'n')) p->flags[channum] |= HAS_N | HAS_F | HAS_O | HAS_M;
			if(strchr(flags, 't')) p->flags[channum] |= HAS_T | HAS_N | HAS_F | HAS_O | HAS_M;
			if(strchr(flags, 's')) p->flags[channum] |= HAS_S | HAS_N | HAS_F | HAS_O | HAS_M;
     		if(strchr(flags, 'x')) p->flags[channum] |= HAS_S | HAS_N | HAS_F | HAS_O | HAS_M | CREATOR;
		}
		if(strchr(flags, 'd')) p->flags[channum] |= HAS_D;

		nextSave = NOW + 60;
		return p->flags[channum];
	}
	else
	{
		if(channum != MAX_CHANNELS) return -6;
        p->flags[MAX_CHANNELS] = BOT_FLAGS + ((p->flags[MAX_CHANNELS] & HAS_H) ? HAS_H : 0);

		if(strchr(flags, 'l')) p->flags[MAX_CHANNELS] |= HAS_L;
		if(strchr(flags, 'h')) p->flags[MAX_CHANNELS] |= HAS_H;
		if(strchr(flags, 's')) p->flags[MAX_CHANNELS] |= HAS_H | HAS_L;

		nextSave = NOW + 60;
		return p->flags[MAX_CHANNELS];
	}
}

int ul::changeFlags(inetconn *c, char *name, char *flags, char *channel)
{
	if(!c->checkFlag(HAS_S) && (strchr(flags, 's') || strchr(flags, 't')) ||
		!hasWriteAccess(c, name)) return -5;
	if(!c->checkFlag(CREATOR) && strchr(flags, 'x')) return -5;
	return changeFlags(name, flags, channel);
}

int ul::changeFlags(char *name, char *flags, char *channel)
{
	HANDLE *p = findHandle(name);
	int num = MAX_CHANNELS;

	if(!p) return -1;
	if(strlen(channel))
	{
		num = findChannelInList(channel);
		if(num == -1) return -2;
	}
	return changeFlags(p, flags, num);
}

int ul::findHost(HANDLE *p, char *host)
{
	int i;

	if(!p) return -1;

	for(i=0; i<MAX_HOSTS; i++)
		if(p->host[i])
			if(!strcasecmp(p->host[i], host)) return i;

	return -1;
}

HANDLE *ul::findHandle(char *name)
{
	HANDLE *p = first;

	while(p)
	{
		if(!strcmp(p->name, name)) return p;
		p = p->next;
	}
	return NULL;
}

int ul::removeHost(HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			if(!strcmp(p->host[i], host))
			{
				free(p->host[i]);
				p->host[i] = NULL;
				nextSave = NOW + 60;
				return i;
			}
		}
	}
	return -1;
}

int ul::addHost(HANDLE *p, char *host)
{
	int i;

	if(findHost(p, host) != -1) return -1;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] == NULL)
		{
			mem_strcpy(p->host[i], host);
			nextSave = NOW + 60;
			return i;
		}
	}
	return -1;
}

int ul::removeHandle(char *name)
{
	HANDLE *p = first;

	if(!first || !name) return 0;
    if(!strcasecmp(first->name, name) || !strcasecmp(first->next->name, name))
		return -1;

    if(!strcasecmp(last->name, name))
	{
        if(last->flags[MAX_CHANNELS] & CREATOR) return -1;
		p = last->prev;
		p->next = NULL;
		destroy(last);
		last = p;
		nextSave = NOW + 60;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->name, name))
			{
                if(p->flags[MAX_CHANNELS] & CREATOR) return -1;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				destroy(p);
				nextSave = NOW + 60;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

HANDLE *ul::addHandle(char *name, unsigned int ip, int flags, char *sec, char *nano)
{
    HANDLE *p;

	if(findHandle(name)) return NULL;

    if(!first)
    {
		last = first = new(HANDLE);
		first->next = first->prev = NULL;
		memset(last, 0, sizeof(HANDLE));
	}
    else
    {
		p = last->next = new(HANDLE);
        memset(p, 0, sizeof(HANDLE));
		p->prev = last;
		p->next = NULL;
		last = p;
    }

	mem_strcpy(last->name, name);
	last->ip = ip;
    last->flags[MAX_CHANNELS] = flags;

	if(flags & HAS_B) ++bots;
    else ++users;

    if(sec && nano) last->creation = new ptime(sec, nano);
    else last->creation = new ptime();

    nextSave = NOW + 60;

    return last;
}

/* Constructor */
ul::ul()
{
	first = last = NULL;
	bots = users = 0;
	SN = 0;
	nextSave = 0;
	int i;

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
}

/* Destruction derby */
ul::~ul()
{
	HANDLE *hp = first;
	HANDLE *hq;
	int i;

	while(hp)
	{
		hq = hp;
		hp = hp->next;
		destroy(hq);
	}

	for(i=0; i<MAX_CHANNELS; ++i) destroy(&chanlist[i]);
}

void ul::destroy(CHANLIST *p)
{
	if(p->name) free(p->name);
	if(p->pass) free(p->pass);
    delete(p->chset);
	delete(p->wasop);
	if(p->allowedOps) delete(p->allowedOps);
	memset(p, 0, sizeof(CHANLIST));
}

void ul::destroy(HANDLE *p)
{
	int i;
    inetconn *c = net.findConn(p);

    while(c)
    {
		c->close("Lost handle");
		c = net.findConn(p);
		if(!c) break;
	}

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i]) free(p->host[i]);
	}
	free(p->name);
	if(p->pass) free(p->pass);
	if(p->creation) delete p->creation;
	delete(p);
}


void ul::reset()
{
	this->~ul();
	first = last = NULL;
	bots = users = 0;
	SN = 0;
	nextSave = 0;
	int i;

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
}
