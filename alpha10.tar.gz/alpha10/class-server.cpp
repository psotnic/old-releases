#include "prots.h"
#include "global-var.h"

int client::ConnectToHUB()
{
	int n, i, fd;
	struct sockaddr_in peer;
	socklen_t peersize;
	const int one = 1;
	char port[2][16], auth_reply[MAX_LEN], ident[16], *a, *b;

	hub.fd = 0;
	fd = DoConnect(hub.host, hub.port, O_NONBLOCK);
	if(fd > 0)
	{
		n = DoConnect(hub.host, 113, 0);
		if(n > 0)
		{
			peersize = sizeof(struct sockaddr_in);
			getpeername(fd, (sockaddr *) &peer, &peersize);
			sprintf(port[0], "%d", ntohs(peer.sin_port));
			peersize = sizeof(struct sockaddr_in);
			getsockname(fd, (sockaddr *) &peer, &peersize);
			sprintf(port[1], "%d", ntohs(peer.sin_port));
			quote(n, port[0], " , ", port[1], NULL);

			memset(auth_reply, 0, MAX_LEN);
			i = ReadOneLine(n, auth_reply, MAX_LEN);
			if(sclose(n) != 0) debug();
			if(i > 0)
			{
				memset(ident, 0, sizeof(ident));
				a = strrchr(auth_reply, ' ') + 1;
				for(i=0; i<sizeof(ident)-1; i++)
				{
					if(isspace(a[i])) break;
					ident[i] = a[i];
				}
				if(!strcmp(ident, hub.ident))
				{
					hub.fd = fd;
					return fd;
				}
			}
			else debug();
		}
		else debug();
	}
	else debug();

	if(fd > 0) sclose(fd);
	return -1;
}

int client::ConnectToIRC()
{
	int i, n;

	ME.status = 0;
	ME.servid = -1;
	ME.servfd = 0;

	for(i=0; i<MAX_SERVERS; i++)
	{
		if(server[i].port)
		{
			printf(">> Connecting to: %s:%d\n", server[i].ip, server[i].port);
			n = DoConnect(server[i].ip, server[i].port, O_NONBLOCK);
			if(n > 0)
			{
				printf(">> Connected\n");
				ME.servid = i;
				ME.servfd = n;
				ME.status = STATUS_CONNECTED;
				return n;
			}
			else printf(">> Cannot connect\n");
		}
	}
	return 0;
}

void client::CheckQueue()
{
	time_t now;
	chan *ch;
	CHANNEL *p;
	int j;
	CHANUSER **MultHandle;

	p = first;

	now = time(NULL);
	while(1)
	{

		if(!p) return;
		ch = &p->channel;
		if(!ch)
		{
			p = p->next;
			continue;
		}
		if(!ch->ptr)
		{
			p = p->next;
			continue;
		}
		if(!(ch->ptr->flags & IS_OP))
		{
			p = p->next;
			continue;
		}
		if(ch->NextCheck <= now)
		{
			if(ch->BotsToOp.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
				j = GetRandomItems(MultHandle, ch->BotsToOp.first, ch->BotsToOp.ent, 3);
				ch->Op(MultHandle, j);
				ch->NextCheck += 2;
				free(MultHandle);
			}
			else if(ch->ToKick.ent)
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
				j = GetRandomItems(MultHandle, ch->ToKick.first, ch->ToKick.ent, 4);
				ch->Kick(MultHandle, j);
				free(MultHandle);
				ch->NextCheck += j;
			}
		}
		p = p->next;
	}
}

void client::GotUserQuit(char *mask)
{
	char *a, *nick;
	CHANNEL *p;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);

	p = first;
	while(1)
	{
		if(!p) break;
		p->channel.GotPart(nick);
		p = p->next;
	}
	free(nick);
}

void client::RemoveChannel(char *name)
{
	CHANNEL *p;

	if(!strcmp(first->channel.name, name))
	{
		p = first;
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		channels--;

	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->channel.name, name))
			{
				channels--;
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
			}
		}
	}
	current = first;
}


chan *client::FindChannel(char *name)
{
 	if(!current) return NULL;
		if(!strcmp(current->channel.name, name)) return &current->channel;
	current = first;
	while(1)
	{
		if(!current) break;
		if(!strcmp(current->channel.name, name)) return &current->channel;
		current = current->next;
	}
	return NULL;
}

chan *client::CreateNewChannel(char *name)
{
	if(!channels)
	{
		first = current = last = new(CHANNEL);
		current->prev = current->next = NULL;
		mem_strcpy(current->channel.name, name);
		current->channel.modes = 0;
		channels++;
		return &current->channel;
	}
	else
	{
		current = last->next = new(CHANNEL);
  		current->prev = last;
		current->next = NULL;
		current->channel.modes = 0;
		mem_strcpy(current->channel.name, name);
		last = current;
		channels++;
		return &current->channel;
	}

}

client::client()
{
	first = last = current = NULL;
	channels = 0;
	status = 0;
	nextconn = 0;
	nick = NULL;

}

client::~client()
{
	CHANNEL *p;

	p = first;
	while(1)
	{
		if(!p) break;
		RemoveChannel(p->channel.name);
		p = p->next;
	}
	free(nick);
	free(ident);
	free(host);
	free(mask);
	first = last = current = NULL;
	client();
}
