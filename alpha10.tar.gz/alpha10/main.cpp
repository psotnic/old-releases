#include "prots.h"

int AUTOOP_BOTS;
int PUNISH_BOTS;
time_t NOW;
int PUNISH_METHOD;
unsigned int magic[9];
client ME;
ul userlist;
SOCK sock[MAX_CONN];
SERVER server[MAX_SERVERS];
int I_AM_HUB;
int listenfd;
HUB hub;

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd;

	precache();

	if(argc > 1) I_AM_HUB = 1;
	else I_AM_HUB = 0;

	if(I_AM_HUB)
	{
		printf(">> Opening listening socket on %s:%d\n", hub.host, hub.port);
		if((listenfd = StartListening("", hub.port)) < 1)
		{
			debug();
			exit(1);
		}
		printf(">> Done.. %d\n", listenfd);
	}

	while(1)
	{
		n = ME.ConnectToIRC();
		if(n < 1)
		{
			printf("Waiting 30 secs\n");
			sleep(IRC_CONN_DLEAY);
			continue;
		}
		tv.tv_sec = 1;
    	tv.tv_usec = 0;
		srand(time(NULL)*getpid());
		sprintf(buf, "p[%d]", rand()%1000);
		quote(ME.servfd, "NICK ", buf, NULL);
		quote(ME.servfd, "USER bot 8 * :tra la la", NULL);
		last = NOW = time(NULL);
		while(1)
		{
			if(!tv.tv_sec) tv.tv_sec = 1;

			FD_ZERO(&rfd);
    		FD_SET(ME.servfd, &rfd);
			if(I_AM_HUB)
			{
				FD_SET(listenfd, &rfd);
				for(i=0; i<MAX_CONN; i++) if(sock[i].fd > 0) FD_SET(sock[i].fd, &rfd);
			}
			else if(hub.fd) FD_SET(hub.fd, &rfd);


			ret = select(65535, &rfd, NULL, NULL, &tv);

			NOW = time(NULL);
			if(NOW > last + 2)
			{
				last = NOW;
				if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
			}
			if(ME.nextconn <= NOW && hub.fd < 1 && !I_AM_HUB)
			{
				printf("## Connecting to hub\n");
				ME.ConnectToHUB();
				if(!hub.fd)
				{
					ME.nextconn = NOW + HUB_CONN_DELAY;
					printf("## Cannot connect to Hub, next conn in %d secs\n", HUB_CONN_DELAY);
				}
				else
				{
					printf("## Connected to hub\n");
				}

			}

			if(!ret) continue;
			if(FD_ISSET(ME.servfd, &rfd))
			{
				n = ReadOneLine(ME.servfd, buf, MAX_LEN);
				if(n < 1)
				{
					printf("Lost server\n");
					debug();
					if(sclose(ME.servfd) !=0) debug();
					ME.servfd = 0;
					ME.~client();
					break;
				}
				ircparser(buf);
			}
			if(FD_ISSET(hub.fd, &rfd))
			{

				n = ReadOneLine(hub.fd, buf, MAX_LEN);
				if(n < 1)
				{
					debug();
					if(sclose(hub.fd) != 0) debug();
					hub.fd = 0;
				}
			}
			if(FD_ISSET(listenfd, &rfd))
			{
				n = AcceptConnection(listenfd);
			}
			for(i=0; i<MAX_CONN; i++)
            {
                if(sock[i].fd > 0)
                {
                    if(FD_ISSET(sock[i].fd, &rfd))
                    {
                        if(ReadOneLine(sock[i].fd, buf, sizeof(buf)) != -1)
						{
							if(sock[i].flags & STATUS_OWNER)
							{
								ownerparser(&sock[i], buf);
							}
						}
						else
						{
                            printf("Dead socket: sock[%d].fd = %d, Shuting down\n", i, sock[i].fd);
							if(sock[i].flags & STATUS_REGISTERED) quote(FD_OWNERS, "*** ", sock[i].nick, " has left the partyline (", strerror(errno), ")", NULL);
							CloseSock(&sock[i]);
						}
                    }
                }
            }
		}
	}
	return 0;
}

