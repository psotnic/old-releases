#include "prots.h"
#include "global-var.h"

void ownerparser(SOCK *s, char *data)
{
	char arg[10][MAX_LEN], *a, *b, *c, buf[MAX_LEN];
	chan *ch;
	HANDLE *h;
	CHANNEL *x;
	int i, flags, n;

	if(!strlen(data)) return;

	for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  									  &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
	if(!strcmp(arg[0], ".bye"))
	{
		quote(FD_OWNERS, "*** ", s->nick, " has left the partyline (bye)", NULL);
		/* connection handling in main() wont piss about droped connection */
		s->flags = STATUS_CONNECTED;
		CloseSock(s);
		return;
	}
	if(!strcmp(arg[0], ".+user") && strlen(arg[1]))
	{
		if(userlist.AddHandle(arg[1])) quote(FD_OWNERS, "Adding user '", arg[1], "'", NULL);
		else quote(s->fd, "User '", arg[1], "' allready exists", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-user") && strlen(arg[1]))
	{
		if(userlist.RemoveHandle(arg[1])) quote(FD_OWNERS, "Removing user '", arg[1], "'", NULL);
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
	}
	if(!strcmp(arg[0], ".users"))
	{
		if(!userlist.ent) quote(s->fd, "No users in userlist", NULL);
		else
		{
			h = userlist.first->next;
			a = push(NULL, userlist.first->name, NULL);
			while(1)
			{
				if(!h) break;
				a = push(a, ", ", h->name, NULL);
				h = h->next;
			}
			quote(s->fd, "Users: ", a, NULL);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.AddHost(h, arg[2]) != -1) quote(FD_OWNERS, "Adding host '", arg[2], "' to user '", arg[1], "'", NULL);
			else quote(s->fd, "Host '", arg[2], "' exists", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-host") && strlen(arg[2]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.RemoveHost(h, arg[2]) != -1) quote(FD_OWNERS, "Removing host '", arg[2], "' from user '", arg[1], "' host list", NULL);
			else quote(s->fd, "Host '", arg[2], "' does not exists", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".match") && strlen(arg[1]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			userlist.GetFlags(h, buf);
			quote(s->fd, arg[1], "'s flags: ", buf, NULL);
			quote(s->fd, arg[1], "'s hosts:", NULL);
			for(i=0, n=0; i<MAX_HOSTS; i++)
			{
				if(h->host[i] != NULL)
				{
					n++;
					quote(s->fd, "-> ", h->host[i], NULL);
				}
			}
			if(!n) quote(s->fd, "No hosts has been found", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".chattr") && strlen(arg[1]))
	{
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			userlist.ChangeFlags(h, arg[2]);
			userlist.GetFlags(h, buf);
			quote(FD_OWNERS, "Changing flags for '", arg[1], "' to '", buf, "'", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".channels"))
	{
		a = push(NULL, "channels: ", NULL);
		x = ME.first->next;
		a = push(NULL, ME.first->channel.name, NULL);
		while(1)
		{
			if(!x) break;
			a = push(a, ", ", x->channel.name, NULL);
			x = x->next;
		}
		quote(s->fd, "Joined channels: ", a, NULL);
		free(a);
		return;
	}
	if(!strcmp(arg[0], ".save"))
	{
		userlist.Save(NULL);
		return;
	}
	if(!strcmp(arg[0], ".help"))
	{
		quote(s->fd, "Avaible commands:", NULL);
		quote(s->fd, ".+user <id>          - adds user to userlist", NULL);
		quote(s->fd, ".-user <id>          - removes user from userlist", NULL);
		quote(s->fd, ".+host <id> <host>   - assigns host to user", NULL);
		quote(s->fd, ".-host <id> <host>   - removes host from user", NULL);
		quote(s->fd, ".chattr <id> <flags> - changes user flags", NULL);
		quote(s->fd, ".match <id>          - displays users info", NULL);
		quote(s->fd, ".users               - displays users in userlist", NULL);
		quote(s->fd, ".channels            - displays bots channels", NULL);
		quote(s->fd, ".bye                 - quits partyline", NULL);
		quote(s->fd, ".save                - saves userlist", NULL);
		quote(s->fd, "", NULL);
		quote(s->fd, "Flags:", NULL);
		quote(s->fd, "a - autop on join", NULL);
		quote(s->fd, "d - not allowed to have op", NULL);
		quote(s->fd, "o - allowed to have op", NULL);
		quote(s->fd, "f - friend, do not punish", NULL);
		quote(s->fd, "m - is allowed to op ppl", NULL);
		quote(s->fd, "n - is allowed to control bot (you)", NULL);
		quote(s->fd, "b - bot _ONLY_ flag", NULL);
		return;
	}
	if(arg[0][0] == '.')
	{
		quote(s->fd, "What? You need .help?", NULL);
		return;
	}
}
