#include "prots.h"
#include "global-var.h"

int precache()
{
    int i;
    /* calculate 8 powers of 6 - will be used in hash32 function*/
    for (i = 1, magic[0] = 6; i<9; i++) magic[i] = magic[i-1]*6;
	AUTOOP_BOTS = 3;
	PUNISH_BOTS = 3;
	PUNISH_METHOD = 2;
}

void Divide(int *ret, int value, int parts, int part_size)
{
	if(parts == 1)
	{
		ret[0] = value;
		ret[1] = ret[2] = 0;
		return;
	}

	if(value > part_size*2)
    {
        ret[0] = value / parts;
        ret[1] = (value - ret[0]) / (parts-1);
        if(parts == 3) ret[2] = value - ret[0] - ret[1];
        else ret[2] = 0;
    }
    else if(value > part_size)
    {
        ret[0] = part_size;
        ret[1] = value - ret[0];
        ret[2] = 0;
    }
    else
    {
        ret[0] = value;
        ret[1] = ret[2] = 0;
    }
}

int DoConnect(char *server, int port)
{
    struct sockaddr_in sin;
    struct in_addr addr;
    int s;
 
    /* create a socket */
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (!s) return -1;

    /* set up my ip (vhosts not supported yet) */
    memset (&sin, 0, sizeof (struct sockaddr_in));
    sin.sin_addr.s_addr = INADDR_ANY;
    if (bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1) return -2;

    /* where do we want to connect */
    memset (&sin, 0, sizeof (struct sockaddr_in));
    sin.sin_family = PF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);
    if (sin.sin_addr.s_addr == -1) return -3;

    /* connect to server */
    if (connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1) return -4;

	return s;
}

int match(char *str, char *pattern)
{
    if (!fnmatch(pattern, str, FNM_CASEFOLD)) return 1;
    else return 0;
}



unsigned int hash32(char *word)
{
    unsigned int i, crc;
    for(i = 0, crc = 0; i < strlen(word); i++) crc+=word[i]*magic[i];
    if(crc < 0) crc = 0;
    return crc;
}

void quote(int file, char *lst, ...)
{
    va_list ap;
	char *ptr;
    int size=2;
	char *p;

    /* get size */
    va_start(ap, lst);
    size+=strlen(lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }
    /* alocate memory and copy | cat first element*/
    va_start(ap, lst);
    ptr = (char *) malloc(size*sizeof(char));
    strcpy(ptr, lst);
    /* strcat rest */
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
	}

	ptr[size-1] = '\n';
	strcat(ptr, "\0");
	write(file, ptr, size);
	size = printf("<%s> send[%d]: %s\n", ME.nick, size, ptr);
	free(ptr);
}

char *push(char *ptr, char *lst, ...)
{
    va_list ap;
    int size=1;
    char *p;

    /* get size */
    va_start(ap, lst);
    size+=strlen(lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }

    /* alocate memory and copy | cat first element*/
    va_start(ap, lst);
    if(ptr)
    {
        size+=strlen(ptr);
        ptr = (char *) realloc(ptr, size*sizeof(char));
        strcat(ptr, lst);
    }
    else
    {
        ptr = (char *) malloc(size*sizeof(char));
        strcpy(ptr, lst);
    }

    /* strcat rest */
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
    }
    return ptr;
}
