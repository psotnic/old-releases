extern int AUTOOP_BOTS;
extern int PUNISH_BOTS;
extern time_t NOW;
extern int PUNISH_METHOD;
extern unsigned int magic[9];
extern struct client ME;
