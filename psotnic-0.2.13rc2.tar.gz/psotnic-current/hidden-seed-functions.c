void gen_cfg_seed(unsigned char *out)
{
    int i;
    out[0] = 30;
    out[1] = 17;
    out[2] = 98;
    out[3] = 13;
    out[4] = 132;
    out[5] = 235;
    out[6] = 101;
    out[7] = 134;
    out[8] = 97;
    out[9] = 155;
    out[10] = 173;
    out[11] = 58;
    out[12] = 223;
    out[13] = 105;
    out[14] = 75;
    out[15] = 236;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 111;
    }
}

void gen_ul_seed(unsigned char *out)
{
    int i;
    out[0] = 12;
    out[1] = 194;
    out[2] = 62;
    out[3] = 16;
    out[4] = 178;
    out[5] = 106;
    out[6] = 26;
    out[7] = 54;
    out[8] = 12;
    out[9] = 70;
    out[10] = 188;
    out[11] = 44;
    out[12] = 126;
    out[13] = 63;
    out[14] = 66;
    out[15] = 10;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 56;
    }
}

