#define _GNU_SOURCE	1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fnmatch.h>
#include <arpa/inet.h>

#define mem_strncpy(dest, src, n) \
        dest = (char *) malloc(n+1); \
        strncpy(dest, src, n); \
	        dest[n-1] = '\0'
			
#define mem_strcpy(dest, src) \
        dest = (char *) malloc(strlen(src)+1); \
        strcpy(dest, src)

#define HAS_A                   1
#define HAS_B                   2
#define HAS_O                   4
#define HAS_F                   8
#define HAS_M                   16
#define HAS_N                   32
#define HAS_S                   64
#define HAS_D                   128
#define IS_OP                   256

#define ARG_MODES				"oblkeIv"
#define MAX_LEN					"4096";

#define LIST_TOOP					1
#define LIST_BOTSTOOP				2
#define LIST_BOTS					4
#define LIST_TOKICK					8

struct _chanuser
{
    char *nick;
    char *ident;
    char *host;
    int flags;
	  unsigned int crc;
    struct _chanuser *next;
    struct _chanuser *prev;
};

struct _ptrlist
{
	struct _chanuser *ptr;
	struct _ptrlist *next;
	struct _ptrlist *prev;
};

typedef struct _chanuser CHANUSER;
typedef struct _ptrlist PTRLIST;

class ptrlist
{
	private:
	PTRLIST *first;

	int ent;

	public:
	void Add(CHANUSER *ptr);
	void Remove(char *nick);
	int Find(CHANUSER *ptr);
	void DebugDisplay();
	ptrlist();
};


class chan
{
    private:
    CHANUSER *first, *last, *current;
	ptrlist ToOp, BotsToOp, Bots, ToKick;

	int index, users;

    int GetFlagsFromUserList(char *mask);
	CHANUSER *GetUser(char *nick);
	void AddToPtrList(CHANUSER *p);
	void RemoveAll(CHANUSER *handle);

    public:
	void GotNickChange(char *from, char *to);
	void GotMode(char *_args, char *_mode, char *nick);
	void GotKick(char *victim, char *offender);
	void GotPart(char *nick);
    void DebugDisplay();
	CHANUSER *GotJoin(char *mask);
    chan();
};


int DoConnect(char *server, int port);
int match(char *str, char *pattern);
int precache();
unsigned int hash32(char *word);

