#include "prots.h"
#include "global-var.h"

int DoConnect(char *server, int port)
{
    struct sockaddr_in sin;
    struct in_addr addr;
    int s;
    char buf[1024];

    /* create a socket */
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (!s)
    {
		printf("error: socket() failed\n");
		return -2;
    }

    /* set up my ip (vhosts not supported yet) */
    memset (&sin, 0, sizeof (struct sockaddr_in));
    sin.sin_addr.s_addr = INADDR_ANY;
    if (bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1)
    {
        printf("error: bind() failed\n");
		return -2;
    }
			        
    /* where do we want to connect */
    memset (&sin, 0, sizeof (struct sockaddr_in));
    sin.sin_family = PF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);
    if (sin.sin_addr.s_addr == -1)
    {
		printf("error: inet_addr(): No such ip\n");
		return -2;
    }

    /* connect to server */
    if (connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1)
    {
		printf("error: connect() failed\n");
		return -2;
    }
    return s;
}

int match(char *str, char *pattern)
{
    if (!fnmatch(pattern, str, FNM_CASEFOLD)) return 1;
    else return 0;
}

int precache()
{
    int i;
    /* calculate 8 powers of 6 - will be used in hash32 function*/
    for (i = 1, magic[0] = 6; i<9; i++) magic[i] = magic[i-1]*6;
}
	    
unsigned int hash32(char *word)
{
    unsigned int i, crc;
    for(i = 0, crc = 0; i < strlen(word); i++) crc+=word[i]*magic[i];
    if(crc < 0) crc = 0;
    return crc;
}

