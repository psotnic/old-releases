#include "prots.h"

int ptrlist::Find(CHANUSER *ptr)
{
	PTRLIST *p;
	int i=0;
	p=first;
	while(1)
	{
		if(!p) return -1;
		if(ptr == p->ptr) return i;
		i++;
		p = p->next;
	}
}
void ptrlist::Remove(char *nick)
{
	PTRLIST *p;
	p = first;

	if(!ent) return;
	if(!strcmp(first->ptr->nick, nick))
	{
		p = first;
		first->prev = NULL;
		first = first->next;
		delete(p);
		ent--;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->ptr->nick, nick))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
				ent--;
				break;
			}
			p = p->next;
		}
	}
}

void ptrlist::Add(CHANUSER *ptr)
{
	PTRLIST *p, *q;

	if(!ent)
	{
		first = new(PTRLIST);
		first->next = first->prev = NULL;
		first->ptr = ptr;
	}
	else
	{
		if(ptr->crc < first->ptr->crc)
		{
			q = new(PTRLIST);
			q->ptr = ptr;
			first->prev = q;
			q->prev = NULL;
			q->next = first;
			first = q;
		}
		else
		{
			p = first;
			while(1)
			{
				if(ptr->crc == p->ptr->crc) return;
				if(ptr->crc < p->ptr->crc) break;
				else if(p->next == NULL) break;
				p = p->next;
			}
			q = new(PTRLIST);
			if(p->next)
			{
				q->ptr = ptr;
				q->next = p;
				q->prev = p->prev;
				q->prev->next = q;
				p->prev = q;
			}
			else
			{
				//printf("po.. %s\n",
				q->ptr = ptr;
				q->next = NULL;
				q->prev = p;
				p->next = q;
			}
		}
	}
	ent++;
}

void ptrlist::DebugDisplay()
{
	PTRLIST *p;
	p = first;
	printf("Ptr-list: \n");
	while(1)
	{

		if(p == NULL) break;
		printf("[%d]: %s!%s@%s [%d]\n", p->ptr->crc, p->ptr->nick, p->ptr->ident, p->ptr->host, p->ptr->flags);
		p = p->next;
	}
}

ptrlist::ptrlist()
{
	first = NULL;
	ent = 0;
}
