#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int i;
	char buf[4096];
	
	for(i=1; i<argc; ++i)
	{
		sprintf(buf, "./lfe {4v=s@IdpZs]. %s %s-lfe", argv[i], argv[i]);
		system(buf);
	}
	return 0;
}


