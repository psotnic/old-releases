/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

int ul::IsIdiot(char *mask, int channum)
{
	if(HAS_D & (first->flags[MAX_CHANNELS] | first->flags[channum]))
	{
		for(int i=0; i<MAX_HOSTS; ++i)
			if(first->host[i])
				if(match(mask, first->host[i]))
					return 1;
	}
	return 0;
}

int ul::GlobalChset(int fd, char *var, char *value)
{
	int i;

	if(!chanlist[0].name)
	{
		quote(fd, "I dont have any channels in my list", NULL);
		return 0;
	}
	if(chanlist[0].chset->parseuser(fd, "all channels", var, value) == -1)
		return 0;
	
	for(i=1; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			chanlist[i].chset->parseuser(-1, "all channels", var, value);

	return 1;
}

int ul::AddChannelToList(char *name, char *pass)
{
	int i;
	USER_HANDLE *u = first;

	/* change pass */
	if((i = FindChannelInList(name)) != -1)
	{
		if(!strcmp(chanlist[i].pass, pass)) return -1;
		free(chanlist[i].pass);
		mem_strcpy(chanlist[i].pass, pass);
		return -2;
	}
	/* add new channel */
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(!chanlist[i].name)
		{
			mem_strcpy(chanlist[i].name, name);
			mem_strcpy(chanlist[i].pass, pass);
			chanlist[i].chset = new(chanset);
			chanlist[i].joinsent = 0;
			while(u)
			{
				u->flags[i] = 0;
				u = u->next;
			}
			return i;
		}
	}
	return -3;
}

int ul::FindChannelInList(char *name)
{
	int i;

	for(i=0; i<MAX_CHANNELS; ++i)
		if(chanlist[i].name)
			if(!strcasecmp(chanlist[i].name, name)) return i;
	return -1;
}

int ul::RemoveChannelFromList(char *name)
{
	int i;
	USER_HANDLE *u = first;

	i = FindChannelInList(name);
	if(i == -1) return 0;
	while(u)
	{
		u->flags[i] = 0;
		u = u->next;
	}
	Destroy(&chanlist[i]);
	return 1;
}

void ul::Update()
{
	int n;
	char arg[10][MAX_LEN], buf[MAX_LEN];
	char *b = ulbuf;
	char *a = NULL;
	USER_HANDLE *h;

	reset();
	set.reset();

	for(n=0; n<ulbuflines; ++n)
	{
		memset(buf, 0, MAX_LEN);
		a = strchr(b, '\n');
		strncpy(buf, b, abs(b-a));
		b = a + 1;
		
		str2words(arg[0], buf, 10, MAX_LEN);

		if(!strcmp(arg[0], S_ADDUSER) && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], S_ADDHOST) && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], S_CHATTR) && strlen(arg[2]))
		{
			ChangeFlags(arg[1], arg[2], arg[3]);
			continue;
		}
		if(!strcmp(arg[0], S_ADDCHAN) && strlen(arg[1]))
		{
			if(strlen(arg[2]))AddChannelToList(arg[1], arg[2]);
   			else AddChannelToList(arg[1], "");
			continue;
		}
		if(!strcmp(arg[0], S_ADDBOT) && strlen(arg[2]))
		{
			AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], S_SN) && strlen(arg[1]))
		{
			SN = strtoull(arg[1], NULL, 10);
			continue;
		}
		if(!strcmp(arg[0], S_SET) && strlen(arg[2]))
		{
			set.setvar(arg[1], arg[2]);
			continue;
		}
		if(!strcmp(arg[0], S_CHSET) && strlen(arg[3]))
		{
			int i = FindChannelInList(arg[1]);
			if(i != -1)	chanlist[i].chset->setvar(arg[2], arg[3]);
			continue;
		}
	}

	free(ulbuf);
	putlog("[+] Rehashed\n");
	Save(config.userlist_file);
}


void ul::Send(int fd)
{
	char buf[MAX_LEN];
	USER_HANDLE *h = first;
	BOT_HANDLE *b = Bfirst;
	int i, n;

	if(fd < 1) return;

	quote(fd, S_UL_UPLOAD_START, NULL);
	sprintf(buf, "%llu", SN);
	quote(fd, S_SN, " ", buf, NULL);
	for(i=0; i<MAX_CHANNELS; ++i)
	{
		if(chanlist[i].name)
		{
			if(strlen(chanlist[i].pass)) quote(fd, S_ADDCHAN, " ", chanlist[i].name, " ", chanlist[i].pass, NULL);
			else quote(fd, S_ADDCHAN, " ", chanlist[i].name, NULL);
			chanset *chset = chanlist[i].chset;
			for(n=0; n < chset->ent; ++n)
			{
				if(chset->varent[n].def != *chset->varent[n].i)
				{
					sprintf(buf, "%d", *chset->varent[n].i);
					quote(fd, S_CHSET, " ", chanlist[i].name, " ", chset->varent[n].name, " ", buf, NULL);
				}
			}
		}
	}
	while(h)
	{
		if(h != first) quote(fd, S_ADDUSER, " ", h->name, NULL);
		for(i=0; i<MAX_HOSTS; ++i)
			if(h->host[i]) quote(fd, S_ADDHOST, " ", h->name, " ", h->host[i], NULL);

		if(h->flags[MAX_CHANNELS])
		{
			flags2str(h->flags[MAX_CHANNELS], buf);
			quote(fd, S_CHATTR, " ", h->name, " ", buf, NULL);
		}
		for(i=0; i<MAX_CHANNELS; ++i)
		{
			if(chanlist[i].name && h->flags[i])
			{
				flags2str(h->flags[i], buf);	
				quote(fd, S_CHATTR, " ", h->name, " ", buf, " ", chanlist[i].name, NULL);
			}
		}
		h = h->next;
	}
	while(b)
	{
		quote(fd, S_ADDBOT, " ", b->mask, " ", S_SECRET, " ", S_SECRET, NULL);
		b = b->next;
	}
 	for(i=0; i<set.ent; ++i)
	{
		if(set.varent[i].def != *set.varent[i].i)
		{
			sprintf(buf, "%d", *set.varent[i].i);
			quote(fd, S_SET, " ", set.varent[i].name, " ", buf, NULL);
		}
	}
	quote(fd, S_UL_UPLOAD_END, NULL);
}

char *ul::CheckBotMD5Digest(char *ip, char *digest, char *authstr)
{
	BOT_HANDLE *b = Bfirst;

	while(b)
	{
		if(match(ip, b->ip))
			if(MD5HexValidate(digest, authstr, strlen(authstr), b->pass, strlen(b->pass))) return b->pass;
		b = b->next;
	}
	return NULL;

}

int ul::IsOwner(char *mask)
{
	USER_HANDLE *h = first;
	int i;

	if(match(mask, config.owner)) return 1;
	while(h)
	{
		if(h->flags[MAX_CHANNELS] & HAS_N)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(h->host[i])
				{
					if(match(mask, h->host[i]))
					{
						return 1;
					}
				}
			}
		}
		h = h->next;
	}
	return 0;
}

int ul::IsBot(char *ip)
{
	BOT_HANDLE *b = Bfirst;

	while(b)
	{
		if(match(ip, b->ip)) return 1;
		b = b->next;
	}
	return 0;
}

BOT_HANDLE *ul::FindBot(char *mask)
{
	BOT_HANDLE *p = Bfirst;

	while(p)
	{
		if(!strcasecmp(p->mask, mask)) return p;
		p = p->next;
	}
	return NULL;
}

BOT_HANDLE *ul::AddBot(char *mask, char *ip, char *pass)
{
    BOT_HANDLE *p;

	if(FindBot(mask)) return NULL;
    if(!bots)
    {
		Blast = Bfirst = new(BOT_HANDLE);
		Bfirst->next = Bfirst->prev = NULL;
	}
    else
    {
		p = Blast->next = new(BOT_HANDLE);
		p->prev = Blast;
		p->next = NULL;
		Blast = p;
    }
	++bots;
	mem_strcpy(Blast->mask, mask);
	mem_strcpy(Blast->ip, ip);
	mem_strcpy(Blast->pass, pass);
	return Blast;
}

int ul::RemoveBot(char *mask)
{
	BOT_HANDLE *p = Bfirst;

	if(!Bfirst) return 0;
	if(!strcasecmp(Bfirst->mask, mask))
	{
		Bfirst = Bfirst->next;
		if(Bfirst) Bfirst->prev = NULL;
		Destroy(p);
		--bots;
		if (!bots) Blast = NULL;
		return 1;
	}
	else if(!strcasecmp(Blast->mask, mask))
	{
		p = Blast->prev;
		p->next = NULL;
		Destroy(Blast);
		--bots;
		Blast = p;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->mask, mask))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--bots;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

int ul::GetFlags(char *mask, chan *ch)
{
	USER_HANDLE *p = first;
	BOT_HANDLE *b = Bfirst;
	int need = HAS_ALL, got, i;

	if(IsIdiot(mask, ch->channum)) return HAS_D;
	
	while(b)
	{
		if(match(mask, b->mask))
		{
			need -= HAS_A + HAS_O + HAS_F + HAS_M + HAS_B;
			break;
		}
		b = b->next;
	}
	while(p)
	{
		got = need & (p->flags[MAX_CHANNELS] | p->flags[ch->channum]);
		if(got)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(p->host[i])
				{
					if(match(mask, p->host[i]))
					{
						need -= got;
						break;
					}
				}
			}
		}
		p = p->next;
	}
	got = HAS_ALL - need;
	return (got & HAS_D) ? HAS_D : got;
}

int ul::Save(char *file)
{
	char buf[MAX_LEN];
	FILE *f;
	USER_HANDLE *h = first;
	BOT_HANDLE *b = Bfirst;
	STRINGLIST *s = shitlist.first;
	int i, n;

	putlog("[*] Saving userlist\n");
	f = fopen(file, "w");
	if(!f)
	{
		putlog("[-] Error: %s\n", strerror(errno));
		exit(1);
	}
	fprintf(f, "#userlist generated by %s version %s\n", S_BOTNAME, S_VERSION);
	fprintf(f, "#if you want to hand edit please change value of SERIAL_NUMBER\n");
	fprintf(f, "#WARNING: .+chan entries must be placed before any .chattr entires\n\n");
	fprintf(f, "SERIAL_NUMBER %llu\n\n", SN);

	for(i=0; i<MAX_CHANNELS; i++)
	{
		if(chanlist[i].name)
		{
			if(strlen(chanlist[i].pass)) fprintf(f, ".+chan %s %s\n", chanlist[i].name, chanlist[i].pass);
			else fprintf(f, ".+chan %s\n", chanlist[i].name);
			for(n=0; n < chanlist[i].chset->ent; ++n)
			{
				if(chanlist[i].chset->varent[n].def != *chanlist[i].chset->varent[n].i)
				{
					fprintf(f, ".chset %s %s %d\n", chanlist[i].name,
												 	 chanlist[i].chset->varent[n].name,
												 	 *chanlist[i].chset->varent[n].i);
				}
			}
		}
	}
	fprintf(f, "\n");
	while(h)
	{
		if(h != first) fprintf(f, ".+user %s\n", h->name);
		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i] != NULL) fprintf(f, ".+host %s %s\n", h->name, h->host[i]);

		if(h->flags[MAX_CHANNELS])
		{
			flags2str(h->flags[MAX_CHANNELS], buf);
			fprintf(f, ".chattr %s %s\n", h->name, buf);
		}
		for(i=0; i<MAX_CHANNELS; ++i)
		{
			if(chanlist[i].name && h->flags[i])
			{
				flags2str(h->flags[i], buf);
				fprintf(f, ".chattr %s %s %s\n", h->name, buf, chanlist[i].name);
			}
		}
		h = h->next;
		fprintf(f, "\n");
	}
	while(b)
	{
		fprintf(f, ".+bot %s %s %s\n", b->mask, b->ip, b->pass);
		b = b->next;
	}
	fprintf(f, "\n");
	for(i=0; i<set.ent; ++i)
	{
		if(set.varent[i].def != *set.varent[i].i)
		{
			fprintf(f, ".set %s %d\n", set.varent[i].name, *set.varent[i].i);
		}
	}
	fprintf(f, "\n");
	if(config.listenport)
	{
		while(s)
		{
			if(s->str[1])	fprintf(f, ".+shit %s %s\n", s->str[0], s->str[1]);
			else fprintf(f, ".+shit %s\n", s->str[0]);
			s = s->next;
		}
	}
	
	if(set.SAVE_NICK)
	{
		fprintf(f, "\n");
		fprintf(f, ".nick %s\n", config.nick);
	}
	fclose(f);
	putlog("[+] Done\n");
	return 1;
}

int ul::Load(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN];
	char *a;
	USER_HANDLE *h;
	FILE *f;

	printf("[*] Loading userlist from '%s'\n", config.userlist_file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[W] Userlist file not present (new bot?)\n");
		return 0;
	}
	while(!feof(f))
	{
		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);
		str2words(arg[0], buf, 10, MAX_LEN);
		buf[strlen(buf) - 1] = '\0';

		if(*buf == '\0' || *buf == '#' || *buf == ';') continue;

		if(!strcmp(arg[0], ".+user") && strlen(arg[1]) && strcasecmp(arg[1], "bot"))
		{
			AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
		{
			h = FindHandle(arg[1]);
			if(h) AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
		{
			ChangeFlags(arg[1], arg[2], arg[3]);
			continue;
		}
		if(!strcmp(arg[0], ".+chan") && strlen(arg[1]))
		{
			AddChannelToList(arg[1], arg[2]);
			continue;
		}

		if(!strcmp(arg[0], ".+bot") && strlen(arg[3]))
		{
			AddBot(arg[1], arg[2], arg[3]);
   			continue;
		}
		if(!strcmp(arg[0], "SERIAL_NUMBER") && strlen(arg[1]))
		{
			SN = strtoull(arg[1], NULL, 10);
			continue;
		}
		if(!strcmp(arg[0], ".set") && strlen(arg[2]))
		{
			set.setvar(arg[1], arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chset") && strlen(arg[3]))
		{
			int i = FindChannelInList(arg[1]);
			if(i != -1)	chanlist[i].chset->setvar(arg[2], arg[3]);
			continue;
		}
		if(config.listenport)
		{
			if(!strcmp(arg[0], ".+shit") && strlen(arg[1]))
			{
				a = srewind(buf, 2);
				if(a) shitlist.Add(arg[1], a, NULL, 0);
				else shitlist.Add(arg[1], NULL, NULL, 0);
				continue;
			}
		}
		if(!strcmp(arg[0], ".nick") && strlen(arg[1]))
		{
			free(config.nick);
			mem_strcpy(config.nick, arg[1]);
			continue;
		}
	}
	fclose(f);
	printf("[+] Userlist loaded\n");
	return 1;
}

void ul::flags2str(int flags, char *str)
{
	int i = 0;
	if(flags & HAS_A) str[i++] = 'a';
	if(flags & HAS_O) str[i++] = 'o';
	if(flags & HAS_F) str[i++] = 'f';
	if(flags & HAS_M) str[i++] = 'm';
	if(flags & HAS_N) str[i++] = 'n';
	if(flags & HAS_D) str[i++] = 'd';
	if(i == 0) str[i++] = '-';
	str[i] = '\0';
}

int ul::ChangeFlags(USER_HANDLE *p, char *flags, int channum)
{
	p->flags[channum] = 0;
	if(p != first)
	{
		if(strchr(flags, 'a')) p->flags[channum] += HAS_A;
		if(strchr(flags, 'o')) p->flags[channum] += HAS_O;
		if(strchr(flags, 'f')) p->flags[channum] += HAS_F;
		if(strchr(flags, 'm')) p->flags[channum] += HAS_M;
		if(strchr(flags, 'n')) p->flags[channum] += HAS_N;
	}
	if(strchr(flags, 'd')) p->flags[channum] += HAS_D;
	return p->flags[channum];	
}

int ul::ChangeFlags(char *name, char *flags, char *channel)
{
	USER_HANDLE *p = FindHandle(name);
	int num = MAX_CHANNELS;

	if(!p) return -1;
	if(strlen(channel))
	{
		num = FindChannelInList(channel);
		if(num == -1) return -2;
	}
	return ChangeFlags(p, flags, num);
}

int ul::FindHost(USER_HANDLE *p, char *host)
{
	int i;

	if(!p) return -1;

	for(i=0; i<MAX_HOSTS; i++)
		if(p->host[i])
			if(!strcasecmp(p->host[i], host)) return i;

	return -1;
}

USER_HANDLE *ul::FindHandle(char *name)
{
	USER_HANDLE *p = first;

	while(p)
	{
		if(!strcasecmp(p->name, name)) return p;
		p = p->next;
	}
	return NULL;
}

int ul::RemoveHost(USER_HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			if(!strcasecmp(p->host[i], host))
			{
				free(p->host[i]);
				p->host[i] = NULL;
				return i;
			}
		}
	}
	return -1;
}

int ul::AddHost(USER_HANDLE *p, char *host)
{
	int i;

	if(FindHost(p, host) != -1) return -1;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] == NULL)
		{
			mem_strcpy(p->host[i], host);
			return i;
		}
	}
	return -1;
}

int ul::RemoveHandle(char *name)
{
	USER_HANDLE *p = first;

	if(!first) return 0;

	if(!strcasecmp(first->name, name))
	{
		putlog("[!!!] Please don't hack me, thank you [!!!]\n");
		return 0;
		/*
		first = first->next;
		if(first) first->prev = NULL;
		Destroy(p);
		--ent;
		if(!ent) last = NULL;
		return 1;
		*/
	}
	else if(!strcasecmp(last->name, name))
	{
		p = last->prev;
		p->next = NULL;
		Destroy(last);
		--ent;
		last = p;
		return 1;
	}
	else
	{
		while(p)
		{
			if(!strcasecmp(p->name, name))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--ent;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

USER_HANDLE *ul::AddHandle(char *name)
{
    USER_HANDLE *p;
	int i;

	if(FindHandle(name)) return NULL;
    if(!ent)
    {
		last = first = new(USER_HANDLE);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(USER_HANDLE);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
	++ent;
	mem_strcpy(last->name, name);
	for(i=0; i<MAX_HOSTS; ++i) last->host[i] = NULL;
	for(i=0; i<MAX_CHANNELS + 1; ++i) last->flags[i] = 0;
	return last;
}

/* Constructor */
ul::ul()
{
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
	int i;

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
	AddHandle("idiots");
	first->flags[MAX_CHANNELS] = HAS_D;
}

/* Destruction derby */
ul::~ul()
{
	USER_HANDLE *hp = first;
	USER_HANDLE *hq;
	int i;
	
	while(hp)
	{
		hq = hp;
		hp = hp->next;
		Destroy(hq);
	}

	BOT_HANDLE *bp = Bfirst;
	BOT_HANDLE *bq;
	while(bp)
	{
		bq = bp;
		bp = bp->next;
		Destroy(bq);
	}

	for(i=0; i<MAX_CHANNELS; ++i) Destroy(&chanlist[i]);
}

void ul::Destroy(CHANLIST *p)
{
	if(p->name) free(p->name);
	if(p->pass) free(p->pass);
	delete(p->chset);
	memset(p, 0, sizeof(CHANLIST));
}

void ul::Destroy(BOT_HANDLE *p)
{
	if(p->mask) free(p->mask);
	if(p->ip) free(p->ip);
	if(p->pass) free(p->pass);
	free(p);
}

void ul::Destroy(USER_HANDLE *p)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i])
		{
			free(p->host[i]);
			p->host[i] = NULL;
		}
	}
	free(p->name);
	free(p);
}

void ul::reset()
{
	Bfirst = Blast = NULL;
	first = last = NULL;
	bots = ent = 0;
	SN = 0;
	int i;

	this->~ul();

	for(i=0; i<MAX_CHANNELS; ++i) memset(&chanlist[i], 0, sizeof(chanlist[i]));
	AddHandle("idiots");
	first->flags[MAX_CHANNELS] = HAS_D;
}


