extern time_t NOW;
extern client ME;
extern settings set;
extern ul userlist;
extern SOCK sock[MAX_CONN];
extern SOCK hub;
extern int listenfd;
extern CONFIG config;
extern SOCKBUF readbuf[MAX_CONN+2];
extern SOCKBUF writebuf[MAX_CONN+2];
extern stringlist shitlist;
extern char *thisfile;
extern int logfile;

