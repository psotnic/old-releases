/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void stringlist::Display()
{
	STRINGLIST *p = first;

	while(p)
	{
		printf("[%s] [%s] [%s] [%d]\n", p->str[0], p->str[1], p->str[2], p->status);
		p = p->next;
	}
}

STRINGLIST *stringlist::WildFind(char *str, int num)
{
	STRINGLIST *p = first;

	while(p)
	{
		if(match(str, p->str[num])) return p;
		p = p->next;
	}
	return NULL;
}

STRINGLIST *stringlist::Find(char *a, char *b, char *c)
{
	for(STRINGLIST *p=first; p; p=p->next)
	{
		if(a) if(strcasecmp(p->str[0], a)) continue;
		if(b) if(strcasecmp(p->str[1], b)) continue;
		if(c) if(strcasecmp(p->str[2], c)) continue;
		return p;
	}
	return NULL;
}


STRINGLIST *stringlist::Find(char *str, int num)
{
	STRINGLIST *p = first;

	while(p)
	{
		if(!strcasecmp(str, p->str[num])) return p;
		p = p->next;
	}
	return NULL;
}

STRINGLIST *stringlist::Add(char *a, char *b, char *c, int status)
{
	STRINGLIST *p;

	if(Find(a, b, c)) return NULL;
	if(!ent)
	{
		first = last = new(STRINGLIST);
		first->prev = first->next = NULL;
	}
	else
	{
		p = last->next = new(STRINGLIST);
  		p->prev = last;
		p->next = NULL;
		last = p;
	}
	if(a) mem_strcpy(last->str[0], a)
	else last->str[0] = NULL;
	if(b) mem_strcpy(last->str[1], b)
	else last->str[1] = NULL;
	if(c) mem_strcpy(last->str[2], c)
	else last->str[2] = NULL;
	last->status = status;
	++ent;
	return last;
}

int stringlist::Remove(char *str, int num)
{
	STRINGLIST *p = first;

	if(!first) return 0;

	if(!strcasecmp(first->str[num], str))
	{
		first = first->next;
		if(first) first->prev = NULL;
		Destroy(p);
		--ent;
		if(!ent) last = NULL;
		return 1;
	}
	else if(!strcasecmp(last->str[num], str))
	{
		p = last->prev;
		p->next = NULL;
		Destroy(p);
		--ent;
		last = p;
		return 1;
	}
	else
	{
		p = first->next;
		while(p)
		{
			if(!strcasecmp(p->str[num], str))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Destroy(p);
				--ent;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

stringlist::stringlist()
{
	first = last = NULL;
	ent = 0;
}

/* Destruction derby */
stringlist::~stringlist()
{
	STRINGLIST *p = first;
	STRINGLIST *q;

	while(p)
	{
		q = p;
		p = p->next;
		Destroy(q);
	}
}

void stringlist::Destroy(STRINGLIST *p)
{
	if(p->str[0]) free(p->str[0]);
	if(p->str[1]) free(p->str[1]);
	if(p->str[2]) free(p->str[2]);
	free(p);
}
