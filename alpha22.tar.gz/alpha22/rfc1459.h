int _rfc_ncasecmp(const char *str1, const char *str2, int n);
int _rfc_casecmp(const char *s1, const char *s2);
int _rfc_tolower(int c);
int _rfc_toupper(int c);
