/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_irc(char *data)
{
	char arg[11][MAX_LEN], *a, *b, buf[MAX_LEN];
	chan *ch;
	CHANUSER *p;
	int i;

	if(!strlen(data)) return;
	str2words(arg[0], data, 11, MAX_LEN);

	ME.KillTime = NOW + set.PING_TIMEOUT;
	
	/* debug */
	if(!strcmp(arg[1], "PRIVMSG"))
	{
		ch = ME.FindChannel(arg[2]);
		if(!strcasecmp(arg[3], "!debug"))
		{
			printf("### DEBUG ###\n");
			if(ch) ch->Display();
			printf("CHANNELS: %d\n", ME.channels);
			ME.Display();
		}
		else if(!strcasecmp(arg[3], "!re"))
		{
			ME.RecheckFlags();
		}
	}

	/* reaction */
	if(!strcmp(arg[1], "JOIN"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ME.CreateNewChannel(arg[2]);
			quote(ME.servfd, "WHO ", arg[2], NULL);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch)
			{
				putlog("[E] Join observred on nonexiting channel '%s'\n", arg[2]);
			}
			if(!ch->ptr) return;
			ch->GotJoin(arg[0], 0);
		}
		return;
	}
	if(!strcmp(arg[1], "MODE"))
	{
		ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(!ch->ptr) return;
			a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
			ch->GotMode(arg[3], a, arg[0]);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[1], "KICK"))
	{
		if(!strcasecmp(ME.nick, arg[3]))
		{
			ME.RemoveChannel(arg[2]);
			userlist.chanlist[userlist.FindChannelInList(arg[2])].joinsent = 0;
			ME.Rejoin(arg[2], set.REJOIN_DELAY);
			ME.nextjoin = NOW + set.REJOIN_DELAY;
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch)
			{
				putlog("[E] Kick observred on nonexiting channel '%s'\n", arg[2]);
			}
			if(!ch->ptr) return;
			ch->GotKick(arg[3], arg[0]);
		}
		return;
	}
	if(!strcmp(arg[1], "PART"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ME.RemoveChannel(arg[2]);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch)
			{
				putlog("[E] Part observred on nonexiting channel '%s'\n", arg[2]);
			}
			if(!ch->ptr) return;
			mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
			ch->GotPart(a, 0);
			free(a);

		}
		return;
	}
	if(!strcmp(arg[1], "NICK"))
	{
		ME.GotNickChange(arg[0], arg[2]);
		return;
	}
	if(!strcasecmp(arg[1], "352"))
	{
		ch = ME.FindChannel(arg[3]);
		a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
		p = ch->GotJoin(a, match(arg[8], "*@*"));
		if(!strcasecmp(arg[7], ME.nick))
		{
			ch->ptr = p;
			set(p->flags, HAS_B);
		}
		free(a);
		return;
	}
	if(!strcmp(arg[1], "315"))
	{
		ch = ME.FindChannel(arg[3]);
		if(!ch->ToKick.ent)
		{
			quote(ME.servfd, "MODE ", arg[3], NULL);
		}
		set(ch->status, STATUS_SYNCED);
		return;
	}
	if(!strcmp(arg[1], "324"))
	{
		ch = ME.FindChannel(arg[3]);
		if(ch)
		{
			if(ch->modes) free(ch->modes);
			ch->limit = 0;
			mem_strcpy(ch->modes, arg[4] + 1);

			a = strchr(arg[4], 'l');
			b = strchr(arg[4], 'k');
			if(a > b)
			{
				ch->UpdateKey(arg[6]);
				if(*arg[5]) ch->limit = atol(arg[5]);
			}
			else if(b > a)
			{
				ch->UpdateKey(arg[5]);
				if(*arg[6]) ch->limit = atol(arg[6]);
			}
			else ch->UpdateKey("");
		}
		/*
		if(strlen(arg[4]) == 1 && !strcmp(ch->ptr->nick, ME.nick) && ch->ptr->flags & IS_OP)
			quote(ME.servfd, "MODE ", arg[3], " +snt", NULL);
		*/
		return;
	}
	if(!strcmp(arg[1], "QUIT"))
	{
		ME.GotUserQuit(arg[0]);
		return;
	}
	if(!strcmp(arg[0], "PING"))
	{
		quote(ME.servfd, "PONG ", arg[1], NULL);
		return;
	}
	if(!strcmp(arg[1], "433"))
	{
		if(ME.status & STATUS_REGISTERED) ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		else ME.RegisterWithNewNick(arg[3]);
		return;
	}
	if(!strcmp(arg[1], "437"))
	{
		if(ME.status & STATUS_REGISTERED)
		{
			i = userlist.FindChannelInList(arg[3]);
			if(i == -1)
			{
				/* Nick is temp...*/
				ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
			}
			else
			{
				/* Channel is temp... */
				ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);
			}
		}
		else ME.RegisterWithNewNick(arg[3]);
	}
	if(!strcmp(arg[1], "471") || !strcmp(arg[1], "473") || !strcmp(arg[1], "474"))
	{
		i = userlist.FindChannelInList(arg[3]);
		if(i != -1)
		{
			ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);

			if(!config.listenport) quote(hub.fd, S_INVITE, " ", arg[3], NULL);
			else quote(FD_BOTS, S_INVITE, " ", arg[3], NULL);
		}
		return;
	}
	if(!strcmp(arg[1], "475"))
	{
		i = userlist.FindChannelInList(arg[3]);
		if(i != -1)
		{
			ME.Rejoin(arg[3], set.REJOIN_FAIL_DELAY);
			if(!config.listenport) quote(hub.fd, S_KEY, " ", arg[3], NULL);
			else quote(FD_BOTS, S_KEY, " ", arg[3], NULL);
		}
		return;
	}
	if(!strcmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
	{
		ME.status += STATUS_REGISTERED;
		maskstrip(arg[9], ME.nick, ME.ident, ME.host);
		mem_strcpy(ME.mask, arg[9]);
		mem_strcpy(ME.servname, arg[0]);
		srand(hash32(ME.nick)*getpid());
		if(hub.fd && hub.status & STATUS_REGISTERED) quote(hub.fd, S_NEWNICK, " ", ME.nick, NULL);
		if(strcmp(ME.nick, config.nick)) ME.NextNickCheck = NOW + set.KEEP_NICK_CHECK_DELAY;
		else ME.NextNickCheck = 0;
		ME.ScheludeJoinToAllChannels();
		return;
	}
	if(!strcmp(arg[1], "INVITE"))
	{
		if((i = userlist.FindChannelInList(arg[3])) != -1 && !ME.FindChannel(arg[3]))
		{
			if(!userlist.chanlist[i].joinsent)
			{
				quote(ME.servfd, "JOIN ", arg[3], " ", userlist.chanlist[i].pass, NULL);
				userlist.chanlist[i].joinsent = 1;
			}
		}
		return;
	}
	if(!strcmp(arg[1], "NOTICE") && !strcasecmp(arg[0], ME.servname))
	{
		if(!strcasecmp(arg[6], "invitation"))
		{
			ch = ME.FindChannel(arg[2]);
			if(ch) mem_strncpy(ch->BanOverride, arg[10], strlen(arg[10]) - 1);
		}
		return;
	}
	if(!strcmp(arg[1], "PRIVMSG"))
	{
 		if(arg[3][0] == '\001')
		{
			if(data[strlen(data)-2] != '\001') return;
			data[strlen(data)-2] = '\0';
			for(i=0; i<3; ) if(*data++ == ' ') ++i;
			parse_ctcp(arg[0], ++data, arg[2]);
			return;
		}
		if(!strcmp(arg[3], "!hub") && config.listenport)
		{
			quote(ME.servfd, "NOTICE ", arg[0], " :Hub version ", S_VERSION, " reporting for duty, sir", NULL);
			return;
		}
		if(!strcmp(arg[3], "!op"))
		{
			ch = ME.FindChannel(arg[2]);
			if(ch)
			{
				if(MyTurn(&ch->OpedBots, hash32(arg[0]) + hash32(arg[2]), ch->NumberOfBots(ch->chset->AUTOOP_BOTS)))
				{
					a = strchr(arg[0], '!');
					strncpy(buf, arg[0], abs(a - arg[0]));
					buf[abs(a - arg[0])] = '\0';
					p = ch->GetUser(buf);
					if(p)
						if(p->flags & HAS_O && !(p->flags & HAS_D) && !(p->flags & IS_OP))
							quote(ME.servfd, "MODE ", arg[2], " +o ", p->nick, NULL);
				}
			}
			return;
		}
		return;
	}
}
