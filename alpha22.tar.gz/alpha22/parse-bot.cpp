/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_bot(SOCK *s, char *data)
{
	char arg[10][MAX_LEN], *a;
	chan *ch;

	if(!strlen(data)) return;
	str2words(arg[0], data, 10, MAX_LEN);
	
	/* REGISTER CONNECTION */
	if(!(s->status & STATUS_REGISTERED))
	{
		switch(s->authstep)
		{
			case 1:
			{
				if(!strcmp(arg[0], config.botnetword))
				{
					s->authstr = (char *) malloc(AUTHSTR_LEN + 1);
					++s->authstep;
					MD5CreateAuthString(s->authstr, AUTHSTR_LEN);
					quote(s->fd, S_AUTH, " ", s->authstr, NULL);
					return;
				}
				break;
			}
			case 2:
			{
				if(!strcmp(arg[0], S_AUTHRPL) && strlen(arg[1]) == 32)
				{
					a = userlist.CheckBotMD5Digest(getpeerip(s->fd), arg[1], s->authstr);
					if(a)
					{
						s->pass = a;
						++s->authstep;
						quote(s->fd, S_AUTHOK, NULL);
						return;
					}
				}
				break;
			}
			case 3:
			{
				if(!strcmp(arg[0], S_AUTH) && strlen(arg[1]) == AUTHSTR_LEN)
				{
					char hash[33];

					++s->authstep;
					MD5HexHash(hash, arg[1], AUTHSTR_LEN, s->pass, strlen(s->pass));
					quote(s->fd, S_AUTHRPL, " ", hash, NULL);
					return;
				}
				break;
			}
			case 4:
			{
				/* S_REGISTER <ME.nick> <S_VERSION> <userlist.SN> */
				if(!strcmp(arg[0], S_REGISTER) && strlen(arg[3]))
				{
					quote(s->fd, S_NEWNICK, " ", ME.nick, NULL);
					mem_strcpy(s->name, arg[1]);
					s->status = STATUS_CONNECTED + STATUS_REGISTERED + STATUS_BOT;
					s->authstep = 0;
					s->killtime = NOW + set.PING_TIMEOUT;
					s->lastping = NOW;
					quote(FD_OWNERS, "*** ", arg[1], " has joined the botnet", NULL);
					if(userlist.SN != strtoull(arg[3], NULL, 10))
					{
						quote(FD_OWNERS, "*** Sending userlist to ", arg[1], NULL);
						userlist.Send(s->fd);
					}
					++set.pl_bots;
					return;
				}
				break;
			}
			default: break;
		}
		/* HUH */
		putlog("[-] Failed to register bot\n");
		CloseSock(s);
	}

	/* PARSE DATA FROM REGISTERED BOT */

	s->killtime = NOW + set.PING_TIMEOUT;
	
	if(!strcmp(arg[0], S_NEWNICK) && strlen(arg[1]))
	{
		quote(FD_OWNERS, "*** ", s->name, " is now known as ", arg[1], NULL);
		free(s->name);
		mem_strcpy(s->name, arg[1]);
		return;
	}
	/* S_INVITE <chan> [nick] */
	if(!strcmp(arg[0], S_INVITE) && strlen(arg[1]))
	{
		if(strlen(arg[2])) ME.BotNetInvite(arg[1], arg[2]);
		else ME.BotNetInvite(arg[1], s->name);
		return;
	}
	if(!strcmp(arg[0], S_KEY) && strlen(arg[1]))
	{
		ch = ME.FindChannel(arg[1]);
		if(strlen(arg[2]))
		{
			mem_strcpy(a, arg[2]);
		}
		else mem_strcpy(a, s->name);

		if(ch)
		{
			if(ch->key)
			{
				quote(s->fd, S_KEYRPL, " ", arg[1], " ", ch->key, NULL);
			}
		}
		free(a);
		return;
	}
	if(!strcmp(arg[0], S_OP) && strlen(arg[1]))
	{
		ch = ME.FindChannel(arg[1]);
		if(strlen(arg[2]))
		{
			mem_strcpy(a, arg[2]);
		}
		else mem_strcpy(a, s->name);

		if(ch)
		{
			CHANUSER *u = ch->GetUser(a);
			if(u) ch->Op(u);
		}
	}
	if(!strcmp(arg[0], S_GETOP) && strlen(arg[2]))
	{
		if(userlist.FindChannelInList(arg[1]) != -1)
		{
			int n = FindSock(arg[2]);
			if(n != -1) quote(sock[n].fd, S_OP, " ", arg[1], " ", s->name, NULL);
		}
	}
}
