#define _NO_LAME_ERRNO			1

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/utsname.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fnmatch.h>
#include <arpa/inet.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <arpa/nameser.h>
#include <resolv.h>

#include "rfc1459.h"
#include "defines.h"
#include "structs.h"
#include "temp-array.h"
#include "temp-list.h"
#include "classes.h"
#include "md5.h"

typedef void (*sighandler_t)(int);
typedef void (*sig_t)(int);

/* parse functions */
void parse_irc(char *data);
void parse_owner(SOCK *s, char *data);
void parse_bot(SOCK *s, char *data);
void parse_hub(char *data);
void parse_ctcp(char *mask, char *data, char *to);

/* net functions  */
int DoConnect(char *server, int port, char *vhost, int noblock);
int DoConnect6(char *server, int port, char *vhost, int options);
int ReadOneLine(int fd, char *buf, int len);
int AcceptConnection(int fd);
int StartListening(char *ip, int port);
int getpeerport(int fd);
int AddSock(int fd);
int FindSock(char *name);
void CloseSock(SOCK *s);
void sclose(int fd);
void HandleDeadSocket(int fd, SOCK *s);
void RemoveBuffers(int fd);
void quote(int file, char *lst, ...);
void BufWrite(int fd, char *data, int len);
char *getpeerip(int fd);
char *inet2char(unsigned int inetip);
int SendDNSQuery(int fd, char *domain, int type);

/* random stuff */
void Divide(int *ret, int value, int parts, int part_size);
int GetRandomNumbers(int *n, int start, int end, int num);
int MyTurn(ptrlist *p, int hash, int num);
int GetRandomItems(CHANUSER **ret, PTRLIST *start, int interval, int num);

/* string functions */
int match(char *str, char *pattern);
int MagicNickCreator(char *nick);
int extendhost(char *host, char *buf, unsigned int len);
char *push(char *ptr, char *lst, ...);
unsigned int hash32(char *word);
unsigned int hash32(char *word, char *where);
void str2words(char *word, char *str, int x, int y);
char *srewind(char *str, int word);
char *my_strstr(char *haystack, size_t haystacklen, char *needle, size_t needlelen);

/* rest */
void precache();
void SignalHandling();
int SafeExit();
void propaganda();
void badparameters(char *str);
void LoadConfig(char *file);
void SendLogo(int fd, char *who);
long int nanotime();
int UserLevel(CHANUSER *u);
void validate();
void parse_cmdline(int argc, char *argv[]);
void lurk();

