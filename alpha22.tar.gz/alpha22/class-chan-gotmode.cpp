/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*                                
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void chan::GotMode(char *modes, char *args, char *mask)
{
	char mode[2][4];
	char *arg[4];
	char *a, *b, *nick;
	char sign = '+';
	char *unban = NULL;
	CHANUSER *NickHandle, *ArgHandle, ServerHandle;
	CHANUSER **MultHandle = NULL;
	PTRLIST *p;
	int i, j, just_opped, oped, mypos, n[6], hash;

	oped = just_opped = 0;
	mypos = -1;

	a = strchr(mask, '!');
	mem_strncpy(nick, mask, abs(a - mask) + 1);
	NickHandle = GetUser(nick);

	if(!NickHandle)
	{
		memset(&ServerHandle, 0, sizeof(CHANUSER));
		NickHandle = &ServerHandle;
	}

	/* mode striper */
	memset(mode, 0, sizeof(mode));
	for(i=j=0; i<4 && (unsigned int) j < strlen(modes); i++, j++)
	{
		if(modes[j] == '+' || modes[j] == '-')
		{
			sign = modes[j];
			j++;
		}
		mode[0][i] = sign;
		mode[1][i] = modes[j];
	}

	/* arg striper */
	for(i=0; i<4; i++)
	{
		if(strchr(ARG_MODES, mode[1][i]) && !(mode[0][i] == '-' && mode[1][i] == 'l'))
		{
			a = strchr(args, ' ');
			if(a)
			{
				mem_strncpy(arg[i], args, abs(args - a)+1);
			}
			else
			{
				mem_strncpy(arg[i], args, strlen(args));
			}
			args = a+1;
		}
		else arg[i] = NULL;
	}

	/* reaction on modes */
	for(i=0; i<4; i++)
	{
		if(mode[0][i] == '+')
		{
   			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				if(ArgHandle->flags & HAS_B)
				{
					BotsToOp.Remove(ArgHandle);
					OpedBots.SortAdd(ArgHandle);
					oped++;
				}

				if(ArgHandle->flags & HAS_O) ToOp.Remove(ArgHandle);
				set(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);
				if(!(NickHandle->flags & HAS_M) && (chset->STOP_NETHACK ? 1 : NickHandle != &ServerHandle))
				{
					if(!(ArgHandle->flags & HAS_O) && !(ArgHandle->flags & HAS_F))
					{
						ToKick.SortAdd(ArgHandle);
						if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					}
				}
				if(ArgHandle->flags & HAS_D) ToKick.SortAdd(ArgHandle);
				if(ptr == ArgHandle) mypos = oped - 1;

				/* Set initial op */
				if(OpedBots.ent == 1 && !InitialOp) InitialOp = NOW;
				mode[0][i] = 0;
				continue;
   			}
			if(mode[1][i] == 'b')
			{
				if(GotBan(arg[i], NickHandle)) unban = push(unban, arg[i], " ", NULL);
				ToBan.Remove(arg[i], 0);
				mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'k')
			{
				UpdateKey(arg[i]);
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '-';
				else mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'l')
			{
				j = limit;
				limit = atol(arg[i]);
				if(limit == j)
				{
					mode[0][i] = 0;
					continue;
				}
				if(!(NickHandle->flags & HAS_M))
				{
					free(arg[i]);
					if(j)
					{
						arg[i] = (char *) malloc(16);
						sprintf(arg[i], "%d", j);
						mode[0][i] = '+';
					}
					else
					{
						mode[0][i] = '-';
						arg[i] = NULL;
					}
				}
				else
				{
					if(chset->LIMIT_CHAN_USERS)
					{
						if(NickHandle->flags & HAS_B)
						{
							if(NickHandle == ptr) nextlimit = NOW + chset->LIMIT_UPDATE_TIME * chset->LIMIT_UPDATE_BOTS;
							else nextlimit = NOW + chset->LIMIT_UPDATE_TIME;
						}
					}
					EnforceLimits();
					mode[0][i] = 0;
				}
				continue;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '-';
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}

		if(mode[0][i] == '-')
		{
			if(mode[1][i] == 'o')
			{
				ArgHandle = GetUser(arg[i]);
				ToKick.Remove(ArgHandle);
				unset(ArgHandle->flags, IS_OP);
				unset(ArgHandle->flags, OP_SENT);
				if(ArgHandle->flags & HAS_B)
				{
					OpedBots.Remove(ArgHandle);
					--oped;
				}

	
				if(ArgHandle->flags & HAS_F)
				{
					if(!(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);
					if(ArgHandle->flags & HAS_A && ArgHandle->flags & HAS_O)
					{
						if(ArgHandle->flags & HAS_B) BotsToOp.SortAdd(ArgHandle);
						else ToOp.SortAdd(ArgHandle);
					}
				}
				if(ptr == ArgHandle)
				{
					mypos = -1;
					p = ToKick.first;
					while(p)
					{
						unset(p->ptr->flags, KICK_SENT);
						p = p->next;
					}
				}
				mode[0][i] = 0;
				continue;
			}
			/*
			if(mode[1][i] == 'b' && config.listenport)
			{
				//ToBan.Remove(arg[i]);
				mode[0][i] = 0;
				continue;
			}
			*/
			if(mode[1][i] == 'k')
			{
				UpdateKey(arg[i]);
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '+';
				else mode[0][i] = 0;
				continue;
			}
			if(mode[1][i] == 'l')
			{
				j = limit;
				limit = 0;
				if(j == limit)
				{
					mode[0][i] = 0;
					continue;
				}
				if(!(NickHandle->flags & HAS_M))
				{
					arg[i] = (char *) malloc(16);
					sprintf(arg[i], "%d", j);
					mode[0][i] = '+';
				}
				else mode[0][i] = 0;
				continue;
			}
			if(strchr(NONARG_MODES, mode[1][i]))
			{
				if(!(NickHandle->flags & HAS_M)) mode[0][i] = '+';
				else mode[0][i] = 0;
				continue;
			}
			mode[0][i] = 0;
		}
	}

	/* channel modes protection */
	j = 0;
	if(MyTurn(&OpedBots, hash32(nick, name), NumberOfBots(chset->PROTECT_MODE_BOTS)))
	{
		mem_strcpy(a, "");
		mem_strcpy(b, "");

		for(i=0; i<4; ++i)
		{
			if(mode[0][i])
			{
				a = (char *) realloc(a, strlen(a) + 3);
				j = strlen(a);
				a[j+2] = '\0';
				a[j+1] = mode[1][i];
				a[j] = mode[0][i];
				if(arg[i]) b = push(b, arg[i], " ", NULL);
				++j;
			}
		}
		if(j)
		{
			Kick(NickHandle, config.kickreason);
			
			/* TODO: QUEUE */
			quote(ME.servfd, "MODE ", name, " ", a, " ", b, NULL);
		}
		free(a);
		free(b);
	}
	if(j && !(NickHandle->flags & HAS_F)) ToKick.SortAdd(NickHandle);

	/* Executeted only during initail opping (takeover code) */
	if(mypos != -1 && ME.NextAction<= NOW)
	{
		j=0;
		Divide((int *) &n, BotsToOp.ent, oped, 3);
		if(n[mypos])
		{
			/* +o[o][o] & 4 KICK */
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *) * set.OPS_PER_MODE);
			if(mypos == 0) j = GetRandomItems(MultHandle, BotsToOp.first, n[mypos], set.OPS_PER_MODE);
			else if(mypos == 1)	j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1]), n[mypos], set.OPS_PER_MODE);
			else j = GetRandomItems(MultHandle, BotsToOp.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], set.OPS_PER_MODE);
			Op(MultHandle, j);
			free(MultHandle);

			Divide((int *) &n, ToKick.ent, oped, 4);
			if(n[mypos])
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*4);
				if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 4);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 4);
				else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 4);
				Kick4(MultHandle, j);
				free(MultHandle);
			}
		}
		/* kick 6 */
		else if(ToKick.ent)
		{
			Divide((int *) &n, ToKick.ent, oped, 6);
			if(n[mypos])
			{
				MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*6);
				if(mypos == 0) j = GetRandomItems(MultHandle, ToKick.first, n[mypos], 6);
				else if(mypos == 1)	j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1]), n[mypos], 6);
				else j = GetRandomItems(MultHandle, ToKick.GetItem(n[mypos-1] + n[mypos-2]), n[mypos], 6);
				Kick6(MultHandle, j);
				free(MultHandle);
			}
		}
	}

	/* executed when somebody is playing with modes */
	if(mypos == -1 && ME.NextAction <= NOW)
	{
		if(ToKick.ent)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*6);
			j = GetRandomItems(MultHandle, ToKick.first, ToKick.ent, 6);

			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick, name);
			if(MyTurn(&OpedBots, hash, NumberOfBots(chset->PUNISH_BOTS)))
			{
				Kick6(MultHandle, j);
			}
			free(MultHandle);
		}
		if(BotsToOp.ent < 4)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
			j = GetRandomItems(MultHandle, BotsToOp.first, BotsToOp.ent, 3);
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick, name);
			if(MyTurn(&OpedBots, hash, NumberOfBots(chset->BOT_AUTOOP_BOTS)))
			{
				Op(MultHandle, j);
			}
			free(MultHandle);
		}
		/*
		if(ToOp.ent < 4)
		{
			hash = 0;
			MultHandle = (CHANUSER **) malloc(sizeof(CHANUSER *)*3);
			j = GetRandomItems(MultHandle, ToOp.first, BotsToOp.ent, 3);
			for(i=0; i<j; i++) hash += hash32(MultHandle[i]->nick, name);
			if(MyTurn(&OpedBots, hash, NumberOfBots(chset->AUTOOP_BOTS)))
			{
				Op(MultHandle, j);
			}
			free(MultHandle);
		}
		*/
	}

	if(unban)
	{
		Unban(unban, hash32(unban, nick));
		free(unban);
	}
	free(nick);
	for(i=0; i<4; i++) if(arg[i]) free(arg[i]);
}
