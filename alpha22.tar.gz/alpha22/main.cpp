/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"

int listenfd;
time_t NOW;
client ME;
settings set;
ul userlist;
SOCK sock[MAX_CONN];
SOCK hub;
SOCKBUF readbuf[MAX_CONN+2];
SOCKBUF writebuf[MAX_CONN+2];
CONFIG config;
stringlist shitlist;
char *thisfile;
int logfile;


int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd, wfd;

	mem_strcpy(thisfile, argv[0]);
		
	propaganda();
	precache();
	parse_cmdline(argc, argv);
	LoadConfig(argv[1]);
	userlist.Load(config.userlist_file);
	SignalHandling();
	if(!set.debug) lurk();
	
	last = NOW = time(NULL);
	tv.tv_sec = 1;

	/* MAIN LOOP */
	while(1)
	{
		if(tv.tv_sec > 1 || tv.tv_sec <= 0) tv.tv_sec = 1;
		tv.tv_usec = 0;

		/* Add sockets to SETs */
		FD_ZERO(&rfd);
		FD_ZERO(&wfd);
		//FD_SET(DNS.resfd, &rfd);

	   	if(ME.servfd)
	    {
			if(ME.KillTime <= NOW && ME.KillTime)
			{
				errno = ETIMEDOUT;
				HandleDeadSocket(ME.servfd, NULL);
			}
			else FD_SET(ME.servfd, &rfd);
		}
		if(config.listenport)
		{
			FD_SET(listenfd, &rfd);
			for(i=0; i<MAX_CONN; ++i)
			{
				if(sock[i].fd)
				{					
					if(sock[i].lastping && NOW - sock[i].lastping > set.PING_TIMEOUT / 3)
					{
						quote(sock[i].fd, S_FOO, NULL);
						sock[i].lastping = NOW;
					}
					if(sock[i].killtime < NOW && sock[i].killtime)
					{
						errno = ETIMEDOUT;
						HandleDeadSocket(0, &sock[i]);
					}
					else FD_SET(sock[i].fd, &rfd);
				}
			}
		}
		if(hub.fd)
		{
			if(hub.status & STATUS_SYNSENT) FD_SET(hub.fd, &wfd);
	
			if(hub.lastping && NOW - hub.lastping > set.PING_TIMEOUT / 3)
			{
				quote(hub.fd, S_FOO, NULL);
				hub.lastping = NOW;
			}
			if(hub.killtime < NOW && hub.killtime)
			{
				errno = ETIMEDOUT;
				HandleDeadSocket(0, &hub);
			}
			else FD_SET(hub.fd, &rfd);
		}

		for(i=0; i<MAX_BUFS; ++i) if(writebuf[i].fd) FD_SET(writebuf[i].fd, &wfd);

		/* SELECT */
		ret = select(65535, &rfd, &wfd, NULL, &tv);

		NOW = time(NULL);
		if(NOW > last + 2)
		{
			last = NOW;
			if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
		}
		if(ME.nextconn_hub <= NOW && !hub.fd  && config.havehub)
		{
			ME.ConnectToHUB();
			ME.nextconn_hub = NOW + set.HUB_CONN_DELAY;
		}
		if(ME.nextconn_serv <= NOW && !ME.servfd)
		{
			ME.ConnectToIRC();
			ME.nextconn_serv = NOW + set.IRC_CONN_DELAY;
		}
		if(ME.status & STATUS_REGISTERED && ME.NextNickCheck <= NOW && ME.NextNickCheck)
		{
			quote(ME.servfd, "NICK ", config.nick, NULL);
			ME.NextNickCheck = 0;
		}
		ME.RejoinCheck();

		if(ret < 1) continue;

		/* WRITE BUFFER */
		for(i=0; i<MAX_BUFS; ++i)
		{
			if(FD_ISSET(writebuf[i].fd, &wfd))
			{
				write(writebuf[i].fd, writebuf[i].buf + writebuf[i].pos++, 1);
				if(writebuf[i].pos == writebuf[i].len)
				{
					free(writebuf[i].buf);
					memset(&writebuf[i], 0, sizeof(writebuf[i]));
				}
			}
		}

		/* READ from DNS */
		/*
		if(FD_ISSET(DNS.resfd, &rfd))
		{
			DNS.RecvPacket();
		}
		*/
		/* READ from IRC */
		if(FD_ISSET(ME.servfd, &rfd))
		{
			n = ReadOneLine(ME.servfd, buf, MAX_LEN);
			if(n > 0) parse_irc(buf);
			else if(n == -1) HandleDeadSocket(ME.servfd, NULL);
		}

		/* READ from HUB */
		if(FD_ISSET(hub.fd, &rfd))
		{
			n = ReadOneLine(hub.fd, buf, MAX_LEN);
			if(n > 0 && hub.status & STATUS_CONNECTED) parse_hub(buf);
			else if(n == -1) HandleDeadSocket(hub.fd, NULL);
		}

		/* ACCEPT connections */
		if(FD_ISSET(listenfd, &rfd)) AcceptConnection(listenfd);

		/* READ from BOTS and OWNERS */
		if(config.listenport)
		{
			for(i=0; i<MAX_CONN; i++)
			{
				if(sock[i].fd > 0)
				{
					if(FD_ISSET(sock[i].fd, &rfd))
					{
						n = ReadOneLine(sock[i].fd, buf, sizeof(buf));
						if(n > 0)
						{
							if(sock[i].status & STATUS_OWNER) parse_owner(&sock[i], buf);
							else if(sock[i].status & STATUS_BOT) parse_bot(&sock[i], buf);
						}
						else if(n == -1) HandleDeadSocket(0, &sock[i]);
                	}
            	}
			}
		}
		if(hub.fd && hub.status & STATUS_SYNSENT)
		{
			if(FD_ISSET(hub.fd, &wfd))
			{
				putlog("[+] Connection to HUB established\n");
				hub.status = STATUS_CONNECTED;
				hub.authstep = 1;
				hub.killtime = NOW + set.AUTH_TIME;
				quote(hub.fd, config.botnetword, NULL);
			}
		}
	}
	//return 0;
}

