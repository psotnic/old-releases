/**************************************************
*  This file is a part of psotnic irc bot code
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void var::reset()
{
	for(int i=0; i<ent; ++i) *varent[i].i = varent[i].def;
}

int var::parseuser(int fd, char *name, char *a, char *b)
{
	char buf[MAX_LEN];
	int i;

	memset(buf, 0, MAX_LEN);

	if(!*a)
	{
		for(i=0; i<ent ;++i)
		{
			if(varent[i].i)
			{
				sprintf(buf, "%d", *varent[i].i);
				quote(fd, name, ": ", varent[i].name, " = ", buf, NULL);
			}
		}
		return -2;
	}
	else if(!*b)
	{
		i = getvar(a);
		if(i == -1)	quote(fd, "No such variable '", a, "'", NULL);
		else
		{
			sprintf(buf, "%d", *varent[i].i);
			quote(fd, name, ": ", varent[i].name, " = ", buf, NULL);
			return -2;
		}
	}
	else
	{
		i = setvar(a, b);
		if(i == -1)	quote(fd, "No such variable '", a, "'", NULL);
		else if(i < -1)
		{
			i = i*(-1)-2;
			sprintf(buf, "Value does not bellong to range <%d, %d>", varent[i].from, varent[i].to);
			quote(fd, buf, NULL);
		}
		else
		{
			sprintf(buf, "%d", *varent[i].i);
			if(fd != -1) quote(FD_OWNERS, name, ": variable '", a, "' has been set to ", buf, NULL);
			return i;
		}
	}
	return -1;
}

int var::setvar(char *name, char *val)
{
	int i, v;
	i = getvar(name);
	if(i == -1) return -1;
	v = atoi(val);
	if(v >= varent[i].from && v <= varent[i].to)
	{
		*varent[i].i = atoi(val);
		return i;
	}
	return i*(-1)-2;
}

int var::getvar(char *name)
{
	int i;
	for(i=0; i<ent; ++i)
		if(!strcmp(varent[i].name, name)) return i;
	return -1;
}

void var::addvar(char *name, int def, int *iptr, int a, int b)
{
 	varent = (VAR *) realloc(varent, (ent + 1) * sizeof(VAR));
	mem_strcpy(varent[ent].name, name);
	varent[ent].i = iptr;
	*varent[ent].i = def;
	varent[ent].def = def;
	varent[ent].from = a;
	varent[ent].to = b;
	++ent;
}

/* Constructors */
var::var()
{
	//printf(">> Var constructor\n");
}

settings::settings()
{
	pl_bots = pl_owners = ent = debug = master = 0;
	varent = NULL;

	//printf(">> Settings constructor\n");

	addvar("cycle-delay", 10, &CYCLE_DELAY, 0, MAX_INT);
	addvar("rejoin-delay", 2, &REJOIN_DELAY, 0, MAX_INT);
	addvar("rejoin-fail-delay", 30, &REJOIN_FAIL_DELAY, 0, MAX_INT);
	addvar("hub-conn-delay", 30, &HUB_CONN_DELAY, 10, MAX_INT);
	addvar("irc-conn-delay", 30, &IRC_CONN_DELAY, 10, MAX_INT);
	addvar("auth-time", 10, &AUTH_TIME, 1, 30);
	addvar("action-penality", 3, &ACTION_PENALITY, 0, MAX_INT);
	addvar("friend-action-penality", 1, &FRIEND_ACTION_PENALITY, 0, MAX_INT);
	addvar("no-private-ctcp", 0, &NO_PRIVATE_CTCP, 0, 1);
	addvar("ops-per-mode", 2, &OPS_PER_MODE, 1, 3);
	addvar("ask-for-op-delay", 4, &ASK_FOR_OP_DELAY, 0, MAX_INT);
	addvar("ping-timeout", 180, &PING_TIMEOUT, 90, MAX_INT);
	addvar("keep-nick-check-delay", 7, &KEEP_NICK_CHECK_DELAY, 0, MAX_INT);
	addvar("save-nick", 1, &SAVE_NICK, 0, 1);
	addvar("remember-old-keys", 0, &REMEMBER_OLD_KEYS, 0, 1);
}

chanset::chanset()
{
	ent = 0;
	varent = NULL;

	//printf(">> Chanset constructor\n");

	addvar("autoop-bots", 3, &AUTOOP_BOTS, -100, MAX_INT);
	addvar("bot-autoop-bots", 1, &BOT_AUTOOP_BOTS, -100, MAX_INT);
	addvar("getop-bots", 2, &GETOP_BOTS, -100, MAX_INT);
	addvar("punish-bots", -40, &PUNISH_BOTS, -100, MAX_INT);
	addvar("unban-bots", 3, &UNBAN_BOTS, -100, MAX_INT);
	addvar("shit-bots", 3, &SHIT_BOTS, -100, MAX_INT);
	addvar("invite-bots", 3, &INVITE_BOTS, -100, MAX_INT);
	addvar("no-channel-ctcp", 0, &NO_GLOBAL_CTCP, 0, 1);
	addvar("enforce-bans", 1, &ENFORCE_BANS, 0, 1);
	addvar("enforce-limits", 1, &ENFORCE_LIMITS, 0, 1);
	addvar("stop-nethack", 1, &STOP_NETHACK, 0, 1);
	addvar("limit-chan-users", 1, &LIMIT_CHAN_USERS, 0, 1);
	addvar("limit-update-time", 60, &LIMIT_UPDATE_TIME, 1, MAX_INT);
	addvar("limit-update-by", 5, &LIMIT_UPDATE_BY, 1, MAX_INT);
	addvar("limit-update-bots", 2, &LIMIT_UPDATE_BOTS, 1, 2);
	addvar("protect-mode-bots", 3, &PROTECT_MODE_BOTS, -100, MAX_INT);
}

/* Destruction derby */
void var::DestroyThisShit()
{
	while(--ent)
	{
		//printf(">> destructor: del %s\n", varent[ent-1].name);
		free(varent[ent-1].name);
	}
	free(varent);
}

settings::~settings()
{
	DestroyThisShit();
}

chanset::~chanset()
{
	DestroyThisShit();
};
