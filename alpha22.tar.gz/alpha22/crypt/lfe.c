/* Copyright (c) 2003 Grzegorz Rusin <pks@irc.pl>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions, and the following disclaimer,
 *    without modification, immediately at the beginning of the file.
 * 2. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include "lfe.h"
#define LEN 16

int main(int argc, char *argv[])
{
	unsigned char KEY[16], buf[2], h = 0;
	int i, m, p, of = 0, op;
	int in;
	int out;

	/* Frontend */
	if(argc != 4 && argc != 5)
	{
		printf("Lame file encryptor 0.0.2\n");
		printf("Copyright (c) 2003 Grzegorz Rusin <pks@irc.pl>\n\n");
		printf("Syntax: %s <password> <input file> <output file> [--decode|-d]\n", argv[0]);
		exit(1);
	}
	if(argc == 5)
	{
		if(strcmp(argv[4], "-d") && strcmp(argv[4], "--decode"))
		{
			printf("Unknown option `%s'\n", argv[4]);
			exit(1);
		}
		op = '-';
	}
	else op = '+';
	
	if(strlen(argv[1]) < 8)
	{
		printf("Password must be at least 8 characters long\n");
		exit(1);
	}
	in = open(argv[2], O_RDONLY);
	if(in < 1)
	{
		printf("Cannot open input file: %s\n", strerror(errno));
		exit(1);
	}
	out = open(argv[3], O_WRONLY | O_CREAT);
	if(out < 1)
	{
		printf("Cannot create output file: %s\n", strerror(errno));
		exit(1);
	}
	
	/* convert password to 128 bit hash */
	MD5Hash(KEY, argv[1], strlen(argv[1]), NULL, 0);

	/* we dont want other users see our pass, do we? :) */
	for(i=0; i<argc; ++i) memset(argv[i], 0, strlen(argv[i]));
	
	/* we have plenty of space coz argv[1] must be > 8 bytes */
	strcpy(argv[0], "-bash");
	
	/* i know... this is lame */
	while(read(in, buf, 1) > 0)
	{
		of %= LEN;
		p = KEY[of++] % LEN;		
		
		for(i=0,m=1; i<8; ++i,m*=2,++p)
		{
			p %= LEN;
			h += KEY[p];
		}
		(op == '+') ? (buf[0] += h) : (buf[0] -= h);
		write(out, buf, 1);
	}
	
	/* paranoid */
	memset(KEY, 0, LEN);
	
	close(in);
	close(out);
	return 0;
}
