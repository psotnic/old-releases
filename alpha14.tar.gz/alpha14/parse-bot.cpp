#include "prots.h"
#include "global-var.h"

void botparser(SOCK *s, char *data)
{
	char arg[10][MAX_LEN], *a;
	int i;

	if(!strlen(data)) return;

	for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  									  &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);

	if(!strcmp(arg[0], S_NEWNICK) && strlen(arg[1]))
	{
		quote(FD_OWNERS, "*** ", s->name, " is now known as ", arg[1], NULL);
		free(s->name);
		mem_strcpy(s->name, arg[1]);
		return;
	}
}
