#include "prots.h"
#include "global-var.h"

void ircparser(char *data)
{
	char arg[10][MAX_LEN], *a, *b, *c;
	chan *ch;
	CHANUSER *p;
	int i, flags, n;

	if(!strlen(data)) return;

	for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));

	sscanf(data, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  									  &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
	/* debug */
	if(!strcasecmp(arg[1], "PRIVMSG"))
	{
		ch = ME.FindChannel(arg[2]);
		if(!strcasecmp(arg[3], "!debug"))
		{
			printf("### DEBUG ###\n");
			if(ch) ch->DebugDisplay();
			printf("CHANNELS: %d\n", ME.channels);
		}
		/*
		else if(!strcasecmp(arg[3], "!cycle"))
		{
			quote(ME.servfd, "PART ", arg[2], " :Cycle time", NULL);
			ME.chanlist[ME.FindChannelInList(arg[2])].joinsent = 0;
			ME.nextjoin = NOW + CYCLE_DELAY;
		}
		*/
		else if(!strcasecmp(arg[3], "!re"))
		{
			ME.RecheckChannels();
		}
	}

	/* reaction */
	if(!strcasecmp(arg[1], "JOIN"))
	{
		if(!strcasecmp(ME.mask, arg[0]))
		{
			ch = ME.CreateNewChannel(arg[2]);
			quote(ME.servfd, "WHO ", arg[2], NULL);
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch)
			{
				printf("[E] Join observed on nonexisting channel %s\n", arg[2]);
				ME.Display();
			}
			if(!ch->ptr) return;
			ch->GotJoin(arg[0], 0);
		}
		return;
	}
	if(!strcasecmp(arg[1], "MODE"))
	{
		ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(!ch->ptr) return;
			a = push(NULL, arg[4], " ", arg[5], " ", arg[6], " ", arg[7], NULL);
			ch->GotMode(arg[3], a, arg[0]);
			free(a);
		}
		return;
	}
	if(!strcasecmp(arg[1], "KICK"))
	{
		if(!strcasecmp(ME.nick, arg[3]))
		{
			ME.RemoveChannel(arg[2]);
			ME.chanlist[ME.FindChannelInList(arg[2])].joinsent = 0;
			ME.nextjoin = NOW + REJOIN_DELAY;
		}
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch->ptr) return;
			ch->GotKick(arg[3], arg[0]);
		}
		return;
	}
	if(!strcasecmp(arg[1], "PART"))
	{
		if(!strcasecmp(ME.mask, arg[0])) ME.RemoveChannel(arg[2]);
		else
		{
			ch = ME.FindChannel(arg[2]);
			if(!ch)
			{
				printf("[E] Part observed on nonexisting channel %s\n", arg[2]);\
				ME.Display();
			}
			if(!ch->ptr) return;
			mem_strncpy(a, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
			ch->GotPart(a);
			free(a);
		}
		return;
	}
	if(!strcasecmp(arg[1], "NICK"))
	{
		ME.GotNickChange(arg[0], arg[2]);
		return;
	}
	if(!strcasecmp(arg[1], "352"))
	{
		ch = ME.FindChannel(arg[3]);
		a = push(NULL, arg[7], "!", arg[4], "@", arg[5], NULL);
		p = ch->GotJoin(a, match(arg[8], "*@*"));
		if(!strcasecmp(arg[7], ME.nick))
		{
			ch->ptr = p;
			//if(!(p->flags & HAS_B)) p->flags += HAS_B;
		}
		free(a);
		return;
	}
	if(!strcasecmp(arg[1], "315"))
	{
		ch = ME.FindChannel(arg[3]);
		//ch->DebugDisplay();
		return;
	}
	if(!strcasecmp(arg[1], "QUIT"))
	{
		ME.GotUserQuit(arg[0]);
		return;
	}
	if(!strcasecmp(arg[0], "PING"))
	{
		quote(ME.servfd, "PONG :", arg[1], NULL);
		return;
	}
	if(!strcasecmp(arg[1], "433"))
	{
		if(MagicNickCreator(arg[3])) quote(ME.servfd, "NICK ", arg[3], NULL);
		else
		{
			printf("[*] Cannot generate alternative nick for %s\n", arg[3]);
			SafeExit();
		}
		return;
	}
	if(!strcasecmp(arg[1], "471") || !strcasecmp(arg[1], "473") || !strcasecmp(arg[1], "474") || !strcasecmp(arg[1], "475"))
	{
		ME.chanlist[ME.FindChannelInList(arg[3])].joinsent = 2;
		return;
	}
	if(!strcasecmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
	{
		ME.status += STATUS_REGISTERED;
		maskstrip(arg[9], ME.nick, ME.ident, ME.host);
		mem_strcpy(ME.mask, arg[9]);
		srand(hash32(ME.nick)*getpid());
		if(hub.fd) quote(hub.fd, S_NEWNICK, " ", ME.nick, NULL);
		return;
	}
	if(!strcasecmp(arg[1], "PRIVMSG") && I_AM_HUB)
	{
  		if(userlist.IsOwner(arg[0]))
  		{
   			if(!strcasecmp(arg[5], "CHAT"))
			{
				printf("[*] Dcc chat request from owner, connecting to: %s:%d\n", inet2char(htonl(atol(arg[6]))), atoi(arg[7]));
				n = DoConnect(inet2char(htonl(atol(arg[6]))), atoi(arg[7]), config.myipv4, O_NONBLOCK);
				if(n > 0)
				{
					printf("[+] Connected\n");
					i = AddSock(n);
					if(i != -1)
					{
						sock[i].status = STATUS_CONNECTED + STATUS_OWNER + STATUS_REGISTERED;
						mem_strncpy(sock[i].name, arg[0], abs(arg[0] - strchr(arg[0], '!')) + 1);
						quote(FD_OWNERS, "*** ", sock[i].name, " has joined the partyline", NULL);
					}
					else
					{
						quote(ME.servfd, "PRIVMSG ", arg[0], " Cannot establish connection (No free slots)", NULL);
						printf("[-] Droping connection No free slots)\n");
					}
				}
				else
				{
					quote(ME.servfd, "PRIVMSG ", arg[0], " :Cannot establish connection (", strerror(errno), ")",  NULL);
					printf("[-] Cannot establish connection (%s)\n", strerror(errno));
				}
			}
			if(!strcmp(arg[3], "!hub"))
			{
				quote(ME.servfd, "NOTICE ", arg[0], " :Hub version ", S_VERSION, " reporting for duty, sir", NULL);
			}
			return;
		}
	}
}
