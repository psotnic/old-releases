#include "prots.h"
#include "global-var.h"

void LoadConfig(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	FILE *f;
	int line, i, errors;

	printf("[*] Loading config from '%s'\n", file);
	f = fopen(file, "r");
	if(!f)
	{
		printf("[-] Cannot open config file!!!\n");
		exit(1);
	}
	line = 0;
	while(1)
	{
		if(feof(f)) break;

		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);
		line++;
		for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
													 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
		if(arg[0][0] == '#') continue;
		if(!strcmp(arg[0], "nick"))
		{
			if(!strlen(arg[1]) || strlen(arg[1]) > 9)
			{
				printf("[-] %s:%d: invalid or no nick\n", file, line);
				exit(1);
			}
			mem_strcpy(config.nick, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "ident"))
		{
			if(!strlen(arg[1]) || strlen(arg[1]) > 9)
			{
				printf("[-] %s:%d: invalid or no idnet\n", file, line);
				exit(1);
			}
			mem_strcpy(config.ident, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "realname"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: invalid or no realname\n", file, line);
				exit(1);
			}
			for(a=buf+strlen(arg[0]); *a!='\0' && isspace(*a); a++);
			mem_strcpy(config.realname, a);
			config.realname[strlen(config.realname)-1] = '\0';
			continue;
		}
		if(!strcmp(arg[0], "userlist"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: no userlist file\n", file, line);
				exit(1);
			}
			mem_strcpy(config.userlist_file, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "myipv4"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: ipv4 address missing\n", file, line);
				exit(1);
			}
			mem_strcpy(config.myipv4, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "vhost"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: vhost missing\n", file, line);
				exit(1);
			}
			mem_strcpy(config.vhost, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "hub"))
		{
			if(!strlen(arg[4]))
			{
				printf("[-] %s:%d: bad string format\n", file, line);
				exit(1);
			}
			mem_strcpy(hub.ident, arg[1]);
			mem_strcpy(hub.host, arg[2]);
			hub.port = atoi(arg[3]);
			mem_strcpy(hub.pass, arg[4]);
			continue;
		}
		if(!strcmp(arg[0], "server"))
		{
			if(!strlen(arg[2]))
			{
				printf("[-] %s:%d: server address/port missing\n", file, line);
				exit(1);
			}
			for(i=0; i<MAX_SERVERS; i++)
			{
				if(config.server[i].host == NULL)
				{
					config.server[i].port = atoi(arg[2]);
					mem_strcpy(config.server[i].host, arg[1]);
					break;
				}
			}
			continue;
		}
		if(!strcmp(arg[0], "nickappend"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: nickappend string missing\n", file, line);
				exit(1);
			}
			mem_strcpy(config.nickappend, arg[1]);
			continue;
		}
		if(!strcmp(arg[0], "channel"))
		{
			if(!strlen(arg[1]))
			{
				printf("[-] %s:%d: channel string missing\n", file, line);
				exit(1);
			}
			mem_strcpy(config.default_channel, arg[1]);
			mem_strcpy(config.default_channel_pass, arg[2]);
			ME.AddChannelToList(arg[1], arg[2]);
			continue;
		}
		if(strlen(arg[0])) printf("[W] %s:%d: unknown option '%s'\n", file, line, arg[0]);
	}

	errors = 0;
	if(!config.nick) printf("[E]%2d: 'nick' not set\n", ++errors);
	if(!config.ident) printf("[E]%2d: 'ident' not set\n", ++errors);
	if(!config.nickappend) printf("[E]%2d: 'nickappend' not set\n", ++errors);
	if(!config.realname) printf("[E]%2d: 'realname' not set\n", ++errors);
	if(!config.userlist_file) printf("[%d]: 'userlist_file' not set\n", ++errors);
	if(!config.myipv4) printf("[E]2%d: 'myipv4' not set\n", ++errors);
	if(!config.vhost) printf("[E]%2d: 'vhost' not set\n", ++errors);
	if(!hub.host) printf("[E]%2d: 'hub' not set\n", ++errors);
	if(!config.server[0].host) printf("[E]%2d: 'server' not set\n", ++errors);
	if(!config.default_channel) printf("[E]%2d: 'channel' not set\n", ++errors);
	if(errors)
	{
		printf("[-] Errors found, baling out\n", errors);
		exit(1);
	}
	else printf("[+] Config loaded\n");

}
