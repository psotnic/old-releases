#include "prots.h"
#include "global-var.h"

int SafeExit()
{
	printf("[*] Killed by user\n");
	userlist.Save(config.userlist_file);
	printf("[*] calling exit(1) \n");
	exit(1);
}

int SegFault()
{
	printf("[E] Fuck, not again\n");
	printf("[E] SEGMENTATION VIOLATION\n");
	printf("[*] Please send log (10-30 lines) to pks@irc.pl !!!\n");
	printf("[*] calling exit(2)\n");
	exit(2);
}

int SignalHandling()
{
	sigset_t sigmask;
	struct sigaction safeexit, fault;

	/* SIGPIPE */
	sigemptyset(&sigmask);
	sigaddset(&sigmask, SIGPIPE);
	sigprocmask(SIG_SETMASK, &sigmask, 0);

	/* term, int, hup */
    sigemptyset(&safeexit.sa_mask);
    safeexit.sa_handler = (sighandler_t) SafeExit;
    safeexit.sa_flags = 0;
 	sigaction(SIGTERM, &safeexit, NULL);
	sigaction(SIGINT, &safeexit, NULL);
	sigaction(SIGHUP, &safeexit, NULL);

	/* Segmentation fault */
/*
	sigemptyset(&fault.sa_mask);
    fault.sa_handler = (sighandler_t) SegFault();
    fault.sa_flags = 0;
	sigaction(SIGSEGV, &fault, NULL);
*/
	return 0;
}



