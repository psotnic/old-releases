#include "prots.h"
#include "global-var.h"

int ul::GetFlags(char *mask)
{
	HANDLE *p = userlist.first;
	int need = HAS_ALL, got, i;

	//printf("need: %u\n", need);
	while(1)
	{
		if(!p) break;
		got = need & p->flags;
		//printf("%s->flags = %d\n", p->name, p->flags);
		//printf("got: %d\n", got);
		if(got)
		{
			for(i=0; i<MAX_HOSTS; i++)
			{
				if(p->host[i])
				{
					if(match(mask, p->host[i]))
					{
						need -= got;
						//printf("match(): need: %d\n", need);
						break;
					}
				}
			}
		}
		p = p->next;
	}
	return HAS_ALL - need;
}

int ul::Save(char *file)
{
	char buf[MAX_LEN];
	FILE *f;
	HANDLE *h;
	int i;

	printf("[*] Saving userlist\n");
	h = first;
	f = fopen(file, "w");
	if(!f)
	{
		printf("[-] Error: %s\n", strerror(errno));
		exit(1);
	}
	while(1)
	{
		if(!h) break;
		fprintf(f, ".+user %s\n", h->name);
		for(i=0; i<MAX_HOSTS; i++)
			if(h->host[i] != NULL) fprintf(f, ".+host %s %s\n", h->name, h->host[i]);
		GetFlags(h, buf);
		fprintf(f, ".chattr %s %s\n\n", h->name, buf);
		h = h->next;
	}

	for(i=0; i<MAX_CHANNELS; i++)
		if(ME.chanlist[i].name)
			fprintf(f, ".+chan %s %s\n", ME.chanlist[i].name, ME.chanlist[i].pass);

	fclose(f);
	printf("[+] Done\n");
}

int ul::Load(char *file)
{
	char arg[10][MAX_LEN], buf[MAX_LEN];
	HANDLE *h;
	FILE *f;
	int i;

	printf("[*] Loading userlist\n");
	f = fopen(file, "r");
	if(!f)
	{
		printf("[W] Userlist file not present (new bot?)\n");
		return 0;
	}
	while(1)
	{
		if(feof(f)) break;

		memset(buf, 0, MAX_LEN);
		fgets(buf, MAX_LEN, f);

		for (i=0; i < 10; i++) memset(arg[i], 0, sizeof(arg[i]));
		sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
			  										 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
		if(!strcmp(arg[0], ".+user") && strlen(arg[1]))
		{
			userlist.AddHandle(arg[1]);
			continue;
		}
		if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
		{
			h = userlist.FindHandle(arg[1]);
			if(h) userlist.AddHost(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".chattr") && strlen(arg[1]))
		{
			h = userlist.FindHandle(arg[1]);
			if(h) userlist.ChangeFlags(h, arg[2]);
			continue;
		}
		if(!strcmp(arg[0], ".+chan") && strlen(arg[1]))
		{
			if(strlen(arg[2])) ME.AddChannelToList(arg[1], arg[2]);
   			else ME.AddChannelToList(arg[1], "");
		}
	}
	fclose(f);
	printf("[+] Userlist loaded\n");
	return 1;
}

void ul::GetFlags(HANDLE *p, char *buf)
{
	int i = 0;

	if(p->flags & HAS_A) buf[i++] = 'a';
	if(p->flags & HAS_B) buf[i++] = 'b';
	if(p->flags & HAS_O) buf[i++] = 'o';
	if(p->flags & HAS_F) buf[i++] = 'f';
	if(p->flags & HAS_M) buf[i++] = 'm';
	if(p->flags & HAS_N) buf[i++] = 'n';
	if(p->flags & HAS_D) buf[i++] = 'd';
	if(i == 0) buf[i++] = '-';
	buf[i] = '\0';
}

int ul::FindHost(HANDLE *p, char *host)
{
	int i;

	if(!p) return -1;

	for(i=0; i<MAX_HOSTS; i++)
		if(p->host[i])
			if(!strcasecmp(p->host[i], host)) return i;

	return -1;
}

int ul::ChangeFlags(char *name, char *flags)
{
	HANDLE *p;

	p = FindHandle(name);
	if(!p) return 0;
	return ChangeFlags(p, flags);
}


HANDLE *ul::FindHandle(char *name)
{
	HANDLE *p;

	p = first;
	while(1)
	{
		if(!p) return NULL;
		if(!strcasecmp(p->name, name)) return p;
		p = p->next;
	}
}

int ul::ChangeFlags(HANDLE *p, char *flags)
{
	p->flags = 0;
	if(strchr(flags, 'a')) p->flags += HAS_A;
	if(strchr(flags, 'b')) p->flags += HAS_B;
	if(strchr(flags, 'o')) p->flags += HAS_O;
	if(strchr(flags, 'f')) p->flags += HAS_F;
	if(strchr(flags, 'm')) p->flags += HAS_M;
	if(strchr(flags, 'n')) p->flags += HAS_N;
	if(strchr(flags, 's')) p->flags += HAS_S;
	if(strchr(flags, 'd')) p->flags += HAS_D;
	return p->flags;
}

int ul::RemoveHost(HANDLE *p, char *host)
{
	int i;

	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] != NULL)
		{
			if(!strcasecmp(p->host[i], host))
			{
				free(p->host[i]);
				p->host[i] = NULL;
				return i;
			}
		}
	}
	return -1;
}

int ul::AddHost(HANDLE *p, char *host)
{
	int i;

	if(FindHost(p, host) != -1) return -1;
	for(i=0; i<MAX_HOSTS; i++)
	{
		if(p->host[i] == NULL)
		{
			mem_strcpy(p->host[i], host);
			return i;
		}
	}
	return -1;
}

void ul::RemoveAllData(HANDLE *p)
{
	int i;

	free(p->name);
	for(i=0; i<MAX_HOSTS; i++) if(p->host[i] != NULL) free(p->host[i]);
}

int ul::RemoveHandle(char *name)
{
	HANDLE *p;
	p = first;

	if(!first) return 0;
	if(!strcasecmp(first->name, name))
	{

		first = first->next;
		if(first) first->prev = NULL;
		RemoveAllData(p);
		delete(p);
		ent--;
		return 1;
	}
	else if(!strcasecmp(last->name, name))
	{
		p = last->prev;
		p->next = NULL;
		RemoveAllData(last);
		delete(last);
		ent--;
		last = p;
		return 1;
	}
	else
	{
		while(1)
		{
			if(!p)
			{
				return 0;
			}
			if(!strcasecmp(p->name, name))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				RemoveAllData(p);
				delete(p);
				ent--;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

HANDLE *ul::AddHandle(char *name)
{
    HANDLE *p;

	if(FindHandle(name)) return NULL;
    if(!ent)
    {
		last = first = new(HANDLE);
		first->next = first->prev = NULL;
	}
    else
    {
		p = last->next = new(HANDLE);
		p->prev = last;
		p->next = NULL;
		last = p;
    }
	ent++;
	mem_strcpy(last->name, name);
	memset(&last->host, 0, MAX_HOSTS);
	last->flags = 0;
	return last;
}

ul::ul()
{
	first = last = NULL;
	ent = 0;
}

ul::~ul()
{
	HANDLE *h;

	h = first;
	while(1)
	{
		if(!h) break;
		RemoveAllData(h);
		h = h->next;
	}

	first = last = NULL;
	ent = 0;
}
