#include "prots.h"

int AUTOOP_BOTS, PUNISH_BOTS, PUNISH_METHOD, I_AM_HUB, listenfd;
unsigned int magic[9];
time_t NOW;
client ME;
ul userlist;
SOCK sock[MAX_CONN];
CONFIG config;
HUB hub;
extern int errno;

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd;

	precache();
	LoadConfig("tomek.conf");
	userlist.Load(config.userlist_file);
	SignalHandling();

	if(argc > 1) I_AM_HUB = 1;
	else I_AM_HUB = 0;

	if(I_AM_HUB)
	{
		if((listenfd = StartListening(hub.host, hub.port)) < 1)
		{
			printf("[-] Cannot open socket\n");
			SafeExit();
		}
	}
	last = NOW = time(NULL);
	tv.tv_sec = 1;

	while(1)
	{
		if(!tv.tv_sec) tv.tv_sec = 1;
		tv.tv_usec = 0;

		FD_ZERO(&rfd);
	   	if(ME.servfd > 0) FD_SET(ME.servfd, &rfd);
		if(I_AM_HUB)
		{
			FD_SET(listenfd, &rfd);
			for(i=0; i<MAX_CONN; i++) if(sock[i].fd > 0) FD_SET(sock[i].fd, &rfd);
		}
		else if(hub.fd > 0)	FD_SET(hub.fd, &rfd);

		ret = select(65535, &rfd, NULL, NULL, &tv);

		NOW = time(NULL);
		if(NOW > last + 2)
		{
			last = NOW;
			if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
		}
		if(ME.nextconn_hub <= NOW && hub.fd < 1 && !I_AM_HUB)
		{
			ME.ConnectToHUB();
			if(!hub.fd) ME.nextconn_hub = NOW + HUB_CONN_DELAY;
		}
		if(ME.nextconn_serv <= NOW && ME.servfd < 1)
		{
			ME.ConnectToIRC();
			if(!ME.servfd) ME.nextconn_serv = NOW + 3;
		}
		if(ME.nextjoin <= NOW && ME.status & STATUS_REGISTERED)
		{
			ME.JoinChannels();
			ME.nextjoin = NOW + CHAN_CHECK_DELAY;
		}

		if(ret < 1) continue;

		if(FD_ISSET(ME.servfd, &rfd))
		{
			n = ReadOneLine(ME.servfd, buf, MAX_LEN);
			if(n < 0)
			{
				debug();
				printf("[-] Lost server\n");
				if(sclose(ME.servfd) != 0) debug();
				ME.reset();
			}
			else ircparser(buf);
		}
		if(FD_ISSET(hub.fd, &rfd))
		{
			n = ReadOneLine(hub.fd, buf, MAX_LEN);
			if(n < 1)
			{
				debug();
				if(sclose(hub.fd) != 0) debug();
				hub.fd = 0;
			}
		}
		if(FD_ISSET(listenfd, &rfd))
		{
			n = AcceptConnection(listenfd);
		}
		if(I_AM_HUB)
		{
			for(i=0; i<MAX_CONN; i++)
			{
				if(sock[i].fd > 0)
				{
					if(FD_ISSET(sock[i].fd, &rfd))
					{
						if(ReadOneLine(sock[i].fd, buf, sizeof(buf)) != -1)
						{
							if(sock[i].flags & STATUS_OWNER)
							{
								ownerparser(&sock[i], buf);
							}
						}
						else
						{
							printf("[-] Dead socket: sock[%d].fd = %d, Shuting down\n", i, sock[i].fd);
							if(sock[i].flags & STATUS_REGISTERED) quote(FD_OWNERS, "*** ", sock[i].nick, " has left the partyline (", strerror(errno), ")", NULL);
							CloseSock(&sock[i]);
						}
                	}
            	}
			}
		}
	}
	return 0;
}

