#include "prots.h"
#include "global-var.h"

void ptrlist::reset()
{
	PTRLIST *p, *q;

	p=first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		delete(q);
	}
	first = NULL;
	ent = 0;
}

PTRLIST *ptrlist::GetItem(int num)
{
	PTRLIST *p;
	int i;

	if(num+1 > ent) return NULL;
	p = first;
	i = 0;

	while(1)
	{
		if(i == num) return p;
		p = p->next;
		i++;
	}
}

int ptrlist::Find(CHANUSER *ptr)
{
	PTRLIST *p;
	int i=0;
	p=first;
	while(1)
	{
		if(!p) return -1;
		if(ptr == p->ptr) return i;
		i++;
		p = p->next;
	}
}

void ptrlist::Remove(char *nick)
{
	PTRLIST *p;
	p = first;

	if(!ent) return;
	if(!strcmp(first->ptr->nick, nick))
	{
		first = first->next;
		if(first) first->prev = NULL;
		delete(p);
		ent--;
	}
	else
	{
		while(1)
		{
			if(!p) break;
			if(!strcmp(p->ptr->nick, nick))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				delete(p);
				ent--;
				break;
			}
			p = p->next;
		}
	}
}

int ptrlist::SortAdd(CHANUSER *ptr)
{
	PTRLIST *p, *q;
	int i=0;

	if(!ent)
	{
		first = new(PTRLIST);
		first->next = first->prev = NULL;
		first->ptr = ptr;
	}
	else
	{	if(strcmp(ptr->nick, first->ptr->nick) < 0)
  		{
			q = new(PTRLIST);
			q->ptr = ptr;
			first->prev = q;
			q->prev = NULL;
			q->next = first;
			first = q;
		}
		else
		{
			p = first;
			while(1)
			{
				if(!strcmp(ptr->nick, p->ptr->nick)) return -1;
				if(strcmp(ptr->nick, p->ptr->nick) < 0)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = p;
					q->prev = p->prev;
					p->prev->next = q;
					p->prev = q;
					break;
				}
				else if(p->next == NULL)
				{
					q = new(PTRLIST);
					q->ptr = ptr;
					q->next = NULL;
					q->prev = p;
					p->next = q;
					break;
				}
				p = p->next;
				i++;
			}
		}
	}
	ent++;
	return i;
}

void ptrlist::DebugDisplay()
{
	PTRLIST *p;
	p = first;
	while(1)
	{
		if(p == NULL) break;
		printf("[%d]: %s!%s@%s \n", p->ptr->flags, p->ptr->nick, p->ptr->ident, p->ptr->host);
		p = p->next;
	}
}

ptrlist::ptrlist()
{
	first = NULL;
	ent = 0;
}

ptrlist::~ptrlist()
{
	PTRLIST *p, *q;

	p=first;
	while(1)
	{
		if(!p) break;
		q = p;
		p = p->next;
		delete(q);
	}
}
