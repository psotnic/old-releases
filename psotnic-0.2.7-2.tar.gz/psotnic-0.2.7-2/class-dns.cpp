/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"
//#include <arpa/nameser_compat.h>

dns::dns(char *primary, char *secondary)
{
	fd = socket(AF_INET, SOCK_DGRAM, 0);

	if(fd < 1)
	{
		printf("[-] Cannot create UDP socket: %s\n", strerror(errno));
		exit(1);
	}

	ns[0].sin_family = AF_INET;
	ns[0].sin_addr.s_addr = inet_addr(primary);
	ns[0].sin_port = htons(53);

	ns[1].sin_family = AF_INET;
	ns[1].sin_addr.s_addr = inet_addr(secondary);
	ns[1].sin_port = htons(53);
}

int dns::recvAnswer()
{
	sockaddr_in from;
	socklen_t fromlen = sizeof(sockaddr);
	char buf[MAX_LEN];
	int len;

	printf(">>> Waiting for reply ...\n");
	len = recvfrom(fd, buf, MAX_LEN, 0, (sockaddr *) &from, &fromlen);
	printf(">>> Got %d bytes ;-)\n", len);

	hexDump(buf, len);

	printf(">>> packet info:\n");
	showPacketInfo(buf);

	return 1;

}

int dns::sendQuery()
{
	if(packetlen < 12)
		return 0;

	int s;

	for(int i=0; i<2; ++i)
	{
		if(ns[i].sin_addr.s_addr)
		{
			s = sendto(fd, dnspacket, packetlen, 0, (sockaddr *) &ns[i], sizeof(sockaddr));
			printf(">>> Wrote %d bytes\n", s);
		}
	}

	return 1;
}

int dns::buildQuery(char *query, int type)
{
	printf(">>> bulding query: %s\n", query);
	HEADER *head = (HEADER *) dnspacket;

	head->id = htons(1337);	// sn
	head->qr = 0;			// 0-query, 1-reply
	head->opcode = 0; 		// 0-normal query, 1-inverse query
	head->aa = 0;			// authority
	head->tc = 0;			// truncated packet
	head->rd = 1;			// recurive search
	head->ra = 0;			// set by server
	head->unused = 0;		// not used
	head->ad = 0;			// not used
	head->cd = 0;			// not used
	head->rcode = 0;		// set by server
	head->qdcount = htons(1);
	head->ancount = 0;
	head->nscount = 0;
	head->arcount = 0;

	//build question section (QNAME)
	char *q = query;
	char *p = dnspacket + 13;
	int len = 0;
	int first = 1;

	while(1)
	{
		if(*q == '.')
		{
			if(first)
			{
				*(p-len-1) = len;
				first = 0;
			}
			else
				*(p-len) = len - 1;
			len = 0;
		}
		else if(!*q)
		{
			if(len) *(p-len) = len - 1;
			*p = '\0';
			++p;
			break;
		}
		else
		{
			*p = *q;
		}

		++q;
		++p;
		++len;
		if(len > 63)
		{
			printf("[!] dns::buildquery : too long label : %s\n", query);
			packetlen = 0;
			return 0;
		}
	}

	FOOTER *footer = (FOOTER *) p;
	footer->qtype = htons(type);
	footer->qclass = htons(C_IN);

	p += 4; //sizeof(FOOTER);

	//debug :)
	hexDump(dnspacket, p - dnspacket);

	return (packetlen = p - dnspacket);
}

void dns::showPacketInfo(void *pkt)
{
	HEADER *dnsheader = (HEADER*) pkt;

	printf("Dumping DNS packet header:\n");
	printf("ID = %x, response = %s, opcode = ", ntohs (dnsheader->id), (dnsheader->qr ? "yes" : "no"));

	switch (dnsheader->opcode)
	{
		case 0:
			printf ("standard query\n");
			break;
		case 1:
			printf ("inverse query\n");
			break;
		default:
			printf ("undefined\n");
			break;
	}

	printf ("Flags: %s %s %s %s\n", ((dnsheader->aa) ? "authoritative answer,\t" : ""),
			((dnsheader->tc) ? "truncated message,\t" : ""), ((dnsheader->rd) ? "recursion desired," : ""),
			((dnsheader->ra) ? "recursion available\t" : ""));

	if(dnsheader->qr)
	{
		printf("Response code - ");
		switch (dnsheader->rcode)
		{
			case 0:
				printf ("no error\n");
				break;
			case 1:
				printf ("format error\n");
				break;
			case 2:
				printf ("server failure\n");
				break;
			case 3:
				printf ("non existent domain\n");
				break;
			case 4:
				printf ("not implemented\n");
				break;
			case 5:
				printf ("query refused\n");
				break;
			default:
				printf ("undefined\n");
				break;
		}

	}

	printf("Question # - %d, Answer # - %d, NS # - %d, Additional # - %d\n",
		   ntohs (dnsheader->qdcount), ntohs (dnsheader->ancount), ntohs (dnsheader->nscount), ntohs (dnsheader->arcount));
	return;
}
