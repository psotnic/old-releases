/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

char _chmodes[MAX_LEN];

#ifdef HAVE_ADNS
void chan::updateDnsEntries()
{
	ptrlist<chanuser>::iterator u = users.begin();
	shitlist::entry *s;
	char buf[MAX_LEN];

	while(u)
	{
		if(!*u->ip4 && !*u->ip6)
		{
			u->updateDNSEntry();
			if(u->flags & CHECK_SHIT && me->flags & IS_OP)
			{
				//DEBUG(printf("checking shit for %s on %s\n", u->nick, (const char *) name));
				snprintf(buf, MAX_LEN, "%s!%s@%s", u->nick, u->ident, u->host);
				
				if(!(u->flags & HAS_F) && !list[EXEMPT].match(buf) &&
					(s = shit->match(u)) || (s = userlist.shit.match(u)))
				{
					u->setReason(s->fullReason());
					toKick.sortAdd(u);

					if(myTurn(chset->PUNISH_BOTS, u->hash32()))
					{
						modeQ[PRIO_HIGH].add(NOW, "+b", s->mask);
						modeQ[PRIO_HIGH].flush(PRIO_HIGH);
					}
					else modeQ[PRIO_LOW].add(NOW+2, "+b", s->mask);
				}
				u->flags &= ~CHECK_SHIT;
			}
		}
		u++;
	}
}
#endif

int chan::flushKickQueue()
{
	chanuser *MultHandle[6];

	if(toKick.entries() - sentKicks)
	{
		int j = getRandomItems(MultHandle, toKick.begin(), toKick.entries() - sentKicks, 6, KICK_SENT);
		kick4(MultHandle, j);
		return 1;
	}
	return 0;
}

int chan::myPos()
{
	ptrlist<chanuser>::iterator p = opedBots.begin();
	int i;

	for(i=0; p; ++i)
	{
		if(me == p) return i;
		p++;
	}

	return -1;
}


char chan::valid(const char *str)
{
	if(strlen(str) >= 50) return 0;

	if(*str == '#' || *str == '&' || *str == '+') return 1;
	if(*str == '!' && str[1] != '!') return 1;

	return 0;
}

void chan::names(const char *owner)
{

	int j, i, rows;
	rows = (users.entries() / 6) + 1;

	ptrlist<chanuser>::iterator p;
	char nick[6][13];

	net.sendOwner(owner, "[Users ", (const char *) name, "]", NULL);
	for(i=0; i<rows; ++i)
	{
		for(j=0; j<6; ++j)
		{
			memset(nick[j], 0, 13);
			p = users.getItem(i*6+j);
			if(p)
				snprintf(nick[j], 13, "[%c%-9s]", p->flags & IS_OP ? '@' : ' ', p->nick);
		}
		if(strlen(nick[0]))
			net.sendOwner(owner, nick[0], " ", nick[1], " ", nick[2], " ", nick[3], " ",  nick[4], " ", nick[5], NULL);
	}
	i = chops();
	char ops[16], normal[16], total[16];

	strcpy(ops, itoa(i));
	strcpy(total, itoa(users.entries()));
	strcpy(normal, itoa(users.entries() - i));
	net.sendOwner(owner, "-!- Psotnic: ", (const char *) name, "(", getModes(), "): Total of ", total, " nicks [",
			ops, " ops, ", normal, " normal]", NULL);
}


int chan::userLevel(int flags) const
{
	if(flags & HAS_X) return 6;
	if(flags & (HAS_S | HAS_B)) return 5;
	if(flags & HAS_N) return 4;
	if(flags & HAS_M) return 3;
	if(flags & HAS_F) return 2;
	if(flags & HAS_O) return 2;
	if(flags & HAS_V && flags & HAS_A) return 1;
	if(flags & HAS_Q) return -1;
	if(flags & HAS_D) return -2;
	if(flags & HAS_K) return -3;
	return 0;
}

int chan::userLevel(const chanuser *u) const
{
	return u ? userLevel(u->flags) : 0;
}

char *chan::getModes()
{
	/* imnpstaqr */
	memset(_chmodes, 0, MAX_LEN);

	//overflow
	if(key && strlen(key) > MAX_LEN - 50)
	{
		strcpy(_chmodes, "buffer overflow attempt");
		return _chmodes;
	}
	strcpy(_chmodes, "+");
	if(key && *key)	strcat(_chmodes, "k");
	if(limit) strcat(_chmodes, "l");
	if(flags & FLAG_I) strcat(_chmodes, "i");
	if(flags & FLAG_M) strcat(_chmodes, "m");
	if(flags & FLAG_N) strcat(_chmodes, "n");
	if(flags & FLAG_P) strcat(_chmodes, "p");
	if(flags & FLAG_S) strcat(_chmodes, "s");
	if(flags & FLAG_T) strcat(_chmodes, "t");
	if(flags & FLAG_Q) strcat(_chmodes, "q");
	if(flags & FLAG_R) strcat(_chmodes, "r");

	if(key && *key)
	{
		strcat(_chmodes, " ");
		strcat(_chmodes, key);
	}
	if(limit)
	{
		strcat(_chmodes, " ");
		strcat(_chmodes, itoa(limit));
	}
	return _chmodes;
}

int chan::myTurn(int num, int hash)
{
	chanuser **MultHandle;
	int i, j;

	num = numberOfBots(num);
	if(num < 1) return 0;

	MultHandle = (chanuser **) malloc(sizeof(chanuser *)*num);
	srand(hash, hash32(name));
	j = getRandomItems(MultHandle, opedBots.begin(), opedBots.entries(), num);
	for(i=0; i<j; ++i)
	{
		if(!strcmp(MultHandle[i]->nick, ME.nick))
		{
			free(MultHandle);
			srand();
			return 1;
		}
	}
	srand();
	free(MultHandle);
	return 0;
}

void chan::buildAllowedOpsList(const char *offender)
{
	ptrlist<chanuser>::iterator p = users.begin();
	chanuser *kicker;
	if(userlist.chanlist[channum].allowedOps)
		delete userlist.chanlist[channum].allowedOps;

	if(synced())
	{
		if(chset->TAKEOVER)
		{
			userlist.chanlist[channum].allowedOps = NULL;
			return;
		}
		else
			userlist.chanlist[channum].allowedOps = new wasoptest(60);

		kicker = getUser(offender);
		if(kicker && !(kicker->flags & HAS_F)) toKick.sortAdd(kicker);

		while(p)
		{
			if((p->flags & IS_OP) && !(p->flags & HAS_F) && !toKick.find(p))
			{
				userlist.chanlist[channum].allowedOps->add(p);
			}
			p++;
		}
	}
}

void chan::setFlags(const char *str)
{
	flags = 0;
	addFlags(str);
}

void chan::addFlags(const char *str)
{
	/* imnpstaqr */
	strchr(str, 'i') ? flags |= FLAG_I : 0;
	strchr(str, 'n') ? flags |= FLAG_N : 0;
	strchr(str, 's') ? flags |= FLAG_S : 0;
	strchr(str, 'm') ? flags |= FLAG_M : 0;
	strchr(str, 't') ? flags |= FLAG_T : 0;
	strchr(str, 'r') ? flags |= FLAG_R : 0;
	strchr(str, 'p') ? flags |= FLAG_P : 0;
	strchr(str, 'q') ? flags |= FLAG_Q : 0;

}

void chan::removeFlags(const char *str)
{
	strchr(str, 'i') ? flags &= ~FLAG_I : 0;
	strchr(str, 'n') ? flags &= ~FLAG_N : 0;
	strchr(str, 's') ? flags &= ~FLAG_S : 0;
	strchr(str, 'm') ? flags &= ~FLAG_M : 0;
	strchr(str, 't') ? flags &= ~FLAG_T : 0;
	strchr(str, 'r') ? flags &= ~FLAG_R : 0;
	strchr(str, 'p') ? flags &= ~FLAG_P : 0;
	strchr(str, 'q') ? flags &= ~FLAG_Q : 0;
}

int chan::hasFlag(char f) const
{
	if(f == 'i' && flags & FLAG_I) return 1;
	else if(f == 'n' && flags & FLAG_N) return 1;
	else if(f == 's' && flags & FLAG_S) return 1;
	else if(f == 'm' && flags & FLAG_M) return 1;
	else if(f == 't' && flags & FLAG_T) return 1;
	else if(f == 'r' && flags & FLAG_R) return 1;
	else if(f == 'p' && flags & FLAG_P) return 1;
	else if(f == 'q' && flags & FLAG_Q) return 1;

	return 0;
}

int chan::synced() const
{
	return synlevel;
}

int chan::chops() const
{
	int ops = 0;
	ptrlist<chanuser>::iterator u = users.begin();

	while(u)
	{
		if(u->flags & IS_OP) ++ops;
		u++;
	}
	return ops;
}

void chan::updateKey(const char *newkey)
{
	if(!strcmp(key, newkey)) return;

	key = newkey;

	if(set.REMEMBER_OLD_KEYS ? *newkey : 1)
	{
  		userlist.chanlist[channum].pass = newkey;
		userlist.nextSave = NOW + SAVEDELAY;
	}
}

void chan::requestOp() const
{

	chanuser **multHandle = (chanuser **) malloc(sizeof(chanuser *) * chset->GETOP_BOTS);
	int i, j;
	inetconn *c;

	j = getRandomItems(multHandle, opedBots.begin(), opedBots.entries(), chset->GETOP_BOTS);

	for(i=0; i<j; ++i)
	{
		c = net.findConn(multHandle[i]->nick);
		if(c && c->isRegBot())
		{
			c->send(S_BOP, " ", (const char *) name, NULL);
		}
	}
	free(multHandle);
}

void chan::recheckFlags()
{
	ptrlist<chanuser>::iterator p = users.begin();

	botsToOp.clear();
	toOp.clear();
	opedBots.clear();

	while(p)
	{
		p->getFlags(this);
		if(p->flags & HAS_B)
		{
			if(p->flags & IS_OP) opedBots.sortAdd(p);
			else botsToOp.sortAdd(p);
		}
		p++;
	}
}

int chan::gotBan(const char *ban, chanuser *caster)
{
	if(!ban) return 0;

	HANDLE *h = userlist.first;
	ptrlist<chanuser>::iterator u;

	if(!(caster->flags & HAS_B))
	{
		//check if banned mask matches smb with higer level
		u = users.begin();
		while(u)
		{
			if(userLevel(&u) > userLevel(caster))
			{
				if(u->matchesBan(ban))
				{
					if(caster->nick && *caster->nick) toKick.sortAdd(caster);
					return 1;
				}
			}
			u++;
		}

		if(chset->STRICT_BANS)
		{
			while(h)
			{
				if(userLevel(h->flags[GLOBAL] | h->flags[channum]) > userLevel(caster) &&
					userlist.wildFindHostExtBan(h, ban) != -1)
				{
					if(caster->nick && *caster->nick) toKick.sortAdd(caster);
					return 1;
				}
				h = h->next;
			}
		}
	}

	//enforce this ban
	if(chset->ENFORCE_BANS)
	{
		static char reason[MAX_LEN];
		shitlist::entry *s;

		if(caster->flags & HAS_B && ((s = shit->find(ban)) ||
			(s = userlist.shit.find(ban))))
			snprintf(reason, MAX_LEN, "%s", s->fullReason());
		else if(caster->flags & HAS_B)
			snprintf(reason, MAX_LEN, "banned");
		else
			snprintf(reason, MAX_LEN, "banned by %s: \002%s\002", caster->nick, ban);

		int ulevel = userLevel(caster);

		if(chset->ENFORCE_BANS == 2 && ulevel <= userLevel(HAS_O))
			ulevel = userLevel(HAS_O);

		int shitlisted = shit->find(ban) || userlist.shit.find(ban);

		for(u = users.begin(); u; u++)
		{
			if(!(u->flags & HAS_F) && ulevel > userLevel(&u))
			{
				if(chset->CLONECHECK == 1 && caster->flags & HAS_B && (u->flags & HAS_C) && !shitlisted)
					continue;

				if(u->matchesBan(ban))
				{
					if(!u->reason)
						u->setReason(reason);
					toKick.sortAdd(u);
				}
			}
		}
	}
	return 0;
}

int chan::numberOfBots(int num) const
{
	if(num >= 0) return num;
	if(num == -100) return opedBots.entries();
	return ((num * opedBots.entries()) / (-100)) + 1;
}

void chan::reOp()
{
	if(users.entries() == 1)
	{
		net.irc.send("PART ", (const char *) name, NULL);
		net.irc.send("JOIN ", (const char *) name, NULL);
	}
	else if(users.entries() > 1 && config.listenport)
	{
		char *buf = push(NULL, S_CYCLE, (const char *) name, NULL);
		quoteBots(buf);
		net.send(HAS_N, "[*] Reoping ", (const char *) name, NULL);
		free(buf);
	}
}

void chan::quoteBots(const char *str)
{
	ptrlist<chanuser>::iterator p = users.begin();
	inetconn *c;

	while(p)
	{
		if(p->flags & HAS_B)
		{
			c = net.findConn(p->nick);
			if(c && c->isRegBot()) c->send(str, NULL);
			p++;
		}
	}
}

void chan::gotNickChange(const char *from, const char *to)
{
	chanuser *p = getUser(from);
	int status = 0;

	if(!p) return;

	if(toOp.remove(p)) status += 1;
	if(botsToOp.remove(p)) status += 2;
	if(opedBots.remove(p)) status += 4;
	if(toKick.remove(p)) status += 8;

	users.remove(p, 0);

	free(p->nick);
	mem_strcpy(p->nick, to);
	p->hash = hash32(p->nick);

	users.add(p);

	if(status & 1) toOp.sortAdd(p);
	if(status & 2) botsToOp.sortAdd(p);
	if(status & 4) opedBots.sortAdd(p);
	if(status & 8) toKick.sortAdd(p);

	if(p->flags & KICK_SENT)
	{
		p->flags &= ~KICK_SENT;
		--sentKicks;
	}

	shitlist::entry *s;
	if((chset->CHECK_SHIT_ON_NICK_CHANGE || config.check_shit_on_nick_change) && !(p->flags & HAS_F)
		&& myTurn(chset->PUNISH_BOTS, p->hash32()) && ((s = shit->match(p)) || (s = userlist.shit.match(p))))
	{
		p->setReason(s->fullReason());
		toKick.sortAdd(p);
	}
}

chanuser *chan::getUser(const char *nick)
{
	if(!nick) return NULL;

	chanuser x = chanuser(nick);
	ptrlist<chanuser>::iterator ret = users.find(x);

	return (bool) ret ? &ret : NULL;
}

void chan::gotKick(const char *victim, const char *offender)
{
	chanuser *kicked, *kicker;
	int inv = 0;

	kicked = getUser(victim);
	kicker = getUser(offender);

	if(kicker)
	{
		if(userLevel(kicked) > userLevel(kicker))
		{
			toKick.sortAdd(kicker);
			if(myTurn(chset->PUNISH_BOTS, kicker->hash32()))
			{
				kick(kicker, config.kickreason);
			}
		}
	}


	HOOK(kick, kick(this, kicked, kicker));

	if((limit <= users.entries() - 1 || flags & FLAG_I) && kicked->flags & HAS_I &&
		myTurn(chset->INVITE_BOTS, kicker->hash32()))
		inv = 1;

	gotPart(victim);

	if(inv)
	{
		invite(victim);
		if(toKick.entries() < 2 && penalty < 9) ::invite.flush(&net.irc);
	}
}

void chan::gotPart(const char *nick, int netsplit)
{
	chanuser *p = getUser(nick);

	if(p)
	{
		if(netsplit && (p->flags & (IS_OP | HAS_F)) == IS_OP && !toKick.find(p))
			wasop->add(p);

		if(p->flags & KICK_SENT) --sentKicks;

		toKick.remove(p);
		opedBots.remove(p);
		botsToOp.remove(p);
		toOp.remove(p);

		clone_host x = clone_host(p);
		clone_ident y = clone_ident(p);
		clone_proxy z = clone_proxy(p);
		hostClones.remove(x);
		identClones.remove(y);
		proxyClones.remove(z);

		users.remove(p);

		if(synced() && users.entries() == 1 && !(me->flags & IS_OP))
		{
			net.irc.send("PART ", (const char *) name, " :regaining op... duuuh", NULL);
			penalty += 2;
			ME.rejoin(name, 0);
		}
	}
}

#ifdef HAVE_DEBUG
void chan::display()
{
	printf("users (%d):\n", users.entries());
	users.display();
	printf("toOp (%d):\n", toOp.entries());
	toOp.display();
	printf("botsToOp (%d):\n", botsToOp.entries());
	botsToOp.display();
	printf("toKick (%d):\n", toKick.entries());
	toKick.display();
	printf("opedBots (%d):\n", opedBots.entries());
	opedBots.display();
	printf("modes: %s\n", getModes());
}
#endif


bool chan::checkClone(chanuser *p)
{
	char buf[MAX_LEN];
	bool badBoy = false;

	/* clone check */
	if(!(p->flags & HAS_C) && chset->CLONECHECK)
	{
		buf[0] = '\0';

		/* ident clones */
		if(set.IDENT_CLONES && identClones.addLast(new clone_ident(p)) > set.IDENT_CLONES && synced())
		{
			if(isPrefix(*p->ident))
				snprintf(buf, MAX_LEN, "*!?%s@*", p->ident+1);
			else
				snprintf(buf, MAX_LEN, "*!%s@*", p->ident);

			punishClones(buf, myTurn(chset->GUARDIAN_BOTS, hash32(p->ident)));
			badBoy = true;
		}

		/* proxy clones */
		if(set.PROXY_CLONES && isPrefix(*p->ident) && getPartOfDomain(p->host, 3) && synced() &&
			proxyClones.addLast(new clone_proxy(p)) > set.PROXY_CLONES)
		{
			//FIXME: what about ipv6 proxy clones? :P
			snprintf(buf, MAX_LEN, "*!*@*.%s", getPartOfDomain(p->host, 2));

			punishClones(buf, myTurn(chset->GUARDIAN_BOTS));
			badBoy = true;
		}

		/* host clones */
		if(set.HOST_CLONES && hostClones.addLast(new clone_host(p)) > set.HOST_CLONES && synced())
		{
			switch(p->dnsinfo & (HOST_IPV4 | HOST_IPV6 | HOST_DOMAIN))
			{
				case HOST_DOMAIN:
				{
					snprintf(buf, MAX_LEN, "*!*@%s", p->host);
					break;
				}
				case HOST_IPV4:
				{
					char *n = nindex(p->host, 3, '.');
					if(n)
					{
						//the trick
						*n = '\0';
						snprintf(buf, MAX_LEN, "*!*@%s.*", p->host);
						*n = '.';
					}
					break;
				}
				case HOST_IPV6:
				{
					char *n = nindex(p->host, 4, ':');
					if(n)
					{
						//the trick
						*n = '\0';
						snprintf(buf, MAX_LEN, "*!*@%s:*", p->host);
						*n = ':';
					}
					break;
				}
			}
			if(*buf)
			{
				punishClones(buf, myTurn(chset->GUARDIAN_BOTS, hash32(p->host)));
				badBoy = true;
			}
		}
	}
	return badBoy;
}

chanuser *chan::gotJoin(const char *mask, int def_flags)
{
	static char buf[MAX_LEN];
    chanuser *p  = new chanuser(mask, this, def_flags, 1);
	shitlist::entry *s;
	bool badBoy;

#ifdef HAVE_ADNS
	 badBoy = p->updateDNSEntry();
#endif

	users.add(p);

	if(ME.overrider)
	{
		if(synced() && !(p->flags & HAS_F))
		{
			chanuser *over = getUser(ME.overrider);

			if(!over)
			{
				p->setReason(config.limitreason);
				toKick.sortAdd(p);

				chanuser tmp(ME.overrider, this);
				if(tmp.ok())
				{
					badBoy = true;
					snprintf(buf, MAX_LEN, "*!%s@%s", tmp.ident, tmp.host);
					enforceBan(buf, me, config.limitreason);
				}
			}
			else if(!(over->flags & HAS_N))
			{
				p->setReason(config.limitreason);
				toKick.sortAdd(p);
				badBoy = true;

				snprintf(buf, MAX_LEN, "*!%s@%s", over->ident, over->host);
				enforceBan(buf, me, config.limitreason);
			}
		}
		ME.overrider = "";
	}

	if(p->flags & HAS_K)
	{
		p->setReason(config.kickreason);
		toKick.sortAdd(p);
		badBoy = true;

		if(synced() && myTurn(chset->PUNISH_BOTS, p->hash32()))
				kick(p, config.kickreason);
	}
	else if(((chset->TAKEOVER ? 1 : !(def_flags & NET_JOINED)) && chset->ENFORCE_LIMITS
		&& limit && users.entries() > limit && !(p->flags & HAS_F)))
	{
		if(synced())
		{
			p->setReason(config.limitreason);
			toKick.sortAdd(p);
			if(myTurn(chset->PUNISH_BOTS, p->hash32()))
				kick(p, config.limitreason);

			badBoy = true;
		}
	}
	else if(!(p->flags & HAS_F) && !list[EXEMPT].match(mask) && ((s = shit->match(p)) || (s = userlist.shit.match(p))))
	{
		p->setReason(s->fullReason());
		toKick.sortAdd(p);
		badBoy = true;

		if(myTurn(chset->PUNISH_BOTS, p->hash32()))
		{
			modeQ[PRIO_HIGH].add(NOW, "+b", s->mask);
			modeQ[PRIO_HIGH].flush(PRIO_HIGH);

			//kick(p, p->reason);
		}
		else modeQ[PRIO_LOW].add(NOW+2, "+b", s->mask);
	}
	else if((p->flags & (HAS_O | HAS_A | IS_OP)) == (HAS_O | HAS_A))
	{
		if(p->flags & HAS_B) botsToOp.sortAdd(p);
		else toOp.sortAdd(p);

		if(synced() && opedBots.entries() && me->flags & IS_OP)
		{
			//if it is a bot
			if(p->flags & HAS_B)
			{
				if(net.findConn(p->nick) && myTurn(chset->BOT_AOP_BOTS, p->hash32()))
				{
					if(chset->TAKEOVER ? 1 : !(def_flags & NET_JOINED))
						op(p);

					modeQ[PRIO_HIGH].add(NOW+2, "+o", p->nick);
				}
			}
			else if(myTurn(chset->AOP_BOTS, p->hash32()))
			{
				if(chset->TAKEOVER ? 1 : !(def_flags & NET_JOINED))
					op(p);

				modeQ[PRIO_LOW].add(NOW+2, "+o", p->nick);
			}
		}
	}
	else if((p->flags & (HAS_V | HAS_A | IS_VOICE)) == (HAS_V | HAS_A))
	{
		if(synced() && opedBots.entries())
		{
			if(myTurn(chset->AOP_BOTS, p->hash32()))
			{
				modeQ[PRIO_LOW].add(NOW+2, "+v", p->nick);
			}
		}
	}

	if(p->flags & IS_OP)
	{
		if(!(p->flags & HAS_O))
		{
			if(chset->TAKEOVER || (userlist.chanlist[channum].allowedOps &&
				!userlist.chanlist[channum].allowedOps->remove(p)))
					toKick.sortAdd(p);
		}

		if(p->flags & HAS_B)
		{
			opedBots.sortAdd(p);
			if(!initialOp) initialOp = NOW;
		}
	}
	if(botsToOp.entries() == users.entries() && config.listenport && synced()) reOp();

	if(!(def_flags & NET_JOINED)) wasop->remove(p);


	badBoy |= checkClone(p);

#ifdef HAVE_ADNS
	if(!badBoy)
		resolver.resolv(p->host);
#endif

	if(!(p->flags & HAS_F) && synced())
		p->flags |= CHECK_SHIT;

	if(penalty < 10)
		modeQ[PRIO_HIGH].flush(PRIO_HIGH);

	if(synced())
		HOOK(join, join(p, this, mask, def_flags & NET_JOINED));

	return p;
}

/* Constructor */
chan::chan()
{
    sentKicks = flags = limit = status = synlevel = 0;
	me = NULL;
	initialOp = 0;
	since = NOW;
	nextlimit = -1;
	users.removePtrs();
	hostClones.removePtrs();
	identClones.removePtrs();
	proxyClones.removePtrs();
	modeQ[0].setChannel(this);
	modeQ[1].setChannel(this);

#ifdef HAVE_MODULES
	if(customDataConstructor)
		customDataConstructor(this);
#endif

}

/* Destruction derby */
chan::~chan()
{
#ifdef HAVE_MODULES
	if(customDataDestructor)
		customDataDestructor(this);
#endif

}

/* class chanuser */

chanuser::chanuser(const char *str)
{
	char *a = strchr(str, '!');
	if(a) mem_strncpy(nick, str, (int) abs(str - a) + 1);
	else mem_strcpy(nick, str);

	flags = 0;
	ident = NULL;
	host = NULL;
	hash = ::hash32(nick);
	handle = NULL;
	reason = NULL;
	ip4 = NULL;
	ip6 = NULL;
}

chanuser::chanuser(const char *m, const chan *ch, const int f, const bool scan)
{
	char *a = strchr(m, '!');
    char *b = strchr(m, '@');

	reason = NULL;

	if(!a || !b)
	{
		memset(this, 0, sizeof(chanuser));
		return;
	}

	mem_strncpy(nick, m, (int) abs(m - a) +1);
    mem_strncpy(ident, a+1, (int) abs(a - b));
    mem_strcpy(host, b+1);
	flags = f;
	if(scan)
		flags |= userlist.getFlags(m, ch);

	hash = ::hash32(nick);
	handle = NULL;
	mem_strcpy(ip4, "");
	mem_strcpy(ip6, "");

	switch(isValidIp(host))
	{
		case 4: dnsinfo = HOST_IPV4; break;
		case 6: dnsinfo = HOST_IPV6; break;
		case 0: dnsinfo = HOST_DOMAIN; break;
		default: break;
	}

#ifdef HAVE_MODULES
	if(customDataConstructor)
		customDataConstructor(this);
#endif
}

chanuser::~chanuser()
{
	if(nick) free(nick);
	if(ident) free(ident);
	if(ip4) free(ip4);
	if(ip6) free(ip6);
	if(host)
	{
		free(host);
#ifdef HAVE_MODULES
		if(customDataDestructor)
			customDataDestructor(this);
#endif
	}

	if(reason) free(reason);
}

int chanuser::operator==(const chanuser &c) const
{
	return (hash == c.hash) && !strcmp(nick, c.nick);
}

int chanuser::operator<(const chanuser &c) const
{
	return strcmp(nick, c.nick) < 0 ? 1 : 0;
}

void chanuser::getFlags(const chan *ch)
{
	char *m = push(NULL, nick, "!", ident, "@", host, NULL);
	flags &= ~(HAS_ALL);
	flags |= userlist.getFlags(m, ch);
	free(m);
}

unsigned int chanuser::hash32() const
{
	return hash;
}

#ifdef HAVE_DEBUG
void chanuser::display()
{
	char *tmp, buf[MAX_LEN];
	if(flags & IS_OP)
	{
		strcpy(buf, "@");
		tmp = buf + 1;
	}
	else tmp = buf;
	userlist.flags2str(flags, tmp);

	printf("%s!%s@%s (%d) [%s] [%s] [%s]\n", nick, ident, host, hash, buf, ip4, ip6);
}
#endif

void chanuser::setReason(const char *r)
{
	if(reason)
		free(reason);

	mem_strcpy(reason, r);
}

int chanuser::matches(const char *mask) const
{
	static char buf[MAX_LEN];

	snprintf(buf, MAX_LEN, "%s!%s@%s", nick, ident, host);
	return match(mask, buf);
}

int chanuser::matchesBan(const char *mask) const
{
	return matchBan(mask, this);
}

bool chanuser::ok() const
{
	return nick && host && ident;
}

#ifdef HAVE_ADNS
int chanuser::updateDNSEntry()
{
	adns::host2ip *info = resolver.getIp(host);

	if(info)
	{
		if(ip4)
			free(ip4);
		if(ip6)
			free(ip6);

		mem_strcpy(ip4, info->ip4);
		mem_strcpy(ip6, info->ip6);

		//DEBUG(printf(">>> Updating: %s (%s, %s)\n", nick, ip4, ip6));
		return 1;
	}

	return 0;
}
#endif
