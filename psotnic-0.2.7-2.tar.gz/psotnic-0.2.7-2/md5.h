#ifndef RSA_PKS_MD5_H
#define RSA_PKS_MD5_H 1

struct MD5_CTX
{
  unsigned long int state[4];
  unsigned long int count[2];
  unsigned char buffer[64];
};


void MD5Init(MD5_CTX *context);
void MD5Update(MD5_CTX *context, const unsigned char *input, unsigned long int inputLen);
void MD5Final(unsigned char digest[16], MD5_CTX *context);
void MD5Transform(unsigned long int state[4], const unsigned char block[64]);
void Encode(unsigned char *output, const unsigned long int *input, unsigned long int len);
void Decode(unsigned long int *output, const unsigned char *input, unsigned long int len);

void MD5Hash(unsigned char digest[16], const char *data, int datalen, const unsigned char *key=NULL, int keylen=0);
void MD5HexHash(char digest[33], const char *data, int datalen, const unsigned char *key=NULL, int keylen=0);
void MD5CreateAuthString(char *str, int len);
int MD5HexValidate(const char digest[33], const char *data, int datalen, const unsigned char *key=NULL, int keylen=0);
int MD5Validate(const unsigned char digest[16], const char *data, int datalen, const unsigned char *key=NULL, int keylen=0);
int MD5HashFile(unsigned char digest[16], const char *file, const unsigned char *key=NULL, int keylen=0);
int MD5HashFile(unsigned char digest[16], int fd, const unsigned char *key=NULL, int keylen=0);
#endif
