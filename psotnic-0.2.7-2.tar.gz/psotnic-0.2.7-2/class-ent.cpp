/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "defines.h"
#include "global-var.h"

/**
 * ent
 */
bool ent::operator<(const ent &e) const
{
	return strcmp(name, e.name) < 0 ? 1 : 0;
}

bool ent::operator==(const ent &e) const
{
	return !strcmp(name, e.name);
}

const char *ent::print(const int n) const
{
	static char buf[256];
	const char *v = getValue();
	snprintf(buf, 256, "%s %*s", name, n - strlen(name) + 3 + strlen(v), v);
	return buf;
}

const char *ent::getName() const
{
	return name;
}

options::event *ent::set(const char *arg, const bool justTest)
{
	return setValue(name, arg, justTest);
}

bool ent::isPrintable() const
{
	return dontPrintIfDefault ? !isDefault() : 1;
}

/**
 * entBool
 */
options::event ent::_event;

entBool::operator int() const
{
	return value;
}

const char *entBool::getValue() const
{
	return value ? "ON" : "OFF";
}

options::event *entBool::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		bool ok;
		bool n = str2int(arg2, ok);

		if(ok)
		{
			if(!justTest)
				value = n;

			_event.setOk(this, "%s has been turned %s", name, getValue());
			return &_event;
		}
		else
		{
			_event.setError(this, "argument is not a boolean value");
			return &_event;
		}
	}
	else if((*arg1 == '-' || *arg1 == '+') && !strcmp(arg1+1, name))
	{
		if(!justTest)
			value = (*arg1 == '+');

		_event.setOk(this, "%s has been turned %s", name, value ? "ON" : "OFF");
		return &_event;
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

bool entBool::str2int(const char *str, bool &ok) const
{
	if(!strcmp(str, "yes") || !strcmp(str, "ON") ||
		   !strcmp(str, "enable") || !strcmp(str, "1"))
	{
		ok = true;
		return 1;
	}

	if(!strcmp(str, "no") || !strcmp(str, "off") ||
		   !strcmp(str, "disable") || !strcmp(str, "0"))
	{
		ok = true;
		return 0;
	}

	ok = false;
	return 0;
}

void entBool::reset()
{
	value = defaultValue;
}
bool entBool::isDefault() const
{
	return value == defaultValue;
}

/**
 * entInt
 */
options::event *entInt::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		bool ok;
		int n = str2int(arg2, ok);

		if(!ok)
		{
			_event.setError(this, "argument is not an integer type");
			return &_event;
		}
		if(n >= min && n <= max)
		{
			if(!justTest)
				value = n;

			_event.setOk(this, "%s has been set to %s", name, getValue());
			return &_event;
		}
		else
		{
			_event.setError(this, "argument does not belong to range <%s, %s>", getMin(), getMax());
			return &_event;
		}
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

const char *entInt::getValue() const
{
	static char buf[20];
	sprintf(buf, "%d", value);
	return buf;
}

int entInt::str2int(const char *str, bool &ok) const
{
	ok = true;
	return atoi(str);
}

const char *entInt::getMin() const
{
	static char buf[20];
	sprintf(buf, "%d", min);
	return buf;
}

const char *entInt::getMax() const
{
	static char buf[20];
	if(max != MAX_INT)
		sprintf(buf, "%d", max);
	else
		strcpy(buf, "INFINITY");

	return buf;
}

/**
 * class entTime
 */
int entTime::str2int(const char *str, bool &ok) const
{
	int ret = 0;

	if(units2int(str, ut_time, ret) != 1)
	{
		ok = false;
		return 0;
	}

	ok = true;
	return ret;
}

const char *entTime::getValue() const
{
	static char buf[80];
	int2units(buf, 80, value, ut_time);

	return buf;
}

const char *entTime::getMin() const
{
	static char buf[80];
	int2units(buf, 80, min, ut_time);

	return buf;
}

const char *entTime::getMax() const
{
	static char buf[80];

	if(max != MAX_INT)
		int2units(buf, 80, max, ut_time);
	else
		strcpy(buf, "INFINITY");

	return buf;
}

/**
 * class entPerc
 */
int entPerc::str2int(const char *str, bool &ok) const
{
	int ret = 0;

	if(units2int(str, ut_perc, ret) != 1)
	{
		ok = false;
		return 0;
	}

	ok = true;
	return ret;
}

const char *entPerc::getValue() const
{
	static char buf[80];
	int2units(buf, 80, value, ut_perc);

	return buf;
}

const char *entPerc::getMax() const
{
	static char buf[80];
	int2units(buf, 80, min, ut_perc);

	return buf;
}

const char *entPerc::getMin() const
{
	static char buf[80];
	int2units(buf, 80, max, ut_perc);

	return buf;
}

/**
 * class entIp
 */
entIp::operator const char*() const
{
	return (const char *) ip;
}

const char *entIp::getValue() const
{
	return ip;
}

void entIp::reset()
{
	ip = "0.0.0.0";
}

bool entIp::isDefault() const
{
	return !strcmp(ip, "0.0.0.0");
}

options::event *entIp::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		switch(isValidIp(arg2))
		{
			case 4:
			{
				if(type & ipv4)
				{
					if(!justTest)
						ip = arg2;
					_event.setOk(this, "%s has been set to %s", name, getValue());
					return &_event;
				}
				else
				{
					_event.setError(this, "%s is not a valid IPV6 address", arg2);
					return &_event;
				}
			}
			case 6:
			{
				if(type & ipv6)
				{
					if(!justTest)
						ip = arg2;
					_event.setOk(this, "%s has been set to %s", name, getValue());
					return &_event;
				}
				else
				{
					_event.setError(this, "%s is not a valid IPV4 address", arg2);
					return &_event;
				}
			}
			default:
			{
				if(type & resolve)
				{
					char buf[MAX_LEN];
					bool ok = false;
#ifdef HAVE_IPV6
					if(type & ipv6 && inet::gethostbyname(arg2, buf, AF_INET6))
						ok = true;
					else
#endif
					if(!ok && type & ipv4 && inet::gethostbyname(arg2, buf, AF_INET))
						ok = true;

					if(ok)
					{
						if(!justTest)
							ip = buf;
						_event.setOk(this, "%s has been set to %s", name, getValue());
					}
					else if (errno)
						_event.setError(this, "Unknown host: %s (%s)", arg2, hstrerror(errno));
					else
						_event.setError(this, "Unknown host: %s", arg2);

					return &_event;
				}

				if(type & (ipv4 | ipv6) == (ipv4 | ipv6))
					_event.setError(this, "argument is not a valid IPV4 nor IPV6 address");
				else if(type & ipv4)
					_event.setError(this, "argument is not a valid IPV4 address");
				else if(type & ipv6)
					_event.setError(this, "argument is not a valid IPV6 address");

				return &_event;
			}
		}
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

entIp::operator unsigned int() const
{
	return inet_addr(ip);
}

/**
 * class entString
 */
const char *entString::getValue() const
{
	return string;
}

options::event *entString::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}
		int n = strlen(arg2);

		if(n > max)
		{
			_event.setError(this, "argument is longer than %d characters", max);
			return &_event;
		}
		else if(n < min)
		{
			_event.setError(this, "argument is shorter than %d characters", min);
			return &_event;
		}
		else
		{
			if(!justTest)
				string = arg2;

			_event.setOk(this, "%s has been set to %s", name, getValue());
			return &_event;
		}
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

void entString::reset()
{
	string = defaultString;
}

bool entString::isDefault() const
{
	return !strcmp(defaultString, string);
}

entString::operator const char*() const
{
	return string;
}

int entString::getLen() const
{
	return string.len();
}

/**
 * class entWord
 */
options::event *entWord::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}
		if(countWords(arg2) > 1)
		{
			_event.setError(this, "argument is not a one word");
			return &_event;
		}

		int n = strlen(arg2);

		if(n > max)
		{
			_event.setError(this, "argument is longer than %d characters", max);
			return &_event;
		}
		else if(n < min)
		{
			_event.setError(this, "argument is shorter than %d characters", min);
			return &_event;
		}
		else
		{
			if(!justTest)
				string = arg2;

			_event.setOk(this, "%s has been set to %s", name, getValue());
			return &_event;
		}
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

/**
 * class entIPPH
 */
options::event *entIPPH::_setValue(const char *arg1, const char *arg2, const char *arg3, const char *arg4, const char *arg5, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}
		options::event *e;

		if(_ip)
		{
			e = _ip->set(arg2, 1);
			if(!e || !e->ok)
				return e;
		}
		if(_port)
		{
			e = _port->set(arg3, 1);
			if(!e || !e->ok)
				return e;
		}
		if(_pass)
		{
			e = _pass->set(arg4, 1);
			if(!e || !e->ok)
				return e;
		}
		if(_handle)
		{
			e = _handle->set(arg5, 1);
			if(!e || !e->ok)
				return e;
		}

		if(!justTest)
		{
			if(_ip)
				_ip->set(arg2);
			if(_port)
				_port->set(arg3);
			if(_pass)
				_pass->set(arg4);
			if(_handle)
				_handle->set(arg5);
		}

		_event.setOk(this, "%s has been set to %s", name, getValue());

		return &_event;
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

const char *entIPPH::getValue() const
{
	static char buf[1024];

	if(_ip)
		strcpy(buf, _ip->getValue());
	if(_port)
	{
		strcat(buf, " ");
		strcat(buf, _port->getValue());
	}
	if(_pass)
	{
		strcat(buf, " ");
		strcat(buf, _pass->getValue());
	}
	if(_handle)
	{
		strcat(buf, " ");
		strcat(buf, _handle->getValue());
	}

	return buf;
}

options::event *entIPPH::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	char arg[4][256];
	str2words(arg[0], arg2 ? arg2 : "", 4, 256);

	return _setValue(arg1, arg[0], arg[1], arg[2], arg[3], justTest);
}

void entIPPH::reset()
{
	if(_ip)
		_ip->reset();
	if(_port)
		_port->reset();
	if(_pass)
		_pass->reset();
	if(_handle)
		_handle->reset();
}

bool entIPPH::isDefault() const
{
	if(_ip && !_ip->isDefault())
		return false;
	if(_port && !_port->isDefault())
		return false;
	if(_pass && !_pass->isDefault())
		return false;
	if(_handle && !_handle->isDefault())
		return false;

	return true;
}

entIPPH::~entIPPH()
{
	if(_ip)
		delete _ip;
	if(_port)
		delete _port;
	if(_pass)
		delete _pass;
	if(_handle)
		delete _handle;
}

entIPPH &entIPPH::operator=(const entIPPH &e)
{
	name = e.name;
	dontPrintIfDefault = e.dontPrintIfDefault;
	readOnly = e.readOnly;

	this->~entIPPH();

	if(e._ip)
	{
		_ip = new entIp();
		*_ip = *e._ip;
	}
	else
		_ip = NULL;

	if(e._port)
	{
		_port = new entInt();
		*_port = *e._port;
	}
	else
		_port = NULL;

	if(e._pass)
	{
		if(typeid(*e._pass) == typeid(entWord))
			_pass = new entWord();
		else if(typeid(*e._pass) == typeid(entMD5Hash))
			_pass = new entMD5Hash();

		*_pass = *e._pass;
	}
	else
		_pass = NULL;

	if(e._handle)
	{
		_handle = new entWord();
		*_handle = *e._handle;
	}
	else
		_handle = NULL;

	return *this;
}

/**
 * class entMD5Hash
 */
options::event *entMD5Hash::setValue(const char *arg1, const char *arg2, const bool justTest)
{
	if(!strcmp(arg1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}
		//TODO: add [0-9a-f] check
		//its a hash
		int n = strlen(arg2);
		if(n == 32)
		{
			if(!justTest)
			{
				string =  arg2;
				quoteHex(arg2, hash);
			}
		}
		else
		{
			if(!justTest)
			{
				char buf[33];
				MD5Hash(hash, arg2, n);
				quoteHexStr(hash, buf, 16);
				string = buf;
			}
		}

		_event.setOk(this, "%s has been set to %s", arg1, getValue());
		return &_event;
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

entMD5Hash::operator const unsigned char*() const
{
	return hash;
}

const unsigned char *entMD5Hash::getHash() const
{
	return hash;
}

void entMD5Hash::reset()
{
	memset(hash, 0, 16);
	string = "";
}

bool entMD5Hash::isDefault() const
{
	for(int i=0; i<16; ++i)
		if(hash[i])
			return 0;

	return 1;
}

/**
 * class entMult
 */
options::event *entMult::setValue(const char *arg1, const char *arg2, bool justTest)
{
	if(!strcmp(arg1, name) || (*arg1 == '+' && !strcmp(arg1+1, name)))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		ptrlist<ent>::iterator i = list.begin();
		while(i)
		{
			if(i->isDefault())
			{
				options::event *e = i->set(arg2, justTest);
				if(!e || !e->ok)
					return e;

				_event.setOk(i, "adding new entry: %s %s", i->name, i->getValue());
				return &_event;
			}
			i++;
		}
		_event.setError(this, "%s has reached maximum number of entries, please remove some entries in order to add new ones", name);
		return &_event;
	}
	else if(*arg1 == '-' && arg2 && *arg2 && !strcmp(arg1+1, name))
	{
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		ptrlist<ent>::iterator i = list.begin();
		while(i)
		{
			if(!i->isDefault() && !strcmp(i->getValue(), arg2))
			{
				_event.setOk(i, "removing entry: %s %s", i->name, i->getValue());
				i->reset();
				return &_event;
			}
			i++;
		}
		_event.setError(this, "no such entry");
		return &_event;
	}
	else
	{
		_event.setError(this);
		return NULL;
	}
}

void entMult::reset()
{
	ptrlist<ent>::iterator i = list.begin();
	while(i)
	{
		i->reset();
		i++;
	}
}

void entMult::add(ent *e)
{
	list.addLast(e);
}

/**
 * entServer
 */
options::event *entServer::set(const char *ip, const char *port, const bool justTest)
{
	return _setValue(name, ip, port, "", ip, justTest);
}

/**
 * entLoadModules
 */
extern void registerAll(int (*_register)(const char *name, FUNCTION address));

options::event *entLoadModules::setValue(const char *arg1, const char *arg2, bool justTest)
{
	char arg[2][256];
	str2words(arg[0], arg2 ? arg2 : "", 2, 256);

	return _setValue(arg1, arg[0], arg[1], justTest);
}

options::event *entLoadModules::_setValue(const char *arg1, const char *arg2, const char *arg3, bool justTest)
{
	if(!strcmp(arg1, name))
	{
#ifdef HAVE_MODULES
		if(isReadOnly())
		{
			_event.setError(this, "entry %s is read-only", name);
			return &_event;
		}

		if(findModule(arg2))
		{
			_event.setError(this, "module is already loaded");
			return &_event;
		}

		int fd;
		unsigned char digest[16];
		char digestHex[33];

		if(md5)
		{
			fd = open(arg2, O_RDONLY);

			if(fd == -1)
			{
				_event.setError(this, "cannot open %s: %s", arg2, strerror(errno));
				close(fd);
				return &_event;
			}
			MD5HashFile(digest, fd);
			close(fd);

			quoteHexStr(digest, digestHex, 16);

			if(*arg3)
			{
				if(strcmp(digestHex, arg3))
				{
					_event.setError(this, "cannot load %s: md5 signature missmatch", arg2);
					return &_event;
				}
			}
			//else wee load new module
		}
		else
			digestHex[0] = '\0';


		int (*_register)(const char *name, FUNCTION address);
		module *(*init)();
		void *handle = dlopen(arg2, RTLD_LAZY);

		if(!handle)
		{
			_event.setError(this, "error while loading %s: %s", arg2, dlerror());
			return &_event;
		}

		_register = (int (*)(const char*, int*)) dlsym(handle, "_register");
		if(!_register)
		{
			_event.setError(this, "error while loading %s: %s", arg2, dlerror());
			return &_event;
		}

		init = (module*(*)()) dlsym(handle, "init");
		if(!init)
		{
			_event.setError(this, "error while loading %s: %s", arg2, dlerror());
			return &_event;
		}

		registerAll(_register);

		module *m = init();

		if(!justTest)
		{
			modules.addLast(m);
			m->file = arg2;
			m->md5sum = digestHex;
			m->loadDate = time(NULL);
		}
		else
			dlclose(handle);

		_event.setOk(this, "loaded module %s", arg2);
		return &_event;

#else
	_event.setError(this, "This verion of bot does not support modules");
	return &_event;
#endif
	}
	return NULL;
}

ptrlist<module>::iterator entLoadModules::findModule(const char *str)
{
	ptrlist<module>::iterator i = modules.begin();

	while(i)
	{
		if(!strcmp(i->file, str))
			return i;

			i++;
	}

	return i;
}

/*
bool entLoadModules::unload(const char *str)
{
	ptrlist<module>::iterator i = findModule(str);

	if(i)
	{
		modules.removeLink(i);
		return true;
	}
	return false;
}
*/

/*
bool entLoadModules::rehash(const char *str)
{
	if(
*/
//options::event *entLoadModules::_setValue(const char *arg1, const char *arg2, const char *arg3, bool justTest)
//moved to modules.cpp
