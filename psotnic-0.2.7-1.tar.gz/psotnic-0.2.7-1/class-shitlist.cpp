/***************************************************************************
 *   Copyright (C) 2003-2005 by Grzegorz Rusin                             *
 *   grusin@gmail.com                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "prots.h"
#include "global-var.h"

shitlist::entry::entry()
{
}

shitlist::entry::entry(const char *_mask, const char *_by, const char *_reason, time_t _when, time_t _expires, bool _sticky)
{
	mem_strcpy(mask, _mask);
	mem_strcpy(by, _by);
	if(_reason && *_reason)
		mem_strcpy(reason, _reason);
	else
		mem_strcpy(reason, "requested");

	when = _when;
	expires = _expires;
	sticky = _sticky;
}

shitlist::entry::~entry()
{
	free(mask);
	free(by);
	free(reason);
}

char *shitlist::entry::fullReason()
{
	static char buf[MAX_LEN];

	if(expires && expires - NOW <= 20*3600)
	{
		snprintf(buf, MAX_LEN, "\002%s\002: %s - expires: %s", by, reason,
			timestr("%T", expires));
	}

	else
	{
		snprintf(buf, MAX_LEN, "\002%s\002: %s - expires: %s", by, reason,
			expires ? timestr("%d/%m/%Y", expires) : "never");
	}

	return buf;
}

shitlist::shitlist()
{
	data.removePtrs();
}

shitlist::~shitlist()
{
	data.clear();
}

shitlist::entry *shitlist::wildMatch(const char *mask)
{
	ptrlist<entry>::iterator l = data.begin();

	while(l)
	{
		if(::wildMatch(mask, l->mask))
			return l;
		l++;
	}

	return NULL;
}

shitlist::entry *shitlist::conflicts(const char *mask)
{
	ptrlist<entry>::iterator i = data.begin();

	while(i)
	{
		if(::match(i->mask, mask))
			return i;
		i++;
	}
	return NULL;
}

shitlist::entry *shitlist::match(const chanuser *u)
{
	ptrlist<entry>::iterator l = data.begin();

	while(l)
	{
		if(matchBan(l->mask, u))
			return l;
		l++;
	}
	return NULL;
}

shitlist::entry *shitlist::add(const char *mask, const char *by, time_t when, time_t expires, const char *reason, bool sticky)
{
	entry *e = new entry(mask, by, reason, when, expires, sticky);
	data.addLast(e);
	return e;
}

int shitlist::remove(const char *mask)
{
	ptrlist<entry>::iterator l = data.begin();

	if(*mask == '#')
	{
		if(!*mask || !isdigit(mask[1]))
			return 0;

		return remove(atoi(mask+1));
	}

	while(l)
	{
		if(!strcmp(mask, l->mask))
		{
			data.removeLink(l);
			return 1;
		}
		l++;
	}
	return 0;
}

int shitlist::remove(int n)
{
	ptrlist<entry>::iterator l = data.getItem(n-1);

	if(l)
	{
		data.removeLink(l);
		return 1;
	}

	return 0;
}

int shitlist::sendShitsToOwner(inetconn *c, const char *name, int i)
{
	//int i = start;
	ptrlist<entry>::iterator s = data.begin();

	if(s)
	{
		c->send(name, " shits: ", NULL);

		while(s)
		{
			++i;
			c->send(i > 99 ? "[\002" : i > 9 ? "[ \002" : "[  \002", itoa(i), "\002]\002:\002 ", s->mask,
					" (expires\002:\002 ", s->expires ?
					timestr("%d/%m/%Y %T", s->expires) : "never", ")", NULL);

			c->send(s->sticky ? "[ * ]  " : "       ", s->by, "\002:\002 ", s->reason, NULL);
			c->send("       created\002:\002 ", timestr("%d/%m/%Y %T", s->when), NULL);

			s++;
		}
	}
	return i;
}

void shitlist::sendToUserlist(inetconn *c, const char *name)
{
	ptrlist<entry>::iterator s = data.begin();

	while(s)
	{
		c->send(s->sticky ? S_ADDSTICK : S_ADDSHIT, " ", name, " ", s->mask, " ", s->by, " ",
				itoa(s->when), " ", itoa(s->expires), " ", s->reason, NULL);
		s++;
	}
}

int shitlist::sendShitsToOwner(inetconn *c, const char *channel, const char *)
{
	int matches = 0;
	CHANLIST *chLst;

	if((!channel || !*channel || !strcmp(channel, "*")) && c->checkFlag(HAS_N))
	{
		matches += userlist.shit.sendShitsToOwner(c, "Global");
	}

	if(channel && *channel)
	{
		foreachMatchingChanlist(chLst, channel)
		{
			if(c->checkFlag(HAS_N) || c->checkFlag(HAS_N, _i))
				matches += chLst->shit->sendShitsToOwner(c, chLst->name);
		}
	}

	if(!matches)
		c->send("No matches has been found", NULL);
	else
		c->send("--- Found ", itoa(matches), matches == 1 ? " match" : " matches", NULL);

	return matches;
}


shitlist::entry *shitlist::find(const char *str)
{
	ptrlist<entry>::iterator s = data.begin();

	while(s)
	{
		if(!strcmp(str, s->mask))
			return s;

		s++;
	}

	return NULL;
}

int shitlist::expire(const char *channel)
{
	if(config.bottype != BOT_MAIN)
		return 0;

	ptrlist<entry>::iterator n, s = data.begin();
	int i=0;

	while(s)
	{
		n = s;
		n++;
		if(s->expires && s->expires <= NOW)
		{
			net.send(HAS_B, S_RMSHIT, " ", s->mask, " ", channel, NULL);
			data.removeLink(s);
			++userlist.SN;
			++i;
		}
		s = n;
	}
	return i;
}

int shitlist::expireAll()
{
	if(config.bottype != BOT_MAIN)
		return 0;

	CHANLIST *chLst;
	int i=0;

	foreachNamedChanlist(chLst)
		i += chLst->shit->expire(chLst->name);

	i += userlist.shit.expire();


	if(i)
		userlist.nextSave = NOW + SAVEDELAY;

	return i;
}

void shitlist::clear()
{
	data.clear();
}

bool shitlist::isSticky(const char *ban, const chan *ch)
{
	entry *b = ch->shit->find(ban);

	if((b && b->sticky) || ((b = userlist.shit.find(ban)) && b->sticky))
		return true;

	return false;
}


