/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void CheckEXE()
{
	MD5_CTX md5;
	unsigned char hash[16];
	unsigned char p[64];
	int i;

	MD5Init(&md5);
	for(i=0; ;++i)
	{
		if(!strlen(TXT[i])) break;
		memset(p, 0, 64);
		memcpy(p, TXT[i], strlen(TXT[i]));
		MD5Update(&md5, p, 64);
	}
	MD5Final(hash, &md5);

	for(i=0; i<16; ++i)
	{
		if(hash[i] != TXTdigest[i])
		{
			printf(S_HACKED);
			printf("\n[-] Calling exit(5)\n");
			exit(5);
		}
	}

}

char *srewind(char *str, int word)
{
	int i;

	if(!str) return NULL;

	while(isspace(*str))
	{
		if(*str == '\0') return NULL;
		++str;
	}
	for(i=0; i<word; ++i)
	{
		while(!isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
		while(isspace(*str))
		{
			if(*str == '\0') return NULL;
			++str;
		}
	}
	return str;
}

/*
int SendDNSQuery(int fd, char *domain, int type)
{
	u_char buf[MAX_LEN];
	int i, n;
	printf("quering: %s\n", domain);
	printf("fd: %d\n", fd);
	i = res_mkquery(QUERY, domain, C_IN, 1, NULL, 0, NULL, buf, MAX_LEN);
	if(i == -1) debug();
	else
	{
		//buf[i++] = '\n';
		//buf[i++] = '\0';
		printf("buffer size: %d\n", i);
		n = write(fd, buf, i);
		printf("wrote %d bytes\n", n);
	}

	return 1;
}
*/

int UserLevel(CHANUSER *u)
{
	if(u->flags & HAS_N || u->flags & HAS_B) return 3;
	if(u->flags & HAS_M) return 2;
	if(u->flags & HAS_O) return 1;
	return 0;
}

void str2words(char *word, char *str, int x, int y)
{
	int i, j;

	for(i=0; i<x; ++i)
	{
		while(isspace(*str))
		{
			if(*str == '\0') break;
			++str;
		}
		if(*str == '\0') break;
		
		for(j=0; j<y-1 && !isspace(*str); ++j, ++str)
		{
			if(*str == '\0') break;
			*word = *str;
			++word;
		}
		memset(word, 0, y - j - 1);
		word += y - j;
		if(*str == '\0') break;
	}

	for(++i; i<x; ++i)
	{
		memset(word, 0, y - 1);
		word += y;
	}

}

void sclose(int fd)
{
	#ifdef _NO_LAME_ERRNO
	int e = errno;
	#endif
	shutdown(fd, SHUT_RDWR);
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
}

long int nanotime()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_usec;
}

void HandleDeadSocket(int fd, SOCK *s)
{
	/* IRC */
	if(!s)
	{
		if(fd == ME.servfd)
		{
			printf("[-] Disconnected from IRC (%s)\n", strerror(errno));
			RemoveBuffers(ME.servfd);
			sclose(ME.servfd);
			ME.reset();
			return;
		}

		/* HUB */
		if(fd == hub.fd)
		{
			if(hub.status & STATUS_CONNECTED) printf("[-] Disconnected from HUB (%s)\n", strerror(errno));
			else printf("[-] Cannot establish connection to HUB (%s)\n", strerror(errno));
			CloseSock(&hub);
			return;
		}
	}
	else
	{
		printf("[-] Socket %d is dead, shuting down\n", s->fd);
		if(s->status & STATUS_REGISTERED)
		{
			int n;
			n = s->status;
			s->status =0;

			if(n & STATUS_OWNER)
			{
				quote(FD_OWNERS, "*** ", s->name, " has left the partyline (", strerror(errno), ")", NULL);
				--VAR.pl_owners;
			}
			else
			{
				quote(FD_OWNERS, "*** ", s->name, " has left the botnet (", strerror(errno), ")", NULL);
				--VAR.pl_bots;
			}
		}
		CloseSock(s);
	}
}


void SendLogo(int fd, char *who)
{
	char owners[16], bots[16], *timestr;
	struct utsname name;

	timestr = ctime(&NOW);
	timestr[strlen(timestr) - 1] = '\0';
	
	uname(&name);
	sprintf(owners, "%d", VAR.pl_owners);
	sprintf(bots, "%d", VAR.pl_bots);

	quote(fd, "", NULL);
	quote(fd, "\002    _/_/_/   _/_/_/   _/_/_/  _/_/_/_/ _/      _/  _/   _/_/_/\002", NULL);
	quote(fd, "\002   _/   _/ _/       _/    _/    _/    _/_/    _/  _/  _/\002", NULL);
	quote(fd, "\002  _/_/_/   _/_/_/  _/    _/    _/    _/  _/  _/  _/  _/\002", NULL);
	quote(fd, "\002 _/            _/ _/    _/    _/    _/    _/_/  _/  _/\002", NULL);
	quote(fd, "\002_/       _/_/_/   _/_/_/     _/    _/      _/  _/   _/_/_/\002", NULL);
	quote(fd, "", NULL);
	quote(fd, "     ", S_COPYRIGHT, NULL);
	quote(fd, "", NULL);
	quote(fd, "Psotnic version: \002", S_VERSION , "\002", NULL);
	quote(fd, "Local time: \002", timestr, "\002", NULL);
	quote(fd, "Machine info: \002", name.sysname, " ", name.release, " ", name.machine, "\002", NULL);
	quote(fd, "Owners on-line: \002", owners, "\002 (type .owners to see list)", NULL);
	quote(fd, "Bots on-line: \002", bots, "\002 (type .bots to see list)", NULL);
	quote(fd, "", NULL);
	quote(FD_OWNERS, "*** ", who, " has joined the partyline", NULL);
}

int DoConnect6(char *server, int port, char *vhost, int options)
{
    struct sockaddr_in6 sin6;
	int s;

	s = socket(AF_INET6, SOCK_STREAM, 0);
	if(!s) return -1;

	memset(&sin6, 0, sizeof(sin6));

	if(strlen(vhost)) inet_pton(AF_INET6, vhost, (void *) &sin6.sin6_addr);
	else sin6.sin6_addr = in6addr_any;

	if(bind (s, (struct sockaddr *) &sin6, sizeof (sin6)) == -1)
	{
		sclose(s);
		return -1;
	}

	memset(&sin6, 0, sizeof (struct sockaddr_in6));
	sin6.sin6_family = AF_INET6;
	sin6.sin6_port = htons(port);
	inet_pton(AF_INET6, server, (void *) &sin6.sin6_addr);

	if(connect(s, (struct sockaddr *) &sin6, sizeof(sin6)) == -1)
	{
		sclose(s);
		return -1;
	}

	if(options > 0) if(fcntl(s, F_SETFL, options) == -1)
	{
		sclose(s);
		return -1;
	}
	return s;
}

void badparameters(char *str)
{
	printf("[-] %s\n", str);
	printf("[*] Usage: ./%s <config file>\n", S_BOTNAME);
	printf("[*] Calling exit(1)\n");
	exit(1);
}

void propaganda()
{
	CheckEXE();
	printf("\n");
	printf(S_LONGVERSION, S_VERSION, S_DATE, S_TIME);
	printf("\n");
	printf(S_COPYRIGHT);
	printf("\n\n");
}

void BufWrite(int fd, char *data, int len)
{
	int i, n;

	if(fd < 0) return;
	/* add to buf */
	for(i=0; i<MAX_BUFS; ++i)
	{
		if(writebuf[i].fd == fd)
		{
			//printf("## add to buf ##\n");
			writebuf[i].buf = (char *) realloc(writebuf[i].buf, writebuf[i].len + len);
			memcpy(writebuf[i].buf + writebuf[i].len, data, len);
			writebuf[i].len += len;
			return;
		}
	}

	/* try to send whole packet */
	errno = 0;
	n = write(fd, data, len);
	if(n == -1) n = 0;
	if(n < len)
	{
		if(errno != EPIPE)
		{
			//HandleDeadSocket(fd);
			return;
		}

		/* create new buf */
		for(i=0; i<MAX_BUFS; ++i)
		{
			if(!writebuf[i].fd)
			{
				//printf("## new buf ##\n");
				writebuf[i].fd = fd;
				writebuf[i].len = len-n;
				writebuf[i].pos = 0;
				writebuf[i].buf = (char *) malloc(len-n);
				memcpy(writebuf[i].buf, data+n, len-n);
				return;
			}
		}
	}
	else return;

	printf("[E] No free buffers, this should not happen\n");
	SafeExit();
}

int extendhost(char *host, char *buf, unsigned int len)
{
    char *ex, *at;

    if(strlen(host) + 10 > len) return 0;

    ex = strchr(host, '!');
    at = strchr(host, '@');

    if(ex != strrchr(host, '!') || at != strrchr(host, '@')) return 0;

    if(at)
    {
        if(!ex)
        {
            if(at == host) strcpy(buf, "*!*");
            else strcpy(buf, "*!");
            strcat(buf, host);
        }
        else if(ex == host)
        {
            strcpy(buf, "*");
            strcat(buf, host);
        }
        else strcpy(buf, host);
        if(*(at + 1) == '\0') strcat(buf, "*");
        return 1;
    }
    else
    {
        if(ex) return 0;
        if(strchr(host, '.') || strchr(host, ':'))
        {
            strcpy(buf, "*!*@");
            strcat(buf, host);
            return 1;
        }
        strcpy(buf, "*!");
        strcat(buf, host);
        strcat(buf, "@*");
        return 1;
    }
}

int MagicNickCreator(char *nick)
{
	int nicklen, applen;
	char *n;

	nicklen = strlen(nick);
	applen = strlen(config.nickappend);

	if(nicklen >= 9 && (!strchr(config.nickappend, nick[8]) || nick[8] == config.nickappend[applen-1]))
		return 0;

	n = strchr(config.nickappend, nick[nicklen-1]);

	if(n)
	{
		if(nick[nicklen-1] == config.nickappend[applen-1]) nick[nicklen] = config.nickappend[0];
		else nick[nicklen-1] = config.nickappend[abs(n - config.nickappend) + 1];
	}
	else nick[nicklen] = config.nickappend[0];

	return 1;
}

void RemoveBuffers(int fd)
{
	int i;

	for(i=0; i<MAX_BUFS; ++i)
	{
		if(readbuf[i].fd == fd)
		{
			if(readbuf[i].buf) free(readbuf[i].buf);
			memset(&readbuf[i], 0, sizeof(SOCKBUF));
		}
		if(writebuf[i].fd == fd)
		{
			if(writebuf[i].buf) free(writebuf[i].buf);
			memset(&writebuf[i], 0, sizeof(SOCKBUF));
		}
	}
}

void CloseSock(SOCK *s)
{
	RemoveBuffers(s->fd);
	sclose(s->fd);
	if(s->name) free(s->name);
	if(s->authstr) free(s->authstr);
	memset(s, 0, sizeof(SOCK));
}

char *inet2char(int inetip)
{
	struct sockaddr_in sin;
	sin.sin_addr.s_addr = inetip;
	return inet_ntoa(sin.sin_addr);
}

int AcceptConnection(int fd)
{
	int n, i;
	struct sockaddr_in from;
	socklen_t fromsize = sizeof(struct sockaddr_in);
	const int one = 1;

	if((n = accept(fd, (sockaddr *) &from, &fromsize)) > 0)
	{
		printf("[*] Connection attempt from %s\n", inet_ntoa(from.sin_addr));
		if(userlist.IsBot(inet_ntoa(from.sin_addr)))
		{
			fcntl(n, F_SETOWN);
			fcntl(n, F_SETFL, O_NONBLOCK);
			setsockopt(n, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof(one));
			if((i = AddSock(n)) == -1)
			{
				sclose(n);
				return -1;
			}
			sock[i].authstep = 1;
			sock[i].killtime = NOW + VAR.AUTH_TIME;
			sock[i].status = STATUS_CONNECTED + STATUS_BOT;
			printf("[+] Accepting connection\n");
			return n;
		}
		else
		{
			printf("[-] Unknown ip, disconnecting\n");
			sclose(n);
			return -1;
		}
	}
	else
	{
		sclose(n);
		printf("[-] Connection lost (%s)\n", strerror(errno));
		return -1;
	}
}

char *getpeerip(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int e = errno;
	#endif
	socklen_t peersize;
	peersize = sizeof(struct sockaddr_in);
	if(getpeername(fd, (sockaddr *) &peer, &peersize) == -1) return NULL;
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	return inet_ntoa(peer.sin_addr);
}

int getpeerport(int fd)
{
	struct sockaddr_in peer;
	#ifdef _NO_LAME_ERRNO
	int e = errno;
	#endif
	socklen_t peersize;
	peersize = sizeof(struct sockaddr_in);
	if(getpeername(fd, (sockaddr *) &peer, &peersize) == -1) return -1;
	#ifdef _NO_LAME_ERRNO
	errno = e;
	#endif
	return ntohs(peer.sin_port);
}

int ReadOneLine(int fd, char *buf, int len)
{
	int i, n;

	if(read(fd, buf, 1) > 0)
	{
		if(buf[0] == ':') return 0;
		if(buf[0] == '\n' || buf[0] == '\0')
		{
			for(i=0; i<MAX_BUFS; ++i)
			{
				if(readbuf[i].fd == fd)
				{
					n = readbuf[i].len;
					strncpy(buf, readbuf[i].buf, n);
					buf[n] = '\0';
					free(readbuf[i].buf);
					memset(&readbuf[i], 0, sizeof(readbuf[i]));
					printf("[*] read[%2d:%5d]: %s\n", strlen(buf), getpeerport(fd), buf);
					return n;
				}
			}
			return 0;
		}
		else
		{
			for(i=0; i<MAX_CONN; ++i)
			{
				if(readbuf[i].fd == fd)
				{
					//printf("--- add to read buf\n");
					readbuf[i].buf[readbuf[i].len++] = buf[0];

					if(readbuf[i].len == MAX_LEN - 1)
					{
						/* DoS detected */
						free(readbuf[i].buf);
						memset(&readbuf[i], 0, sizeof(readbuf[i]));
					}
					return 0;
				}
			}
			for(i=0; i<MAX_CONN; ++i)
			{
				if(readbuf[i].fd < 1)
                {
                    //printf("--- new read buf\n");
					readbuf[i].buf = (char *) malloc(len);
					readbuf[i].buf[0] = buf[0];
					readbuf[i].len = 1;
					readbuf[i].fd = fd;
					return 0;
				}
			}
		}
	}
	return -1;
}

int StartListening(char *ip, int port)
{
    struct sockaddr_in sin;
    int s;
    const int one = 1;

	printf("[*] Opening listening socket at %s:%d\n", ip, port);
    if((s = socket(AF_INET, SOCK_STREAM, 0)) == 0)
	{
		sclose(s);
		return -1;
	}

    if(setsockopt(s , SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0)
	{
		sclose(s);
		return -1;
	}

    memset (&sin, 0, sizeof (struct sockaddr_in));
    if(strlen(ip)) sin.sin_addr.s_addr = inet_addr(ip);
    else sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    if(bind (s, (struct sockaddr *) &sin, sizeof (struct sockaddr_in)) == -1)
	{
		sclose(s);
		return -1;
	}

    if(listen(s, SOMAXCONN) == -1)
	{
		sclose(s);
		return -1;
	}

	if(strcmp(ip, inet2char(sin.sin_addr.s_addr)) || ntohs(sin.sin_port) != port)
	{
		sclose(s);
		printf("[-] Invalid ip address or port\n");
		return -1;
	}
	printf("[+] Socket awaits incomming connections\n");

    return s;
}

int AddSock(int fd)
{
    int i;

    for(i=0; i<MAX_CONN; i++)
    {
        if(sock[i].fd < 1)
        {
            sock[i].fd = fd;
			sock[i].status = STATUS_CONNECTED;
            return i;
        }
    }
	return -1;
}


void precache()
{
    int i;

	for(i=0; i<MAX_CONN; ++i) memset(&sock[i], 0, sizeof(sock[i]));
	for(i=0; i<MAX_SERVERS; ++i) memset(&config.server[i], 0, sizeof(config.server[i]));
	for(i=0; i<MAX_CHANNELS; ++i) memset(&ME.chanlist[i], 0, sizeof(ME.chanlist[i]));
	for(i=0; i<MAX_BUFS; ++i)
	{
		memset(&readbuf[i], 0, sizeof(readbuf[i]));
		memset(&writebuf[i], 0, sizeof(writebuf[i]));
	}

	memset(&hub, 0, sizeof(hub));
	memset(&config, 0, sizeof(config));
}

void Divide(int *ret, int value, int parts, int part_size)
{
	if(parts == 1)
	{
		ret[0] = value;
		ret[1] = ret[2] = 0;
		return;
	}

	if(value > part_size*2)
    {
        ret[0] = value / parts;
        ret[1] = (value - ret[0]) / (parts-1);
        if(parts == 3) ret[2] = value - ret[0] - ret[1];
        else ret[2] = 0;
    }
    else if(value > part_size)
    {
        ret[0] = part_size;
        ret[1] = value - ret[0];
        ret[2] = 0;
    }
    else
    {
        ret[0] = value;
        ret[1] = ret[2] = 0;
    }
}

int DoConnect(char *server, int port, char *vhost, int noblock)
{
    struct sockaddr_in sin;
    int s;

	s = socket(AF_INET, SOCK_STREAM, 0);
    if(!s) return -1;

	memset (&sin, 0, sizeof (sin));
    if(strlen(vhost)) sin.sin_addr.s_addr = inet_addr(vhost);
	else sin.sin_addr.s_addr = INADDR_ANY;
    if(bind (s, (struct sockaddr *) &sin, sizeof (sin)) == -1)
	{
		sclose(s);
		return -1;
	}

    memset (&sin, 0, sizeof (sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(server);

	if(noblock == -1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		sclose(s);
		return -1;
	}
    if(connect(s, (struct sockaddr *) &sin, sizeof(sin)) == -1)
	{
		if(noblock == -1 && errno == EINPROGRESS) return s;
		sclose(s);
		return -1;
	}
	if(noblock == 1 && fcntl(s, F_SETFL, O_NONBLOCK) == -1)
	{
		sclose(s);
		return -1;
	}
	return s;
}

int match(char *str, char *pattern)
{
    if (!fnmatch(pattern, str, FNM_CASEFOLD | FNM_NOESCAPE)) return 1;
    else return 0;
}

unsigned int hash32(char *word)
{
    char c;
    unsigned bit_hi = 0;
    int bit_low = 0;
    int len = strlen(word);

    if(len > 64) len = 63;

	/* i barrowed this code from epic ;-) */
    for(; *word && len; ++word, --len)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
    return ((bit_hi & 8191) << 3) + (bit_low & 0x7);
}

unsigned int hash32(char *word, char *where)
{
    char c;
    unsigned bit_hi = 0;
    int bit_low = 0;
    int wordlen = strlen(word);
	int wherelen = strlen(where);

    if(wordlen > 32) wordlen = 32;
	if(wherelen > 32) wherelen = 31;

    for(; *word && wordlen; ++word, --wordlen)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
	for(; *where && wherelen; ++where, --wherelen)
    {
        c = tolower(*word);
        bit_hi = (bit_hi << 1) + c;
        bit_low = (bit_low >> 1) + c;
    }
    return ((bit_hi & 8191) << 3) + (bit_low & 0x7);
}

void quote(int file, char *lst, ...)
{
    va_list ap;
	char *ptr, *p;
    int size=2, i;

    va_start(ap, lst);
	size+=strlen(lst);
	while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }
	va_end(ap);

	va_start(ap, lst);
	ptr = (char *) malloc(size*sizeof(char));
    strcpy(ptr, lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
	}
	va_end(ap);

	ptr[size-1] = '\n';
	strcat(ptr, "\0");

	if(file > 0)
	{
		BufWrite(file, ptr, size);
		printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(file), ptr);
	}
	else if(file == FD_OWNERS)
	{
		for(i=0; i<MAX_CONN; i++)
		{
			if(sock[i].fd && sock[i].status & STATUS_REGISTERED && sock[i].status & STATUS_OWNER)
			{
				BufWrite(sock[i].fd, ptr, size);
				printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(sock[i].fd), ptr);
			}
		}
	}
	else if(file == FD_BOTS)
	{
		for(i=0; i<MAX_CONN; i++)
		{
			if(sock[i].fd && sock[i].status & STATUS_REGISTERED && sock[i].status & STATUS_BOT)
			{
				BufWrite(sock[i].fd, ptr, size);
				printf("[*] send[%2d:%5d]: %s\n", size, getpeerport(sock[i].fd), ptr);
			}
		}
	}
	free(ptr);
}

char *push(char *ptr, char *lst, ...)
{
    va_list ap;
    int size=1;
    char *p;

    va_start(ap, lst);
    size+=strlen(lst);
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        size+=strlen(p);
    }
	va_end(ap);

    va_start(ap, lst);
    if(ptr)
    {
        size+=strlen(ptr);
        ptr = (char *) realloc(ptr, size*sizeof(char));
        strcat(ptr, lst);
    }
    else
    {
        ptr = (char *) malloc(size*sizeof(char));
        strcpy(ptr, lst);
    }

    /* strcat rest */
    while(1)
    {
        p = va_arg(ap, char *);
        if(p == NULL) break;
        strcat(ptr, p);
    }
	va_end(ap);
    return ptr;
}
