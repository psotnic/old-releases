/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "strings.h"
#include "prots.h"

int listenfd;
time_t NOW;
client ME;
var VAR;
ul userlist;
SOCK sock[MAX_CONN];
SOCK hub;
SOCKBUF readbuf[MAX_CONN+2];
SOCKBUF writebuf[MAX_CONN+2];
CONFIG config;
masklist shitlist;
dns DNS;
extern int errno;

int main(int argc, char *argv[])
{
	char buf[MAX_LEN];
	int i, n, ret;
	struct timeval tv;
	time_t last;
	fd_set rfd, wfd;
	/*
	i = DoConnect("127.0.0.1", 53, "", 0);
	SendDNSQuery(i, "ursynow.eu.org.", 0);
	n = read(i, buf, MAX_LEN);
	printf("read[%d]: %s\n", n, buf);
	exit(1);
	*/
	propaganda();

	if(argc != 2) badparameters("Wrong number of parameters");

	precache();
	LoadConfig(argv[1]);

	if(config.listenport)
	{
		if(config.havehub)
		{
			printf("[*] Acting as SLAVE\n");
			printf("[-] SLAVE function not implemented yet\n");
			printf("[*] Calling exit(1)\n");
			exit(1);
		}
		else printf("[*] Acting as HUB\n");
	}
	else printf("[*] Acting as BOT\n");

	userlist.Load(config.userlist_file);
	SignalHandling();

	if(config.listenport)
	{
		if((listenfd = StartListening(config.myipv4, config.listenport)) < 1)
		{
			printf("[-] Cannot open socket (%s)\n", strerror(errno));
			SafeExit();
		}
	}
	last = NOW = time(NULL);
	tv.tv_sec = 1;

	/* MAIN LOOP */
	while(1)
	{
		if(!tv.tv_sec) tv.tv_sec = 1;
		tv.tv_usec = 0;

		/* Add sockets to SETs */
		FD_ZERO(&rfd);
		FD_ZERO(&wfd);
	   	if(ME.servfd > 0) FD_SET(ME.servfd, &rfd);
		if(config.listenport)
		{
			FD_SET(listenfd, &rfd);
			for(i=0; i<MAX_CONN; ++i)
			{
				if(sock[i].fd)
				{
					FD_SET(sock[i].fd, &rfd);
					if(sock[i].killtime < NOW && sock[i].killtime)
					{
						printf("[*] Killing socket %d (Registration time elapsed)\n", sock[i].fd);
						CloseSock(&sock[i]);
					}
				}
			}
		}
		if(hub.fd)
		{
			FD_SET(hub.fd, &rfd);
			if(hub.status & STATUS_SYNSENT)
			{
				FD_SET(hub.fd, &wfd);
				if(hub.killtime < NOW && hub.killtime)
				{
					printf("[*] Killing HUB socket (Registration time elapsed)\n");
					CloseSock(&hub);
				}
			}
		}


		for(i=0; i<MAX_BUFS; ++i) if(writebuf[i].fd) FD_SET(writebuf[i].fd, &wfd);

		/* SELECT */
		ret = select(65535, &rfd, &wfd, NULL, &tv);

		NOW = time(NULL);
		if(NOW > last + 2)
		{
			last = NOW;
			if(ME.status & STATUS_REGISTERED) ME.CheckQueue();
		}
		if(ME.nextconn_hub <= NOW && hub.fd < 1 && config.havehub)
		{
			ME.ConnectToHUB();
			ME.nextconn_hub = NOW + VAR.HUB_CONN_DELAY;
		}
		if(ME.nextconn_serv <= NOW && ME.servfd < 1)
		{
			if(ME.ConnectToIRC()) ME.ScheludeJoinToAllChannels();
			ME.nextconn_serv = NOW + VAR.IRC_CONN_DELAY;
		}
		ME.RejoinCheck();

		if(ret < 1) continue;

		/* WRITE BUFFER */
		for(i=0; i<MAX_BUFS; ++i)
		{
			if(FD_ISSET(writebuf[i].fd, &wfd))
			{
				write(writebuf[i].fd, writebuf[i].buf + writebuf[i].pos++, 1);
				if(writebuf[i].pos == writebuf[i].len)
				{
					free(writebuf[i].buf);
					memset(&writebuf[i], 0, sizeof(writebuf[i]));
				}
			}
		}

		/* READ from IRC */
		if(FD_ISSET(ME.servfd, &rfd))
		{
			n = ReadOneLine(ME.servfd, buf, MAX_LEN);
			if(n > 0) parse_irc(buf);
			else if(n == -1) HandleDeadSocket(ME.servfd, NULL);
		}

		/* READ from HUB */
		if(FD_ISSET(hub.fd, &rfd))
		{
			n = ReadOneLine(hub.fd, buf, MAX_LEN);
			if(n > 0 && hub.status & STATUS_CONNECTED) parse_hub(buf);
			else if(n == -1) HandleDeadSocket(hub.fd, NULL);
		}

		/* ACCEPT connections */
		if(FD_ISSET(listenfd, &rfd)) AcceptConnection(listenfd);

		/* READ from BOTS and OWNERS */
		if(config.listenport)
		{
			for(i=0; i<MAX_CONN; i++)
			{
				if(sock[i].fd > 0)
				{
					if(FD_ISSET(sock[i].fd, &rfd))
					{
						n = ReadOneLine(sock[i].fd, buf, sizeof(buf));
						if(n > 0)
						{
							if(sock[i].status & STATUS_OWNER) parse_owner(&sock[i], buf);
							else if(sock[i].status & STATUS_BOT) parse_bot(&sock[i], buf);
						}
						else if(n == -1) HandleDeadSocket(0, &sock[i]);
                	}
            	}
			}
		}
		if(hub.fd && hub.status & STATUS_SYNSENT)
		{
			if(FD_ISSET(hub.fd, &wfd))
			{
				printf("[+] Connection to HUB established\n");
				hub.status = STATUS_CONNECTED;
				hub.authstep = 1;
				quote(hub.fd, config.botnetword, NULL);
			}
		}
	}
	return 0;
}

