/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void masklist::Remove(MASKLIST *p)
{
	free(p->mask);
	free(p->info[0]);
	free(p->info[1]);
	free(p);
}

MASKLIST *masklist::WildFind(char *mask)
{
	MASKLIST *p = first;

	while(1)
	{
		if(!p) return NULL;
		if(match(mask, p->mask)) return p;
		p = p->next;
	}
	return NULL;
}

MASKLIST *masklist::Find(char *mask)
{
	MASKLIST *p = first;

	while(p)
	{
		if(!p) return NULL;
		if(!strcasecmp(mask, p->mask)) return p;
		p = p->next;
	}
	return NULL;
}

int masklist::Add(char *mask, char *info, char *info2)
{
	MASKLIST *p;

	if(Find(mask)) return 0;
	if(!ent)
	{
		first = last = new(MASKLIST);
		first->prev = first->next = NULL;
		mem_strcpy(first->mask, mask);
		mem_strcpy(first->info[0], info);
		mem_strcpy(first->info[1], info2);
	}
	else
	{
		p = last->next = new(MASKLIST);
  		p->prev = last;
		p->next = NULL;
		mem_strcpy(p->mask, mask);
		mem_strcpy(p->info[0], info);
		mem_strcpy(p->info[1], info2);
		last = p;
	}
	++ent;
	return 1;
}

int masklist::Remove(char *mask)
{
	MASKLIST *p;

	if(!first) return 0;
	p = first;

	if(ent == 1)
	{
		Remove(p);
		ent = 0;
		first = last = NULL;
		return 1;
	}
	else if(!strcasecmp(first->mask, mask))
	{
		first = first->next;
		if(p) first->prev = NULL;
		Remove(p);
		--ent;
		return 1;
	}
	else if(!strcasecmp(last->mask, mask))
	{
		p = last->prev;
		p->next = NULL;
		Remove(p);
		--ent;
		last = p;
		return 1;
	}
	else
	{
		p = first->next;
		while(1)
		{
			if(!p) break;
			if(!strcasecmp(p->mask, mask))
			{
				p->prev->next = p->next;
				if(p->next) p->next->prev = p->prev;
				Remove(p);
				--ent;
				return 1;
			}
			p = p->next;
		}
	}
	return 0;
}

masklist::masklist()
{
	first = last = NULL;
	ent = 0;
}

masklist::~masklist()
{
	MASKLIST *p = first;
	MASKLIST *q;
	ent = 0;

	while(1)
	{
		if(!p) return;
		q = p->next;
		Remove(p);
		p = q;
	}
}
