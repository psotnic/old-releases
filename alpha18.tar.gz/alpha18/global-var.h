/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

extern time_t NOW;
extern client ME;
extern var VAR;
extern ul userlist;
extern SOCK sock[MAX_CONN];
extern SOCK hub;
extern int errno;
extern int listenfd;
extern CONFIG config;
extern SOCKBUF readbuf[MAX_CONN+2];
extern SOCKBUF writebuf[MAX_CONN+2];
extern masklist shitlist;
extern dns DNS;
extern char TXT[][64];
extern unsigned char TXTdigest[17];
