/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

void parse_owner(SOCK *s, char *data)
{
	char arg[10][MAX_LEN], buf[MAX_LEN], *a;
	HANDLE *h;
	MASKLIST *m;
	BOT *b;
	int i, n;

	if(!strlen(data)) return;
	memset(buf, 0, MAX_LEN);
	str2words(arg[0], data, 10, MAX_LEN);

	/* small hack */
	s->status -= STATUS_OWNER;
	quote(FD_OWNERS, "\002#\002", s->name, "\002#\002 ", data, NULL);
	s->status += STATUS_OWNER;

	/* big hack ;-) */
	if(!strcmp(arg[0], ".bye"))
	{
		quote(FD_OWNERS, "*** ", s->name, " has left the partyline (bye)", NULL);
		CloseSock(s);
		return;
	}
	if(!strcmp(arg[0], ".+user") && strlen(arg[1]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			quote(s->fd, "Please add bots via .+bot command", NULL);
			return;
		}
		if(userlist.AddHandle(arg[1]))
		{
			quote(FD_OWNERS, "Adding user '", arg[1], "'", NULL);
			quote(FD_BOTS, S_ADDUSER, " ", arg[1], NULL);
			++userlist.SN;
		}
		else quote(s->fd, "User '", arg[1], "' allready exists", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-user") && strlen(arg[1]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			quote(s->fd, "Please remove bots via .-bot command", NULL);
			return;
		}
		if(userlist.RemoveHandle(arg[1]))
		{
			quote(FD_OWNERS, "Removing user '", arg[1], "'", NULL);
			quote(FD_BOTS, S_RMUSER, " ", arg[1], NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".users"))
	{
		if(!userlist.ent) quote(s->fd, "No users in userlist", NULL);
		else
		{
			h = userlist.first->next;
			a = push(NULL, userlist.first->name, NULL);
			while(1)
			{
				if(!h) break;
				a = push(a, ", ", h->name, NULL);
				h = h->next;
			}
			quote(s->fd, "Users: ", a, NULL);
			free(a);
		}
		return;
	}
	if(!strcmp(arg[0], ".+host") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			quote(s->fd, "Please add bots via .+bot command", NULL);
			return;
		}
		if(!extendhost(arg[2], buf, MAX_LEN))
		{
			quote(s->fd, "Invalid hostname", NULL);
			return;
		}
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.AddHost(h, buf) != -1)
			{
				quote(FD_OWNERS, "Adding host '", buf, "' to user '", arg[1], "'", NULL);
				quote(FD_BOTS, S_ADDHOST, " ", arg[1], " ", buf, NULL);
				ME.RecheckFlags();
				++userlist.SN;
			}
			else quote(s->fd, "Host '", buf, "' exists", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);

		return;
	}
	if(!strcmp(arg[0], ".-host") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			quote(s->fd, "Please remove bots via .-bot command", NULL);
			return;
		}
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			if(userlist.RemoveHost(h, arg[2]) != -1)
			{
				quote(FD_OWNERS, "Removing host '", arg[2], "' from user '", arg[1], "'", NULL);
				quote(FD_BOTS, S_RMHOST, " ", arg[1], " ", buf, NULL);
				ME.RecheckFlags();
				++userlist.SN;
			}
			else quote(s->fd, "Host '", arg[2], "' does not exists", NULL);
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".match") && strlen(arg[1]))
	{
		if(strcasecmp(arg[1], "bot"))
		{
			h = userlist.FindHandle(arg[1]);
			if(h)
			{
				userlist.GetFlags(h, buf);
				quote(s->fd, arg[1], "'s flags: ", buf, NULL);
				quote(s->fd, arg[1], "'s hosts:", NULL);
				for(i=0, n=0; i<MAX_HOSTS; i++)
				{
					if(h->host[i] != NULL)
					{
						sprintf(buf, "[#%d]: ", ++n);
						quote(s->fd, buf, h->host[i], NULL);
					}
				}
				if(!n) quote(s->fd, "No hosts has been found", NULL);
			}
			else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		}
		else
		{
			if(userlist.bots)
			{
				quote(s->fd, "Found following bots (mask/ip/pass):", NULL);
				b = userlist.Bfirst;
				n = 0;
				while(1)
				{
					if(!b) break;
					sprintf(buf, "[#%d]: ", ++n);
					quote(s->fd, buf, b->mask, " ", b->ip, " ", b->pass, NULL);
					b = b->next;
				}
			}
			else quote(s->fd, "No bot entries has been found", NULL);
		}
		return;
	}
	if(!strcmp(arg[0], ".chattr") && strlen(arg[2]))
	{
		if(!strcasecmp(arg[1], "bot"))
		{
			quote(s->fd, "Cannot change bot flags, resetting to 'aofmb'", NULL);
			return;
		}
		h = userlist.FindHandle(arg[1]);
		if(h)
		{
			userlist.ChangeFlags(h, arg[2]);
			userlist.GetFlags(h, buf);
			quote(FD_OWNERS, "Changing flags for '", arg[1], "' to '", buf, "'", NULL);
			quote(FD_BOTS, S_CHATTR, " ", arg[1], " ", arg[2], NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else quote(s->fd, "User '", arg[1], "' does not exist", NULL);
		return;
	}
	if((!strcmp(arg[0], ".+chan") || !strcmp(arg[0], ".join")) && strlen(arg[1]))
	{
		if(arg[1][0] != '#' && arg[1][0] != '+' && arg[1][0] != '&' && arg[1][0] != '!')
		{
			quote(s->fd, "Invalid channel name", NULL);
			return;
		}
		n = ME.AddChannelToList(arg[1], arg[2]);
		if(n == -2)
		{
			quote(FD_OWNERS, "Changing password for channel '", arg[1], "' to '", arg[2], "'", NULL);
			quote(FD_BOTS, S_ADDCHAN, " ", arg[1], " ", arg[2], NULL);
		}
		else if(n > -1)
		{
			quote(FD_OWNERS, "Channel '", arg[1], "' has been added to channel list", NULL);
			quote(FD_BOTS, S_ADDCHAN, " ", arg[1], " ", arg[2], NULL);
			if(strlen(arg[2])) quote(ME.servfd, "JOIN ", arg[1], " ", arg[2], NULL);
			else quote(ME.servfd, "JOIN ", arg[1], NULL);
			ME.chanlist[n].joinsent = 1;
			++userlist.SN;
		}
		else if(n == -1) quote(s->fd, "Channel exists in channel list", NULL);
		else quote(s->fd, "Maximum number of channels joined", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-chan") || !strcmp(arg[0], ".part") && strlen(arg[1]))
	{
		if(ME.RemoveChannelFromList(arg[1]))
		{
			quote(FD_OWNERS, "Channel '", arg[1], "' removed from userlist", NULL);
			quote(FD_BOTS, S_RMCHAN, " ", arg[1], NULL);
			quote(ME.servfd, "PART ", arg[1], " :", config.partreason, NULL);
			++userlist.SN;
		}
		else quote(s->fd, "Channel does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".+bot") && strlen(arg[3]))
	{
		if(!extendhost(arg[1], buf, MAX_LEN))
		{
			quote(s->fd, "Invalid hostname", NULL);
			return;
		}
		if((inet_addr(arg[2]) == INADDR_NONE || !match(arg[2], "*.*.*.*")) && strcmp(arg[2], "-"))
		{
			quote(s->fd, "Invalid IPv4 address", NULL);
			return;
		}
		if(userlist.AddBot(buf, arg[2], arg[3]))
		{
			quote(FD_OWNERS, "Adding new bot ", buf, " / ", arg[2], " / ", arg[3], NULL);
			quote(FD_BOTS, S_ADDBOT, " ", buf, " ", S_UNKNOWN, " ", S_UNKNOWN, NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else quote(s->fd, "Mask '", buf, "' allready appears in userlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-bot") && strlen(arg[1]))
	{
		if(userlist.RemoveBot(arg[1]))
		{
			quote(FD_OWNERS, "Removing bot '", arg[1], "'", NULL);
			quote(FD_BOTS, S_RMBOT, " ", arg[1], NULL);
			ME.RecheckFlags();
			++userlist.SN;
		}
		else quote(s->fd, "Host '", arg[1], "' does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".channels"))
	{
		int i;
		a = push(NULL, ME.chanlist[0].name, NULL);
		if(strlen(ME.chanlist[0].pass)) a = push(a , "(key: ", ME.chanlist[0].pass, ")", NULL);
		for(i=1; i<MAX_CHANNELS; i++)
		{
			if(ME.chanlist[i].name)
			{
				a = push(a, ", ", ME.chanlist[i].name, NULL);
				if(strlen(ME.chanlist[i].pass)) a = push(a , "(key: ", ME.chanlist[i].pass, ")", NULL);
			}
		}
		quote(s->fd, "Channels: ", a, NULL);
		free(a);
		return;
	}
	if(!strcmp(arg[0], ".save"))
	{
		userlist.Save(config.userlist_file);
		quote(FD_OWNERS, "Saving userlist", NULL);
		quote(FD_BOTS, S_ULSAVE, NULL);
		return;
	}
	if(!strcmp(arg[0], ".bots"))
	{
		if(VAR.pl_bots)
		{
			a = NULL;
			for(i=0; i<MAX_CONN; ++i)
				if(sock[i].status & STATUS_REGISTERED && sock[i].status & STATUS_BOT)
					a = push(a, sock[i].name, " ", NULL);

		sprintf(buf, "%d", VAR.pl_bots);
		quote(s->fd, "Bots on-line(", buf, "): ", a, NULL);
		free(a);
		}
		else quote(s->fd, "All bots are down", NULL);
		return;
	}
	if(!strcmp(arg[0], ".owners"))
	{
		a = NULL;
		for(i=0; i<MAX_CONN; ++i)
		{
			if(sock[i].status & STATUS_REGISTERED && sock[i].status & STATUS_OWNER)
				a = push(NULL, sock[i].name, " ", NULL);
		}
		sprintf(buf, "%d", VAR.pl_owners);
		quote(s->fd, "Owners on-line(", buf, "): ", a, NULL);
		if(a) free(a);
		return;
	}

	if(!strcmp(arg[0], ".set"))
	{
		if(!strlen(arg[1]))
		{
			for(i=0; i<VAR.ent ;++i)
			{
				if(VAR.varent[i].i)
				{
					sprintf(buf, "%d", *VAR.varent[i].i);
					quote(s->fd, "-> ", VAR.varent[i].name, " = ", buf, NULL);
				}
			}
		}
		else if(!strlen(arg[2]))
		{
			i = VAR.getvar(arg[1]);
			if(i == -1)	quote(s->fd, "No such variable '", arg[1], "'", NULL);
			else
			{
				sprintf(buf, "%d", *VAR.varent[i].i);
				quote(s->fd, "-> ", VAR.varent[i].name, " = ", buf, NULL);
			}
		}
		else
		{
			i = VAR.setvar(arg[1], arg[2]);
			if(i == -1)	quote(s->fd, "No such variable '", arg[1], "'", NULL);
			else if(i < -1)
			{
				i = i*(-1)-2;
				sprintf(buf, "Value does not bellong to range <%d, %d>", VAR.varent[i].from, VAR.varent[i].to);
				quote(s->fd, buf, NULL);
			}
			else
			{
				sprintf(buf, "%d", *VAR.varent[i].i);
				quote(s->fd, "Variable '", arg[1], "' has been set to ", buf, NULL);
				quote(FD_BOTS, S_SET, " ", arg[1], " ", buf, NULL);
				++userlist.SN;
			}
		}
		return;
	}
	if(!strcmp(arg[0], ".cycle") && strlen(arg[1]))
	{
		if(ME.FindChannelInList(arg[1]) != -1)
		{
			if(ME.FindChannel(arg[1]))
			{
				quote(ME.servfd, "PART ", arg[1], " :", config.cyclereason, NULL);
				ME.Rejoin(arg[1], VAR.CYCLE_DELAY);
			}
			quote(FD_BOTS, S_CYCLE, " ", arg[1], NULL);
			quote(FD_OWNERS, "Doing cycle on ", arg[1], NULL);
		}
		else quote(s->fd, "Invalid channel", NULL);
		return;
	}
	if(!strcmp(arg[0], ".+shit") && strlen(arg[1]))
	{
		if(!extendhost(arg[1], buf, MAX_LEN))
		{
			quote(s->fd, "Invalid mask", NULL);
			return;
		}
		a = srewind(data, 2);
		if(shitlist.Add(buf, a ? a : (char *) "", ""))
  		{
			if(a) quote(FD_OWNERS, "Adding new shit '", buf, " (", a , ")'", NULL);
			else quote(FD_OWNERS, "Adding new shit '", buf, NULL);
  		}
		else quote(s->fd, "Mask exists in shitlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".-shit") && strlen(arg[1]))
	{
		if(shitlist.Remove(arg[1]))
		{
			quote(FD_OWNERS, "Removing host '", arg[1], "' from shitlist", NULL);
		}
		else quote(s->fd, "Mask does not exist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".shits"))
	{
		if(shitlist.ent)
		{
			sprintf(buf, "%d", shitlist.ent);
			quote(s->fd, "Found ", buf, " shit(s)", NULL);
			m = shitlist.first;
			i = 0;
			while(1)
			{
				if(!m) break;
				sprintf(buf, "[#%d]: ", ++i);
				if(strlen(m->info[0])) quote(s->fd, buf, m->mask, " (", m->info[0], ")", NULL);
				else quote(s->fd, buf, m->mask, NULL);
				m = m->next;
			}
		}
		else quote(s->fd, "No masks in shitlist", NULL);
		return;
	}
	if(!strcmp(arg[0], ".invite") && strlen(arg[2]))
	{
		if(ME.FindChannelInList(arg[2]) == -1)
		{
			quote(s->fd, arg[2], " is not in my chanlist", NULL);
			return;
		}
		chan *ch = ME.FindChannel(arg[2]);
		if(ch)
		{
			if(ME.lastminoraction <= NOW && ch->ptr->flags & IS_OP)
			{
				if(!ch->GetUser(arg[1]))
				{
					quote(ME.servfd, "INVITE ", arg[1], " ", arg[2], NULL);
					ME.lastminoraction = NOW + VAR.FRIEND_ACTION_PENALITY;
					quote(FD_OWNERS, "Inviting ", arg[1], " to ", arg[2], NULL);
				}
				else quote(s->fd, "From my point of view you are on ", arg[2], NULL);
			}
			else if(!(ch->ptr->flags & IS_OP)) quote(s->fd, "Strange, I don't have op", NULL);
			else quote(s->fd, "I am too busy, try again in few secs", NULL);
		}
		else
		{
			quote(s->fd, "I am not on ", arg[2], ", retry this request in few secs ;-)", NULL);
			if(ME.lastminoraction <= NOW + 1) quote(FD_BOTS, S_INVITE, " ", arg[2], " ", ME.nick, NULL);
		}
		return;
	}
	if(!strcmp(arg[0], ".help"))
	{
		quote(s->fd, "Avaible commands:", NULL);
		quote(s->fd, ".+user <handle>              .-user <handle>", NULL);
		quote(s->fd, ".+host <handle> <host>       .-host <handle> <host>", NULL);
		quote(s->fd, ".+bot <mask> <dccip> <pass>  .-bot <mask>", NULL);
		quote(s->fd, ".+chan <chan> [key]          .-chan <chan>", NULL);
		quote(s->fd, ".+shit <mask> [reason]       .-shit <mask>", NULL);
		quote(s->fd, ".chattr <handle> <flags>     .match <handle|\"bot\">", NULL);
		quote(s->fd, ".set [var] [value]           .cycle <chan>", NULL);
		quote(s->fd, ".invite <nick> <chan>        .users", NULL);
		quote(s->fd, ".bots                        .owners", NULL);
		quote(s->fd, ".shits                       .bye", NULL);
		quote(s->fd, ".channels                    .save", NULL);
		quote(s->fd, "Supported flags: aofmnd", NULL);
		return;
	}
	if(arg[0][0] == '.')
	{
		quote(s->fd, "What? You need .help?", NULL);
		return;
	}
}
