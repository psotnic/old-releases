/**************************************************
*  Psotnic 0.x.x
*  Copyright 2003 Grzegorz Rusin <pks@irc.pl>
*
*  PRIVATE CODE - DO NOT DISTRIBUTE
*
*/

#include "prots.h"
#include "global-var.h"

dns::dns()
{
	int i;
	resfd = socket(AF_INET, SOCK_DGRAM, 0);

	if(resfd <= 0)
	{
		propaganda();
		printf("[-] Cannot create udp socket (%s)\n", strerror(errno));
		printf("[*] Calling exit(4)\n");
		exit(4);
	}

	res_init();
	if (!_res.nscount)
	{
		printf("[-] No nameservers found\n");
		printf("[*] Calling exit(4)\n");
		exit(4);
	}
    _res.options |= RES_RECURSE | RES_DEFNAMES | RES_DNSRCH;

	for (i=0; i<_res.nscount; i++)
		_res.nsaddr_list[i].sin_family = AF_INET;
}
