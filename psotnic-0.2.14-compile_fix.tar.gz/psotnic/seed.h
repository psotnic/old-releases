/*
 * This file contains magical seeds that will be used during encryption/decryption process.
 * So make sure that you store it in safe place, if you loose it you wont be able to decode
 * crypted files.
 */

#ifndef PSOTNIC_SEED_H
#define PSOTNIC_SEED_H 1

static unsigned char cfg_seed[] = "\x2c\x75\x7d\xe7\xdd\x19\x2c\x81\xb7\xee\x3c\x7f\xfd\xce\x0d\x15";
static unsigned char ul_seed[] = "\x25\x81\xa2\x9d\xa2\xa7\x9e\x60\xcf\x52\x07\x75\xb9\xb1\xfc\xc6";

#endif
