#ifndef PSOTNIC_CONFIG_H
#define PSOTNIC_CONFIG_H 1

#ifndef HAVE_LITTLE_ENDIAN
	#define HAVE_LITTLE_ENDIAN	1
#endif

#ifndef HAVE_IPV6
	#define HAVE_IPV6	1
#endif

#ifndef HAVE_ADNS
	#define HAVE_ADNS	1
#endif

#ifndef HAVE_ADNS_PTHREAD
	#define HAVE_ADNS_PTHREAD	1
#endif

#ifndef HAVE_ANTIPTRACE
	#define HAVE_ANTIPTRACE	1
#endif

#ifndef HAVE_IRC_BACKTRACE
	#define HAVE_IRC_BACKTRACE	1
#endif

#ifndef SVN_REVISION
#	define SVN_REVISION	"205"
#endif


#endif
