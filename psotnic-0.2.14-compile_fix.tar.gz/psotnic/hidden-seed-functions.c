void gen_cfg_seed(unsigned char *out)
{
    int i;
    out[0] = 72;
    out[1] = 17;
    out[2] = 25;
    out[3] = 131;
    out[4] = 185;
    out[5] = 125;
    out[6] = 72;
    out[7] = 229;
    out[8] = 211;
    out[9] = 138;
    out[10] = 88;
    out[11] = 27;
    out[12] = 153;
    out[13] = 170;
    out[14] = 105;
    out[15] = 113;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 100;
    }
}

void gen_ul_seed(unsigned char *out)
{
    int i;
    out[0] = 103;
    out[1] = 195;
    out[2] = 224;
    out[3] = 223;
    out[4] = 224;
    out[5] = 229;
    out[6] = 220;
    out[7] = 34;
    out[8] = 141;
    out[9] = 16;
    out[10] = 69;
    out[11] = 55;
    out[12] = 251;
    out[13] = 243;
    out[14] = 190;
    out[15] = 132;

    for(i=0; i<16; ++i)
    {
        out[i] ^= 66;
    }
}

