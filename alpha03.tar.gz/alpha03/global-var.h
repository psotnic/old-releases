extern unsigned int magic[8];
extern struct _me ME;
