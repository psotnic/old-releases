#include "prots.h"
unsigned int magic[8];

int main()
{
	client ME;
	chan *ch;
	char buf[MAX_LEN], arg[10][MAX_LEN], *a, *b, *c;
	int i, serv;

	precache();

	ME.status = 0;
	serv = DoConnect("127.0.0.1", 6667);
	if(serv) ME.status += STATUS_CONNECTED;
	quote(serv, "NICK bot", NULL);
	quote(serv, "USER bot 8 * :tra la la", NULL);


	while(serv)
	{
			/* xmas clean ups */
			memset(&buf, 0, sizeof(buf));
			for (i=0; i < 10; i++) memset(&arg[i], 0, sizeof(arg[i]));

			/* read one line */
			for (i=0; i<MAX_LEN; i++)
			{
				read(serv, &buf[i], 1);
				if (buf[i] == '\0') break;
				if (buf[i] == '\n')
				{
					buf[i] = '\0';
					break;
				}
				if (buf[i] == ':' && (buf[i-1] == ' ' || i == 0)) i--;
			}
			sscanf(buf, "%s %s %s %s %s %s %s %s %s %s", &arg[0], &arg[1], &arg[2], &arg[3], &arg[4],
														 &arg[5], &arg[6], &arg[7], &arg[8], &arg[9]);
			/* debug */
			if(!strcasecmp(arg[1], "PRIVMSG") && !strcasecmp(arg[3], "!debug"))
			{
				ch = ME.FindChannel(arg[2]);
				printf("### DEBUG ###\n");
				if(ch) ch->DebugDisplay();
			}
			printf("recv[%2d]: ", strlen(buf), buf);
			for (i=0; i<10; i++) printf("%s ", arg[i]);
			printf("\n");

			/* reaction */
			if(!strcasecmp(arg[1], "JOIN"))
			{
				if(!strcmp(ME.mask, arg[0]))
				{
					ch = ME.CreateNewChannel(arg[2]);
					quote(serv, "WHO ", arg[2]);
				}
				else
				{
					ch = ME.FindChannel(arg[2]);
					ch->GotJoin(arg[0], 0);
				}
			}
			else if(!strcasecmp(arg[1], "MODE"))
			{
				ch = ME.FindChannel(arg[2]);
				if(ch)
				{
					a = push(NULL, arg[4], arg[5], arg[6], arg[7], NULL);
					ch->GotMode(arg[3], a, arg[0]);
					free(a);
				}

			}
			else if(!strcasecmp(arg[1], "KICK"))
			{
				if(!strcasecmp(ME.nick, arg[3]))
				{
					ME.RemoveChannel(arg[2]);
					quote(serv, "JOIN ", arg[2]);
				}
				else
				{
					ch = ME.FindChannel(arg[2]);
					ch->GotKick(arg[3], arg[0]);
				}
			}
			else if(!strcasecmp(arg[1], "PART"))
			{
				if(!strcasecmp(ME.mask, arg[0])) ME.RemoveChannel(arg[2]);
				else
				{
					ch = ME.FindChannel(arg[2]);
					ch->GotPart(arg[0]);
				}
			}
			else if(!strcasecmp(arg[1], "352"))
			{
				ch = ME.FindChannel(arg[3]);
				ch->GotJoin(arg[7], arg[4], arg[5], match(arg[8], "*@*"));
			}
			else if(!strcasecmp(arg[1], "315")) ME.FindChannel(arg[3])->DebugDisplay();
			else if(!strcasecmp(arg[0], "PING")) quote(serv, "PONG :", arg[1]);
			else if(!strcasecmp(arg[1], "433")) quote(serv, "NICK ", arg[3], "_", NULL);
			else if(!strcasecmp(arg[1], "001") && !(ME.status & STATUS_REGISTERED))
			{
				ME.status += STATUS_REGISTERED;
				maskstrip(arg[9], ME.nick, ME.ident, ME.host);
				mem_strcpy(ME.mask, arg[9]);
				quote(serv, "join #piwo", NULL);
			}
	}
	ME.status = 0;
	return 0;
}

